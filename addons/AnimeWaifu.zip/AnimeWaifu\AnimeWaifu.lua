-- Anime Waifu
-- Hitmarker + waifu image + sound whenever you land critical damage.

local ADDON  = "AnimeWaifu"
local EVT_NS = ADDON .. "_Events"
local wm     = WINDOW_MANAGER

local WAIFU_TEX     = "AnimeWaifu/waifu.dds"
local HITMARKER_TEX = "AnimeWaifu/hitmarker.dds"
local BASE_SIZE     = 256   -- base waifu image size in px at scale 1.0
local MIN_SCALE     = 0.25
local MAX_SCALE     = 4.0

-- ESO cannot import custom audio, so these are the game's own built-in sounds.
local SOUND_CHOICES = {
    "ACHIEVEMENT_AWARDED",
    "DUEL_WON",
    "JUSTICE_NOW_KOS",
    "DEATH_RECAP_KILLING_BLOW_SHOWN",
    "LEVEL_UP",
    "ABILITY_MORPH_PURCHASE",
    "GROUP_FINDER_ALERT",
}

local defaults = {
    enabled    = true,
    waifuScale = 1.0,
    posLeft    = nil,      -- nil = centered (default position)
    posTop     = nil,
    offsetY    = -40,      -- vertical offset used only while centered
    throttleMs = 500,
    soundName  = "ACHIEVEMENT_AWARDED",
    showWaifu  = true,
    showText   = true,
    showMarker = true,
    preview    = false,
    text       = "Shoyru is the best!",
    textSize   = 42,
    textColor  = { 1, 0.55, 0.8, 1 },
}

local sv
local lastTrigger = 0
local settingsPanel

-- controls / animations
local waifuTLW, waifuTex, waifuLabel, previewHint, waifuTimeline
local markerTLW, markerTex, markerTimeline

local function chat(msg)
    d("|cFF99CC[Anime Waifu]|r " .. tostring(msg))
end

local function clampScale(s)
    if s < MIN_SCALE then return MIN_SCALE end
    if s > MAX_SCALE then return MAX_SCALE end
    return s
end

-- ----------------------------------------------------------------------------
-- Layout
-- ----------------------------------------------------------------------------
local function ApplyVisual()
    local size = BASE_SIZE * (sv.waifuScale or 1.0)
    waifuTLW:SetDimensions(size, size)
    waifuTex:SetDimensions(size, size)
    waifuTLW:ClearAnchors()
    if sv.posLeft then
        waifuTLW:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, sv.posLeft, sv.posTop)
    else
        waifuTLW:SetAnchor(CENTER, GuiRoot, CENTER, 0, sv.offsetY or -40)
    end
end

local function ApplyText()
    waifuLabel:SetFont(("$(BOLD_FONT)|%d|soft-shadow-thick"):format(sv.textSize or 42))
    waifuLabel:SetText(sv.text or defaults.text)
    local c = sv.textColor or defaults.textColor
    waifuLabel:SetColor(c[1], c[2], c[3], c[4] or 1)
end

-- Preview/position mode: image stays on screen, draggable + scroll-to-resize.
local function ApplyPreview()
    if sv.preview then
        waifuTimeline:Stop()
        waifuTex:SetHidden(false)
        waifuLabel:SetHidden(false)
        previewHint:SetHidden(false)
        waifuTLW:SetMovable(true)
        waifuTLW:SetMouseEnabled(true)
        waifuTLW:SetAlpha(1)
    else
        previewHint:SetHidden(true)
        waifuTLW:SetMovable(false)
        waifuTLW:SetMouseEnabled(false)
        waifuTLW:SetAlpha(0)
    end
end

-- ----------------------------------------------------------------------------
-- UI
-- ----------------------------------------------------------------------------
local function BuildUI()
    waifuTLW = wm:CreateTopLevelWindow(ADDON .. "_Waifu")
    waifuTLW:SetDrawTier(DT_HIGH)
    waifuTLW:SetDrawLayer(DL_OVERLAY)
    waifuTLW:SetClampedToScreen(true)
    waifuTLW:SetMouseEnabled(false)
    waifuTLW:SetAlpha(0)

    waifuTex = wm:CreateControl(ADDON .. "_WaifuTex", waifuTLW, CT_TEXTURE)
    waifuTex:SetTexture(WAIFU_TEX)
    waifuTex:SetAnchor(CENTER, waifuTLW, CENTER, 0, 0)

    waifuLabel = wm:CreateControl(ADDON .. "_WaifuText", waifuTLW, CT_LABEL)
    waifuLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    waifuLabel:SetAnchor(TOP, waifuTLW, BOTTOM, 0, 6)

    previewHint = wm:CreateControl(ADDON .. "_Hint", waifuTLW, CT_LABEL)
    previewHint:SetFont("$(MEDIUM_FONT)|18|soft-shadow-thin")
    previewHint:SetColor(1, 1, 0.4, 1)
    previewHint:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    previewHint:SetText("Anime Waifu - drag to move, scroll to resize")
    previewHint:SetAnchor(BOTTOM, waifuTLW, TOP, 0, -6)
    previewHint:SetHidden(true)

    -- drag-to-move: remember where it was dropped
    waifuTLW:SetHandler("OnMoveStop", function()
        sv.posLeft, sv.posTop = waifuTLW:GetLeft(), waifuTLW:GetTop()
    end)
    -- scroll-to-resize while in preview mode
    waifuTLW:SetHandler("OnMouseWheel", function(_, delta)
        sv.waifuScale = clampScale((sv.waifuScale or 1.0) + delta * 0.05)
        ApplyVisual()
    end)

    -- Hitmarker (centered on the reticle)
    markerTLW = wm:CreateTopLevelWindow(ADDON .. "_Marker")
    markerTLW:SetDimensions(96, 96)
    markerTLW:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0)
    markerTLW:SetDrawTier(DT_HIGH)
    markerTLW:SetDrawLayer(DL_OVERLAY)
    markerTLW:SetMouseEnabled(false)
    markerTLW:SetAlpha(0)

    markerTex = wm:CreateControl(ADDON .. "_MarkerTex", markerTLW, CT_TEXTURE)
    markerTex:SetTexture(HITMARKER_TEX)
    markerTex:SetDimensions(64, 64)
    markerTex:SetAnchor(CENTER, markerTLW, CENTER, 0, 0)
end

local function BuildAnims()
    waifuTimeline = ANIMATION_MANAGER:CreateTimeline()
    local aIn = waifuTimeline:InsertAnimation(ANIMATION_ALPHA, waifuTLW, 0)
    aIn:SetAlphaValues(0, 1); aIn:SetDuration(120)
    local sc = waifuTimeline:InsertAnimation(ANIMATION_SCALE, waifuTex, 0)
    sc:SetScaleValues(1.3, 1.0); sc:SetDuration(200)
    local aOut = waifuTimeline:InsertAnimation(ANIMATION_ALPHA, waifuTLW, 950)
    aOut:SetAlphaValues(1, 0); aOut:SetDuration(600)

    markerTimeline = ANIMATION_MANAGER:CreateTimeline()
    local mIn = markerTimeline:InsertAnimation(ANIMATION_ALPHA, markerTLW, 0)
    mIn:SetAlphaValues(0, 1); mIn:SetDuration(40)
    local mSc = markerTimeline:InsertAnimation(ANIMATION_SCALE, markerTLW, 0)
    mSc:SetScaleValues(1.6, 1.0); mSc:SetDuration(130)
    local mOut = markerTimeline:InsertAnimation(ANIMATION_ALPHA, markerTLW, 150)
    mOut:SetAlphaValues(1, 0); mOut:SetDuration(190)
end

-- ----------------------------------------------------------------------------
-- Trigger
-- ----------------------------------------------------------------------------
local function Trigger(force)
    if not force then
        if not sv.enabled then return end
        local now = GetGameTimeMilliseconds()
        if now - lastTrigger < sv.throttleMs then return end
        lastTrigger = now
    end

    if sv.showMarker then
        markerTimeline:Stop()
        markerTLW:SetAlpha(0)
        markerTimeline:PlayFromStart()
    end

    -- In preview mode the image is already pinned on screen, so don't fade it.
    if not sv.preview and (sv.showWaifu or sv.showText) then
        waifuTex:SetHidden(not sv.showWaifu)
        waifuLabel:SetHidden(not sv.showText)
        waifuTimeline:Stop()
        waifuTLW:SetAlpha(0)
        waifuTimeline:PlayFromStart()
    end

    local id = SOUNDS[sv.soundName]
    if id then PlaySound(id) end
end

-- ----------------------------------------------------------------------------
-- Combat event: player critical damage only (enforced via event filters)
-- ----------------------------------------------------------------------------
local function OnCombatEvent()
    Trigger(false)
end

local function RegisterCombat()
    EVENT_MANAGER:RegisterForEvent(EVT_NS, EVENT_COMBAT_EVENT, OnCombatEvent)
    EVENT_MANAGER:AddFilterForEvent(EVT_NS, EVENT_COMBAT_EVENT,
        REGISTER_FILTER_COMBAT_RESULT, ACTION_RESULT_CRITICAL_DAMAGE,
        REGISTER_FILTER_SOURCE_COMBAT_UNIT_TYPE, COMBAT_UNIT_TYPE_PLAYER,
        REGISTER_FILTER_IS_ERROR, false)
end

-- ----------------------------------------------------------------------------
-- Settings panel (LibAddonMenu-2.0)
-- ----------------------------------------------------------------------------
local function BuildSettings()
    local LAM = LibAddonMenu2
    if not LAM then return end

    local panelData = {
        type                = "panel",
        name                = "Anime Waifu",
        displayName         = "|cFF99CCAnime Waifu|r",
        author              = "Shoyru",
        version             = "1.0",
        registerForRefresh  = true,
        registerForDefaults = true,
    }
    settingsPanel = LAM:RegisterAddonPanel(ADDON .. "Panel", panelData)

    local opts = {
        {
            type = "checkbox", name = "Enabled",
            tooltip = "Master on/off switch.",
            getFunc = function() return sv.enabled end,
            setFunc = function(v) sv.enabled = v end,
            default = defaults.enabled,
        },
        {
            type = "button", name = "Preview Effect",
            tooltip = "Fire the full effect once to see it.",
            func = function() Trigger(true) end,
        },
        {
            type = "checkbox", name = "Position mode",
            tooltip = "Pins the image on screen so you can DRAG it to move and " ..
                      "SCROLL the mouse wheel over it to resize. Turn off for normal play.",
            getFunc = function() return sv.preview end,
            setFunc = function(v) sv.preview = v; ApplyPreview() end,
            default = defaults.preview,
        },

        { type = "header", name = "What shows" },
        {
            type = "checkbox", name = "Show image",
            getFunc = function() return sv.showWaifu end,
            setFunc = function(v) sv.showWaifu = v end,
            default = defaults.showWaifu,
        },
        {
            type = "checkbox", name = "Show text",
            getFunc = function() return sv.showText end,
            setFunc = function(v) sv.showText = v end,
            default = defaults.showText,
        },
        {
            type = "checkbox", name = "Show hitmarker",
            getFunc = function() return sv.showMarker end,
            setFunc = function(v) sv.showMarker = v end,
            default = defaults.showMarker,
        },

        { type = "header", name = "Text" },
        {
            type = "editbox", name = "Text",
            getFunc = function() return sv.text end,
            setFunc = function(v) sv.text = (v ~= "" and v) or defaults.text; ApplyText() end,
            default = defaults.text,
        },
        {
            type = "slider", name = "Text size", min = 18, max = 96, step = 2,
            getFunc = function() return sv.textSize end,
            setFunc = function(v) sv.textSize = v; ApplyText() end,
            default = defaults.textSize,
        },
        {
            type = "colorpicker", name = "Text color",
            getFunc = function()
                local c = sv.textColor; return c[1], c[2], c[3], c[4] or 1
            end,
            setFunc = function(r, g, b, a) sv.textColor = { r, g, b, a }; ApplyText() end,
        },

        { type = "header", name = "Sound & behavior" },
        {
            type = "dropdown", name = "Sound",
            tooltip = "Built-in ESO sound played on crit (custom audio can't be imported).",
            choices = SOUND_CHOICES,
            getFunc = function() return sv.soundName end,
            setFunc = function(v)
                sv.soundName = v
                local id = SOUNDS[v]; if id then PlaySound(id) end
            end,
            default = defaults.soundName,
        },
        {
            type = "slider", name = "Throttle (seconds)", min = 0, max = 5, step = 1,
            tooltip = "Minimum gap between triggers so rapid crits don't spam. " ..
                      "Use /waifu throttle 0.5 for finer values.",
            getFunc = function() return math.floor((sv.throttleMs or 0) / 1000 + 0.5) end,
            setFunc = function(v) sv.throttleMs = v * 1000 end,
            default = 1,
        },
    }

    LAM:RegisterOptionControls(ADDON .. "Panel", opts)
end

-- ----------------------------------------------------------------------------
-- Slash command
-- ----------------------------------------------------------------------------
local function HandleSlash(input)
    input = zo_strlower(zo_strtrim(input or ""))
    local cmd, rest = input:match("^(%S*)%s*(.-)$")

    if cmd == "test" then
        Trigger(true)
    elseif cmd == "on" then
        sv.enabled = true; chat("enabled")
    elseif cmd == "off" then
        sv.enabled = false; chat("disabled")
    elseif cmd == "preview" or cmd == "move" then
        sv.preview = not sv.preview; ApplyPreview()
        chat("position mode " .. (sv.preview and "ON - drag/scroll the image" or "OFF"))
    elseif cmd == "throttle" then
        local n = tonumber(rest)
        if n and n >= 0 then sv.throttleMs = math.floor(n * 1000); chat("throttle = " .. n .. "s")
        else chat("usage: /waifu throttle 0.5") end
    elseif cmd == "" or cmd == "settings" or cmd == "config" then
        if LibAddonMenu2 and settingsPanel then
            LibAddonMenu2:OpenToPanel(settingsPanel)
        else
            chat("settings unavailable")
        end
    else
        chat("commands: /waifu (settings), test, preview, on, off, throttle <sec>")
    end
end

-- ----------------------------------------------------------------------------
-- Load
-- ----------------------------------------------------------------------------
local function OnAddOnLoaded(_, name)
    if name ~= ADDON then return end
    EVENT_MANAGER:UnregisterForEvent(EVT_NS, EVENT_ADD_ON_LOADED)

    -- v2: re-applies defaults once (early dev build defaulted the text to "Waifu!")
    sv = ZO_SavedVars:NewAccountWide("AnimeWaifuSavedVariables", 2, nil, defaults)

    BuildUI()
    BuildAnims()
    ApplyVisual()
    ApplyText()
    ApplyPreview()
    RegisterCombat()
    BuildSettings()

    SLASH_COMMANDS["/waifu"]      = HandleSlash
    SLASH_COMMANDS["/animewaifu"] = HandleSlash

    chat("loaded. /waifu opens settings, /waifu preview to position the image.")
end

EVENT_MANAGER:RegisterForEvent(EVT_NS, EVENT_ADD_ON_LOADED, OnAddOnLoaded)
