DeepFissureAlert = {}
DeepFissureAlert.name = "DeepFissureAlert"
DeepFissureAlert.version = "1.0"

local ADDON_NAME = DeepFissureAlert.name
local COMBAT_EVENT_NAME = ADDON_NAME .. "_Combat"
local TIMER_NAME = ADDON_NAME .. "_Timer"
local LOAD_EVENT_NAME = ADDON_NAME .. "_Loaded"

local SHALK_1_ID = 94424   -- First shalk landing triggers the alert
local SHALK_2_ID = 181331  -- Second shalk landing auto-dismisses
local SHALK_2_DELAY_MS = 6000
local BURST_WARNING_MS = 2000  -- switch to "BURST INCOMING" this many ms before shalk 2 lands

-- Sound options available in the settings dropdowns.
-- key maps to the SOUNDS table; pcall-guarded so unknown keys fail silently.
local SOUND_OPTIONS = {
    { label = "Ability Activated",  key = "ABILITY_ACTIVATED" },
    { label = "Major Buff",         key = "ABILITY_MAJOR_BUFF" },
    { label = "Killing Blow",       key = "DEATH_RECAP_KILLING_BLOW_SHOWN" },
    { label = "Quickslot Use",      key = "QUICKSLOT_USE" },
    { label = "Achievement",        key = "ACHIEVEMENT_AWARDED" },
    { label = "Skill Purchased",    key = "ABILITY_MORPH_PURCHASED" },
    { label = "Level Up",           key = "LEVELUP_LEVEL_GAINED" },
    { label = "Alert Ping",         key = "GENERAL_ALERT_ERROR" },
    { label = "Zone Discovered",    key = "VASHARI_ZONE_DISCOVERED" },
    { label = "Raid Score",         key = "RAID_TRIAL_SCORE_TIER_ACHIEVED" },
}

local SOUND_LABEL_TO_KEY = {}
local SOUND_CHOICES = {}
for _, opt in ipairs(SOUND_OPTIONS) do
    SOUND_LABEL_TO_KEY[opt.label] = opt.key
    table.insert(SOUND_CHOICES, opt.label)
end

local defaults = {
    enabled = true,
    soundAlert = true,
    alertSoundLabel = "Ability Activated",
    burstSoundLabel = "Killing Blow",
    offsetX = 0,
    offsetY = -220,
    width = 420,
    height = 115,
    scale = 1.0,
    showTestAlert = false,
    debugMode = false,
}

local alertWindow = nil
local alertLabel = nil
local casterLabel = nil
local countdownLabel = nil
local timerBarContainer = nil
local timerBarFill = nil

local alertActive = false
local shalk2EndTimeMs = 0
local burstWarningSounded = false

local function GetNowMs()
    return GetFrameTimeMilliseconds()
end

local function GetBarWidth()
    local sv = DeepFissureAlert.savedVariables
    return (sv and sv.width or 420) - 40
end

local function PlaySoundByLabel(label)
    local key = SOUND_LABEL_TO_KEY[label]
    if not key then return end
    local ok, sound = pcall(function() return SOUNDS[key] end)
    if ok and sound then
        PlaySound(sound)
    end
end

local function ApplyAlertLayout()
    if not alertWindow or not DeepFissureAlert.savedVariables then return end
    local sv = DeepFissureAlert.savedVariables
    alertWindow:ClearAnchors()
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, sv.offsetX or 0, sv.offsetY or -220)
    alertWindow:SetDimensions(sv.width or 420, sv.height or 115)
    alertWindow:SetScale(sv.scale or 1.0)
end

local function HideAlert()
    alertActive = false
    shalk2EndTimeMs = 0
    alertWindow:SetHidden(true)
    EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
end

local function IsHitResult(result)
    return result == ACTION_RESULT_DAMAGE
        or result == ACTION_RESULT_CRITICAL_DAMAGE
        or result == ACTION_RESULT_DAMAGE_SHIELDED
        or result == ACTION_RESULT_BLOCKED_DAMAGE
end

local function UpdateAlert()
    if not alertActive then return end

    local now = GetNowMs()
    local remaining = shalk2EndTimeMs - now

    if remaining <= 0 then
        HideAlert()
        return
    end

    if remaining <= BURST_WARNING_MS then
        alertLabel:SetText("DEEP FISSURE — BURST INCOMING!")
        alertLabel:SetColor(1, 0.05, 0.05, 1)
        if not burstWarningSounded then
            burstWarningSounded = true
            local sv = DeepFissureAlert.savedVariables
            if sv and sv.soundAlert then
                PlaySoundByLabel(sv.burstSoundLabel)
            end
        end
    else
        alertLabel:SetText("DEEP FISSURE — 2nd Shalk incoming!")
        alertLabel:SetColor(1, 0.5, 0.1, 1)
    end

    countdownLabel:SetText(string.format("%.1f s", remaining / 1000))

    local barWidth = GetBarWidth()
    local pct = remaining / SHALK_2_DELAY_MS
    timerBarFill:SetWidth(math.max(0, barWidth * pct))

    local r = math.min(1, 2 * (1 - pct))
    local g = math.min(1, 2 * pct)
    timerBarFill:SetCenterColor(r, g, 0, 1)
end

local function TriggerAlert(sourceName)
    alertActive = true
    shalk2EndTimeMs = GetNowMs() + SHALK_2_DELAY_MS
    burstWarningSounded = false

    alertLabel:SetText("DEEP FISSURE — 2nd Shalk incoming!")
    alertLabel:SetColor(1, 0.5, 0.1, 1)
    local cleanName = sourceName and sourceName:match("^(.-)%^") or sourceName
    casterLabel:SetText("Caster: " .. (cleanName ~= "" and cleanName or "Unknown"))
    countdownLabel:SetText("6.0 s")

    local barWidth = GetBarWidth()
    timerBarContainer:SetWidth(barWidth)
    timerBarFill:SetWidth(barWidth)
    timerBarFill:SetCenterColor(0, 1, 0, 1)

    alertWindow:SetHidden(false)

    local sv = DeepFissureAlert.savedVariables
    if sv and sv.soundAlert then
        PlaySoundByLabel(sv.alertSoundLabel)
    end

    EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    EVENT_MANAGER:RegisterForUpdate(TIMER_NAME, 100, UpdateAlert)
end

local function OnCombatEvent(
    eventCode, result, isError,
    abilityName, abilityGraphic, abilityActionSlotType,
    sourceName, sourceType,
    targetName, targetType,
    hitValue, powerType, damageType, log,
    sourceUnitId, targetUnitId, abilityId, overflow
)
    if not DeepFissureAlert.savedVariables or not DeepFissureAlert.savedVariables.enabled then
        return
    end

    if isError then return end

    if DeepFissureAlert.savedVariables.debugMode and IsHitResult(result) then
        CHAT_SYSTEM:AddMessage(string.format("[DFA] id=%d result=%d src=%s ability=%s", abilityId, result, tostring(sourceName), tostring(abilityName)))
    end

    if abilityId == SHALK_2_ID and alertActive then
        HideAlert()
        return
    end

    if abilityId ~= SHALK_1_ID then return end
    if not IsHitResult(result) then return end

    TriggerAlert(sourceName)
end

local function CreateUI()
    alertWindow = WINDOW_MANAGER:CreateTopLevelWindow(ADDON_NAME .. "_Window")
    alertWindow:SetDimensions(420, 115)
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, 0, -220)
    alertWindow:SetMovable(false)
    alertWindow:SetMouseEnabled(false)
    alertWindow:SetHidden(true)
    alertWindow:SetDrawTier(DT_HIGH)
    alertWindow:SetDrawLayer(DL_OVERLAY)

    alertWindow:SetHandler("OnMoveStop", function()
        if not DeepFissureAlert.savedVariables then return end
        local _, _, _, offsetX, offsetY = alertWindow:GetAnchor(0)
        DeepFissureAlert.savedVariables.offsetX = offsetX
        DeepFissureAlert.savedVariables.offsetY = offsetY
    end)

    local bg = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_BACKDROP)
    bg:SetAnchorFill(alertWindow)
    bg:SetCenterColor(0, 0, 0, 0.78)
    bg:SetEdgeColor(0.9, 0.2, 0.05, 1)
    bg:SetEdgeTexture(nil, 2, 2, 2, 0)

    alertLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    alertLabel:SetFont("ZoFontWinH2")
    alertLabel:SetColor(1, 0.5, 0.1, 1)
    alertLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    alertLabel:SetAnchor(TOP, alertWindow, TOP, 0, 8)
    alertLabel:SetWidth(420)
    alertLabel:SetText("DEEP FISSURE — 2nd Shalk incoming!")

    casterLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    casterLabel:SetFont("ZoFontGame")
    casterLabel:SetColor(1, 0.85, 0.2, 1)
    casterLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    casterLabel:SetAnchor(TOP, alertLabel, BOTTOM, 0, 4)
    casterLabel:SetWidth(420)
    casterLabel:SetText("Caster: Unknown")

    countdownLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    countdownLabel:SetFont("ZoFontWinH3")
    countdownLabel:SetColor(1, 1, 0.2, 1)
    countdownLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    countdownLabel:SetAnchor(TOP, casterLabel, BOTTOM, 0, 4)
    countdownLabel:SetWidth(420)
    countdownLabel:SetText("6.0 s")

    timerBarContainer = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_BACKDROP)
    timerBarContainer:SetCenterColor(0.15, 0.15, 0.15, 0.9)
    timerBarContainer:SetEdgeColor(0.05, 0.05, 0.05, 1)
    timerBarContainer:SetEdgeTexture(nil, 1, 1, 1, 0)
    timerBarContainer:SetDimensions(380, 12)
    timerBarContainer:SetAnchor(BOTTOM, alertWindow, BOTTOM, 0, -8)

    timerBarFill = WINDOW_MANAGER:CreateControl(nil, timerBarContainer, CT_BACKDROP)
    timerBarFill:SetCenterColor(0, 1, 0, 1)
    timerBarFill:SetEdgeColor(0, 0, 0, 0)
    timerBarFill:SetEdgeTexture(nil, 1, 1, 1, 0)
    timerBarFill:SetHeight(12)
    timerBarFill:SetAnchor(LEFT, timerBarContainer, LEFT, 0, 0)
    timerBarFill:SetWidth(380)
end

function DeepFissureAlert:CreateSettings()
    local LAM = LibAddonMenu2
    if not LAM then return end

    local panelData = {
        type = "panel",
        name = "Deep Fissure Alert",
        displayName = "Deep Fissure Alert",
        author = "Lebiez",
        version = DeepFissureAlert.version,
        registerForRefresh = true,
        registerForDefaults = true,
    }

    LAM:RegisterAddonPanel(ADDON_NAME .. "Options", panelData)

    local optionsTable = {
        -- General
        {
            type = "checkbox",
            name = "Activate Addon",
            tooltip = "Enable or disable the Deep Fissure alert.",
            getFunc = function() return DeepFissureAlert.savedVariables.enabled end,
            setFunc = function(value)
                DeepFissureAlert.savedVariables.enabled = value
                if not value then HideAlert() end
            end,
            default = defaults.enabled,
        },
        {
            type = "checkbox",
            name = "Play sounds",
            tooltip = "Master toggle for all sounds. Turn off to silence the addon completely.",
            getFunc = function() return DeepFissureAlert.savedVariables.soundAlert end,
            setFunc = function(value) DeepFissureAlert.savedVariables.soundAlert = value end,
            default = defaults.soundAlert,
        },
        {
            type = "checkbox",
            name = "Debug mode",
            tooltip = "Prints every incoming hit's ability ID and name to chat. Use this to verify ability IDs — get hit by an ability, then check chat for its ID.",
            getFunc = function() return DeepFissureAlert.savedVariables.debugMode end,
            setFunc = function(value) DeepFissureAlert.savedVariables.debugMode = value end,
            default = defaults.debugMode,
        },

        -- Sounds
        {
            type = "header",
            name = "Sounds",
        },
        {
            type = "dropdown",
            name = "Initial alert sound",
            tooltip = "Plays when the 1st shalk lands on you or a group member.",
            choices = SOUND_CHOICES,
            getFunc = function() return DeepFissureAlert.savedVariables.alertSoundLabel end,
            setFunc = function(value) DeepFissureAlert.savedVariables.alertSoundLabel = value end,
            default = defaults.alertSoundLabel,
        },
        {
            type = "button",
            name = "Preview initial sound",
            func = function()
                PlaySoundByLabel(DeepFissureAlert.savedVariables.alertSoundLabel)
            end,
        },
        {
            type = "dropdown",
            name = "Burst warning sound",
            tooltip = "Plays ~2 seconds before the 2nd shalk lands.",
            choices = SOUND_CHOICES,
            getFunc = function() return DeepFissureAlert.savedVariables.burstSoundLabel end,
            setFunc = function(value) DeepFissureAlert.savedVariables.burstSoundLabel = value end,
            default = defaults.burstSoundLabel,
        },
        {
            type = "button",
            name = "Preview burst sound",
            func = function()
                PlaySoundByLabel(DeepFissureAlert.savedVariables.burstSoundLabel)
            end,
        },
        {
            type = "button",
            name = "Preview full alert sequence",
            tooltip = "Simulates a Deep Fissure hit so you can see and hear the full countdown.",
            func = function()
                TriggerAlert("EnemyWarden")
            end,
        },

        -- Layout
        {
            type = "header",
            name = "Alert Layout",
        },
        {
            type = "checkbox",
            name = "Show test alert",
            tooltip = "Pin the alert window on screen. Drag it to your preferred position — location saves automatically on release.",
            getFunc = function() return DeepFissureAlert.savedVariables.showTestAlert end,
            setFunc = function(value)
                DeepFissureAlert.savedVariables.showTestAlert = value
                if value then
                    alertWindow:SetMovable(true)
                    alertWindow:SetMouseEnabled(true)
                    alertLabel:SetText("DEEP FISSURE — 2nd Shalk incoming!")
                    alertLabel:SetColor(1, 0.5, 0.1, 1)
                    casterLabel:SetText("Caster: EnemyWarden")
                    countdownLabel:SetText("3.5 s")
                    timerBarFill:SetWidth(GetBarWidth() * 0.58)
                    timerBarFill:SetCenterColor(1, 0.84, 0, 1)
                    alertWindow:SetHidden(false)
                else
                    alertWindow:SetMovable(false)
                    alertWindow:SetMouseEnabled(false)
                    if not alertActive then alertWindow:SetHidden(true) end
                end
            end,
            default = defaults.showTestAlert,
        },
        {
            type = "slider",
            name = "Horizontal position",
            min = -1000, max = 1000, step = 5,
            getFunc = function() return DeepFissureAlert.savedVariables.offsetX end,
            setFunc = function(v)
                DeepFissureAlert.savedVariables.offsetX = v
                ApplyAlertLayout()
            end,
            default = defaults.offsetX,
        },
        {
            type = "slider",
            name = "Vertical position",
            min = -1000, max = 1000, step = 5,
            getFunc = function() return DeepFissureAlert.savedVariables.offsetY end,
            setFunc = function(v)
                DeepFissureAlert.savedVariables.offsetY = v
                ApplyAlertLayout()
            end,
            default = defaults.offsetY,
        },
        {
            type = "slider",
            name = "Alert width",
            min = 200, max = 800, step = 10,
            getFunc = function() return DeepFissureAlert.savedVariables.width end,
            setFunc = function(v)
                DeepFissureAlert.savedVariables.width = v
                ApplyAlertLayout()
            end,
            default = defaults.width,
        },
        {
            type = "slider",
            name = "Alert scale",
            min = 50, max = 200, step = 5,
            getFunc = function()
                return math.floor((DeepFissureAlert.savedVariables.scale or 1.0) * 100)
            end,
            setFunc = function(v)
                DeepFissureAlert.savedVariables.scale = v / 100
                ApplyAlertLayout()
            end,
            default = defaults.scale * 100,
        },
        {
            type = "button",
            name = "Reset layout",
            tooltip = "Restore default alert position and size.",
            func = function()
                local sv = DeepFissureAlert.savedVariables
                sv.offsetX = defaults.offsetX
                sv.offsetY = defaults.offsetY
                sv.width = defaults.width
                sv.height = defaults.height
                sv.scale = defaults.scale
                sv.showTestAlert = defaults.showTestAlert
                ApplyAlertLayout()
                if not alertActive then alertWindow:SetHidden(true) end
            end,
            warning = "This will reset alert layout settings.",
        },
    }

    LAM:RegisterOptionControls(ADDON_NAME .. "Options", optionsTable)
end

local function OnAddonLoaded(event, addonName)
    if addonName ~= ADDON_NAME then return end
    EVENT_MANAGER:UnregisterForEvent(LOAD_EVENT_NAME, EVENT_ADD_ON_LOADED)

    DeepFissureAlert.savedVariables = ZO_SavedVars:NewAccountWide(
        "DeepFissureAlertSavedVars",
        1,
        nil,
        defaults
    )

    CreateUI()
    ApplyAlertLayout()
    DeepFissureAlert:CreateSettings()

    -- No unit tag filter: we want events for self AND all group members
    EVENT_MANAGER:RegisterForEvent(COMBAT_EVENT_NAME, EVENT_COMBAT_EVENT, OnCombatEvent)
end

EVENT_MANAGER:RegisterForEvent(LOAD_EVENT_NAME, EVENT_ADD_ON_LOADED, OnAddonLoaded)
