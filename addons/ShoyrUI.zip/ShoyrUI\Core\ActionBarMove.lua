-- ShoyrUI :: Core/ActionBarMove.lua
-- REPOSITION ESO's NATIVE action bar (potion + abilities + ultimate), treated like a frame in the
-- UI Layout module. We don't rebuild or scale it — we just re-anchor the real ZO_ActionBar1 so all
-- its behavior (cooldowns, procs, ult, key activation) is kept. Works in BOTH UIs (the action bar
-- is native in both); managed only after the user unlocks/drags (otherwise fully native).
-- A draggable holder positions it while unlocked; locked, the holder is click-through so
-- the buttons work. Default position = wherever ESO natively has the bar (captured on first manage,
-- so no jump). ESO re-anchors the bar on scene/combat changes, so we re-assert on those events.
-- "Base game" (or Reset) restores ESO's original anchor.

ShoyrUI = ShoyrUI or {}
local AB = {}
ShoyrUI.ActionBar = AB

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style

-- x/y start nil = "not moved yet" → we leave the bar fully native until the user drags it (or
-- unlocks to edit). Reposition only — no scaling.
AB.DEFAULTS = { locked = true }

local sv = nil
local holder = nil
local origAnchor = nil     -- ESO's original ZO_ActionBar1 anchor, cached once for restore
local touched = false      -- have we ever re-anchored the native bar? (avoid touching it otherwise)

local function Bar() return ZO_ActionBar1 end

local function CacheOrig()
    if origAnchor then return end
    local bar = Bar()
    if not bar then return end
    local ok, point, relTo, relPoint, ox, oy = bar:GetAnchor(0)
    if ok then origAnchor = { point = point, relTo = relTo, relPoint = relPoint, ox = ox, oy = oy } end
end

local function BuildHolder()
    if holder then return end
    holder = WM:CreateTopLevelWindow("ShoyrUI_ActionBarHolder")
    holder:SetClampedToScreen(true)
    holder:SetDrawTier(DT_HIGH)             -- sit above the bar so it captures the drag when editing
    holder:SetDimensions(520, 70)          -- approx bar footprint; just the drag hit-area
    holder:SetHandler("OnMoveStop", function()
        -- Snap to the grid (if on), then save the holder's bottom-centre offset from GuiRoot's.
        local snap = ShoyrUI.Grid and ShoyrUI.Grid.Snap or function(v) return v end
        sv.x = (snap(holder:GetLeft()) + holder:GetWidth() / 2) - GuiRoot:GetWidth() / 2
        sv.y = snap(holder:GetBottom()) - GuiRoot:GetHeight()
        AB.Apply()
        -- Moving the bar shifts the timer region, so the push-up must re-cascade from the new spot.
        if ShoyrUI.DurationReminder and ShoyrUI.DurationReminder.RestorePush then
            ShoyrUI.DurationReminder.RestorePush()
        end
    end)
    -- Shared edit affordance (same blue frame + hint as trackers/unit frames), shown only while
    -- unlocked. The action bar only moves (no resize), so the hint says just "drag to move".
    holder.edit = Style.CreateEditFrame(holder, "Action bar \226\128\148 drag to move")
end

-- Restore ESO's original anchor + scale (Base game, or the feature turned off).
local function RestoreNative()
    local bar = Bar()
    if not bar then return end
    if origAnchor then
        bar:ClearAnchors()
        bar:SetAnchor(origAnchor.point, origAnchor.relTo, origAnchor.relPoint, origAnchor.ox, origAnchor.oy)
    end
    bar:SetScale(1)
    if holder then
        holder:SetHidden(true); holder:SetMouseEnabled(false); holder:SetMovable(false)
        Style.SetEditFrame(holder.edit, false)
    end
end

function AB.Apply()
    if not sv then return end   -- UF.Apply can fire before AB.Init runs; AB.Init re-applies after
    CacheOrig()
    local bar = Bar()
    if not bar then return end
    -- Manage the bar only in Shoyru's UI, and only once the user engages (unlocked to edit, or a
    -- saved position exists). Otherwise leave ESO's native bar untouched.
    -- Works in BOTH UIs (the action bar is native in both). Manage only once the user engages
    -- (unlocked to edit, or a saved position exists); otherwise leave ESO's bar untouched.
    local moved = (sv.x ~= nil and sv.y ~= nil)
    if not (moved or not sv.locked) then
        if touched then RestoreNative(); touched = false end   -- only undo if WE moved it
        return
    end

    BuildHolder()
    -- First time we manage: capture the bar's CURRENT (native) bottom-centre so it doesn't jump.
    if sv.x == nil or sv.y == nil then
        sv.x = (bar:GetLeft() + bar:GetWidth() / 2) - GuiRoot:GetWidth() / 2
        sv.y = bar:GetBottom() - GuiRoot:GetHeight()
    end
    local bw, bh = bar:GetDimensions()
    if not bw or bw < 8 then bw, bh = 520, 70 end
    holder:ClearAnchors()
    holder:SetDimensions(bw, bh)                          -- match the bar (no scaling) so the box lines up
    holder:SetAnchor(BOTTOM, GuiRoot, BOTTOM, sv.x, sv.y)

    bar:ClearAnchors()
    bar:SetAnchor(BOTTOM, holder, BOTTOM, 0, 0)           -- bar bottom-centre pinned to the holder (a hidden holder still anchors it)

    touched = true
    local editing = not sv.locked
    holder:SetHidden(not editing)                        -- drag guide only; hidden (no box/artifact) when locked
    holder:SetMouseEnabled(editing)                      -- click-through when locked so buttons work
    holder:SetMovable(editing)
    Style.SetEditFrame(holder.edit, editing, holder:GetHeight())   -- show the blue frame + hint while unlocked
end

-- Back to ESO's native position (untouched).
function AB.ResetPosition()
    sv.x, sv.y = nil, nil
    AB.Apply()
end

-- Controls appended as an "Action bar" submenu in the UI Layout panel (see UF.PanelOptions).
function AB.PanelControls()
    return {
        { type = "description", text = "Reposition ESO's action bar (potion, abilities, ultimate). Works in both Base game and Shoyru's UI. Unlock, drag the box to where you want it, then lock. Reset returns it to ESO's default spot." },
        { type = "checkbox", name = "Unlock action bar (drag to move)", width = "full",
          tooltip = "Show a drag box over the bar to reposition it. Lock when done so the buttons are clickable again.",
          getFunc = function() return not sv.locked end,
          setFunc = function(v) sv.locked = not v; AB.Apply() end },
        { type = "button", name = "Reset to default position", width = "full",
          func = function() AB.ResetPosition() end },
    }
end

local function FillDefaults(t, d)
    for k, v in pairs(d) do if t[k] == nil then t[k] = v end end
end

function AB.Init(abSv)
    sv = abSv
    FillDefaults(sv, AB.DEFAULTS)
    CacheOrig()

    -- ESO re-anchors / rebuilds the action bar on these; re-assert our position + scale.
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_AB_Activated", EVENT_PLAYER_ACTIVATED, AB.Apply)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_AB_Combat", EVENT_PLAYER_COMBAT_STATE, AB.Apply)
    if EVENT_GAMEPAD_PREFERRED_MODE_CHANGED then
        EVENT_MANAGER:RegisterForEvent("ShoyrUI_AB_Gamepad", EVENT_GAMEPAD_PREFERRED_MODE_CHANGED, AB.Apply)
    end
    local function onScene() AB.Apply() end
    if HUD_SCENE then HUD_SCENE:RegisterCallback("StateChange", onScene) end
    if HUD_UI_SCENE then HUD_UI_SCENE:RegisterCallback("StateChange", onScene) end

    AB.Apply()
end
