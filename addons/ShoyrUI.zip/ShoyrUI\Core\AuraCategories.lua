-- ShoyrUI :: Core/AuraCategories.lua
-- Categorizes an aura into one of a small set of buckets for the Auras module. Most of it is
-- DERIVABLE (debuff vs buff via effectType; short / long / food via duration; ESO Plus &
-- Battle Spirit via the artificial-effects API). Mundus needs ability ids — the 13 boon ids
-- below are lifted from LuiData (Effects.IsBoon), which is accurate and stable. The OVERRIDE
-- table is grown from /shoyrbuffdump captures to pin down food/class/race ids precisely later.

ShoyrUI = ShoyrUI or {}
local AC = {}
ShoyrUI.AuraCat = AC

-- The 13 Mundus boons (abilityId → true). Source: LuiData Effects.IsBoon.
AC.MUNDUS = {
    [13940] = true, [13943] = true, [13974] = true, [13975] = true, [13976] = true,
    [13977] = true, [13978] = true, [13979] = true, [13980] = true, [13981] = true,
    [13982] = true, [13984] = true, [13985] = true,
}

-- Curated abilityId → category overrides (grown from buff dumps). Seeded empty.
AC.OVERRIDE = {}

AC.FOOD_MIN = 1200   -- a TIMED buff longer than this (20 min) is food/drink
AC.LONG_MIN = 120    -- a timed buff longer than this (2 min, but < FOOD_MIN) is "long-term"

-- Display/sort order + toggle keys + labels. Default visibility leans toward a clean combat
-- view: hide permanent passives and the always-on artificial effects unless asked for.
AC.ORDER = { "short", "long", "mundus", "food", "artificial", "debuff" }
AC.LABEL = {
    short      = "Short-term",
    long       = "Long-term / passives",
    mundus     = "Mundus",
    food       = "Food & drink",
    artificial = "ESO Plus / Battle Spirit",
    debuff     = "Debuffs",
}
AC.DEFAULT_SHOW = {
    short = true, debuff = true, mundus = true, food = true, long = false, artificial = false,
}

AC.RANK = {}
for i, k in ipairs(AC.ORDER) do AC.RANK[k] = i end

-- Resolve an aura's category. `artificial` true = came from the artificial-effects API.
function AC.Of(abilityId, effectType, startT, endT, artificial)
    if artificial then return "artificial" end
    if effectType == BUFF_EFFECT_TYPE_DEBUFF then return "debuff" end
    local ov = abilityId and AC.OVERRIDE[abilityId]
    if ov then return ov end
    if abilityId and AC.MUNDUS[abilityId] then return "mundus" end
    local perm = (endT or 0) <= 0
    if not perm then
        local dur = (endT - (startT or 0))
        if dur > AC.FOOD_MIN then return "food" end
        if dur > AC.LONG_MIN then return "long" end
        return "short"
    end
    return "long"   -- permanent: passives, class/race, vampire/werewolf, etc.
end
