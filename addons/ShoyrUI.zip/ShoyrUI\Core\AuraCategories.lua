-- ShoyrUI :: Core/AuraCategories.lua
-- Categorizes an aura into one of a small set of buckets for the Auras module. Most of it is
-- DERIVABLE (debuff vs buff via effectType; short / long / food via duration; ESO Plus &
-- Battle Spirit via the artificial-effects API). Mundus needs ability ids — the 13 boon ids
-- below are lifted from LuiData (Effects.IsBoon), which is accurate and stable. The OVERRIDE
-- table is grown from /shoyrbuffdump captures to pin down food/class/race ids precisely later.

ShoyrUI = ShoyrUI or {}
local AC = {}
ShoyrUI.AuraCat = AC

-- The 13 Mundus boons (abilityId → true). Source: LuiData Effects.IsBoon.
AC.MUNDUS = {
    [13940] = true, [13943] = true, [13974] = true, [13975] = true, [13976] = true,
    [13977] = true, [13978] = true, [13979] = true, [13980] = true, [13981] = true,
    [13982] = true, [13984] = true, [13985] = true,
}

-- Food & drink buff ids (precise match). Source: LuiData Effects.IsFoodBuff + IsDrinkBuff
-- (48 food + 43 drink). Pins food regardless of duration; the FOOD_MIN heuristic below stays
-- as a fallback for any food id not in this list.
AC.FOOD = {
    -- food
    [17407]=true, [17577]=true, [17581]=true, [17608]=true, [17614]=true, [61218]=true,
    [61255]=true, [61257]=true, [61259]=true, [61260]=true, [61261]=true, [61294]=true,
    [66128]=true, [66130]=true, [66551]=true, [66568]=true, [66576]=true, [68411]=true,
    [72819]=true, [72822]=true, [72824]=true, [72956]=true, [72959]=true, [72961]=true,
    [84678]=true, [84681]=true, [84709]=true, [84725]=true, [84736]=true, [85484]=true,
    [86749]=true, [86787]=true, [86789]=true, [89955]=true, [89971]=true, [92435]=true,
    [92437]=true, [92474]=true, [92477]=true, [100498]=true, [100502]=true, [107748]=true,
    [107789]=true, [127537]=true, [127578]=true, [127596]=true, [127619]=true, [127736]=true,
    -- drink
    [61322]=true, [61325]=true, [61328]=true, [61335]=true, [61340]=true, [61345]=true,
    [61350]=true, [66125]=true, [66132]=true, [66137]=true, [66141]=true, [66586]=true,
    [66590]=true, [66594]=true, [68416]=true, [72816]=true, [72965]=true, [72968]=true,
    [72971]=true, [84700]=true, [84704]=true, [84720]=true, [84731]=true, [84732]=true,
    [84733]=true, [84735]=true, [85497]=true, [86559]=true, [86560]=true, [86673]=true,
    [86674]=true, [86677]=true, [86678]=true, [86746]=true, [86747]=true, [86791]=true,
    [89957]=true, [92433]=true, [92476]=true, [100488]=true, [127531]=true, [127572]=true,
    [148633]=true,
}

-- Curated abilityId → category overrides (grown from buff dumps). Seeded empty.
AC.OVERRIDE = {}

AC.FOOD_MIN = 1200   -- a TIMED buff longer than this (20 min) is food/drink
AC.LONG_MIN = 120    -- a timed buff longer than this (2 min, but < FOOD_MIN) is "long-term"

-- Three display buckets, each with ONE show toggle:
--   LONG    = Mundus, food/drink, ESO Plus/Battle Spirit, and long timed buffs (2-20 min)
--   BUFFS   = short-term combat buffs
--   DEBUFFS = debuffs on the unit
-- Permanent class/race passives bucket as "hidden" (noise — never shown). ORDER puts the whole
-- long-term group FIRST, then combat buffs, then debuffs at the tail, so the volatile combat
-- icons churn at the end while the long-term icons keep a stable position.
AC.ORDER = { "mundus", "food", "long", "artificial", "short", "debuff" }
AC.BUCKET = {
    mundus = "long", food = "long", long = "long", artificial = "long",
    short  = "buffs", debuff = "debuffs", passive = "hidden",
}
AC.DEFAULT_BUCKETS = { long = true, buffs = true, debuffs = true }

AC.RANK = {}
for i, k in ipairs(AC.ORDER) do AC.RANK[k] = i end

function AC.Bucket(cat) return AC.BUCKET[cat] or "buffs" end

-- Resolve an aura's category. `artificial` true = came from the artificial-effects API.
function AC.Of(abilityId, effectType, startT, endT, artificial)
    if artificial then return "artificial" end
    if effectType == BUFF_EFFECT_TYPE_DEBUFF then return "debuff" end
    local ov = abilityId and AC.OVERRIDE[abilityId]
    if ov then return ov end
    if abilityId and AC.MUNDUS[abilityId] then return "mundus" end
    if abilityId and AC.FOOD[abilityId] then return "food" end
    local perm = (endT or 0) <= 0
    if not perm then
        local dur = (endT - (startT or 0))
        if dur > AC.FOOD_MIN then return "food" end
        if dur > AC.LONG_MIN then return "long" end
        return "short"
    end
    return "passive"   -- permanent: class/race passives, forms — bucketed "hidden" (noise)
end
