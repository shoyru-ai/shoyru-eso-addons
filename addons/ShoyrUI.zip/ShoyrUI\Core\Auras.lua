-- ShoyrUI :: Core/Auras.lua
-- Auras module — buff/debuff icon displays per unit, built on the shared Style.
-- A display can ATTACH under its unit frame (player/target): it anchors below the bars and
-- WRAPS at the frame's width (line-breaks where the bar ends), following the frame as it
-- moves/resizes, and inherits the frame's visibility (menu-hide, target-present, active UI).
-- Each aura = icon + countdown + stack count; debuffs get a red border. Effects are split
-- into short-term vs long-term (permanent / >2min: Mundus, food, ESO+) with independent
-- show toggles, so e.g. you can hide your own Mundus but still see an enemy's.

ShoyrUI = ShoyrUI or {}
local AU = {}
ShoyrUI.Auras = AU

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style
local AC = ShoyrUI.AuraCat

local MAX_ICONS = 40        -- pooled icon widgets per display
local TICK_MS = 100         -- countdown / follow-frame cadence

local BUFF_BG   = { 0.05, 0.05, 0.07, 1 }
local DEBUFF_BG = { 0.50, 0.06, 0.06, 1 }

-- `frame` = which unit frame this display attaches under (matches UnitFrames FRAME_DEFS id).
local AURA_DEFS = {
    { id = "player", label = "Player", unit = "player",      frame = "player", reticle = false },
    { id = "target", label = "Target", unit = "reticleover", frame = "target", reticle = true },
}

local function DisplayDefaults(d)
    return {
        show = true, locked = true, attach = true,
        iconSize = 38, gap = 4, width = 320, offsetY = 6, growUp = false,
        showTimer = true, showStacks = true,
        cats = ZO_DeepTableCopy(AC.DEFAULT_SHOW),   -- per-category visibility (see AuraCat.ORDER)
        x = 0, y = (d.id == "target") and -300 or 240,
    }
end

AU.DEFAULTS = { displays = {} }

local sv = nil
AU.displays = {}
AU.menuOpen = false

local function Now() return GetFrameTimeSeconds() end

local function TimerText(remaining)
    if remaining >= 60 then return string.format("%dm", math.floor(remaining / 60)) end
    return string.format("%d", math.ceil(remaining))
end

-- The unit-frame TLW this display attaches to (nil if UI Layout isn't built / active).
local function FrameControl(frameId)
    local frames = ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.frames
    local f = frames and frames[frameId]
    return f and f.frame
end

-- ===========================================================================
-- Display component
-- ===========================================================================

local Display = {}
Display.__index = Display

function Display.New(def, dsv)
    local self = setmetatable({}, Display)
    self.def = def
    self.sv = dsv
    self.icons = {}
    self.list = {}
    return self
end

function Display:Build()
    if self.frame then return end
    local f = WM:CreateTopLevelWindow("ShoyrUI_Auras_" .. self.def.id)
    self.frame = f
    f:SetClampedToScreen(true)
    f:SetMovable(false)
    f:SetMouseEnabled(false)
    f:SetDrawTier(DT_LOW)
    f:SetHandler("OnMoveStop", function() self:SavePosition() end)
    for i = 1, MAX_ICONS do
        local ic = {}
        ic.bg = WM:CreateControl(nil, f, CT_BACKDROP)        -- solid centre colour = the border
        ic.bg:SetDrawLayer(DL_BACKGROUND)
        ic.icon = WM:CreateControl(nil, ic.bg, CT_TEXTURE)   -- ability icon, inset 2px
        ic.icon:SetDrawLayer(DL_CONTROLS)
        ic.timer = WM:CreateControl(nil, ic.bg, CT_LABEL)
        ic.timer:SetDrawLayer(DL_OVERLAY)
        ic.timer:SetColor(1, 1, 1, 1)
        ic.timer:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        ic.timer:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
        ic.stack = WM:CreateControl(nil, ic.bg, CT_LABEL)
        ic.stack:SetDrawLayer(DL_OVERLAY)
        ic.stack:SetColor(1, 0.96, 0.7, 1)
        ic.stack:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
        ic.stack:SetVerticalAlignment(TEXT_ALIGN_TOP)
        ic.bg:SetHidden(true)
        self.icons[i] = ic
    end
    self:ApplyLayout()
end

-- Width to wrap icon rows at: the attached frame's width, else the free-mode Width slider.
function Display:WrapWidth()
    if self.sv.attach ~= false then
        local fc = FrameControl(self.def.frame)
        if fc then return fc:GetWidth() end
    end
    return self.sv.width or 320
end

function Display:LayoutIcons()
    if not self.frame then return end
    local size = self.sv.iconSize or 38
    local gap = self.sv.gap or 4
    local cell = size + gap
    local wrapW = self:WrapWidth()
    self.lastWrapW = wrapW
    local perRow = math.max(1, math.floor((wrapW + gap) / cell))
    local n = #self.list
    local cols = math.min(perRow, math.max(1, n))
    local rows = math.max(1, math.ceil(math.max(n, 1) / perRow))
    local font = math.max(11, math.floor(size * 0.34))
    self.frame:SetDimensions(cols * cell - gap, rows * cell - gap)
    for i, ic in ipairs(self.icons) do
        if i <= n then
            local col = (i - 1) % perRow
            local row = math.floor((i - 1) / perRow)
            local y = self.sv.growUp and (rows - 1 - row) or row
            ic.bg:ClearAnchors()
            ic.bg:SetAnchor(TOPLEFT, self.frame, TOPLEFT, col * cell, y * cell)
            ic.bg:SetDimensions(size, size)
            ic.icon:ClearAnchors()
            ic.icon:SetAnchor(TOPLEFT, ic.bg, TOPLEFT, 2, 2)
            ic.icon:SetAnchor(BOTTOMRIGHT, ic.bg, BOTTOMRIGHT, -2, -2)
            ic.timer:ClearAnchors()
            ic.timer:SetAnchor(BOTTOM, ic.bg, BOTTOM, 0, -1)
            ic.timer:SetDimensions(size, font + 2)
            ic.timer:SetFont(Style.Font(font, "count"))
            ic.stack:ClearAnchors()
            ic.stack:SetAnchor(TOPRIGHT, ic.bg, TOPRIGHT, -2, 0)
            ic.stack:SetDimensions(size, font + 2)
            ic.stack:SetFont(Style.Font(font, "count"))
        else
            ic.bg:SetHidden(true)
        end
    end
end

function Display:Paint(ic, a)
    ic.bg:SetHidden(false)
    ic.bg:SetCenterColor(unpack(a.debuff and DEBUFF_BG or BUFF_BG))
    ic.icon:SetTexture(a.icon ~= "" and a.icon or "/esoui/art/icons/icon_missing.dds")
    if self.sv.showTimer and a.remaining and a.remaining > 0 then
        ic.timer:SetText(TimerText(a.remaining)); ic.timer:SetHidden(false)
    else
        ic.timer:SetHidden(true)
    end
    if self.sv.showStacks and a.stacks and a.stacks > 1 then
        ic.stack:SetText(tostring(a.stacks)); ic.stack:SetHidden(false)
    else
        ic.stack:SetHidden(true)
    end
end

function Display:Refresh()
    if not self.frame then return end
    local editing = self.sv.locked == false
    local cats = self.sv.cats or AC.DEFAULT_SHOW
    local function want(cat) return cats[cat] ~= false end
    self.list = {}
    local unit = self.def.unit
    local now = Now()
    for i = 1, GetNumBuffs(unit) do
        local _, startT, endT, _, stacks, icon, _, effectType, _, _, abilityId = GetUnitBuffInfo(unit, i)
        if icon and icon ~= "" then
            local cat = AC.Of(abilityId, effectType, startT or 0, endT or 0, false)
            if want(cat) then
                self.list[#self.list + 1] = {
                    icon = icon, stacks = stacks or 0, endTime = endT or 0,
                    debuff = (cat == "debuff"), cat = cat,
                }
            end
        end
    end
    -- Player only: ESO Plus / Battle Spirit etc. aren't in GetUnitBuffInfo.
    if unit == "player" and want("artificial") and ZO_GetNextActiveArtificialEffectIdIter then
        for effectId in ZO_GetNextActiveArtificialEffectIdIter do
            local _, icon, _, _, startT, endT = GetArtificialEffectInfo(effectId)
            if icon and icon ~= "" then
                self.list[#self.list + 1] = {
                    icon = icon, stacks = 0, endTime = endT or 0, debuff = false, cat = "artificial",
                }
            end
        end
    end
    table.sort(self.list, function(x, y)
        local rxk, ryk = AC.RANK[x.cat] or 99, AC.RANK[y.cat] or 99
        if rxk ~= ryk then return rxk < ryk end       -- group by category order
        local rx = (x.endTime > 0) and (x.endTime - now) or math.huge
        local ry = (y.endTime > 0) and (y.endTime - now) or math.huge
        return rx < ry                                 -- then soonest-to-expire first
    end)

    if #self.list == 0 and editing then          -- demo icons across categories (respect toggles)
        local demo = {
            { cat = "short",  endTime = now + 8 },
            { cat = "short",  endTime = now + 20, stacks = 3 },
            { cat = "mundus", endTime = 0 },
            { cat = "food",   endTime = now + 1800 },
            { cat = "long",   endTime = 0 },
            { cat = "debuff", endTime = now + 5 },
        }
        for _, dmo in ipairs(demo) do
            if want(dmo.cat) then
                dmo.icon = "/esoui/art/icons/icon_missing.dds"
                dmo.debuff = (dmo.cat == "debuff")
                self.list[#self.list + 1] = dmo
            end
        end
    end

    if #self.list > MAX_ICONS then
        for i = #self.list, MAX_ICONS + 1, -1 do self.list[i] = nil end
    end
    self:LayoutIcons()
    for i, ic in ipairs(self.icons) do
        if self.list[i] then
            self.list[i].remaining = (self.list[i].endTime > 0) and (self.list[i].endTime - now) or 0
            self:Paint(ic, self.list[i])
        end
    end
end

function Display:Tick()
    if not self.frame then return end
    if self.sv.attach ~= false then
        if FrameControl(self.def.frame) ~= self.curAnchorFc then self:ApplyLayout() end  -- (re)anchor when the frame appears/changes
        self:UpdateVisibility()                                   -- follow the frame's show/hide
    end
    if self.frame:IsHidden() then return end
    if self.sv.attach ~= false then                               -- re-wrap if the frame resized
        if self:WrapWidth() ~= self.lastWrapW then self:Refresh() end
    end
    if not self.sv.showTimer then return end
    local now = Now()
    for i, a in ipairs(self.list) do
        local ic = self.icons[i]
        if ic and not ic.bg:IsHidden() and a.endTime and a.endTime > 0 then
            local r = a.endTime - now
            if r > 0 then ic.timer:SetText(TimerText(r)); ic.timer:SetHidden(false)
            else ic.timer:SetHidden(true) end
        end
    end
end

function Display:SavePosition()
    if not self.frame or self.sv.attach ~= false then return end   -- attached = no free position
    self.sv.x = self.frame:GetLeft() - GuiRoot:GetWidth() / 2
    self.sv.y = self.frame:GetTop() - GuiRoot:GetHeight() / 2
end

function Display:ApplyLayout()
    if not self.frame then return end
    self.frame:ClearAnchors()
    local fc = (self.sv.attach ~= false) and FrameControl(self.def.frame)
    if fc then
        self.frame:SetAnchor(TOPLEFT, fc, BOTTOMLEFT, 0, self.sv.offsetY or 6)   -- under the bars
    else
        self.frame:SetAnchor(TOPLEFT, GuiRoot, CENTER, self.sv.x, self.sv.y)     -- free position
    end
    self.curAnchorFc = fc   -- remember what we anchored to (re-anchor in Tick if it changes)
    self:Refresh()
end

function Display:UpdateVisibility()
    if not self.frame then return end
    local editing = self.sv.locked == false
    if self.sv.attach ~= false then
        -- Attached: piggyback on the unit frame's visibility (handles target-present, menu-hide,
        -- and active-UI for us). Show our auras only while that frame is actually visible.
        local fc = FrameControl(self.def.frame)
        local frameVis = fc and not fc:IsHidden()
        self.frame:SetHidden(not (frameVis and (editing or self.sv.show ~= false)))
    else
        local present = (self.def.unit == "player") or DoesUnitExist(self.def.unit)
        self.frame:SetHidden(not (editing or (self.sv.show ~= false and not AU.menuOpen and present)))
    end
end

function Display:SetLocked(locked)
    self.sv.locked = locked
    if not self.frame then return end
    -- Only free-mode displays are draggable; attached ones are positioned by their frame.
    local freeMove = (self.sv.attach == false) and not locked
    self.frame:SetMovable(freeMove)
    self.frame:SetMouseEnabled(freeMove)
    self:ApplyLayout()         -- re-anchor (attach vs free) + refresh (demo when unlocked)
    self:UpdateVisibility()
end

function Display:Apply()
    self:Build()
    self:SetLocked(self.sv.locked ~= false)
end

function Display:ResetPosition()
    local d = DisplayDefaults(self.def)
    self.sv.x, self.sv.y, self.sv.offsetY = d.x, d.y, d.offsetY
    self:ApplyLayout()
end

function Display:PanelControls()
    local svf = self.sv
    local attached = function() return svf.attach ~= false end
    local o = {
        { type = "checkbox", name = "Show this display", width = "half",
          getFunc = function() return svf.show ~= false end,
          setFunc = function(v) svf.show = v; self:UpdateVisibility() end },
        { type = "checkbox", name = "Unlock (move)", width = "half",
          tooltip = "Edit mode: shows demo icons. Free displays can be dragged; attached ones are positioned by their unit frame.",
          getFunc = function() return not svf.locked end,
          setFunc = function(v) self:SetLocked(not v) end },
        { type = "checkbox", name = "Attach under unit frame", width = "full",
          tooltip = "Anchor under the " .. self.def.label:lower() .. " frame and wrap at its width (line-breaks where the bar ends). Uncheck to position freely.",
          getFunc = attached,
          setFunc = function(v) svf.attach = v; self:ApplyLayout(); self:UpdateVisibility() end },
        { type = "header", name = "Categories shown" },
    }
    -- One toggle per category (Short-term / Long-term / Mundus / Food & drink / ESO Plus / Debuffs).
    for _, key in ipairs(AC.ORDER) do
        o[#o + 1] = { type = "checkbox", name = AC.LABEL[key], width = "half",
                      getFunc = function() return (svf.cats and svf.cats[key]) ~= false end,
                      setFunc = function(v) svf.cats = svf.cats or {}; svf.cats[key] = v; self:Refresh() end }
    end
    local layout = {
        { type = "header", name = "Layout" },
        { type = "slider", name = "Icon size", min = 20, max = 72, step = 1, width = "half",
          getFunc = function() return svf.iconSize or 38 end,
          setFunc = function(v) svf.iconSize = v; self:Refresh() end },
        { type = "slider", name = "Icon spacing", min = 0, max = 16, step = 1, width = "half",
          getFunc = function() return svf.gap or 4 end,
          setFunc = function(v) svf.gap = v; self:Refresh() end },
        { type = "slider", name = "Gap below frame", min = 0, max = 60, step = 1, width = "half",
          tooltip = "Vertical distance below the unit frame (attached mode).",
          disabled = function() return not attached() end,
          getFunc = function() return svf.offsetY or 6 end,
          setFunc = function(v) svf.offsetY = v; self:ApplyLayout() end },
        { type = "slider", name = "Row width", min = 80, max = 800, step = 10, width = "half",
          tooltip = "Wrap width when NOT attached to a frame.",
          disabled = attached,
          getFunc = function() return svf.width or 320 end,
          setFunc = function(v) svf.width = v; self:Refresh() end },
        { type = "checkbox", name = "Grow upward", width = "half",
          getFunc = function() return svf.growUp == true end,
          setFunc = function(v) svf.growUp = v; self:Refresh() end },
        { type = "checkbox", name = "Show timers", width = "half",
          getFunc = function() return svf.showTimer ~= false end,
          setFunc = function(v) svf.showTimer = v; self:Refresh() end },
        { type = "checkbox", name = "Show stacks", width = "half",
          getFunc = function() return svf.showStacks ~= false end,
          setFunc = function(v) svf.showStacks = v; self:Refresh() end },
        { type = "button", name = "Reset position", width = "half",
          disabled = attached, func = function() self:ResetPosition() end },
    }
    for _, c in ipairs(layout) do o[#o + 1] = c end
    return o
end

-- ===========================================================================
-- Module
-- ===========================================================================

function AU.PanelOptions()
    local out = {
        { type = "description", text = "Buff/debuff icon displays. Each attaches under its unit frame (wrapping at the bar width) or floats free. Effects auto-sort into categories (short-term, long-term/passives, Mundus, food & drink, ESO Plus/Battle Spirit, debuffs) you can show/hide individually. The Target display reads an enemy's effects \226\128\148 e.g. their Mundus. Run /shoyrbuffdump to help categorize more buffs precisely." },
    }
    for _, d in ipairs(AURA_DEFS) do
        local disp = AU.displays[d.id]
        if disp then out[#out + 1] = { type = "submenu", name = d.label .. " auras", controls = disp:PanelControls() } end
    end
    return out
end

local function FillDefaults(t, d)
    for k, v in pairs(d) do
        if t[k] == nil then t[k] = (type(v) == "table") and ZO_DeepTableCopy(v) or v end
    end
end

function AU.ApplyAll()
    for _, disp in pairs(AU.displays) do disp:Apply() end
end

function AU.UpdateAllVisibility()
    for _, disp in pairs(AU.displays) do if disp.frame then disp:UpdateVisibility() end end
end

-- /shoyrbuffdump — record the player's active effects (id, name, duration, derived category)
-- to SV + chat, so unrecognized food/class/race ids can be baked into AuraCat.OVERRIDE later.
function AU.Dump()
    sv.dump = {}
    local function add(id, name, startT, endT, effectType, artificial)
        local dur = (endT and endT > 0) and (endT - (startT or 0)) or 0
        local cat = AC.Of(id, effectType, startT or 0, endT or 0, artificial)
        sv.dump[#sv.dump + 1] = { id = id or 0, name = name or "?", dur = math.floor(dur), cat = cat, art = artificial or false }
        d(string.format("[ShoyrUI] %-28s id=%-7s %4ds  %s", tostring(name), tostring(id or "-"), math.floor(dur), cat))
    end
    for i = 1, GetNumBuffs("player") do
        local name, startT, endT, _, _, _, _, effectType, _, _, abilityId = GetUnitBuffInfo("player", i)
        add(abilityId, name, startT, endT, effectType, false)
    end
    if ZO_GetNextActiveArtificialEffectIdIter then
        for effectId in ZO_GetNextActiveArtificialEffectIdIter do
            local name, _, effectType, _, startT, endT = GetArtificialEffectInfo(effectId)
            add(nil, (name or "?") .. " (artificial)", startT, endT, effectType, true)
        end
    end
    d("[ShoyrUI] Buff dump: " .. #sv.dump .. " effects saved (SavedVariables \226\134\146 auras.dump). /reloadui then send the file.")
end

function AU.Init(aurasSv)
    sv = aurasSv
    sv.displays = sv.displays or {}
    for _, d in ipairs(AURA_DEFS) do
        sv.displays[d.id] = sv.displays[d.id] or {}
        FillDefaults(sv.displays[d.id], DisplayDefaults(d))
        AU.displays[d.id] = Display.New(d, sv.displays[d.id])
    end

    for _, d in ipairs(AURA_DEFS) do
        local id, unit = d.id, d.unit
        local name = "ShoyrUI_Aura_" .. id
        EVENT_MANAGER:RegisterForEvent(name, EVENT_EFFECT_CHANGED, function()
            local disp = AU.displays[id]
            if disp and disp.frame and (disp.sv.show ~= false or disp.sv.locked == false) then disp:Refresh() end
        end)
        EVENT_MANAGER:AddFilterForEvent(name, EVENT_EFFECT_CHANGED, REGISTER_FILTER_UNIT_TAG, unit)
    end
    -- Target display: re-scan + re-evaluate visibility when the reticle target changes.
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_AuraReticle", EVENT_RETICLE_TARGET_CHANGED, function()
        local disp = AU.displays.target
        if disp and disp.frame then disp:Refresh(); disp:UpdateVisibility() end
    end)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_AuraActivated", EVENT_PLAYER_ACTIVATED, AU.ApplyAll)

    EVENT_MANAGER:RegisterForUpdate("ShoyrUI_AuraTick", TICK_MS, function()
        for _, disp in pairs(AU.displays) do disp:Tick() end
    end)

    local function onHudScene()
        AU.menuOpen = not ((HUD_SCENE and HUD_SCENE:IsShowing()) or (HUD_UI_SCENE and HUD_UI_SCENE:IsShowing()))
        AU.UpdateAllVisibility()
    end
    if HUD_SCENE then HUD_SCENE:RegisterCallback("StateChange", onHudScene) end
    if HUD_UI_SCENE then HUD_UI_SCENE:RegisterCallback("StateChange", onHudScene) end

    SLASH_COMMANDS["/shoyrbuffdump"] = AU.Dump   -- capture active effects to grow the category DB

    AU.ApplyAll()
end
