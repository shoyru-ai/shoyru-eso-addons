-- ShoyrUI :: Core/Auras.lua
-- Auras module — buff/debuff icon displays per unit, built on the shared Style.
-- A display can ATTACH under its unit frame (player/target): it anchors below the bars and
-- WRAPS at the frame's width (line-breaks where the bar ends), following the frame as it
-- moves/resizes, and inherits the frame's visibility (menu-hide, target-present, active UI).
-- Each aura = icon + countdown + stack count; debuffs get a red border. Effects are split
-- into short-term vs long-term (permanent / >2min: Mundus, food, ESO+) with independent
-- show toggles, so e.g. you can hide your own Mundus but still see an enemy's.

ShoyrUI = ShoyrUI or {}
local AU = {}
ShoyrUI.Auras = AU

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style
local AC = ShoyrUI.AuraCat

local MAX_ICONS = 40        -- pooled icon widgets per display
local TICK_MS = 100         -- countdown / follow-frame cadence
local ICON_GAP = 4          -- fixed spacing between icons
local OFFSET_Y = 6          -- fixed gap below the unit frame

local BUFF_BG   = { 0.05, 0.05, 0.07, 1 }
local DEBUFF_BG = { 0.50, 0.06, 0.06, 1 }

-- `frame` = which unit frame this display sits under (matches UnitFrames FRAME_DEFS id). Auras
-- are ALWAYS attached under their frame — they anchor below the bars, wrap at the frame's width,
-- and move/show with the frame. To reposition, move the unit frame itself.
local AURA_DEFS = {
    { id = "player", label = "Player", unit = "player",      frame = "player", reticle = false },
    { id = "target", label = "Target", unit = "reticleover", frame = "target", reticle = true },
}

local function DisplayDefaults(d)
    return {
        iconSize = 38,
        showTimer = true, showStacks = true,   -- always shown (no toggle); Paint reads these
        -- Three bucket show-toggles (the display shows if any is on).
        showLong = true, showBuffs = true, showDebuffs = true,
        -- Base UI free-float mode: show our (categorized) auras instead of ESO's native buffs.
        showInBase = false, baseLocked = true, baseWidth = 320,   -- baseX/baseY nil until positioned
    }
end

AU.DEFAULTS = { displays = {} }

local sv = nil
AU.displays = {}
AU.menuOpen = false

-- True in Base game UI (not Shoyru's UI) — where auras free-float instead of attaching to a frame.
local function InBaseUI()
    return not (ShoyrUI.sv and ShoyrUI.sv.layout and ShoyrUI.sv.layout.activeUI == "shoyru")
end

local function Now() return GetFrameTimeSeconds() end

local function TimerText(remaining)
    if remaining >= 60 then return string.format("%dm", math.floor(remaining / 60)) end
    return string.format("%d", math.ceil(remaining))
end

-- The unit-frame TLW this display attaches to (nil if UI Layout isn't built / active).
local function FrameControl(frameId)
    local frames = ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.frames
    local f = frames and frames[frameId]
    return f and f.frame
end

-- Is the unit frame this display attaches to currently unlocked (edit mode)?
local function FrameUnlocked(frameId)
    local frames = ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.frames
    local f = frames and frames[frameId]
    return (f and f.sv and f.sv.locked == false) or false
end

-- ===========================================================================
-- Display component
-- ===========================================================================

local Display = {}
Display.__index = Display

function Display.New(def, dsv)
    local self = setmetatable({}, Display)
    self.def = def
    self.sv = dsv
    self.icons = {}
    self.list = {}
    return self
end

-- The display is "on" if any of its three bucket toggles is on (there's no separate master).
function Display:AnyShown()
    return self.sv.showLong ~= false or self.sv.showBuffs ~= false or self.sv.showDebuffs ~= false
end

-- Free-float mode = Base UI + this display opted in to replace the native buffs. Otherwise it's
-- attached under the Shoyru custom frame (Shoyru UI).
function Display:FreeMode()
    return InBaseUI() and self.sv.showInBase == true
end

-- Edit mode (shows demo icons). Free mode: our own unlock; attached: the parent frame's unlock.
function Display:Editing()
    if self:FreeMode() then return self.sv.baseLocked == false end
    return FrameUnlocked(self.def.frame)
end

-- Re-evaluate visibility after a show-toggle changes, and re-assert the native buff-bar hide
-- (turning our last bucket off restores ESO's bar; turning one back on hides it again).
function Display:AfterShowChange()
    self:UpdateVisibility()
    if ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.ApplyNativeBuffs then
        ShoyrUI.UnitFrames.ApplyNativeBuffs()
    end
end

function Display:Build()
    if self.frame then return end
    local f = WM:CreateTopLevelWindow("ShoyrUI_Auras_" .. self.def.id)
    self.frame = f
    f:SetClampedToScreen(true)
    f:SetMovable(false)
    f:SetMouseEnabled(false)
    f:SetDrawTier(DT_LOW)
    f:SetHandler("OnMoveStop", function()   -- free mode: save the (grid-snapped) dragged position
        local snap = ShoyrUI.Grid and ShoyrUI.Grid.Snap or function(v) return v end
        self.sv.baseX = snap(f:GetLeft()) - GuiRoot:GetWidth() / 2
        self.sv.baseY = snap(f:GetTop()) - GuiRoot:GetHeight() / 2
        self:ApplyLayout()
    end)
    for i = 1, MAX_ICONS do
        local ic = {}
        ic.bg = WM:CreateControl(nil, f, CT_BACKDROP)        -- solid centre colour = the border
        ic.bg:SetDrawLayer(DL_BACKGROUND)
        ic.icon = WM:CreateControl(nil, ic.bg, CT_TEXTURE)   -- ability icon, inset 2px
        ic.icon:SetDrawLayer(DL_CONTROLS)
        ic.timer = WM:CreateControl(nil, ic.bg, CT_LABEL)
        ic.timer:SetDrawLayer(DL_OVERLAY)
        ic.timer:SetColor(1, 1, 1, 1)
        ic.timer:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        ic.timer:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
        ic.stack = WM:CreateControl(nil, ic.bg, CT_LABEL)
        ic.stack:SetDrawLayer(DL_OVERLAY)
        ic.stack:SetColor(1, 0.96, 0.7, 1)
        ic.stack:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
        ic.stack:SetVerticalAlignment(TEXT_ALIGN_TOP)
        ic.bg:SetHidden(true)
        self.icons[i] = ic
    end
    self:ApplyLayout()
end

-- Width to wrap icon rows at: the free-mode row width, else the frame's width.
function Display:WrapWidth()
    if self:FreeMode() then return self.sv.baseWidth or 320 end
    local fc = FrameControl(self.def.frame)
    if fc then return fc:GetWidth() end
    return 320   -- fallback until the frame is built
end

function Display:LayoutIcons()
    if not self.frame then return end
    local size = self.sv.iconSize or 38
    local gap = ICON_GAP
    local cell = size + gap
    local wrapW = self:WrapWidth()
    self.lastWrapW = wrapW
    local perRow = math.max(1, math.floor((wrapW + gap) / cell))
    local n = #self.list
    local cols = math.min(perRow, math.max(1, n))
    local rows = math.max(1, math.ceil(math.max(n, 1) / perRow))
    local font = math.max(11, math.floor(size * 0.34))
    -- Continuous flow wrapping at the bar width: self.list is sorted long-term group first, then
    -- short-term appended after (see Refresh sort), so the long-term icons keep a stable spot.
    self.frame:SetDimensions(cols * cell - gap, rows * cell - gap)
    for i, ic in ipairs(self.icons) do
        if i <= n then
            local col = (i - 1) % perRow
            local row = math.floor((i - 1) / perRow)
            local y = row
            ic.bg:ClearAnchors()
            ic.bg:SetAnchor(TOPLEFT, self.frame, TOPLEFT, col * cell, y * cell)
            ic.bg:SetDimensions(size, size)
            ic.icon:ClearAnchors()
            ic.icon:SetAnchor(TOPLEFT, ic.bg, TOPLEFT, 2, 2)
            ic.icon:SetAnchor(BOTTOMRIGHT, ic.bg, BOTTOMRIGHT, -2, -2)
            ic.timer:ClearAnchors()
            ic.timer:SetAnchor(BOTTOM, ic.bg, BOTTOM, 0, -1)
            ic.timer:SetDimensions(size, font + 2)
            ic.timer:SetFont(Style.Font(font, "count"))
            ic.stack:ClearAnchors()
            ic.stack:SetAnchor(TOPRIGHT, ic.bg, TOPRIGHT, -2, 0)
            ic.stack:SetDimensions(size, font + 2)
            ic.stack:SetFont(Style.Font(font, "count"))
        else
            ic.bg:SetHidden(true)
        end
    end
end

function Display:Paint(ic, a)
    ic.bg:SetHidden(false)
    ic.bg:SetCenterColor(unpack(a.debuff and DEBUFF_BG or BUFF_BG))
    ic.icon:SetTexture(a.icon ~= "" and a.icon or "/esoui/art/icons/icon_missing.dds")
    if self.sv.showTimer and a.remaining and a.remaining > 0 then
        ic.timer:SetText(TimerText(a.remaining)); ic.timer:SetHidden(false)
    else
        ic.timer:SetHidden(true)
    end
    if self.sv.showStacks and a.stacks and a.stacks > 1 then
        ic.stack:SetText(tostring(a.stacks)); ic.stack:SetHidden(false)
    else
        ic.stack:SetHidden(true)
    end
end

function Display:Refresh()
    if not self.frame then return end
    local editing = self:Editing()
    local function want(cat)
        local b = AC.Bucket(cat)
        if b == "long"    then return self.sv.showLong    ~= false end
        if b == "buffs"   then return self.sv.showBuffs   ~= false end
        if b == "debuffs" then return self.sv.showDebuffs ~= false end
        return false   -- "hidden": permanent passives
    end
    self.list = {}
    local unit = self.def.unit
    local now = Now()
    for i = 1, GetNumBuffs(unit) do
        local _, startT, endT, _, stacks, icon, _, effectType, _, _, abilityId = GetUnitBuffInfo(unit, i)
        if icon and icon ~= "" then
            local cat = AC.Of(abilityId, effectType, startT or 0, endT or 0, false)
            if want(cat) then
                self.list[#self.list + 1] = {
                    icon = icon, stacks = stacks or 0, endTime = endT or 0,
                    debuff = (cat == "debuff"), cat = cat,
                }
            end
        end
    end
    -- Player only: ESO Plus / Battle Spirit etc. aren't in GetUnitBuffInfo.
    if unit == "player" and want("artificial") and ZO_GetNextActiveArtificialEffectIdIter then
        for effectId in ZO_GetNextActiveArtificialEffectIdIter do
            local _, icon, _, _, startT, endT = GetArtificialEffectInfo(effectId)
            if icon and icon ~= "" then
                self.list[#self.list + 1] = {
                    icon = icon, stacks = 0, endTime = endT or 0, debuff = false, cat = "artificial",
                }
            end
        end
    end
    table.sort(self.list, function(x, y)
        local rxk, ryk = AC.RANK[x.cat] or 99, AC.RANK[y.cat] or 99
        if rxk ~= ryk then return rxk < ryk end       -- group by category order
        local rx = (x.endTime > 0) and (x.endTime - now) or math.huge
        local ry = (y.endTime > 0) and (y.endTime - now) or math.huge
        return rx < ry                                 -- then soonest-to-expire first
    end)

    if #self.list == 0 and editing then          -- demo icons across categories (respect toggles)
        local demo = {
            { cat = "short",  endTime = now + 8 },
            { cat = "short",  endTime = now + 20, stacks = 3 },
            { cat = "mundus", endTime = 0 },
            { cat = "food",   endTime = now + 1800 },
            { cat = "long",   endTime = now + 600 },
            { cat = "debuff", endTime = now + 5 },
        }
        for _, dmo in ipairs(demo) do
            if want(dmo.cat) then
                dmo.icon = "/esoui/art/icons/icon_missing.dds"
                dmo.debuff = (dmo.cat == "debuff")
                self.list[#self.list + 1] = dmo
            end
        end
    end

    if #self.list > MAX_ICONS then
        for i = #self.list, MAX_ICONS + 1, -1 do self.list[i] = nil end
    end
    self:LayoutIcons()
    for i, ic in ipairs(self.icons) do
        if self.list[i] then
            self.list[i].remaining = (self.list[i].endTime > 0) and (self.list[i].endTime - now) or 0
            self:Paint(ic, self.list[i])
        end
    end
end

function Display:Tick()
    if not self.frame then return end
    local free = self:FreeMode()
    if free ~= self.lastFree then self.lastFree = free; self:Apply(); return end   -- UI switched → re-apply mode
    if not free and FrameControl(self.def.frame) ~= self.curAnchorFc then self:ApplyLayout() end
    self:UpdateVisibility()
    local editing = self:Editing()                                -- unlock toggles our demo state
    if editing ~= self.lastEditing then self.lastEditing = editing; self:Refresh() end
    if self.frame:IsHidden() then return end
    if self:WrapWidth() ~= self.lastWrapW then self:Refresh() end  -- re-wrap if the frame resized
    if not self.sv.showTimer then return end
    local now = Now()
    for i, a in ipairs(self.list) do
        local ic = self.icons[i]
        if ic and not ic.bg:IsHidden() and a.endTime and a.endTime > 0 then
            local r = a.endTime - now
            if r > 0 then ic.timer:SetText(TimerText(r)); ic.timer:SetHidden(false)
            else ic.timer:SetHidden(true) end
        end
    end
end

function Display:ApplyLayout()
    if not self.frame then return end
    self.frame:ClearAnchors()
    if self:FreeMode() then
        local x, y = self.sv.baseX, self.sv.baseY
        if x == nil then x, y = -160, 200 end                                     -- default free position
        self.frame:SetAnchor(TOPLEFT, GuiRoot, CENTER, x, y)
        self.curAnchorFc = nil
    else
        local fc = FrameControl(self.def.frame)
        if fc then self.frame:SetAnchor(TOPLEFT, fc, BOTTOMLEFT, 0, OFFSET_Y)      -- under the bars
        else self.frame:SetAnchor(TOPLEFT, GuiRoot, CENTER, 0, 240) end            -- fallback
        self.curAnchorFc = fc
    end
    self:Refresh()
end

function Display:UpdateVisibility()
    if not self.frame then return end
    if self:FreeMode() then
        -- Free-float in Base UI: show if something's to show + the unit is present + not in a menu.
        local present = (self.def.unit == "player") or DoesUnitExist(self.def.unit)
        self.frame:SetHidden(not (self:Editing() or (self:AnyShown() and not AU.menuOpen and present)))
    elseif InBaseUI() then
        self.frame:SetHidden(true)                                                -- Base UI, not opted in
    else
        -- Attached: piggyback on the unit frame's visibility (target-present / menu-hide / active-UI).
        local fc = FrameControl(self.def.frame)
        local frameVis = fc and not fc:IsHidden()
        self.frame:SetHidden(not (frameVis and (self:Editing() or self:AnyShown())))
    end
end

function Display:Apply()
    self:Build()
    if self.frame then
        local drag = self:FreeMode() and (self.sv.baseLocked == false)            -- draggable only in free edit mode
        self.frame:SetMovable(drag)
        self.frame:SetMouseEnabled(drag)
    end
    self:ApplyLayout()
    self:UpdateVisibility()
end

function Display:PanelControls()
    local svf = self.sv
    -- Auras always sit under their unit frame; move/size them by moving/sizing the frame. So the
    -- only settings are which buckets to show, plus icon size.
    return {
        { type = "checkbox", name = "Buffs", width = "full",
          tooltip = "Short-term combat buffs (Major/Minor buffs, your ability buffs).",
          getFunc = function() return svf.showBuffs ~= false end,
          setFunc = function(v) svf.showBuffs = v; self:Refresh(); self:AfterShowChange() end },
        { type = "checkbox", name = "Debuffs", width = "full",
          tooltip = "Debuffs on the unit.",
          getFunc = function() return svf.showDebuffs ~= false end,
          setFunc = function(v) svf.showDebuffs = v; self:Refresh(); self:AfterShowChange() end },
        { type = "checkbox", name = "Long-term (Mundus, food, ESO Plus)", width = "full",
          tooltip = "Persistent buffs: Mundus stone, food & drink, ESO Plus / Battle Spirit, and long (2-20 min) buffs. Shown first, wrapping at the bar width.",
          getFunc = function() return svf.showLong ~= false end,
          setFunc = function(v) svf.showLong = v; self:Refresh(); self:AfterShowChange() end },
        { type = "header", name = "Layout" },
        { type = "slider", name = "Icon size", min = 20, max = 72, step = 1, width = "full",
          getFunc = function() return svf.iconSize or 38 end,
          setFunc = function(v) svf.iconSize = v; self:Refresh() end },
    }
end

-- Free-float (Base UI) controls: opt in to replace ESO's native buffs with our categorized,
-- movable auras. Category toggles share the same sv as the attached mode (same preferences).
function Display:BaseControls()
    local svf = self.sv
    local off = function() return svf.showInBase ~= true end
    return {
        { type = "checkbox", name = "Show these auras in Base UI", width = "full",
          tooltip = "Show Shoyru's categorized, movable auras instead of ESO's native buff display for this unit (Base game UI only). Hides the native buff bar while on.",
          getFunc = function() return svf.showInBase == true end,
          setFunc = function(v) svf.showInBase = v; self:Apply(); self:AfterShowChange() end },
        { type = "checkbox", name = "Unlock (drag to move)", width = "full",
          disabled = off,
          getFunc = function() return svf.baseLocked == false end,
          setFunc = function(v) svf.baseLocked = not v; self:Apply() end },
        { type = "slider", name = "Row width", min = 80, max = 800, step = 10, width = "full",
          disabled = off,
          getFunc = function() return svf.baseWidth or 320 end,
          setFunc = function(v) svf.baseWidth = v; self:Refresh() end },
        { type = "header", name = "Shown" },
        { type = "checkbox", name = "Buffs", width = "full", disabled = off,
          getFunc = function() return svf.showBuffs ~= false end,
          setFunc = function(v) svf.showBuffs = v; self:Refresh(); self:AfterShowChange() end },
        { type = "checkbox", name = "Debuffs", width = "full", disabled = off,
          getFunc = function() return svf.showDebuffs ~= false end,
          setFunc = function(v) svf.showDebuffs = v; self:Refresh(); self:AfterShowChange() end },
        { type = "checkbox", name = "Long-term (Mundus, food, ESO Plus)", width = "full", disabled = off,
          getFunc = function() return svf.showLong ~= false end,
          setFunc = function(v) svf.showLong = v; self:Refresh(); self:AfterShowChange() end },
        { type = "slider", name = "Icon size", min = 20, max = 72, step = 1, width = "full", disabled = off,
          getFunc = function() return svf.iconSize or 38 end,
          setFunc = function(v) svf.iconSize = v; self:Refresh() end },
        { type = "button", name = "Reset position", width = "full", disabled = off,
          func = function() svf.baseX, svf.baseY = nil, nil; self:ApplyLayout() end },
    }
end

-- ===========================================================================
-- Module
-- ===========================================================================

-- Aura controls for a given unit frame, so they can live INSIDE that frame's submenu in the
-- UI Layout panel (buffs belong with their frame). Returns nil if this frame has no aura display.
-- A flat control list (no nested submenu) — safe to append into the frame's submenu.
function AU.ControlsForFrame(frameId)
    for _, d in ipairs(AURA_DEFS) do
        if d.frame == frameId then
            local disp = AU.displays[d.id]
            if not disp then return nil end
            local out = { { type = "header", name = "Auras (buffs & debuffs)" } }
            for _, c in ipairs(disp:PanelControls()) do out[#out + 1] = c end
            return out
        end
    end
    return nil
end

local function FillDefaults(t, d)
    for k, v in pairs(d) do
        if t[k] == nil then t[k] = (type(v) == "table") and ZO_DeepTableCopy(v) or v end
    end
end

function AU.ApplyAll()
    for _, disp in pairs(AU.displays) do disp:Apply() end
end

-- True if any aura display is set to show. UnitFrames uses this to decide whether to hide
-- ESO's native buff bar (only hide it when our auras are actually replacing it).
function AU.AnyDisplayShown()
    for _, disp in pairs(AU.displays) do
        if disp:AnyShown() then return true end
    end
    return false
end

-- True if any display opted into Base-UI free mode → hide ESO's native buff bar in Base UI too.
function AU.AnyShowInBase()
    for _, disp in pairs(AU.displays) do
        if disp.sv.showInBase == true then return true end
    end
    return false
end

-- True if the display for a given unit tag ("player" / "reticleover") opted into Base-UI auras.
-- UnitFrames uses this to hide ONLY that unit's native buffs (not the whole bar).
function AU.ShowInBaseForUnit(unitTag)
    for _, disp in pairs(AU.displays) do
        if disp.def.unit == unitTag and disp.sv.showInBase == true then return true end
    end
    return false
end

-- Base-UI free-float aura controls for a unit frame's own "Base game — … buffs" submenu.
function AU.BaseControlsFor(frameId)
    for _, d in ipairs(AURA_DEFS) do
        if d.frame == frameId then
            local disp = AU.displays[d.id]
            return disp and disp:BaseControls()
        end
    end
    return nil
end

function AU.UpdateAllVisibility()
    for _, disp in pairs(AU.displays) do if disp.frame then disp:UpdateVisibility() end end
end

-- /shoyrbuffdump — record the player's active effects (id, name, duration, derived category)
-- to SV + chat, so unrecognized food/class/race ids can be baked into AuraCat.OVERRIDE later.
function AU.Dump()
    sv.dump = {}
    local function add(id, name, startT, endT, effectType, artificial)
        local dur = (endT and endT > 0) and (endT - (startT or 0)) or 0
        local cat = AC.Of(id, effectType, startT or 0, endT or 0, artificial)
        sv.dump[#sv.dump + 1] = { id = id or 0, name = name or "?", dur = math.floor(dur), cat = cat, art = artificial or false }
        d(string.format("[Shoyru's UI] %-28s id=%-7s %4ds  %s", tostring(name), tostring(id or "-"), math.floor(dur), cat))
    end
    for i = 1, GetNumBuffs("player") do
        local name, startT, endT, _, _, _, _, effectType, _, _, abilityId = GetUnitBuffInfo("player", i)
        add(abilityId, name, startT, endT, effectType, false)
    end
    if ZO_GetNextActiveArtificialEffectIdIter then
        for effectId in ZO_GetNextActiveArtificialEffectIdIter do
            local name, _, effectType, _, startT, endT = GetArtificialEffectInfo(effectId)
            add(nil, (name or "?") .. " (artificial)", startT, endT, effectType, true)
        end
    end
    d("[Shoyru's UI] Buff dump: " .. #sv.dump .. " effects saved (SavedVariables \226\134\146 auras.dump). /reloadui then send the file.")
end

function AU.Init(aurasSv)
    sv = aurasSv
    sv.displays = sv.displays or {}
    for _, d in ipairs(AURA_DEFS) do
        sv.displays[d.id] = sv.displays[d.id] or {}
        FillDefaults(sv.displays[d.id], DisplayDefaults(d))
        AU.displays[d.id] = Display.New(d, sv.displays[d.id])
    end

    for _, d in ipairs(AURA_DEFS) do
        local id, unit = d.id, d.unit
        local name = "ShoyrUI_Aura_" .. id
        EVENT_MANAGER:RegisterForEvent(name, EVENT_EFFECT_CHANGED, function()
            local disp = AU.displays[id]
            if disp and disp.frame and (disp:AnyShown() or disp:Editing()) then disp:Refresh() end
        end)
        EVENT_MANAGER:AddFilterForEvent(name, EVENT_EFFECT_CHANGED, REGISTER_FILTER_UNIT_TAG, unit)
    end
    -- Target display: re-scan + re-evaluate visibility when the reticle target changes.
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_AuraReticle", EVENT_RETICLE_TARGET_CHANGED, function()
        local disp = AU.displays.target
        if disp and disp.frame then disp:Refresh(); disp:UpdateVisibility() end
    end)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_AuraActivated", EVENT_PLAYER_ACTIVATED, AU.ApplyAll)

    EVENT_MANAGER:RegisterForUpdate("ShoyrUI_AuraTick", TICK_MS, function()
        for _, disp in pairs(AU.displays) do disp:Tick() end
    end)

    -- Menu open/close re-shows/hides the unit frames; our attached auras piggyback on frame
    -- visibility, so just refresh visibility promptly (rather than waiting for the next tick).
    local function onHudScene()
        AU.menuOpen = not ((HUD_SCENE and HUD_SCENE:IsShowing()) or (HUD_UI_SCENE and HUD_UI_SCENE:IsShowing()))
        AU.UpdateAllVisibility()
    end
    if HUD_SCENE then HUD_SCENE:RegisterCallback("StateChange", onHudScene) end
    if HUD_UI_SCENE then HUD_UI_SCENE:RegisterCallback("StateChange", onHudScene) end

    SLASH_COMMANDS["/shoyrbuffdump"] = AU.Dump   -- capture active effects to grow the category DB

    AU.ApplyAll()
    -- UnitFrames.Init ran its first Apply before our displays existed, so re-assert the native
    -- buff-bar hide now that AnyDisplayShown() can answer correctly.
    if ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.ApplyNativeBuffs then
        ShoyrUI.UnitFrames.ApplyNativeBuffs()
    end
end
