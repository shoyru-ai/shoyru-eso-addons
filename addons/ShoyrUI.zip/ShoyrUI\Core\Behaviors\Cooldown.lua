-- ShoyrUI :: Core/Behaviors/Cooldown.lua
-- The `cooldown` (internal-cooldown / proc) archetype: a set/ability procs, runs
-- an active window, then can't fire again until its internal cooldown elapses.
-- Three states: ACTIVE (proc up) -> COOLDOWN (counting down) -> READY (available,
-- fires a one-shot "off cooldown" alert). Covers Zaan, Maarselok, most monster
-- sets, Mechanical Acuity, etc.
--
-- DATA NOTE: ESO exposes no API for a set's internal cooldown, so cooldownMs is
-- curated (harvested from set bonus text — see Defaults.SET_COOLDOWN_SEC). The
-- ICD is measured from PROC START ("can occur once every X seconds"), so the
-- active window is part of the cooldown, and READY is therefore an estimate.
-- See Behaviors/Stack.lua for the behavior interface + displayState contract.

ShoyrUI = ShoyrUI or {}
ShoyrUI.Behaviors = ShoyrUI.Behaviors or {}

local B = {}
B.__index = B
ShoyrUI.Behaviors.cooldown = B

local function GetNowMs() return GetFrameTimeMilliseconds() end
local Secs = ShoyrUI.FmtTimer   -- global timer format (integer / one-decimal)

function B.New(config)
    local self = setmetatable({}, B)
    self.config     = config
    self.procStartMs = nil
    self.activeEndMs = 0
    self.cdEndMs     = 0
    self.readyFired  = true
    self._pvStep, self._pvStart = nil, 0
    return self
end

function B:Reset()
    self.procStartMs = nil
    self.activeEndMs, self.cdEndMs = 0, 0
    self.readyFired = true
end

function B:OnEffect(changeType, beginTime, endTime, stackCount, unitId)
    local now = GetNowMs()

    if changeType == EFFECT_RESULT_FADED then
        -- Proc ended early — clamp the active window to now; cooldown keeps
        -- running from proc start (the ICD doesn't care when the buff faded).
        if self.procStartMs then self.activeEndMs = math.min(self.activeEndMs, now) end
        return
    end

    local procDur = self.config.defaultDurationMs or 5000
    if beginTime and endTime and endTime > beginTime then
        procDur = (endTime - beginTime) * 1000
    end
    self.procStartMs = now
    self.activeEndMs = now + procDur
    self.cdEndMs     = now + (self.config.cooldownMs or 0)
    if self.cdEndMs < self.activeEndMs then self.cdEndMs = self.activeEndMs end
    self.readyFired  = false
end

function B:Compute(now)
    local c = self.config
    if not self.procStartMs then return nil end

    if now < self.activeEndMs then
        local total = math.max(1, self.activeEndMs - self.procStartMs)
        local rem = self.activeEndMs - now
        return { text = c.activeText or "PROC!", color = c.activeColor or { r=1,g=0.3,b=0.3,a=1 },
                 barPct = rem / total, timerText = Secs(rem), active = true }

    elseif now < self.cdEndMs then
        local total = math.max(1, self.cdEndMs - self.activeEndMs)
        local rem = self.cdEndMs - now
        return { text = c.cooldownText or "CD", color = c.cooldownColor or { r=0.6,g=0.6,b=0.6,a=1 },
                 barPct = rem / total, timerText = Secs(rem), active = false }

    else
        if c.readyAlert and not self.readyFired then
            ShoyrUI.PlaySoundAtVolume(c.readySound, c.soundVolume)
        end
        self.readyFired = true
        if c.showReady == false then return nil end
        return { text = c.readyText or "READY", color = c.readyColor or { r=0.4,g=0.85,b=0.4,a=1 },
                 barPct = 1, timerText = nil, active = false }
    end
end

-- Stay busy until the ready transition has fired its one-shot alert, so the tick
-- loop doesn't stop before READY is rendered/announced.
function B:IsBusy(now)
    if not self.procStartMs then return false end
    return now < self.cdEndMs or not self.readyFired
end

function B:PreviewSteps() return 3 end

function B:PreviewState(step, now)
    if step ~= self._pvStep then self._pvStep, self._pvStart = step, now end
    local c = self.config
    local elapsed = now - self._pvStart

    if step == 1 then
        local total = c.defaultDurationMs or 5000
        local rem = math.max(0, total - elapsed)
        return { text = c.activeText or "PROC!", color = c.activeColor or { r=1,g=0.3,b=0.3,a=1 },
                 barPct = rem / total, timerText = Secs(rem), active = true }
    elseif step == 2 then
        local total = c.cooldownMs or 8000
        local rem = math.max(0, total - elapsed)
        return { text = c.cooldownText or "CD", color = c.cooldownColor or { r=0.6,g=0.6,b=0.6,a=1 },
                 barPct = rem / total, timerText = Secs(rem), active = false }
    else
        return { text = c.readyText or "READY", color = c.readyColor or { r=0.4,g=0.85,b=0.4,a=1 },
                 barPct = 1, timerText = nil, active = false }
    end
end
