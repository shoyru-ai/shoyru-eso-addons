-- ShoyrUI :: Core/Behaviors/DelayedCast.lua
-- The `delayedCast` archetype: a trigger fires, then a known delay later an effect
-- LANDS — so we show a predictive countdown to impact and alert on landing. Each
-- config.phases entry is one cast that lands after delayMs (e.g. DeepFissure's 1st
-- and 2nd shalk, Proximity Detonation, Meteor). Multiple phases can count down at
-- once; we surface the soonest-to-land. Unlike the other archetypes this needs the
-- abilityId of the effect, so Router passes it into OnEffect.
--
-- Note: delayMs is configured here, but is also auto-measurable later from the
-- Discovered catalog (time between the trigger event and the landing event).
-- See Behaviors/Stack.lua for the behavior interface + displayState contract.

ShoyrUI = ShoyrUI or {}
ShoyrUI.Behaviors = ShoyrUI.Behaviors or {}

local B = {}
B.__index = B
ShoyrUI.Behaviors.delayedCast = B

local FLASH_MS = 700
local function GetNowMs() return GetFrameTimeMilliseconds() end
local function Secs(ms) return string.format("%.1fs", math.max(0, ms) / 1000) end

function B.New(config)
    local self = setmetatable({}, B)
    self.config = config
    self.phases = config.phases or {}
    -- Per-phase runtime: landMs (0 = inactive), fired (sound played for this land).
    self.state = {}
    self.byTrigger = {}                              -- triggerId -> { phaseIndex, ... }
    for i, p in ipairs(self.phases) do
        self.state[i] = { landMs = 0, fired = true }
        local tid = p.triggerId
        if tid and tid ~= 0 then
            self.byTrigger[tid] = self.byTrigger[tid] or {}
            table.insert(self.byTrigger[tid], i)
        end
    end
    self.flashUntil, self.flashIdx = 0, nil
    self._pvStep, self._pvStart = nil, 0
    return self
end

function B:Reset()
    for i in ipairs(self.phases) do self.state[i] = { landMs = 0, fired = true } end
    self.flashUntil, self.flashIdx = 0, nil
end

-- abilityId tells us which cast fired; start that phase's countdown to impact.
function B:OnEffect(changeType, beginTime, endTime, stackCount, unitId, abilityId)
    if changeType == EFFECT_RESULT_FADED then return end
    local idxs = abilityId and self.byTrigger[abilityId]
    if not idxs then return end
    local now = GetNowMs()
    for _, i in ipairs(idxs) do
        self.state[i].landMs = now + (self.phases[i].delayMs or 0)
        self.state[i].fired  = false
    end
end

function B:Compute(now)
    -- Fire land alerts for any phase whose impact moment just passed.
    for i, st in ipairs(self.state) do
        if st.landMs > 0 and not st.fired and now >= st.landMs then
            local p = self.phases[i]
            if p.playSound then ShoyrUI.PlaySoundAtVolume(p.sound, self.config.soundVolume) end
            st.fired = true
            self.flashUntil, self.flashIdx = now + FLASH_MS, i
            st.landMs = 0
        end
    end

    -- Prefer the soonest pending impact (the next thing to dodge).
    local bestIdx, bestRem
    for i, st in ipairs(self.state) do
        if st.landMs > now then
            local rem = st.landMs - now
            if not bestRem or rem < bestRem then bestIdx, bestRem = i, rem end
        end
    end
    if bestIdx then
        local p = self.phases[bestIdx]
        return { text = p.text or "CAST", color = p.color or { r=0.95,g=0.83,b=0.49,a=1 },
                 barPct = bestRem / math.max(1, p.delayMs or 1), timerText = Secs(bestRem) }
    end

    -- Brief "landed" flash after impact when nothing else is pending.
    if self.flashIdx and now < self.flashUntil then
        local p = self.phases[self.flashIdx]
        return { text = (p.text or "CAST") .. " LAND", color = p.color or { r=0.91,g=0.32,b=0.32,a=1 },
                 barPct = 1, timerText = nil }
    end
    return nil
end

function B:IsBusy(now)
    for _, st in ipairs(self.state) do
        if st.landMs > now or (st.landMs > 0 and not st.fired) then return true end
    end
    return now < self.flashUntil
end

function B:PreviewSteps() return math.max(1, #self.phases) end

function B:PreviewState(step, now)
    if step ~= self._pvStep then self._pvStep, self._pvStart = step, now end
    local p = self.phases[step] or self.phases[1]
    if not p then return { text = "CAST", color = { r=0.95,g=0.83,b=0.49,a=1 }, barPct = 0 } end
    -- Loop on a modulo clock so a single-phase tracker (PreviewSteps == 1, step never
    -- changes) keeps animating instead of freezing at landed.
    local total = p.delayMs or 2000
    local rem = total - ((now - self._pvStart) % total)
    return { text = p.text or "CAST", color = p.color or { r=0.95,g=0.83,b=0.49,a=1 },
             barPct = rem / total, timerText = Secs(rem) }
end
