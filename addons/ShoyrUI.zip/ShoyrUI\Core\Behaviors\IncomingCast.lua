-- ShoyrUI :: Core/Behaviors/IncomingCast.lua
-- The `incomingCast` archetype: warn about an ENEMY cast landing ON YOU after a
-- windup, so you can time a roll dodge. First instance = Fossilize/Petrify/
-- Shattering Rocks (folded in from the standalone ShoyruFossilizeAlert). Beyond a
-- plain countdown it adds two things the generic archetypes don't:
--   * back-to-back bait detection — a 2nd cast within a window flips the
--     message/color (the classic "dodge the first, eat the second" follow-up).
--   * CC-immunity suppression — no alert while you're already CC-immune (just
--     broke free / roll-dodged), because the stun can't land anyway.
--
-- This archetype needs the combat log, not just buff changes, so it opts into the
-- Router's combat channel (B.usesCombatEvent). The Router feeds it two streams:
--   b:OnCombatEvent(result, abilityId, sourceUnitId, hitValue)  -- EVENT_COMBAT_EVENT (target=player)
--   b:OnPlayerEffect(changeType, beginTime, endTime, abilityId) -- EVENT_EFFECT_CHANGED on player
-- The normal byAbility channel (b:OnEffect) is a no-op here.
--
-- See Behaviors/Stack.lua for the behavior interface + displayState contract.

ShoyrUI = ShoyrUI or {}
ShoyrUI.Behaviors = ShoyrUI.Behaviors or {}

local B = {}
B.__index = B
B.usesCombatEvent = true          -- Router routes EVENT_COMBAT_EVENT to us
ShoyrUI.Behaviors.incomingCast = B

local GOLD = { r = 0.95, g = 0.83, b = 0.49, a = 1 }
local RED  = { r = 0.91, g = 0.32, b = 0.32, a = 1 }

-- Synthetic result for an EFFECT_CHANGED refresh (never collides with ACTION_RESULT_*).
local SYNTHETIC_RESULT_REFRESH = -1
local IMMUNITY_FLAG_MS = 7000     -- fallback CC-immunity window after break-free
local CC_IMMUNITY_ABILITY_ID = 28301

-- Known CC-immunity buff ids (suppress alerts while any is active). Ported from the
-- standalone; a tracker may extend via config.immunityIds.
local DEFAULT_IMMUNITY_IDS = {
    [28301] = true, [21558] = true, [21577] = true, [21587] = true,
    [21597] = true, [21606] = true, [76618] = true, [99830] = true, [123653] = true,
}

local function GetNowMs() return GetFrameTimeMilliseconds() end
local Secs = ShoyrUI.FmtTimer   -- global timer format (integer / one-decimal)

function B.New(config)
    local self = setmetatable({}, B)
    self.config = config
    self:Reset()
    return self
end

function B:Reset()
    self.castActive   = false
    self.castStartedMs, self.castEndMs, self.castDurationMs = 0, 0, 0
    self.isRepeat     = false
    self.lastCastEndedMs = 0
    -- dedup of the EFFECT_GAINED + EFFECT_GAINED_DURATION pair ESO fires per cast
    self.lastTriggerResult, self.lastTriggerSourceUnitId, self.lastTriggerMs = 0, 0, 0
    self.immuneUntilMs = 0
    self._pvStep, self._pvStart = nil, 0
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

function B:IsTrigger(abilityId)
    if not abilityId then return false end
    for _, id in ipairs(self.config.abilityIds or {}) do
        if id == abilityId then return true end
    end
    return false
end

function B:IsImmunityId(abilityId)
    if not abilityId then return false end
    if DEFAULT_IMMUNITY_IDS[abilityId] then return true end
    local extra = self.config.immunityIds
    return extra ~= nil and extra[abilityId] == true
end

-- Longest CC-immunity remaining (ms): our tracked flag + a live buff scan. The
-- 20s sanity cap guards against a time-domain shift permanently suppressing alerts.
function B:GetImmunityRemainingMs()
    local now = GetNowMs()
    local maxRem = math.max(0, self.immuneUntilMs - now)
    local nowSecFn = GetFrameTimeSeconds or GetGameTimeSeconds
    if GetNumBuffs and GetUnitBuffInfo and nowSecFn then
        local n = GetNumBuffs("player")
        local nowSec = nowSecFn()
        for i = 1, n do
            local _, _, timeEnding, _, _, _, _, _, _, _, abilityId = GetUnitBuffInfo("player", i)
            if abilityId and self:IsImmunityId(abilityId) and timeEnding then
                local remMs = (timeEnding - nowSec) * 1000
                if remMs > 20000 then remMs = 0 end
                if remMs > maxRem then maxRem = remMs end
            end
        end
    end
    return maxRem
end

-- Begin (or refresh) a cast alert. Mirrors the standalone's StartCastAlert: immunity
-- suppression, paired-event dedup, and first-vs-back-to-back classification.
function B:StartCastAlert(result, sourceUnitId)
    local c = self.config
    local now = GetNowMs()
    local castTime = c.castTimeMs or 1100
    local window   = c.backToBackMs or 6000

    -- Suppress only if the immunity will still be active when the stun LANDS. A cast
    -- that starts in the immunity tail but lands after it expires is the bait — alert.
    if c.suppressOnImmune ~= false and self:GetImmunityRemainingMs() > castTime + 200 then
        self.lastCastEndedMs = now + castTime   -- so the next one reads as back-to-back
        return
    end

    -- Collapse the GAINED + GAINED_DURATION pair (same cast, ~same frame, same source).
    local sameSource = (sourceUnitId == nil) or (self.lastTriggerSourceUnitId == 0)
        or (sourceUnitId == self.lastTriggerSourceUnitId)
    local isPairedSameCast =
        ((self.lastTriggerResult == ACTION_RESULT_EFFECT_GAINED and result == ACTION_RESULT_EFFECT_GAINED_DURATION)
         or (self.lastTriggerResult == ACTION_RESULT_EFFECT_GAINED_DURATION and result == ACTION_RESULT_EFFECT_GAINED))
    local isContinuation = self.castActive and isPairedSameCast
        and (now - self.lastTriggerMs) < 300 and sameSource

    self.lastTriggerResult = result or 0
    self.lastTriggerSourceUnitId = sourceUnitId or self.lastTriggerSourceUnitId
    self.lastTriggerMs = now
    if isContinuation then return end

    -- New cast. Back-to-back if the previous alert is still up OR ended within window.
    local repeatCast = false
    if self.castActive then
        repeatCast = true
    elseif self.lastCastEndedMs > 0 and (now - self.lastCastEndedMs) <= window then
        repeatCast = true
    end

    self.isRepeat = repeatCast
    self.castActive = true
    self.castStartedMs = now
    self.castEndMs = now + castTime
    self.castDurationMs = castTime

    if c.playSound then ShoyrUI.PlaySoundAtVolume(c.sound, c.soundVolume) end
end

-- ---------------------------------------------------------------------------
-- Router-fed inputs
-- ---------------------------------------------------------------------------

-- EVENT_COMBAT_EVENT (filtered to target=player by the Router).
function B:OnCombatEvent(result, abilityId, sourceUnitId, hitValue)
    local now = GetNowMs()

    -- ACTION_RESULT_IMMUNE proves immunity right now but not for how long; flag
    -- briefly and let the buff events supply the real end time.
    if result == ACTION_RESULT_IMMUNE then
        self.immuneUntilMs = math.max(self.immuneUntilMs, now + 1000)
    end
    -- The CC Immunity buff landing on us is the precise signal; hitValue = duration ms.
    if abilityId == CC_IMMUNITY_ABILITY_ID
       and (result == ACTION_RESULT_EFFECT_GAINED or result == ACTION_RESULT_EFFECT_GAINED_DURATION) then
        local dur = (hitValue and hitValue > 0) and hitValue or IMMUNITY_FLAG_MS
        self.immuneUntilMs = math.max(self.immuneUntilMs, now + dur)
    end

    if not self:IsTrigger(abilityId) then return end
    if result == ACTION_RESULT_BEGIN
       or result == ACTION_RESULT_EFFECT_GAINED
       or result == ACTION_RESULT_EFFECT_GAINED_DURATION
       or result == ACTION_RESULT_STUNNED then
        self:StartCastAlert(result, sourceUnitId)
    end
end

-- EVENT_EFFECT_CHANGED on the player (immunity refresh + the cast's UPDATED refresh
-- that ESO sometimes sends instead of a fresh COMBAT GAINED for a re-application).
function B:OnPlayerEffect(changeType, beginTime, endTime, abilityId)
    if self:IsImmunityId(abilityId) then
        if changeType == EFFECT_RESULT_FADED then
            self.immuneUntilMs = math.min(self.immuneUntilMs, GetNowMs())
        else
            local durMs = IMMUNITY_FLAG_MS
            if beginTime and endTime and endTime > beginTime then durMs = (endTime - beginTime) * 1000 end
            self.immuneUntilMs = math.max(self.immuneUntilMs, GetNowMs() + durMs)
        end
        return
    end
    if not self:IsTrigger(abilityId) then return end
    if changeType == EFFECT_RESULT_UPDATED then
        self:StartCastAlert(SYNTHETIC_RESULT_REFRESH, nil)
    end
end

-- Normal byAbility channel is unused for this archetype.
function B:OnEffect() end

-- ---------------------------------------------------------------------------
-- Render state
-- ---------------------------------------------------------------------------

function B:Compute(now)
    if self.castActive and now >= self.castEndMs then
        self.lastCastEndedMs = self.castEndMs
        self.castActive = false
        self.castEndMs = 0
    end
    if not self.castActive then return nil end   -- nothing to show when idle
    local c = self.config
    local rem = self.castEndMs - now
    local total = (self.castDurationMs > 0) and self.castDurationMs or (c.castTimeMs or 1100)
    local color = self.isRepeat and (c.repeatColor or RED) or (c.firstColor or GOLD)
    local text  = self.isRepeat and (c.repeatText or "ROLL AGAIN!") or (c.firstText or "ROLL NOW!")
    return { text = text, color = color, barPct = math.min(1, rem / total), timerText = Secs(rem) }
end

function B:IsBusy(now)
    return self.castActive and now < self.castEndMs
end

-- Preview cycles first <-> back-to-back, each a fresh countdown.
function B:PreviewSteps() return 2 end

function B:PreviewState(step, now)
    if step ~= self._pvStep then self._pvStep, self._pvStart = step, now end
    local c = self.config
    local total = c.castTimeMs or 1100
    local rem = math.max(0, total - (now - self._pvStart))
    local isRep = (step == 2)
    local color = isRep and (c.repeatColor or RED) or (c.firstColor or GOLD)
    local text  = isRep and (c.repeatText or "ROLL AGAIN!") or (c.firstText or "ROLL NOW!")
    return { text = text, color = color, barPct = rem / total, timerText = Secs(rem) }
end
