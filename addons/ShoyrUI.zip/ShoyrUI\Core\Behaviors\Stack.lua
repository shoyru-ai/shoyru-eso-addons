-- ShoyrUI :: Core/Behaviors/Stack.lua
-- The `stack` archetype: count stacks toward a payoff, escalate text/color at
-- ascending thresholds, optional time-based color escalation while the top
-- threshold is active. Per-target or single-state. This is the original engine
-- behavior, factored out of Tracker so Tracker is now purely a renderer.
--
-- ============================ BEHAVIOR INTERFACE =============================
-- Every Behaviors/<kind>.lua module implements the same contract. Tracker owns
-- the window/chrome and asks the behavior WHAT to draw via a displayState:
--
--   B.New(config)                 -> behavior instance
--   b:OnEffect(changeType, beginTime, endTime, stackCount, unitId, abilityId)
--                                    consume one EVENT_EFFECT_CHANGED hit
--   b:Compute(now)                -> displayState | nil   (nil = hide)
--   b:IsBusy(now)                 -> bool   (does it still need render ticks?)
--   b:PreviewSteps()              -> int    (how many synthetic preview phases)
--   b:PreviewState(step, now)     -> displayState   (unlock-mode demo, no events)
--   b:Reset()                     -> clear runtime state (optional)
--
-- displayState = {
--   text      = string,           main label
--   color     = {r,g,b,a},        label + bar-fill color
--   stacks    = number | nil,     icon overlay count (shown when > 1)
--   barPct    = number,           0..1 fill fraction
--   timerText = string | nil,     right-aligned timer text
--   active    = boolean | nil,    is the tracked thing currently up (drives the state border)
-- }
-- ============================================================================

ShoyrUI = ShoyrUI or {}
ShoyrUI.Behaviors = ShoyrUI.Behaviors or {}

local B = {}
B.__index = B
ShoyrUI.Behaviors.stack = B

local function GetNowMs() return GetFrameTimeMilliseconds() end

function B.New(config)
    local self = setmetatable({}, B)
    self.config   = config
    self.byTarget = {}                              -- unitId -> {stacks,endMs,durationMs}
    self.active   = { stacks = 0, endMs = 0, durationMs = 0 }
    self.activeId = nil
    self._pvStep, self._pvStart = nil, 0
    return self
end

function B:Reset()
    self.byTarget = {}
    self.active = { stacks = 0, endMs = 0, durationMs = 0 }
    self.activeId = nil
end

-- ---------------------------------------------------------------------------
-- Threshold resolution
-- ---------------------------------------------------------------------------

-- Highest threshold whose stacks requirement is met. Returns idx, threshold.
function B:ResolveThreshold(stacks)
    local thresholds = self.config.thresholds
    if not thresholds then return 0, nil end
    local bestIdx, best = 0, nil
    for i, th in ipairs(thresholds) do
        local req = th.stacks or 1
        if req > 0 and stacks >= req then bestIdx, best = i, th end   -- req<=0 = disabled slot
    end
    return bestIdx, best
end

-- text + color for the current state, honoring optional time escalation.
function B:ResolveDisplay(stacks, remainingMs)
    local c = self.config
    local _, th = self:ResolveThreshold(stacks)
    if not th then
        return (c.name or ""), { r=1, g=1, b=1, a=1 }
    end
    local color = th.color
    -- Optional time-escalation: as the timer drops below each step's atSec, swap
    -- color (steps ordered warn -> urgent so the most urgent applies last). Gated on
    -- escalateOn so the editor can toggle it without deleting the configured steps.
    if th.escalate and th.escalateOn then
        local remainSec = (remainingMs or 0) / 1000
        for _, step in ipairs(th.escalate) do
            if remainSec <= (step.atSec or 0) then color = step.color or color end
        end
    end
    return th.text or c.name or "", color or { r=1, g=1, b=1, a=1 }
end

function B:MaybeFireSound(prevStacks, newStacks)
    if newStacks <= prevStacks then return end
    local prevIdx = select(1, self:ResolveThreshold(prevStacks))
    local newIdx, th = self:ResolveThreshold(newStacks)
    if newIdx > prevIdx and th and th.playSound then
        ShoyrUI.PlaySoundAtVolume(th.sound, self.config.soundVolume)
    end
end

-- ---------------------------------------------------------------------------
-- State update
-- ---------------------------------------------------------------------------

function B:ChooseActive(now)
    local bestId, best = nil, nil
    for id, e in pairs(self.byTarget) do
        if e.endMs <= now then
            self.byTarget[id] = nil
        elseif not best or e.endMs > best.endMs then
            bestId, best = id, e
        end
    end
    if best then
        self.activeId = bestId
        self.active.stacks, self.active.endMs, self.active.durationMs = best.stacks, best.endMs, best.durationMs
    else
        self.activeId = nil
        self.active.stacks, self.active.endMs, self.active.durationMs = 0, 0, 0
    end
end

function B:OnEffect(changeType, beginTime, endTime, stackCount, unitId)
    local now = GetNowMs()
    local key = self.config.perTarget and (unitId or 0) or 0

    if changeType == EFFECT_RESULT_FADED then
        if self.config.perTarget then
            self.byTarget[key] = nil
            self:ChooseActive(now)
        else
            self.active.stacks, self.active.endMs = 0, 0
        end
        return
    end

    local durationMs = self.config.defaultDurationMs or 5000
    if beginTime and endTime and endTime > beginTime then
        durationMs = (endTime - beginTime) * 1000
    end

    local stacks = (stackCount and stackCount > 0) and stackCount or 1
    if self.config.maxStacks and stacks > self.config.maxStacks then
        stacks = self.config.maxStacks
    end

    if self.config.perTarget then
        local prev = self.byTarget[key]
        local prevStacks = (prev and prev.endMs > now) and prev.stacks or 0
        self.byTarget[key] = { stacks = stacks, endMs = now + durationMs, durationMs = durationMs }
        self:ChooseActive(now)
        self:MaybeFireSound(prevStacks, stacks)
    else
        local prevStacks = (self.active.endMs > now) and self.active.stacks or 0
        self.active.stacks, self.active.endMs, self.active.durationMs = stacks, now + durationMs, durationMs
        self:MaybeFireSound(prevStacks, stacks)
    end
end

-- ---------------------------------------------------------------------------
-- Render state
-- ---------------------------------------------------------------------------

local function StateFor(self, stacks, remainingMs, durationMs)
    local c = self.config
    local _, th = self:ResolveThreshold(stacks)
    -- Hidden until stacks reach the first configured alert. To see stacks build
    -- from the start, set the first alert to trigger at 1 (there is no separate
    -- "idle" display any more — it was a redundant threshold-zero). Legacy configs
    -- with a leftover showWhenIdle flag are intentionally ignored.
    if th == nil then return nil end

    local text, color = self:ResolveDisplay(stacks, remainingMs)
    local total = (durationMs and durationMs > 0) and durationMs or (c.defaultDurationMs or 5000)
    local pct = (remainingMs and remainingMs > 0) and math.min(1, remainingMs / total) or 0
    return {
        text      = text,
        color     = color,
        stacks    = (stacks and stacks > 1) and stacks or nil,
        barPct    = pct,
        timerText = (remainingMs and remainingMs > 0) and ShoyrUI.FmtTimer(remainingMs) or nil,
    }
end

function B:Compute(now)
    if self.config.perTarget then self:ChooseActive(now) end
    local a = self.active
    if a.stacks <= 0 or (a.endMs ~= 0 and now >= a.endMs) then
        a.stacks, a.endMs = 0, 0
        return nil
    end
    return StateFor(self, a.stacks, a.endMs - now, a.durationMs)
end

function B:IsBusy(now)
    if self.config.perTarget then
        for _, e in pairs(self.byTarget) do
            if e.endMs > now then return true end
        end
        return false
    end
    return self.active.stacks > 0 and now < self.active.endMs
end

-- ---------------------------------------------------------------------------
-- Preview (synthetic — drives unlock mode with no real events)
-- ---------------------------------------------------------------------------

function B:MaxConfiguredStacks()
    local m = 1
    if self.config.thresholds then
        for _, th in ipairs(self.config.thresholds) do m = math.max(m, th.stacks or 1) end
    end
    return math.max(m, self.config.maxStacks or m)
end

function B:PreviewSteps() return self:MaxConfiguredStacks() + 1 end

function B:PreviewState(step, now)
    if step ~= self._pvStep then self._pvStep, self._pvStart = step, now end
    local dur = self.config.defaultDurationMs or 5000
    local remaining = math.max(0, dur - (now - self._pvStart))
    local stacks = math.min(step, self:MaxConfiguredStacks())
    return StateFor(self, stacks, remaining, dur)
        or { text = self.config.name or "", color = { r=1,g=1,b=1,a=1 }, barPct = remaining/dur }
end
