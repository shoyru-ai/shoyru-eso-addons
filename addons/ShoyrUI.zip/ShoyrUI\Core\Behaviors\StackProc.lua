-- ShoyrUI :: Core/Behaviors/StackProc.lua
-- The `stackProc` hybrid archetype: build stacks like `stack`, and when they hit
-- the proc threshold, fire a timed proc window (and optional cooldown before the
-- stacks can rebuild). Covers Kinras (5 stacks -> Berserk aura) and Siroria-style
-- "stack then pop". A four-phase machine: idle -> build -> proc -> cd -> idle.
-- See Behaviors/Stack.lua for the behavior interface + displayState contract.

ShoyrUI = ShoyrUI or {}
ShoyrUI.Behaviors = ShoyrUI.Behaviors or {}

local B = {}
B.__index = B
ShoyrUI.Behaviors.stackProc = B

local function GetNowMs() return GetFrameTimeMilliseconds() end
local function Secs(ms) return string.format("%.1fs", math.max(0, ms) / 1000) end

function B.New(config)
    local self = setmetatable({}, B)
    self.config = config
    self.phase  = "idle"          -- idle | build | proc | cd
    self.stacks = 0
    self.stackEndMs = 0
    self.procEndMs  = 0
    self.cdEndMs    = 0
    self._pvStep, self._pvStart = nil, 0
    return self
end

function B:Reset()
    self.phase, self.stacks = "idle", 0
    self.stackEndMs, self.procEndMs, self.cdEndMs = 0, 0, 0
end

-- Highest build threshold whose stacks requirement is met -> text, color.
function B:BuildDisplay(stacks)
    local c = self.config
    local text, color = c.idleText or c.name or "", c.idleColor or { r=1,g=1,b=1,a=1 }
    if c.thresholds then
        for _, th in ipairs(c.thresholds) do
            local req = th.stacks or 1
            if req > 0 and stacks >= req then text, color = th.text or text, th.color or color end
        end
    end
    return text, color
end

function B:OnEffect(changeType, beginTime, endTime, stackCount, unitId)
    local now = GetNowMs()
    -- While the proc window or its cooldown is running, ignore further stacks.
    if self.phase == "proc" or self.phase == "cd" then return end

    if changeType == EFFECT_RESULT_FADED then
        self.stacks, self.phase = 0, "idle"
        return
    end

    local dur = self.config.defaultDurationMs or 5000
    if beginTime and endTime and endTime > beginTime then dur = (endTime - beginTime) * 1000 end

    local stacks = (stackCount and stackCount > 0) and stackCount or (self.stacks + 1)
    if self.config.maxStacks and stacks > self.config.maxStacks then stacks = self.config.maxStacks end
    self.stacks, self.stackEndMs, self.stackDurMs = stacks, now + dur, dur

    local proc = self.config.proc
    if proc and stacks >= (proc.atStacks or self.config.maxStacks or stacks) then
        self.phase, self.procEndMs = "proc", now + (proc.durationMs or 5000)
        if proc.playSound then ShoyrUI.PlaySoundAtVolume(proc.sound, self.config.soundVolume) end
    else
        self.phase = "build"
    end
end

function B:Compute(now)
    local c, proc = self.config, self.config.proc

    -- Time-driven transitions.
    if self.phase == "build" and now >= self.stackEndMs then
        self.stacks, self.phase = 0, "idle"
    elseif self.phase == "proc" and now >= self.procEndMs then
        if proc and (proc.cooldownMs or 0) > 0 then
            self.phase, self.cdEndMs = "cd", now + proc.cooldownMs
        else
            self.stacks, self.phase = 0, "idle"
        end
    elseif self.phase == "cd" and now >= self.cdEndMs then
        self.stacks, self.phase = 0, "idle"
    end

    if self.phase == "idle" then return nil end

    if self.phase == "build" then
        local text, color = self:BuildDisplay(self.stacks)
        local total = self.stackDurMs or c.defaultDurationMs or 5000   -- the effect's real duration
        local rem = math.max(0, self.stackEndMs - now)
        return { text = text, color = color,
                 stacks = self.stacks > 1 and self.stacks or nil,
                 barPct = rem / total, timerText = Secs(rem) }

    elseif self.phase == "proc" then
        local total = math.max(1, (proc and proc.durationMs) or 5000)
        local rem = self.procEndMs - now
        return { text = (proc and proc.text) or "PROC!", color = (proc and proc.color) or { r=1,g=0.3,b=0.3,a=1 },
                 barPct = rem / total, timerText = Secs(rem) }

    else -- cd
        local total = math.max(1, (proc and proc.cooldownMs) or 1)
        local rem = self.cdEndMs - now
        return { text = (proc and proc.cdText) or "CD", color = (proc and proc.cdColor) or { r=0.6,g=0.6,b=0.6,a=1 },
                 barPct = rem / total, timerText = Secs(rem) }
    end
end

function B:IsBusy(now) return self.phase ~= "idle" end

function B:MaxStacks() return self.config.maxStacks or (self.config.proc and self.config.proc.atStacks) or 5 end

function B:PreviewSteps()
    local n = self:MaxStacks() + 1                       -- build steps + proc
    if self.config.proc and (self.config.proc.cooldownMs or 0) > 0 then n = n + 1 end   -- + cd
    return n
end

function B:PreviewState(step, now)
    if step ~= self._pvStep then self._pvStep, self._pvStart = step, now end
    local c, proc = self.config, self.config.proc
    local maxS = self:MaxStacks()
    local elapsed = now - self._pvStart

    if step <= maxS then
        local text, color = self:BuildDisplay(step)
        local total = c.defaultDurationMs or 5000
        return { text = text, color = color, stacks = step > 1 and step or nil,
                 barPct = math.max(0, (total - elapsed)) / total, timerText = Secs(total - elapsed) }
    elseif step == maxS + 1 then
        local total = (proc and proc.durationMs) or 5000
        return { text = (proc and proc.text) or "PROC!", color = (proc and proc.color) or { r=1,g=0.3,b=0.3,a=1 },
                 barPct = math.max(0, (total - elapsed)) / total, timerText = Secs(total - elapsed) }
    else
        local total = (proc and proc.cooldownMs) or 4000
        return { text = (proc and proc.cdText) or "CD", color = (proc and proc.cdColor) or { r=0.6,g=0.6,b=0.6,a=1 },
                 barPct = math.max(0, (total - elapsed)) / total, timerText = Secs(total - elapsed) }
    end
end
