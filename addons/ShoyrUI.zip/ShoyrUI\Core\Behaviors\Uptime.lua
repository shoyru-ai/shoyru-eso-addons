-- ShoyrUI :: Core/Behaviors/Uptime.lua
-- The `uptime` archetype: track how long a buff/debuff has left and warn before
-- it drops. No stacks, no thresholds — just a depleting bar + timer, switching to
-- a warn color in the final seconds. Single-state or per-target (debuff uptime on
-- the enemy). Covers Major/Minor buffs, set DoTs, snares, "how long is my X up".
-- See Behaviors/Stack.lua for the full behavior interface + displayState contract.

ShoyrUI = ShoyrUI or {}
ShoyrUI.Behaviors = ShoyrUI.Behaviors or {}

local B = {}
B.__index = B
ShoyrUI.Behaviors.uptime = B

local function GetNowMs() return GetFrameTimeMilliseconds() end

function B.New(config)
    local self = setmetatable({}, B)
    self.config   = config
    self.byTarget = {}
    self.active   = { endMs = 0, durationMs = 0 }
    self.activeId = nil
    self._pvStep, self._pvStart = nil, 0
    return self
end

function B:Reset()
    self.byTarget = {}
    self.active = { endMs = 0, durationMs = 0 }
    self.activeId = nil
end

function B:ChooseActive(now)
    local bestId, best = nil, nil
    for id, e in pairs(self.byTarget) do
        if e.endMs <= now then
            self.byTarget[id] = nil
        elseif not best or e.endMs > best.endMs then
            bestId, best = id, e
        end
    end
    if best then
        self.activeId = bestId
        self.active.endMs, self.active.durationMs = best.endMs, best.durationMs
    else
        self.activeId = nil
        self.active.endMs, self.active.durationMs = 0, 0
    end
end

function B:OnEffect(changeType, beginTime, endTime, stackCount, unitId)
    local now = GetNowMs()
    local key = self.config.perTarget and (unitId or 0) or 0

    if changeType == EFFECT_RESULT_FADED then
        if self.config.perTarget then
            self.byTarget[key] = nil
            self:ChooseActive(now)
        else
            self.active.endMs = 0
        end
        return
    end

    local durationMs = self.config.defaultDurationMs or 5000
    if beginTime and endTime and endTime > beginTime then
        durationMs = (endTime - beginTime) * 1000
    end

    if self.config.perTarget then
        self.byTarget[key] = { endMs = now + durationMs, durationMs = durationMs }
        self:ChooseActive(now)
    else
        self.active.endMs, self.active.durationMs = now + durationMs, durationMs
    end
end

local function StateFor(self, remainingMs, durationMs)
    local c = self.config
    local total = (durationMs and durationMs > 0) and durationMs or (c.defaultDurationMs or 5000)
    local warnMs = (c.warnSec or 0) * 1000
    local color = c.color or { r=1, g=1, b=1, a=1 }
    if warnMs > 0 and remainingMs <= warnMs and c.warnColor then color = c.warnColor end
    return {
        text      = c.text or c.name or "",
        color     = color,
        stacks    = nil,
        barPct    = math.min(1, remainingMs / total),
        timerText = string.format("%.1fs", remainingMs / 1000),
    }
end

function B:Compute(now)
    if self.config.perTarget then self:ChooseActive(now) end
    local a = self.active
    if a.endMs == 0 or now >= a.endMs then
        a.endMs = 0
        return nil
    end
    return StateFor(self, a.endMs - now, a.durationMs)
end

function B:IsBusy(now)
    if self.config.perTarget then
        for _, e in pairs(self.byTarget) do
            if e.endMs > now then return true end
        end
        return false
    end
    return self.active.endMs ~= 0 and now < self.active.endMs
end

function B:PreviewSteps() return 1 end

function B:PreviewState(step, now)
    if step ~= self._pvStep then self._pvStep, self._pvStart = step, now end
    -- Single-step archetype: the preview step never changes, so loop on a modulo
    -- clock (counts down, restarts) instead of relying on a step change to reset.
    local dur = self.config.defaultDurationMs or 5000
    local remaining = dur - ((now - self._pvStart) % dur)
    return StateFor(self, remaining, dur)
end
