-- ShoyrUI :: Core/ConfigWindow.lua
-- A custom settings window — the thing LAM can't do: 3 REAL click-tabs (Trackers /
-- UI Layout / PvP) and, inside Trackers, each tracker as its OWN collapsible row
-- (LAM can't nest collapsibles). It reuses LAM's actual widgets (the global
-- LAMCreateControl[type](parent, data)) so we don't rebuild checkboxes/sliders/etc.
--
-- NON-DESTRUCTIVE: opened with /shoyruwin (or the keybind later). The normal LAM
-- panel ("Shoyru's UI") stays registered and fully working as a fallback, so this
-- window can evolve without risking the settings you rely on. Widget creation is
-- wrapped in pcall — a misbehaving control is skipped, never crashes the window.

ShoyrUI = ShoyrUI or {}
local CW = {}
ShoyrUI.ConfigWindow = CW

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style

local win, tabBar, content, scrollChild
local TABS = { { key = "trackers", label = "Trackers" },
               { key = "layout",   label = "UI Layout" },
               { key = "pvp",      label = "PvP" } }
local currentTab = "trackers"
local tabButtons = {}
local expanded = {}   -- trackerId -> bool (collapsible row state)

local PAD = 16
local W, H = 720, 660

-- ---------------------------------------------------------------------------
-- LAM widget hosting (reuse LAM's real controls in our own container)
-- ---------------------------------------------------------------------------

-- Create one LAM widget under `parent`, anchored below `prev`. Returns the new
-- control (or prev unchanged on failure). Half-width pairing is ignored (all
-- stacked full-width) to keep the layout simple and robust.
local function HostWidget(parent, data, prev)
    if not (LAMCreateControl and LAMCreateControl[data.type]) then return prev end
    local ctrl
    local ok = pcall(function() ctrl = LAMCreateControl[data.type](parent, data) end)
    if not ok or not ctrl then return prev end
    ctrl:ClearAnchors()
    if prev then
        ctrl:SetAnchor(TOPLEFT, prev, BOTTOMLEFT, 0, 12)
    else
        ctrl:SetAnchor(TOPLEFT, parent, TOPLEFT, 0, 0)
    end
    return ctrl
end

local function HostList(parent, optionsTable, prev)
    for _, data in ipairs(optionsTable or {}) do
        prev = HostWidget(parent, data, prev)
    end
    return prev
end

-- ---------------------------------------------------------------------------
-- Content builders (rebuilt on each tab show / refresh)
-- ---------------------------------------------------------------------------

-- Hide existing content before rebuilding a tab. (Controls can't be destroyed in
-- ESO; v1 hides them — a pool/reuse pass is a TODO if churn becomes an issue.)
local function ClearContent()
    if not scrollChild then return end
    for i = 1, scrollChild:GetNumChildren() do
        local c = scrollChild:GetChild(i)
        if c then c:SetHidden(true) end
    end
end

-- A collapsible header row: clicking toggles `expanded[id]` and rebuilds the tab.
local function CollapseRow(parent, label, id, prev)
    local row = WM:CreateControl(nil, parent, CT_CONTROL)
    row:SetDimensions(W - PAD * 3 - 20, 30)
    if prev then row:SetAnchor(TOPLEFT, prev, BOTTOMLEFT, 0, 8)
    else row:SetAnchor(TOPLEFT, parent, TOPLEFT, 0, 0) end
    row:SetMouseEnabled(true)

    local bg = WM:CreateControl(nil, row, CT_BACKDROP)
    bg:SetAnchorFill(row)
    bg:SetCenterColor(0.10, 0.10, 0.13, 0.9)
    if Style then Style.ApplyBorder(bg, { r = 0.25, g = 0.25, b = 0.3, a = 1 }, 2) end

    local arrow = WM:CreateControl(nil, row, CT_LABEL)
    arrow:SetAnchor(LEFT, row, LEFT, 8, 0)
    arrow:SetFont(Style and Style.Font(18, "text") or "ZoFontGameBold")
    arrow:SetText(expanded[id] and "|cffffff\226\150\188|r" or "|cffffff\226\150\182|r")
    arrow:SetColor(0.9, 0.83, 0.49, 1)

    local lbl = WM:CreateControl(nil, row, CT_LABEL)
    lbl:SetAnchor(LEFT, arrow, RIGHT, 8, 0)
    lbl:SetFont(Style and Style.Font(18, "text") or "ZoFontGameBold")
    lbl:SetText(label)
    lbl:SetColor(1, 1, 1, 1)

    row:SetHandler("OnMouseUp", function(_, button, upInside)
        if upInside then expanded[id] = not expanded[id]; CW.Refresh() end
    end)
    return row
end

local function BuildTrackers()
    local prev
    -- Create + catalog hosted from the same options the LAM panel uses would require
    -- refactoring; for v1 the create flow stays in the LAM panel. Here we focus on the
    -- thing LAM can't do: per-tracker collapsible rows.
    local intro = WM:CreateControl(nil, scrollChild, CT_LABEL)
    intro:SetAnchor(TOPLEFT, scrollChild, TOPLEFT, 0, 0)
    intro:SetDimensions(W - PAD * 3 - 20, 40)
    intro:SetFont(Style and Style.Font(16, "text") or "ZoFontGame")
    intro:SetColor(0.8, 0.8, 0.85, 1)
    intro:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    intro:SetText("Click a tracker to expand its settings. (Create new trackers from the /shoyrui panel for now.)")
    prev = intro

    -- Profile switcher — instant, rebuilds this tab. Save/create/delete live in the /shoyrui panel.
    -- Deferred one frame so Load's ConfigWindow.Refresh doesn't rebuild this dropdown mid-callback.
    if ShoyrUI.Profiles then
        prev = HostWidget(scrollChild, {
            type = "dropdown", name = "Active profile", width = "full",
            choices = ShoyrUI.Profiles.List(),
            getFunc = function() return ShoyrUI.sv.activeProfile end,
            setFunc = function(v)
                if v ~= ShoyrUI.sv.activeProfile then zo_callLater(function() ShoyrUI.Profiles.Load(v) end, 0) end
            end,
        }, prev)
    end

    if not (ShoyrUI.Editor and ShoyrUI.trackerOrder) then return end
    for _, id in ipairs(ShoyrUI.trackerOrder) do
        local cfg = ShoyrUI.sv and ShoyrUI.sv.trackers[id]
        if cfg then
            local tag = cfg.builtin and "" or "  *"
            local row = CollapseRow(scrollChild, (cfg.name or id) .. tag, id, prev)
            prev = row
            if expanded[id] then
                -- Host this one tracker's real LAM controls just below its row.
                local sub = WM:CreateControl(nil, scrollChild, CT_CONTROL)
                sub:SetAnchor(TOPLEFT, row, BOTTOMLEFT, 16, 10)
                sub:SetDimensions(W - PAD * 3 - 56, 1)
                local controls = ShoyrUI.Editor.BuildOneTracker and ShoyrUI.Editor.BuildOneTracker(cfg) or {}
                local last = HostList(sub, controls, nil)
                if last then sub:SetHeight(2) end
                prev = last or sub
            end
        end
    end
end

local function BuildLayout()
    if ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.PanelOptions then
        HostList(scrollChild, ShoyrUI.UnitFrames.PanelOptions(), nil)
    end
end

local function BuildPvP()
    local lbl = WM:CreateControl(nil, scrollChild, CT_LABEL)
    lbl:SetAnchor(TOPLEFT, scrollChild, TOPLEFT, 0, 0)
    lbl:SetDimensions(W - PAD * 3 - 20, 200)
    lbl:SetFont(Style and Style.Font(16, "text") or "ZoFontGame")
    lbl:SetColor(0.8, 0.8, 0.85, 1)
    lbl:SetText("PvP module — coming soon.\n\nPlanned: incoming-CC/burst alerts, break-free & roll-dodge resource pips, purge reminders, enemy execute-range, focus-target debuffs, and PvP tracker preset packs.")
end

-- ---------------------------------------------------------------------------
-- Tab switching + window
-- ---------------------------------------------------------------------------

function CW.Refresh()
    if not win or win:IsHidden() then return end
    ClearContent()
    for _, b in pairs(tabButtons) do
        b.bg:SetCenterColor(b.key == currentTab and 0.18 or 0.06, b.key == currentTab and 0.18 or 0.06, b.key == currentTab and 0.22 or 0.08, 1)
    end
    if currentTab == "trackers" then BuildTrackers()
    elseif currentTab == "layout" then BuildLayout()
    else BuildPvP() end
end

function CW.ShowTab(key)
    currentTab = key
    CW.Refresh()
end

local function BuildWindow()
    win = WM:CreateTopLevelWindow("ShoyrUI_ConfigWindow")
    win:SetDimensions(W, H)
    win:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0)
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:SetMouseEnabled(true)
    win:SetDrawTier(DT_HIGH)
    win:SetHidden(true)

    local bg = WM:CreateControl(nil, win, CT_BACKDROP)
    bg:SetAnchorFill(win)
    bg:SetCenterColor(0.05, 0.05, 0.06, 0.96)
    if Style then Style.ApplyBorder(bg, { r = 0.3, g = 0.3, b = 0.35, a = 1 }, 2) end

    local title = WM:CreateControl(nil, win, CT_LABEL)
    title:SetAnchor(TOPLEFT, win, TOPLEFT, PAD, 12)
    title:SetFont(Style and Style.Font(26, "text") or "ZoFontWinH1")
    title:SetText("Shoyru's UI")
    title:SetColor(0.95, 0.83, 0.49, 1)

    local close = WM:CreateControlFromVirtual("ShoyrUI_ConfigClose", win, "ZO_CloseButton")
    close:SetAnchor(TOPRIGHT, win, TOPRIGHT, -10, 10)
    close:SetHandler("OnClicked", function() CW.Hide() end)
    close:SetHandler("OnMouseUp", function(_, _, upInside) if upInside then CW.Hide() end end)

    -- Tab bar
    tabBar = WM:CreateControl(nil, win, CT_CONTROL)
    tabBar:SetAnchor(TOPLEFT, win, TOPLEFT, PAD, 52)
    tabBar:SetDimensions(W - PAD * 2, 34)
    local prevBtn
    for _, t in ipairs(TABS) do
        local btn = WM:CreateControl(nil, tabBar, CT_CONTROL)
        btn:SetDimensions(150, 32)
        if prevBtn then btn:SetAnchor(LEFT, prevBtn, RIGHT, 6, 0)
        else btn:SetAnchor(LEFT, tabBar, LEFT, 0, 0) end
        btn:SetMouseEnabled(true)
        local btnBg = WM:CreateControl(nil, btn, CT_BACKDROP)
        btnBg:SetAnchorFill(btn)
        btnBg:SetCenterColor(0.06, 0.06, 0.08, 1)
        if Style then Style.ApplyBorder(btnBg, { r = 0.3, g = 0.3, b = 0.35, a = 1 }, 2) end
        local btnLbl = WM:CreateControl(nil, btn, CT_LABEL)
        btnLbl:SetAnchorFill(btn)
        btnLbl:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        btnLbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        btnLbl:SetFont(Style and Style.Font(18, "text") or "ZoFontGameBold")
        btnLbl:SetText(t.label)
        btnLbl:SetColor(1, 1, 1, 1)
        btn:SetHandler("OnMouseUp", function(_, _, upInside) if upInside then CW.ShowTab(t.key) end end)
        tabButtons[t.key] = { bg = btnBg, key = t.key }
        prevBtn = btn
    end

    -- Content area (plain container for v1; a real scroll pane is a TODO once the
    -- structure is proven — keeps this first pass low-risk and dependency-free).
    content = WM:CreateControl(nil, win, CT_CONTROL)
    content:SetAnchor(TOPLEFT, win, TOPLEFT, PAD, 96)
    content:SetAnchor(BOTTOMRIGHT, win, BOTTOMRIGHT, -PAD, -PAD)
    scrollChild = content
end

function CW.Show()
    if not win then
        local ok, err = pcall(BuildWindow)
        if not ok then d("[Shoyru's UI] config window error: " .. tostring(err)); return end
    end
    win:SetHidden(false)
    CW.ShowTab(currentTab)
end

function CW.Hide() if win then win:SetHidden(true) end end
function CW.Toggle()
    if win and not win:IsHidden() then CW.Hide() else CW.Show() end
end

function CW.Init()
    SLASH_COMMANDS["/shoyruwin"] = function() CW.Toggle() end
end
