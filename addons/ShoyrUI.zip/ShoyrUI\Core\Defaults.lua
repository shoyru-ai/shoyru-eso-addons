-- ShoyrUI :: Core/Defaults.lua
-- Shared constants, a shared sound helper, and the seed tracker definitions.
-- Seeds prove every archetype renders; the two stack seeds (Bound Armaments,
-- Kjalnar) are the real folded-in trackers, the rest are disabled examples that
-- exist so "Unlock all (preview)" can demonstrate cooldown/uptime/stackProc/
-- delayedCast without needing real combat events.

ShoyrUI = ShoyrUI or {}
local D = {}
ShoyrUI.Defaults = D

-- Standard ESO-feel colors (from the addon-dev memory).
D.GOLD   = { r = 0.95, g = 0.83, b = 0.49, a = 1 }
D.RED    = { r = 0.91, g = 0.32, b = 0.32, a = 1 }
D.AMBER  = { r = 1.00, g = 0.60, b = 0.20, a = 1 }
D.VIVID  = { r = 1.00, g = 0.15, b = 0.15, a = 1 }
D.GREEN  = { r = 0.40, g = 0.85, b = 0.40, a = 1 }
D.GREY   = { r = 0.85, g = 0.85, b = 0.85, a = 1 }
D.BLACK  = { r = 0,    g = 0,    b = 0,    a = 1 }

-- Curated loud sounds (ABILITY_MAJOR_BUFF is too quiet for a combat cue).
D.SOUND_NAMES = {
    "Duel Invite", "Duel Start", "New Notification",
    "Ultimate Ready", "Group Invite", "Alert Error",
}
D.SOUND_KEYS = {
    "DUEL_INVITE_RECEIVED", "DUEL_START", "NEW_NOTIFICATION",
    "ABILITY_ULTIMATE_READY", "GROUP_INVITE", "GENERAL_ALERT_ERROR",
}

-- Shared sound helper. ESO's PlaySound has no volume param; replaying the same
-- sound in one frame sums amplitude, so volume N layers it N times. Used by every
-- behavior module (rising-edge stack alerts, cooldown-ready, delayedCast land).
function ShoyrUI.PlaySoundAtVolume(key, volume)
    local s = key and SOUNDS and SOUNDS[key]
    if not s then return end
    volume = math.max(1, math.floor(volume or 1))
    for _ = 1, volume do PlaySound(s) end
end

-- Global countdown formatting, driven by sv.global.timerFormat. "decimal" (default) =
-- one decimal + "s" ("4.4s"); "integer" = whole seconds rounded UP so an active timer
-- never reads 0 ("5s"). Every behavior routes its timer text through this.
function ShoyrUI.FmtTimer(ms)
    local s = math.max(0, ms or 0) / 1000
    local g = ShoyrUI.sv and ShoyrUI.sv.global
    if g and g.timerFormat == "integer" then
        return string.format("%ds", math.ceil(s))
    end
    return string.format("%.1fs", s)
end

-- Curated classification overrides for the Discovered catalog.
-- cat = "ability" | "buff" | "debuff" | "status" | "set"
D.CATEGORY_OVERRIDES = {
    [203447] = "ability",   -- Bound Armaments (slotted skill, self-buff w/ stacks)
    [133505] = "set",       -- Bone Shattering Trauma (Kjalnar's Nightmare proc)
}

-- abilityId -> source set name. Live registry the Set Browser extends at runtime.
D.SET_NAMES = {
    [133505] = "Kjalnar's Nightmare",
}

-- setId -> { proc abilityId, ... }. Curated fallback for the Set Browser.
D.SET_PROC_IDS = {
    [479] = { 133505 },   -- Kjalnar's Nightmare -> Bone Shattering Trauma
}

-- setId -> internal cooldown seconds. ESO has NO API for ICDs, so these are
-- curated (harvested from set bonus text via the ShoyrUISetDump export — see
-- ShoyrUISetDump_classified.csv). Seeds the cooldown archetype.
D.SET_COOLDOWN_SEC = {
    [479]  = nil,    -- Kjalnar is a stack set, not an ICD proc
    -- examples for reference (filled in as cooldown trackers are added):
    -- Zaan = 20, Maarselok = 10
}

-- Cosmetic/layout defaults merged into every tracker for forward-compat. Covers
-- fields used by all archetypes; archetype-specific fields live on the seeds.
D.TRACKER_COMMON = {
    kind            = "stack",
    enabled         = true,
    barBgColor      = { r = 0, g = 0, b = 0, a = 0.75 },
    borderColor     = { r = 0, g = 0, b = 0, a = 1 },
    borderThickness = 2,
    -- State-driven border (off by default = static borderColor). When on, the border is
    -- borderActiveColor while the tracked effect is up and borderIdleColor while it's down.
    borderStateEnabled = false,
    borderActiveColor  = { r = 0.40, g = 0.85, b = 0.40, a = 1 },
    borderIdleColor    = { r = 0, g = 0, b = 0, a = 1 },
    alwaysShow      = false,   -- keep the tracker on-screen (idle state) when the effect is down
    soundVolume     = 1,
    defaultDurationMs = 5000,
    x = 0, y = -260, w = 220, h = 56, scale = 1,
}

-- Seed trackers. Each is a full tracker config (see DESIGN.md schema).
D.SEED_TRACKERS = {
    -- ===== stack (real, folded-in) ========================================
    {
        id        = "boundArmaments",
        name      = "Bound Armaments",
        builtin   = true,
        kind      = "stack",
        abilityIds = { 203447 },
        watch     = "selfBuff",
        perTarget = false,
        y         = -260,
        thresholds = {
            { stacks = 1, text = "BOUND ARMAMENTS", color = D.GREY },
            { stacks = 8, text = "MAX STACKS", color = D.RED, sound = "DUEL_START", playSound = true },
        },
    },
    {
        id        = "kjalnar",
        name      = "Kjalnar Bone",
        builtin   = true,
        kind      = "stack",
        abilityIds = { 133505 },           -- Bone Shattering Trauma
        watch     = "targetDebuff",
        perTarget = true,
        maxStacks = 5,
        y         = -300,
        thresholds = {
            { stacks = 1, text = "BONE",      color = D.GOLD },
            { stacks = 4, text = "STUN NOW!", color = D.RED, sound = "DUEL_INVITE_RECEIVED", playSound = true,
              escalateOn = true,
              escalate = {
                  { atSec = 2.0, color = D.AMBER },
                  { atSec = 1.0, color = D.VIVID },
              },
            },
        },
    },

    -- ===== incomingCast (real, folded-in from ShoyruFossilizeAlert) =======
    {
        id        = "fossilize",
        name      = "Fossilize Alert",
        builtin   = true,
        kind      = "incomingCast",
        abilityIds = { 32685, 29037, 32678 },  -- Fossilize / Petrify / Shattering Rocks
        watch     = "selfBuff",                 -- unused by incomingCast; harmless
        perTarget = false,
        showWhenIdle = false,                   -- only shows during a cast
        castTimeMs   = 1100,
        backToBackMs = 6000,
        firstText    = "Roll Now!",
        repeatText   = "Roll Again!",
        firstColor   = D.GOLD,
        repeatColor  = D.RED,
        suppressOnImmune = true,
        playSound    = true,
        sound        = "DUEL_INVITE_RECEIVED",
        y            = -200,
    },

    -- (The cooldown/uptime/stackProc/delayedCast example seeds were removed once
    --  the engine was verified. Create real trackers of any archetype via the
    --  Create form + the per-tracker Archetype dropdown.)
}
