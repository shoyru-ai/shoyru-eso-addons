-- ShoyrUI :: Core/Discovered.lua
-- Self-growing catalog of every ability the player encounters. Fed from the
-- Router's single EVENT_EFFECT_CHANGED handler (no extra registration), so the
-- "search/pick an ability to track" UI has real data without a bundled DB or a
-- live dependency on another addon. Same idea as the /skippy capture pattern.

ShoyrUI = ShoyrUI or {}
local Disc = {}
ShoyrUI.Discovered = Disc

local catalog = nil       -- ShoyrUI.sv.discovered : abilityId -> entry
local recording = true
local MAX_ENTRIES = 5000
local catalogVersion = 0  -- bumped when an entry is added/removed (proc-index cache key)

-- entry = { name, icon, count, lastSeen (unix), onPlayer, fromPlayer, onTarget,
--           effectType (BUFF_EFFECT_TYPE_*), status (bool: a CC/elemental status) }

-- Category taxonomy. An effect is classified into exactly one of these so the
-- picker can distinguish a slotted ability from an incoming debuff from a gear
-- set proc. Order here is also the display order of the filter.
Disc.CAT_ABILITY = "ability"
Disc.CAT_BUFF    = "buff"
Disc.CAT_DEBUFF  = "debuff"
Disc.CAT_STATUS  = "status"
Disc.CAT_SET     = "set"

-- Short tag shown in the dropdown label per category.
local CAT_TAG = {
    ability = "Ability", buff = "Buff", debuff = "Debuff",
    status = "Status", set = "Set",
}

local function Defaults()
    return ShoyrUI.Defaults or {}
end

function Disc.Init(svTable, enabled)
    catalog = svTable
    recording = enabled ~= false
end

function Disc.SetRecording(v) recording = v end
function Disc.IsRecording() return recording end

function Disc.Clear()
    if not catalog then return end
    for k in pairs(catalog) do catalog[k] = nil end
    catalogVersion = catalogVersion + 1
end

local function Size()
    local n = 0
    for _ in pairs(catalog) do n = n + 1 end
    return n
end

-- Drop the least-recently-seen entry when we exceed the cap.
local function PruneOldest()
    local oldestId, oldest = nil, nil
    for id, e in pairs(catalog) do
        if not oldest or (e.lastSeen or 0) < oldest then
            oldestId, oldest = id, e.lastSeen or 0
        end
    end
    if oldestId then catalog[oldestId] = nil; catalogVersion = catalogVersion + 1 end
end

-- Called by Router for every effect change (gated cheaply on `recording`).
function Disc.Note(effectName, unitTag, stackCount, iconName, unitId, abilityId,
                   sourceType, effectType, statusEffectType)
    if not recording or not catalog then return end
    if not abilityId or abilityId == 0 then return end

    local e = catalog[abilityId]
    if not e then
        if Size() >= MAX_ENTRIES then PruneOldest() end
        e = { count = 0 }
        catalog[abilityId] = e
        catalogVersion = catalogVersion + 1
    end
    if effectName and effectName ~= "" then e.name = effectName end
    if iconName and iconName ~= "" then e.icon = iconName end
    e.count = (e.count or 0) + 1
    e.lastSeen = GetTimeStamp()
    -- Track the highest stack count ever seen; used to default the archetype
    -- (an effect that has stacked > 1 is a stack mechanic, otherwise uptime).
    if stackCount and stackCount > (e.maxStacks or 0) then e.maxStacks = stackCount end
    if unitTag == "player" then e.onPlayer = true end
    if sourceType == COMBAT_UNIT_TYPE_PLAYER then e.fromPlayer = true end
    if unitTag == "reticleover" then e.onTarget = true end
    -- Type metadata for classification (effectType is the live buff/debuff flag;
    -- the old param-10 buffType is deprecated). Keep the last-seen non-nil value.
    if effectType ~= nil then e.effectType = effectType end
    if statusEffectType ~= nil then
        e.status = (statusEffectType ~= STATUS_EFFECT_TYPE_NONE)
    end
end

-- ---------------------------------------------------------------------------
-- Classification
-- ---------------------------------------------------------------------------

-- LibSets has no abilityId->set reverse lookup, so build one lazily from its
-- proc tables (GetAllSetProcData -> per-set GetSetProcAbilityIds -> GetSetName).
-- LibSets' proc data is community-maintained and can lag, so the curated
-- Defaults.SET_NAMES map always takes precedence; this is the best-effort
-- fallback. nil = not built yet, false = LibSets absent.
local libSetsRev = nil

local function LibSetsSetName(abilityId)
    if libSetsRev == nil then
        if LibSets and LibSets.GetAllSetProcData and LibSets.GetSetProcAbilityIds then
            local map, all = {}, LibSets.GetAllSetProcData()
            if type(all) == "table" then
                for setId in pairs(all) do
                    local name = LibSets.GetSetName and LibSets.GetSetName(setId)
                    local ids = LibSets.GetSetProcAbilityIds(setId)
                    if name and type(ids) == "table" then
                        for _, aid in pairs(ids) do
                            if aid then map[aid] = name end
                        end
                    end
                end
            end
            libSetsRev = map
        else
            libSetsRev = false
        end
    end
    return libSetsRev and libSetsRev[abilityId] or nil
end

-- Resolve an ability id to one of the Disc.CAT_* categories. A curated override
-- table (Defaults.CATEGORY_OVERRIDES) is authoritative — it lets Shoyru tag
-- known ids as a slotted ability or a specific set proc. Everything else is
-- auto-classified from the captured effect metadata. A future LibSets lookup
-- can slot in right before the override fallthrough to auto-detect set procs.
function Disc.CategoryOf(abilityId)
    local D = Defaults()
    local override = D.CATEGORY_OVERRIDES and D.CATEGORY_OVERRIDES[abilityId]
    if override then return override end
    if D.SET_NAMES and D.SET_NAMES[abilityId] then return Disc.CAT_SET end
    if LibSetsSetName(abilityId) then return Disc.CAT_SET end    -- optional, if LibSets installed

    local e = catalog and catalog[abilityId]
    if not e then return Disc.CAT_BUFF end
    if e.status then return Disc.CAT_STATUS end
    if e.effectType == BUFF_EFFECT_TYPE_DEBUFF then return Disc.CAT_DEBUFF end
    return Disc.CAT_BUFF
end

-- Proc ability ids for a set, mined from effects already seen in combat. An
-- effect counts if it reverse-maps to this set (LibSets/curated) OR its own name
-- matches the set name. Lets "pick a set" auto-fill a proc you've encountered,
-- even when LibSets has no proc data for it.
--
-- Indexed (lowercased name -> {id=true}) and rebuilt only when the catalog gains
-- or loses an entry (catalogVersion), so it stays cheap when called once per row
-- in the set-search loop.
local procIndex, procIndexVersion = nil, -1
local function BuildProcIndex()
    procIndex = {}
    for id, e in pairs(catalog) do
        local function put(k)
            if not k or k == "" then return end
            k = k:lower()
            local t = procIndex[k]; if not t then t = {}; procIndex[k] = t end
            t[id] = true
        end
        put(Disc.SetName(id))
        put(e.name)
    end
    procIndexVersion = catalogVersion
end

function Disc.SetProcIdsFromCatalog(setName)
    local out = {}
    if not catalog or not setName or setName == "" then return out end
    if procIndex == nil or procIndexVersion ~= catalogVersion then BuildProcIndex() end
    local t = procIndex[setName:lower()]
    if t then for id in pairs(t) do out[#out + 1] = id end end
    return out
end

-- Display name of the source set for a set-proc id (curated map, LibSets later).
function Disc.SetName(abilityId)
    local D = Defaults()
    if D.SET_NAMES and D.SET_NAMES[abilityId] then return D.SET_NAMES[abilityId] end
    return LibSetsSetName(abilityId)
end

-- Suggest the natural watch-mode for an id from how it was seen / its category.
function Disc.SuggestWatch(abilityId)
    local e = catalog and catalog[abilityId]
    local cat = Disc.CategoryOf(abilityId)
    if cat == Disc.CAT_DEBUFF or cat == Disc.CAT_STATUS or cat == Disc.CAT_SET then
        return "targetDebuff"
    end
    if e and e.onPlayer then return "selfBuff" end
    return "selfBuff"
end

-- Suggest the natural archetype for a captured ability: if it has ever been seen
-- with more than one stack it's a stack mechanic, otherwise track its uptime.
-- (Sets are classified separately from the curated D.SET_KINDS table.)
function Disc.SuggestKind(abilityId)
    local e = catalog and catalog[abilityId]
    if e and e.maxStacks and e.maxStacks > 1 then return "stack" end
    return "uptime"
end

-- Map a precise category to a filter group: Buffs include abilities, Debuffs
-- include status effects, Sets are sets. Any other value matches exactly.
local function InCategoryGroup(cat, group)
    if group == Disc.CAT_BUFF   then return cat == Disc.CAT_BUFF   or cat == Disc.CAT_ABILITY end
    if group == Disc.CAT_DEBUFF then return cat == Disc.CAT_DEBUFF or cat == Disc.CAT_STATUS end
    if group == Disc.CAT_SET    then return cat == Disc.CAT_SET end
    return cat == group
end

-- Sorted, capped list for the picker dropdown.
-- filter     (optional): watch-mode pre-filter. "selfBuff" -> onPlayer,
--                        "targetDebuff"/"reticleDebuff" -> fromPlayer/onTarget.
-- category   (optional): one of Disc.CAT_* to show only that kind (nil = all).
-- nameFilter (optional): substring matched against the effect name OR its id.
-- Returns parallel arrays: labels (display, tagged with category), ids.
function Disc.GetChoices(filter, limit, category, nameFilter)
    limit = limit or 250
    nameFilter = (nameFilter and nameFilter ~= "") and nameFilter:lower() or nil
    local list = {}
    for id, e in pairs(catalog) do
        local keep = true
        if filter == "selfBuff" then
            keep = e.onPlayer
        elseif filter == "targetDebuff" or filter == "reticleDebuff" then
            keep = e.fromPlayer or e.onTarget
        end
        local cat = Disc.CategoryOf(id)
        if keep and category and not InCategoryGroup(cat, category) then keep = false end
        if keep and nameFilter then
            local nm = (e.name or ""):lower()
            if not nm:find(nameFilter, 1, true) and not tostring(id):find(nameFilter, 1, true) then
                keep = false
            end
        end
        if keep then
            list[#list + 1] = {
                id = id, name = e.name or ("#" .. id), last = e.lastSeen or 0,
                cat = cat, icon = e.icon,
            }
        end
    end
    table.sort(list, function(a, b)
        if a.last ~= b.last then return a.last > b.last end
        return a.name < b.name
    end)

    local labels, ids = {}, {}
    for i = 1, math.min(limit, #list) do
        local it = list[i]
        local tag = CAT_TAG[it.cat] or "?"
        if it.cat == Disc.CAT_SET then
            tag = "Set: " .. (Disc.SetName(it.id) or "?")
        end
        -- Inline the effect's own icon when the game reported one (|t..|t markup).
        local prefix = ""
        if it.icon and it.icon ~= "" then
            prefix = zo_iconFormat(it.icon, 24, 24) .. " "
        end
        labels[i] = string.format("%s%s  [%s]  (%d)", prefix, it.name, tag, it.id)
        ids[i] = it.id
    end
    return labels, ids
end

-- Count of catalog entries per category (for filter labels / diagnostics).
function Disc.CategoryCounts()
    local counts = {}
    if catalog then
        for id in pairs(catalog) do
            local c = Disc.CategoryOf(id)
            counts[c] = (counts[c] or 0) + 1
        end
    end
    return counts
end

function Disc.GetName(abilityId)
    local e = catalog and catalog[abilityId]
    return e and e.name
end
