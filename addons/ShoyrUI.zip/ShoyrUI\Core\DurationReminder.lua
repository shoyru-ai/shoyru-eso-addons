-- ShoyrUI :: Core/DurationReminder.lua
-- "Action Duration Reminder" — a strip of ability icons + countdown timers shown above the
-- action bar. When you cast a slotted ability (slots 3-7 + ultimate 8) we record it, then match
-- it to the resulting player-sourced effect to learn its duration. Active abilities persist
-- across a weapon-bar swap, so you can watch the OTHER bar's buffs/DoTs tick down. Anchored to
-- ESO's native action bar, so it works in Base UI and Shoyru's UI alike.
--
-- This is a focused build, not a full clone of the ActionDurationReminder addon: it tracks
-- abilities that produce a matched player effect with a real duration. Description-parsed
-- durations, ground/channel special-casing and multi-target DoTs are intentionally out of scope
-- (see the module header note). Default OFF to avoid double timers if ADR is also installed.

ShoyrUI = ShoyrUI or {}
local DR = {}
ShoyrUI.DurationReminder = DR

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style

local TICK_MS = 100            -- countdown refresh cadence
local MATCH_WINDOW_MS = 2000   -- a cast can be matched to an effect gained within this window
local MAX_ICONS = 12           -- pooled icon widgets
local RECAST_GRACE_MS = 400    -- a FADED within this long after an action was (re)set is the OLD
                               -- instance dying on a recast, not a real end — so it must not purge it
local ABILITY_SLOTS = { [3] = true, [4] = true, [5] = true, [6] = true, [7] = true, [8] = true }
local ABILITY_SLOT_LIST = { 3, 4, 5, 6, 7, 8 }   -- ordered, for the per-slot native-icon timers
-- Only the two real weapon bars produce timers we track. GetActiveHotbarCategory can also return
-- transient/overlay categories (Overload, Werewolf, siege/temporary). Keying an action under one of
-- those piles a stale THIRD icon onto a slot that already shows both weapon-bar copies — the "stack
-- of 3" bug. Restrict tracking to PRIMARY/BACKUP so a slot can only ever hold its two weapon copies.
local WEAPON_HOTBARS = { [HOTBAR_CATEGORY_PRIMARY or 0] = true, [HOTBAR_CATEGORY_BACKUP or 1] = true }

local ICON_BG = { 0.05, 0.05, 0.07, 1 }

DR.DEFAULTS = { enabled = false, inCombatOnly = false, hideBackbar = true }

-- The native ESO "inactive weapon bar" ability preview uses this back-row frame art. We locate
-- controls with this texture at runtime and hide their container (reversible) to remove the
-- duplicate snippet our duration reminder replaces.
local BACKBAR_TEX = "backrow_abilityframe"

local sv = nil
local actions = {}    -- key "hotbar:slot" -> { id, name, icon, slot, hotbar, startMs, endMs, stacks }
local pending = {}    -- recent casts awaiting an effect match: { id, name, icon, slot, hotbar, castMs }
local display = nil   -- { frame, icons = {} }
local activeHotbar = nil
local swapGuardMs = 0 -- until this time, FADED events don't purge tracked actions (see OnWeaponSwap)

local function NowMs() return GetGameTimeMilliseconds() end

-- Normalize an ability/effect name for fuzzy matching (strip non-letters, lowercase).
local function Norm(s) return (s or ""):gsub("%W", ""):lower() end
local function NameMatch(a, b)
    a, b = Norm(a), Norm(b)
    if a == "" or b == "" then return false end
    return a == b or a:find(b, 1, true) ~= nil or b:find(a, 1, true) ~= nil
end

-- Icon-path matching, ported from ADR (fRefinePath/fMatchIconPath). An effect's abilityId and name
-- frequently differ from the slotted ability, but the ICON usually matches — this is ADR's primary
-- fuzzy key. Refine = lowercase, truncate at the first 3-digit group, drop ".dds"; then substring.
local function RefinePath(p)
    if not p or p == "" then return p end
    p = p:lower()
    p = p:match("(.-[0-9][0-9][0-9])") or p
    local i = p:find(".dds", 1, true)
    if i and i > 1 then p = p:sub(1, i - 1) end
    return p
end
local function IconMatch(a, b)
    if not a or not b or a == "" or b == "" or a == "/" or b == "/" then return false end
    if a == b then return true end
    a, b = RefinePath(a), RefinePath(b)
    return a:find(b, 1, true) ~= nil or b:find(a, 1, true) ~= nil
end

local function TimerText(remainSec)
    if remainSec >= 60 then return string.format("%dm", math.floor(remainSec / 60)) end
    if remainSec >= 10 then return string.format("%d", math.ceil(remainSec)) end
    return string.format("%.1f", remainSec)   -- sub-10s: one decimal, like most PvP timers
end

-- The native action-bar slot control for a slot index, to anchor that slot's timer above it
-- (works in keyboard + gamepad per ZO_ActionBar_GetButton). Slot positions are shared across the
-- two weapon bars, so a slot-4 ability's timer sits over the physical slot 4 regardless of bar.
local function SlotControl(slot)
    if ZO_ActionBar_GetButton then
        local b = ZO_ActionBar_GetButton(slot)
        if b and b.slot then return b.slot end
    end
    return nil
end

-- ===========================================================================
-- Display (pooled icon strip)
-- ===========================================================================

local function BuildDisplay()
    if display then return end
    local f = WM:CreateTopLevelWindow("ShoyrUI_DurationReminder")
    f:SetClampedToScreen(true)
    f:SetMouseEnabled(false)
    f:SetMovable(false)
    -- Draw ABOVE the native inactive-bar "mini bar" so our slot-sized opaque cells cover it
    -- (ADR's approach). Highest tier + a high draw level so nothing on the HUD sits over us.
    f:SetDrawTier(DT_HIGH)
    f:SetDrawLayer(DL_OVERLAY)
    f:SetDrawLevel(5)
    display = { frame = f, icons = {} }
    for i = 1, MAX_ICONS do
        local ic = {}
        ic.bg = WM:CreateControl(nil, f, CT_BACKDROP)
        ic.bg:SetDrawLayer(DL_BACKGROUND)
        ic.bg:SetCenterColor(unpack(ICON_BG))
        ic.bg:SetEdgeColor(0, 0, 0, 1)
        ic.icon = WM:CreateControl(nil, ic.bg, CT_TEXTURE)
        ic.icon:SetDrawLayer(DL_CONTROLS)
        ic.timer = WM:CreateControl(nil, ic.bg, CT_LABEL)
        ic.timer:SetDrawLayer(DL_OVERLAY)
        ic.timer:SetColor(1, 1, 1, 1)
        ic.timer:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        ic.timer:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
        ic.stack = WM:CreateControl(nil, ic.bg, CT_LABEL)
        ic.stack:SetDrawLayer(DL_OVERLAY)
        ic.stack:SetColor(1, 0.96, 0.7, 1)
        ic.stack:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
        ic.stack:SetVerticalAlignment(TEXT_ALIGN_TOP)
        ic.bg:SetHidden(true)
        display.icons[i] = ic
    end
    -- Per-slot countdown labels drawn ON the native action-bar icon, for the ability on the CURRENT
    -- bar (no duplicate icon above — the in-bar icon is already visible). Only the OTHER bar's
    -- abilities get an icon+timer cell above the bar (display.icons).
    display.slotTimers = {}
    for _, slot in ipairs(ABILITY_SLOT_LIST) do
        local lbl = WM:CreateControl(nil, f, CT_LABEL)
        lbl:SetDrawTier(DT_HIGH); lbl:SetDrawLayer(DL_OVERLAY); lbl:SetDrawLevel(7)
        lbl:SetColor(1, 1, 1, 1)
        lbl:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        lbl:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
        lbl:SetHidden(true)
        display.slotTimers[slot] = lbl
    end
    DR.Anchor()
end

-- The strip is a full-screen invisible container; each timer icon anchors to its own action-bar
-- slot control, so positioning is driven per-slot (not by the container).
function DR.Anchor()
    if not display then return end
    display.frame:ClearAnchors()
    display.frame:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, 0, 0)
    display.frame:SetDimensions(GuiRoot:GetWidth(), GuiRoot:GetHeight())
end

-- Native HUD push-up — a faithful port of ADR's Patch.lua. When timer cells sit above the action
-- bar, cascade ESO's health/magicka/stamina bars AND the self-buff container UP so nothing
-- overlaps. Each control is moved above the accumulated stack of (timer region + already-moved
-- controls) via rectangle-overlap math, so the buff bar ends up above the moved resource bars
-- rather than being covered. Originals are cached and restored when the timers clear.
-- (In Shoyru's UI these native controls are hidden, so this only shows in Base UI.)
local HUDS = { "ZO_PlayerAttributeHealth", "ZO_PlayerAttributeMagicka",
               "ZO_PlayerAttributeStamina", "ZO_BuffDebuffTopLevelSelfContainer" }
local PUSH_GAP = 5
local hudInfo = nil   -- name -> { point,relTo,relPoint,ox,oy, left,top,right,bottom } (originals)
local pushH = 0       -- currently-applied timer-region height (0 = restored)

local function CacheHuds()
    hudInfo = {}
    for _, n in ipairs(HUDS) do
        local c = _G[n]
        -- Skip HIDDEN or zero-size controls: a hidden control (e.g. the native buff bar when Base-UI
        -- auras replace it, or an empty/collapsed buff bar) has stale geometry that would poison the
        -- cascade and make the health-bar push inconsistent. It doesn't need repositioning anyway.
        if c and not c:IsHidden() and c:GetWidth() > 4 and c:GetHeight() > 4 then
            local ok, point, relTo, relPoint, ox, oy = c:GetAnchor(0)
            if ok then
                hudInfo[n] = { point = point, relTo = relTo, relPoint = relPoint, ox = ox, oy = oy,
                    left = c:GetLeft(), top = c:GetTop(), right = c:GetRight(), bottom = c:GetBottom() }
            end
        end
    end
end

-- ADR's moveUp: shift movingRect up so it clears `rect` (only if they overlap horizontally and
-- are within `gap` vertically); returns the delta applied.
local function MoveUp(mv, rect, gap)
    if mv.left > rect.right or mv.right < rect.left then return 0 end
    if mv.bottom + gap < rect.top or mv.top - gap > rect.bottom then return 0 end
    local delta = rect.top - gap - mv.bottom
    mv.top = mv.top + delta; mv.bottom = mv.bottom + delta
    return delta
end

local function RestoreHuds()
    if not hudInfo then return end
    for _, n in ipairs(HUDS) do
        local c, o = _G[n], hudInfo[n]
        if c and o then c:ClearAnchors(); c:SetAnchor(o.point, o.relTo, o.relPoint, o.ox, o.oy) end
    end
end

-- Push the HUD controls above a timer region of height `timerH` sitting on top of the slots.
local function ApplyPush(timerH)
    if timerH == pushH then return end
    if timerH == 0 then RestoreHuds(); pushH = 0; return end
    -- Re-read the bars' positions each time we start a push (from rest), so if the self-frame mover
    -- (NativeMovers) has repositioned them, we push from — and restore to — their CURRENT spot.
    if pushH == 0 then CacheHuds() end
    local s3, s8 = SlotControl(3), SlotControl(8)
    -- `next(hudInfo)` guards the UI-switch race: right after Shoyru→Base, the native bars can still
    -- be hidden when CacheHuds runs, so it captures nothing. Returning WITHOUT setting pushH (still 0)
    -- makes the next tick re-cache once the bars are laid out — instead of committing an empty push
    -- and then short-circuiting forever (the health bar never getting pushed above the timers).
    if not (s3 and s8 and hudInfo and next(hudInfo)) then return end
    local slotTop = s3:GetTop()                          -- slots don't move, so this is stable
    -- Timer region rect: bounding box of the ability slots, `timerH` tall, sitting on the slots.
    local rectList = { {
        left = math.min(s3:GetLeft(), s8:GetLeft()),
        right = math.max(s3:GetRight(), s8:GetRight()),
        top = slotTop - timerH,
        bottom = slotTop,
    } }
    -- Move the bottom-most controls first so higher ones cascade above them (ADR sorts by bottom).
    local names = {}
    for _, n in ipairs(HUDS) do if hudInfo[n] then names[#names + 1] = n end end
    table.sort(names, function(a, b) return hudInfo[a].bottom > hudInfo[b].bottom end)
    for _, n in ipairs(names) do
        local o = hudInfo[n]
        local r = { left = o.left, top = o.top, right = o.right, bottom = o.bottom }   -- from ORIGINAL geometry
        for _, rect in ipairs(rectList) do MoveUp(r, rect, PUSH_GAP) end
        rectList[#rectList + 1] = r
        local c = _G[n]
        c:ClearAnchors()
        c:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, r.left, r.top)
        c:SetAnchor(BOTTOMRIGHT, GuiRoot, TOPLEFT, r.right, r.bottom)
    end
    pushH = timerH
end

-- Re-read originals (ESO re-lays the HUD out on load/zone): restore with the old cache, then forget.
local function ResetHudCache()
    RestoreHuds()
    hudInfo = nil
    pushH = 0
end

-- Public: call this the moment something else (the self-frame mover) repositions the HUD bars, so
-- the push-up restores its current push, forgets the stale originals, and re-cascades from the new
-- position on the next refresh (instead of short-circuiting and restoring to the old spot later).
function DR.RestorePush()
    ResetHudCache()
end

-- True while the push-up is actively managing the HUD bars (timers up). The self-frame mover uses
-- this to STOP re-anchoring the resource bars while we own them — otherwise it yanks them back down
-- onto the timers each time it re-asserts (e.g. on every target change). We restore them to the
-- mover's saved position when the timers clear.
function DR.IsPushing() return pushH > 0 end

function DR.Refresh()
    if not display then return end
    -- The push-up only applies in BASE UI (in Shoyru's UI the native attribute bars are hidden and
    -- replaced by custom frames). Reset the cached originals whenever the Active UI switches, so a
    -- stale cache from the other UI can't break the push-up.
    local shoyruUI = ShoyrUI.sv and ShoyrUI.sv.layout and ShoyrUI.sv.layout.activeUI == "shoyru"
    if shoyruUI ~= DR.lastShoyruUI then DR.lastShoyruUI = shoyruUI; ResetHudCache() end
    -- If the native buff bar's hidden state flips (Base-UI auras toggled) while timers are up, the
    -- push height is unchanged so ApplyPush would short-circuit — force a clean re-push so the
    -- cascade re-reads which controls are visible.
    local bc = _G["ZO_BuffDebuffTopLevelSelfContainer"]
    local buffHidden = (bc and bc:IsHidden()) or false
    if buffHidden ~= DR.lastBuffHidden then DR.lastBuffHidden = buffHidden; ApplyPush(0) end

    if not sv.enabled then display.frame:SetHidden(true); ApplyPush(0); return end
    if sv.inCombatOnly and not IsUnitInCombat("player") then display.frame:SetHidden(true); ApplyPush(0); return end

    local now = NowMs()
    -- Split each slot's active copies: the CURRENT bar's ability shows its countdown ON its native
    -- in-bar icon (no duplicate); only the OTHER bar's ability gets an icon+timer cell ABOVE the bar
    -- (which is what tells you what's on the bar you're NOT on). At most one of each per slot.
    local activeBySlot, otherBySlot = {}, {}
    for _, a in pairs(actions) do
        if a.endMs > now then
            if a.hotbar == activeHotbar then activeBySlot[a.slot] = a else otherBySlot[a.slot] = a end
        end
    end

    local idx, anyAbove, slotH = 0, false, 50
    -- ABOVE the bar: only the OTHER bar's abilities, one flush cell per slot (no stacking — a slot
    -- has just one other-bar copy). Opaque cell so it covers ESO's native inactive-bar preview.
    for slot, a in pairs(otherBySlot) do
        local slotCtrl = SlotControl(slot)
        if slotCtrl then
            local sw, sh = slotCtrl:GetDimensions()
            if sw < 8 or sh < 8 then sw, sh = 50, 50 end        -- guard if the bar isn't laid out yet
            slotH = sh; anyAbove = true
            local font = math.max(12, math.floor(sh * 0.32))
            idx = idx + 1
            local ic = display.icons[idx]
            if ic then
                ic.bg:ClearAnchors()
                ic.bg:SetAnchor(BOTTOM, slotCtrl, TOP, 0, 0)     -- flush directly above the slot
                ic.bg:SetDimensions(sw, sh)
                ic.bg:SetHidden(false)
                ic.bg:SetAlpha(1)
                ic.icon:ClearAnchors()
                ic.icon:SetAnchor(TOPLEFT, ic.bg, TOPLEFT, 1, 1)
                ic.icon:SetAnchor(BOTTOMRIGHT, ic.bg, BOTTOMRIGHT, -1, -1)
                ic.icon:SetTexture(a.icon ~= "" and a.icon or "/esoui/art/icons/icon_missing.dds")
                ic.icon:SetAlpha(0.6)                            -- other bar → dimmed
                ic.timer:ClearAnchors()
                ic.timer:SetAnchor(BOTTOM, ic.bg, BOTTOM, 0, -1)
                ic.timer:SetDimensions(sw, font + 2)
                ic.timer:SetFont(Style.Font(font, "count"))
                ic.timer:SetText(TimerText(math.max(0, (a.endMs - now) / 1000)))
                ic.timer:SetHidden(false)
                ic.stack:ClearAnchors()
                ic.stack:SetAnchor(TOPRIGHT, ic.bg, TOPRIGHT, -2, 0)
                ic.stack:SetDimensions(sw, font + 2)
                ic.stack:SetFont(Style.Font(font, "count"))
                if a.stacks and a.stacks > 1 then ic.stack:SetText(tostring(a.stacks)); ic.stack:SetHidden(false)
                else ic.stack:SetHidden(true) end
            end
        end
    end
    for i = idx + 1, MAX_ICONS do display.icons[i].bg:SetHidden(true) end

    -- ON the bar: the current bar's ability shows just its countdown on its native icon.
    local anyOnBar = false
    for _, slot in ipairs(ABILITY_SLOT_LIST) do
        local lbl = display.slotTimers[slot]
        local a = activeBySlot[slot]
        local slotCtrl = a and SlotControl(slot)
        if lbl and a and slotCtrl then
            local sw, sh = slotCtrl:GetDimensions()
            if sw < 8 or sh < 8 then sw, sh = 50, 50 end
            local font = math.max(12, math.floor(sh * 0.34))
            lbl:ClearAnchors()
            lbl:SetAnchor(BOTTOM, slotCtrl, BOTTOM, 0, -2)
            lbl:SetDimensions(sw, font + 2)
            lbl:SetFont(Style.Font(font, "count"))
            lbl:SetText(TimerText(math.max(0, (a.endMs - now) / 1000)))
            lbl:SetHidden(false)
            anyOnBar = true
        elseif lbl then
            lbl:SetHidden(true)
        end
    end

    display.frame:SetHidden(not (anyAbove or anyOnBar))
    -- Push the native HUD up only in Base UI, and only for the ABOVE-bar row (the on-icon timers
    -- don't add height). At most one row now (the other bar), so push = one slot height.
    ApplyPush(shoyruUI and 0 or (anyAbove and slotH or 0))
end

-- ===========================================================================
-- Tracking
-- ===========================================================================

local function PrunePending(now)
    for i = #pending, 1, -1 do
        if now - pending[i].castMs > MATCH_WINDOW_MS then table.remove(pending, i) end
    end
end

local function OnSlotUsed(_, slotNum)
    if not sv.enabled or not ABILITY_SLOTS[slotNum] then return end
    local hotbar = GetActiveHotbarCategory()
    if not WEAPON_HOTBARS[hotbar] then return end   -- ignore Overload/Werewolf/temporary bars (see WEAPON_HOTBARS)
    local id = GetSlotBoundId(slotNum, hotbar)
    if not id or id == 0 then return end
    local now = NowMs()
    PrunePending(now)
    local name, icon = GetAbilityName(id) or "", GetSlotTexture(slotNum, hotbar) or ""
    pending[#pending + 1] = { id = id, name = name, icon = icon, slot = slotNum, hotbar = hotbar, castMs = now }
    -- Account for EVERY ability up front: if the skill has a base duration, show a timer immediately
    -- from its GetAbilityDuration; a matched effect (OnEffect) later refines endMs to the real value.
    -- This ensures no gap where an ability has no timer (so the native mini bar never peeks through).
    local base = GetAbilityDuration(id) or 0   -- ms
    if base >= 1000 then
        actions[hotbar .. ":" .. slotNum] = {
            id = id, name = name, icon = icon, slot = slotNum, hotbar = hotbar,
            startMs = now, endMs = now + base, stacks = 0, base = true, setMs = now,
        }
        DR.Refresh()
    end
end

local function OnEffect(_, changeType, _, effectName, unitTag, beginSec, endSec, stacks, iconName,
                        buffType, effectType, abilityType, statusEffectType, unitName, unitId, abilityId, sourceType)
    if not sv.enabled then return end

    -- On fade: drop any tracked action that matches this effect (id, icon, or name) — but NOT one we
    -- just (re)set. Recasting a ground/persistent ability (e.g. Channeled Focus) destroys the old
    -- instance, firing a FADED for it AFTER the recast already refreshed the action; without the
    -- recency check that FADED would wipe the freshly-recast timer. The swap-guard covers the sibling
    -- case where a weapon/hotbar swap briefly flickers a self-buff.
    if changeType == EFFECT_RESULT_FADED then
        if NowMs() < swapGuardMs then return end
        local now = NowMs()
        -- Prefer an EXACT ability-id match; only fall back to fuzzy icon/name when NO tracked action
        -- shares this id. Otherwise fading one ability could also wipe a different ability on the
        -- other bar that merely shares a base icon (morph families, skill vs its set proc art).
        local hasIdMatch = false
        for _, a in pairs(actions) do if a.id == abilityId then hasIdMatch = true; break end end
        for key, a in pairs(actions) do
            local match = hasIdMatch and (a.id == abilityId)
                          or (not hasIdMatch and (IconMatch(a.icon, iconName) or NameMatch(a.name, effectName)))
            if match and now - (a.setMs or 0) > RECAST_GRACE_MS then
                actions[key] = nil
            end
        end
        DR.Refresh()
        return
    end

    local durMs = (endSec - beginSec) * 1000
    if durMs <= 0 then return end   -- permanent / passive: nothing to count down

    -- Match to a recent cast: ability id, else ICON path (ADR's primary fuzzy key), else name.
    local now = NowMs()
    PrunePending(now)
    local match
    for i = #pending, 1, -1 do
        local c = pending[i]
        if c.id == abilityId or IconMatch(c.icon, iconName) or NameMatch(c.name, effectName) then
            match = c; break
        end
    end
    if not match then return end

    local key = match.hotbar .. ":" .. match.slot
    actions[key] = {
        id = match.id, name = match.name, icon = match.icon, slot = match.slot, hotbar = match.hotbar,
        startMs = beginSec * 1000, endMs = endSec * 1000, stacks = stacks or 0, setMs = now,
    }
    DR.Refresh()
end

-- Ground / AoE / channel abilities often don't fire a player-tag EVENT_EFFECT_CHANGED, so their
-- duration never reached OnEffect. ADR gets it from EVENT_COMBAT_EVENT's ACTION_RESULT_EFFECT_
-- GAINED_DURATION, where hitValue = the effect duration in ms. Match it to a recent cast (id →
-- icon → name) and set the timer. Ported from ADR onCombatEventFromPlayer.
local function OnCombatEvent(_, result, _, abilityName, _, _, _, _, _, _, hitValue, _, _, _, _, _, abilityId)
    if not sv.enabled then return end
    if result ~= ACTION_RESULT_EFFECT_GAINED_DURATION or not hitValue or hitValue <= 1000 then return end
    local icon = GetAbilityIcon(abilityId) or ""
    local name = zo_strformat("<<1>>", abilityName or "")
    local now = NowMs()
    PrunePending(now)
    for i = #pending, 1, -1 do
        local c = pending[i]
        if c.id == abilityId or IconMatch(c.icon, icon) or NameMatch(c.name, name) then
            actions[c.hotbar .. ":" .. c.slot] = {
                id = c.id, name = c.name, icon = c.icon, slot = c.slot, hotbar = c.hotbar,
                startMs = now, endMs = now + hitValue, stacks = 0, setMs = now,
            }
            DR.Refresh()
            return
        end
    end
end

local function OnTick()
    if not sv.enabled or not display then return end
    -- Drop expired, then refresh (cheap; keeps timers live and clears finished abilities).
    local now = NowMs()
    for key, a in pairs(actions) do
        if a.endMs <= now then actions[key] = nil end
    end
    DR.Refresh()
end

local function OnWeaponSwap()
    activeHotbar = GetActiveHotbarCategory()
    swapGuardMs = NowMs() + 600   -- ignore transient buff fades caused by the swap for a moment
    DR.ApplyBackbarHide(false)
    DR.Refresh()
end

-- ===========================================================================
-- Native "back bar" preview hide — find controls using the back-row ability art and hide their
-- container (reversibly), so ESO's inactive-bar preview doesn't duplicate our timers.
-- ===========================================================================

local backbarParents = nil   -- cached container controls found by the back-row texture

local function CollectBackbar()
    backbarParents = {}
    local seen = {}
    local function walk(c, depth)
        if not c or depth > 8 then return end
        local tex = (c.GetTextureFileName and c:GetTextureFileName()) or ""
        if tex ~= "" and tex:lower():find(BACKBAR_TEX, 1, true) then
            local p = (c.GetParent and c:GetParent()) or c
            if p and not seen[p] then seen[p] = true; backbarParents[#backbarParents + 1] = p end
        end
        if c.GetNumChildren then
            for i = 1, c:GetNumChildren() do walk(c:GetChild(i), depth + 1) end
        end
    end
    for i = 1, GuiRoot:GetNumChildren() do walk(GuiRoot:GetChild(i), 0) end
end

function DR.ApplyBackbarHide(recollect)
    if recollect or not backbarParents or #backbarParents == 0 then CollectBackbar() end
    local hidden = sv.enabled and sv.hideBackbar ~= false   -- only replace it while our reminder is on
    for _, c in ipairs(backbarParents) do
        if c.SetHiddenForReason then c:SetHiddenForReason("ShoyrUIBackbar", hidden) end
    end
end

-- ===========================================================================
-- Module
-- ===========================================================================

function DR.Apply()
    BuildDisplay()
    DR.Anchor()
    ResetHudCache()           -- re-read HUD anchors (ESO re-lays them out on activate)
    DR.ApplyBackbarHide(true)
    DR.Refresh()
end

function DR.PanelOptions()
    return {
        { type = "description", text = "Countdown timers for your cast abilities. For the bar you're ON, the timer shows on the ability's own icon (no duplicate). For your OTHER bar, the icon + timer appear above that slot, so you can watch its buffs/DoTs tick down at a glance. Works in Base UI and Shoyru's UI. (If you also run the Action Duration Reminder addon, keep only one enabled to avoid double timers.)" },
        { type = "checkbox", name = "Enable duration reminder", width = "full",
          getFunc = function() return sv.enabled end,
          setFunc = function(v) sv.enabled = v; DR.ApplyBackbarHide(true); DR.Refresh() end },
        { type = "checkbox", name = "Only in combat", width = "full",
          getFunc = function() return sv.inCombatOnly end,
          setFunc = function(v) sv.inCombatOnly = v; DR.Refresh() end },
        { type = "checkbox", name = "Hide ESO's inactive-bar preview", width = "full",
          tooltip = "Hides the native faded back-bar ability icons ESO shows above the action bar (our timers replace them). Applies only while the reminder is enabled.",
          getFunc = function() return sv.hideBackbar ~= false end,
          setFunc = function(v) sv.hideBackbar = v; DR.ApplyBackbarHide(true) end },
        -- Note: pushing the health/mag/stam + buff bars up is NOT a toggle — timers stack above the
        -- bar by construction, so it's always on to prevent overlap.
    }
end

local function FillDefaults(t, d)
    for k, v in pairs(d) do if t[k] == nil then t[k] = v end end
end

-- /shoyrbars — identify what's drawing the "tiny snippet" above the bar. Reports whether the
-- known culprits (ADR / SwitchBar addons) are enabled, and the control under the mouse (hover
-- the snippet, then run). If it's an addon → disable it in Esc→Add-Ons; if it's a native control
-- (mouse-enabled) → the chain names it so we can hide it like the buff bar.
local function AddonEnabled(name)
    local mgr = GetAddOnManager and GetAddOnManager()
    if not mgr then return nil end
    for i = 1, mgr:GetNumAddOns() do
        local n, _, _, _, enabled = mgr:GetAddOnInfo(i)
        if n == name then return enabled end
    end
    return nil
end

-- Scan every top-level window's descendants for a VISIBLE control sitting in the band just above
-- the action bar (where the mystery snippet shows) that has a texture or text — catches native,
-- mouse-disabled overlays that GetMouseOverControl can't. Cast an ability first so it's showing.
local function ScanAboveBar()
    local bar = ZO_ActionBar1
    if not bar then d("  no ZO_ActionBar1 to measure against."); return end
    local barTop = bar:GetTop()
    d(string.format("  candidates above the bar (barTop=%d) — cast an ability just before running:", barTop))
    local count = 0
    local function nameOf(c) return (c and c.GetName and c:GetName() ~= "" and c:GetName()) or "<anon>" end
    local function walk(c, depth)
        if not c or depth > 7 or count > 80 then return end
        if c.IsHidden and not c:IsHidden() then
            local ok, top = pcall(function() return c:GetTop() end)
            local tex = (c.GetTextureFileName and c:GetTextureFileName()) or ""
            local txt = (c.GetText and c:GetText()) or ""
            if ok and top and top < barTop and top > barTop - 220 and (tex ~= "" or txt ~= "") then
                count = count + 1
                local parent = c.GetParent and c:GetParent()
                d(string.format("   %s  (parent:%s)  y=%d tex=%s txt=%s", nameOf(c), nameOf(parent), top,
                    tex ~= "" and tex or "-", txt ~= "" and txt or "-"))
            end
        end
        if c.GetNumChildren then
            for i = 1, c:GetNumChildren() do walk(c:GetChild(i), depth + 1) end
        end
    end
    for i = 1, GuiRoot:GetNumChildren() do walk(GuiRoot:GetChild(i), 0) end
    d(string.format("  %d candidate(s). The backrow/ability-icon lines + their PARENT name are what we hide.", count))
end

local function DiagnoseBars()
    d("[Shoyru's UI] Bars diagnostic:")
    for _, n in ipairs({ "ActionDurationReminder", "SwitchBar" }) do
        local e = AddonEnabled(n)
        d(string.format("  addon %s: %s", n, e == nil and "not installed" or (e and "ENABLED" or "disabled")))
    end
    local moc = GetMouseOverControl and GetMouseOverControl()
    if moc then
        d("  control under mouse (parents):")
        local c, depth = moc, 0
        while c and depth < 8 do
            local nm = c.GetName and c:GetName() or ""
            d(string.format("   %s%s", string.rep(". ", depth), (nm ~= "" and nm) or "<anon>"))
            c = c.GetParent and c:GetParent() or nil
            depth = depth + 1
        end
    end
    ScanAboveBar()
end

function DR.Init(drSv)
    sv = drSv
    FillDefaults(sv, DR.DEFAULTS)
    activeHotbar = GetActiveHotbarCategory()

    EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_Slot", EVENT_ACTION_SLOT_ABILITY_USED, OnSlotUsed)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_Effect", EVENT_EFFECT_CHANGED, OnEffect)
    EVENT_MANAGER:AddFilterForEvent("ShoyrUI_DR_Effect", EVENT_EFFECT_CHANGED,
        REGISTER_FILTER_SOURCE_COMBAT_UNIT_TYPE, COMBAT_UNIT_TYPE_PLAYER)
    -- Ground / AoE / channel durations (ACTION_RESULT_EFFECT_GAINED_DURATION, hitValue = ms).
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_CombatEvt", EVENT_COMBAT_EVENT, OnCombatEvent)
    EVENT_MANAGER:AddFilterForEvent("ShoyrUI_DR_CombatEvt", EVENT_COMBAT_EVENT,
        REGISTER_FILTER_SOURCE_COMBAT_UNIT_TYPE, COMBAT_UNIT_TYPE_PLAYER)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_Swap", EVENT_ACTIVE_WEAPON_PAIR_CHANGED, OnWeaponSwap)
    -- Some hotbar swaps (werewolf, siege, etc.) don't change the weapon pair; register for the
    -- hotbar-state event too when the client exposes it.
    if EVENT_ACTIVE_HOTBAR_STATE_CHANGED then
        EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_Hotbar", EVENT_ACTIVE_HOTBAR_STATE_CHANGED, OnWeaponSwap)
    end
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_Combat", EVENT_PLAYER_COMBAT_STATE, function() DR.Refresh() end)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_DR_Activated", EVENT_PLAYER_ACTIVATED, function() DR.Apply() end)
    EVENT_MANAGER:RegisterForUpdate("ShoyrUI_DR_Tick", TICK_MS, OnTick)

    SLASH_COMMANDS["/shoyrbars"] = DiagnoseBars   -- identify the "tiny snippet" source

    DR.Apply()
end
