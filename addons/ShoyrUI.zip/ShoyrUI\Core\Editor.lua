-- ShoyrUI :: Core/Editor.lua
-- The per-tracker config UI. Builds one LAM `submenu` (collapsible header) per
-- tracker — the LUI-style accordion — with fields that vary by the tracker's
-- archetype (cfg.kind). Variable-length config (stack thresholds, delayedCast
-- phases) uses fixed slots; a slot with stacks=0 is inert. A Kind dropdown
-- converts a tracker between archetypes (rebuilds its behavior; the new kind's
-- fields appear after the next /reloadui, since LAM panels are built once).
--
-- Behaviors read their cfg table live (same reference the editor mutates), so
-- most edits take effect on the next tick with no rebuild. Cosmetic edits
-- (border/layout) and watch/abilityId changes call the matching refresh.

ShoyrUI = ShoyrUI or {}
local E = {}
ShoyrUI.Editor = E

local D = ShoyrUI.Defaults

local WATCH_LABELS = { "On me (buff/debuff on me)", "On my target \226\128\148 I apply (debuff/proc)",
                       "On my target \226\128\148 their effect (buff)", "Reticle target \226\128\148 I apply" }
local WATCH_VALUES = { "selfBuff", "targetDebuff", "targetBuff", "reticleDebuff" }
local KIND_LABELS  = { "Stack", "Cooldown (proc/ICD)", "Uptime", "Stack + Proc", "Delayed Cast", "Incoming cast (roll dodge)" }
local KIND_VALUES  = { "stack", "cooldown", "uptime", "stackProc", "delayedCast", "incomingCast" }
local THICK_LABELS = { "Thin", "Medium", "Thick" }
local THICK_VALUES = { 2, 4, 8 }

local NUM_PHASE_SLOTS     = 2

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function R(id) return ShoyrUI.Router.Get(id) end

-- abilityIds list <-> editbox text (commas/spaces both fine on input).
local function IdsToString(ids)
    if not ids or #ids == 0 then return "" end
    local parts = {}
    for _, v in ipairs(ids) do parts[#parts + 1] = tostring(v) end
    return table.concat(parts, ", ")
end
local function StringToIds(s)
    local ids = {}
    for tok in tostring(s or ""):gmatch("%d+") do ids[#ids + 1] = tonumber(tok) end
    return ids
end

local function colorGet(tbl, key)
    return function()
        local c = tbl[key] or { r = 1, g = 1, b = 1, a = 1 }
        return c.r, c.g, c.b, c.a or 1
    end
end
local function colorSet(tbl, key, after)
    return function(r, g, b, a)
        tbl[key] = { r = r, g = g, b = b, a = a or 1 }
        if after then after() end
    end
end

local function Thr(cfg, i)
    cfg.thresholds = cfg.thresholds or {}
    cfg.thresholds[i] = cfg.thresholds[i] or { stacks = 0, text = "", color = ZO_DeepTableCopy(D.GOLD) }
    return cfg.thresholds[i]
end

local function Proc(cfg)
    cfg.proc = cfg.proc or { atStacks = cfg.maxStacks or 5, durationMs = 5000, cooldownMs = 0,
                             text = "PROC", color = ZO_DeepTableCopy(D.RED) }
    return cfg.proc
end

local function Ph(cfg, i)
    cfg.phases = cfg.phases or {}
    cfg.phases[i] = cfg.phases[i] or { triggerId = 0, delayMs = 1500, text = "", color = ZO_DeepTableCopy(D.GOLD) }
    return cfg.phases[i]
end

-- A threshold's time-escalation step n (1 = warn, 2 = urgent). Created lazily with
-- the proven Kjalnar defaults (amber under 2s, red under 1s). Steps are ordered
-- warn -> urgent so the engine applies the most urgent last.
local function EscStep(cfg, i, n)
    local th = Thr(cfg, i)
    th.escalate = th.escalate or {}
    th.escalate[n] = th.escalate[n] or { atSec = (n == 1) and 2.0 or 1.0,
                                         color = ZO_DeepTableCopy(n == 1 and D.AMBER or D.VIVID) }
    return th.escalate[n]
end

-- Re-derive delayedCast abilityIds from its phases and reindex the router. Also
-- clears stale countdown state, since the set of watched trigger ids just changed.
local function ResyncDelayed(cfg)
    local ids, seen = {}, {}
    for _, p in ipairs(cfg.phases or {}) do
        local tid = tonumber(p.triggerId)
        if tid and tid ~= 0 and not seen[tid] then seen[tid] = true; ids[#ids + 1] = tid end
    end
    cfg.abilityIds = ids
    local t = R(cfg.id); if t then t:ResetState() end
    ShoyrUI.Router.Refresh()
end

-- ---------------------------------------------------------------------------
-- Per-kind field groups (each appends LAM controls to `o`)
-- ---------------------------------------------------------------------------

local function SoundDropdown(name, getf, setf)
    return { type = "dropdown", name = name, choices = D.SOUND_NAMES, choicesValues = D.SOUND_KEYS,
             width = "half", getFunc = getf, setFunc = setf }
end

-- One threshold slot's controls (6 widgets). i==1 is the first alert; higher
-- slots are optional. A slot whose trigger count is 0 is simply inactive.
-- opts.optional adds "(optional)" to the header; opts.disabled is a function that
-- greys every input (the header can't be disabled, so it always shows).
local function ThresholdSlot(o, cfg, i, opts)
    opts = opts or {}
    local dis = opts.disabled
    -- Name the tiers by ordinal ("First alert") rather than "Threshold N": the
    -- numbering read as if the Display/idle block above were a "threshold 0".
    local ORDINALS = { "First", "Second", "Third", "Fourth", "Fifth" }
    local hdr = (ORDINALS[i] or ("Alert " .. i)) .. " alert"
    if opts.optional then hdr = hdr .. "  (optional)" end
    o[#o+1] = { type = "header", name = hdr }
    o[#o+1] = { type = "slider", name = "Trigger at this many stacks", min = 0, max = 20, step = 1, width = "full",
                disabled = dis,
                tooltip = "Show this alert once the stack count reaches this number. The highest alert you've reached wins; below the first alert the tracker stays hidden. Set to 0 to turn this alert off.",
                getFunc = function() return Thr(cfg, i).stacks or 0 end,
                setFunc = function(v) Thr(cfg, i).stacks = v end }
    o[#o+1] = { type = "editbox", name = "Text", disabled = dis,
                getFunc = function() return Thr(cfg, i).text or "" end,
                setFunc = function(v) Thr(cfg, i).text = v end }
    o[#o+1] = { type = "colorpicker", name = "Color", disabled = dis,
                getFunc = colorGet(Thr(cfg, i), "color"), setFunc = colorSet(Thr(cfg, i), "color") }
    o[#o+1] = { type = "checkbox", name = "Play sound at this alert", width = "half", disabled = dis,
                getFunc = function() return Thr(cfg, i).playSound end, setFunc = function(v) Thr(cfg, i).playSound = v end }
    local snd = SoundDropdown("Sound", function() return Thr(cfg, i).sound end,
                function(v) Thr(cfg, i).sound = v; ShoyrUI.PlaySoundAtVolume(v, cfg.soundVolume) end)
    snd.disabled = dis
    o[#o+1] = snd

    -- (The per-threshold "Color shifts as it expires" option is pulled from the editor FOR NOW to
    -- keep each threshold compact. The engine still honours th.escalateOn / th.escalate, so any
    -- baked-in escalation — e.g. the Kjalnar seed's amber<2s → red<1s at stun range — keeps working;
    -- EscStep is retained so the option can be re-surfaced later without engine changes.)
end

local function StackFields(o, cfg, id)
    o[#o+1] = { type = "header", name = "Stacks" }
    o[#o+1] = { type = "slider", name = "Clamp stack count to (0 = off)", min = 0, max = 20, step = 1, width = "full",
                tooltip = "The displayed count never shows higher than this — ESO sometimes reports more stacks than the real cap. Leave at 0 (off) unless the count misbehaves. e.g. Kjalnar 5, Bound Armaments 8-12.",
                getFunc = function() return cfg.maxStacks or 0 end,
                setFunc = function(v) cfg.maxStacks = (v > 0) and v or nil end }
    o[#o+1] = { type = "description",
                text = "The tracker stays hidden until stacks reach your First alert. To watch stacks build from the very first one, set the First alert to trigger at 1." }

    -- Two alerts: an early warning + a final alert. (The optional third alert was removed as
    -- clutter — revisit based on need. The engine still applies any thresholds[3] left in a saved
    -- config, so a tracker that already had a third keeps working; it's just not editable here.)
    ThresholdSlot(o, cfg, 1)
    ThresholdSlot(o, cfg, 2)
end

local function CooldownFields(o, cfg, id)
    o[#o+1] = { type = "header", name = "Cooldown" }
    o[#o+1] = { type = "slider", name = "Internal cooldown (sec)", min = 0, max = 60, step = 0.5, decimals = 1, width = "full",
                tooltip = "ESO has no API for set ICDs — set it from the bonus text (\"can occur once every X seconds\").",
                getFunc = function() return (cfg.cooldownMs or 0) / 1000 end,
                setFunc = function(v) cfg.cooldownMs = v * 1000 end }
    o[#o+1] = { type = "editbox", name = "Active text", getFunc = function() return cfg.activeText or "" end,
                setFunc = function(v) cfg.activeText = v end }
    o[#o+1] = { type = "colorpicker", name = "Active color", getFunc = colorGet(cfg, "activeColor"), setFunc = colorSet(cfg, "activeColor") }
    o[#o+1] = { type = "editbox", name = "Cooldown text", getFunc = function() return cfg.cooldownText or "" end,
                setFunc = function(v) cfg.cooldownText = v end }
    o[#o+1] = { type = "colorpicker", name = "Cooldown color", getFunc = colorGet(cfg, "cooldownColor"), setFunc = colorSet(cfg, "cooldownColor") }
    o[#o+1] = { type = "checkbox", name = "Show READY state", getFunc = function() return cfg.showReady ~= false end,
                setFunc = function(v) cfg.showReady = v end }
    o[#o+1] = { type = "editbox", name = "Ready text", getFunc = function() return cfg.readyText or "" end,
                setFunc = function(v) cfg.readyText = v end }
    o[#o+1] = { type = "colorpicker", name = "Ready color", getFunc = colorGet(cfg, "readyColor"), setFunc = colorSet(cfg, "readyColor") }
    o[#o+1] = { type = "checkbox", name = "Alert when off cooldown", width = "half",
                getFunc = function() return cfg.readyAlert end, setFunc = function(v) cfg.readyAlert = v end }
    o[#o+1] = SoundDropdown("Ready sound", function() return cfg.readySound end,
                function(v) cfg.readySound = v; ShoyrUI.PlaySoundAtVolume(v, cfg.soundVolume) end)
end

local function UptimeFields(o, cfg, id)
    o[#o+1] = { type = "header", name = "Uptime" }
    o[#o+1] = { type = "editbox", name = "Text", getFunc = function() return cfg.text or "" end,
                setFunc = function(v) cfg.text = v end }
    o[#o+1] = { type = "colorpicker", name = "Color", getFunc = colorGet(cfg, "color"), setFunc = colorSet(cfg, "color") }
    o[#o+1] = { type = "slider", name = "Warn when under (sec left)", min = 0, max = 20, step = 0.5, decimals = 1, width = "full",
                getFunc = function() return cfg.warnSec or 0 end, setFunc = function(v) cfg.warnSec = v end }
    o[#o+1] = { type = "colorpicker", name = "Warn color", getFunc = colorGet(cfg, "warnColor"), setFunc = colorSet(cfg, "warnColor") }
end

local function StackProcFields(o, cfg, id)
    o[#o+1] = { type = "header", name = "Build (stacks)" }
    o[#o+1] = { type = "slider", name = "Max stacks", min = 1, max = 20, step = 1, width = "full",
                getFunc = function() return cfg.maxStacks or 5 end, setFunc = function(v) cfg.maxStacks = v end }
    o[#o+1] = { type = "editbox", name = "Idle text", getFunc = function() return cfg.idleText or "" end,
                setFunc = function(v) cfg.idleText = v end }
    o[#o+1] = { type = "colorpicker", name = "Idle color", getFunc = colorGet(cfg, "idleColor"), setFunc = colorSet(cfg, "idleColor") }
    o[#o+1] = { type = "header", name = "Proc (at max stacks)" }
    o[#o+1] = { type = "slider", name = "Proc at stacks", min = 1, max = 20, step = 1, width = "full",
                getFunc = function() return Proc(cfg).atStacks or 5 end, setFunc = function(v) Proc(cfg).atStacks = v end }
    o[#o+1] = { type = "editbox", name = "Proc text", getFunc = function() return Proc(cfg).text or "" end,
                setFunc = function(v) Proc(cfg).text = v end }
    o[#o+1] = { type = "colorpicker", name = "Proc color", getFunc = colorGet(Proc(cfg), "color"), setFunc = colorSet(Proc(cfg), "color") }
    o[#o+1] = { type = "slider", name = "Proc duration (sec)", min = 0, max = 30, step = 0.5, decimals = 1, width = "half",
                getFunc = function() return (Proc(cfg).durationMs or 0) / 1000 end, setFunc = function(v) Proc(cfg).durationMs = v * 1000 end }
    o[#o+1] = { type = "slider", name = "Proc cooldown (sec)", min = 0, max = 60, step = 0.5, decimals = 1, width = "half",
                getFunc = function() return (Proc(cfg).cooldownMs or 0) / 1000 end, setFunc = function(v) Proc(cfg).cooldownMs = v * 1000 end }
    o[#o+1] = { type = "checkbox", name = "Play sound on proc", width = "half",
                getFunc = function() return Proc(cfg).playSound end, setFunc = function(v) Proc(cfg).playSound = v end }
    o[#o+1] = SoundDropdown("Proc sound", function() return Proc(cfg).sound end,
                function(v) Proc(cfg).sound = v; ShoyrUI.PlaySoundAtVolume(v, cfg.soundVolume) end)
end

local function DelayedFields(o, cfg, id)
    for i = 1, NUM_PHASE_SLOTS do
        o[#o+1] = { type = "header", name = "Phase " .. i .. "  (trigger id = 0 disables)" }
        o[#o+1] = { type = "editbox", name = "Trigger ability ID", width = "half",
                    getFunc = function() return tostring(Ph(cfg, i).triggerId or 0) end,
                    setFunc = function(v) Ph(cfg, i).triggerId = tonumber(v) or 0; ResyncDelayed(cfg) end }
        o[#o+1] = { type = "slider", name = "Lands after (sec)", min = 0, max = 10, step = 0.1, decimals = 1, width = "half",
                    getFunc = function() return (Ph(cfg, i).delayMs or 0) / 1000 end, setFunc = function(v) Ph(cfg, i).delayMs = v * 1000 end }
        o[#o+1] = { type = "editbox", name = "Text", getFunc = function() return Ph(cfg, i).text or "" end,
                    setFunc = function(v) Ph(cfg, i).text = v end }
        o[#o+1] = { type = "colorpicker", name = "Color", getFunc = colorGet(Ph(cfg, i), "color"), setFunc = colorSet(Ph(cfg, i), "color") }
        o[#o+1] = { type = "checkbox", name = "Play sound on land", width = "half",
                    getFunc = function() return Ph(cfg, i).playSound end, setFunc = function(v) Ph(cfg, i).playSound = v end }
        o[#o+1] = SoundDropdown("Land sound", function() return Ph(cfg, i).sound end,
                    function(v) Ph(cfg, i).sound = v; ShoyrUI.PlaySoundAtVolume(v, cfg.soundVolume) end)
    end
end

local function IncomingCastFields(o, cfg, id)
    o[#o+1] = { type = "header", name = "Incoming cast" }
    o[#o+1] = { type = "editbox", name = "Trigger ability IDs (comma-separated)", width = "full",
                tooltip = "The enemy cast ability ids to warn about. Fossilize defaults: 32685 (Fossilize), 29037 (Petrify), 32678 (Shattering Rocks). Any of them landing on you fires the alert.",
                getFunc = function() return IdsToString(cfg.abilityIds) end,
                setFunc = function(v)
                    cfg.abilityIds = StringToIds(v)
                    local t = R(id); if t then t:ResetState(); t:RefreshIcon() end
                    ShoyrUI.Router.Refresh()
                end }
    o[#o+1] = { type = "slider", name = "Cast time / windup (sec)", min = 0.1, max = 4.0, step = 0.1, decimals = 1, width = "half",
                tooltip = "Time between detecting the cast and the stun landing (~1.1s for Fossilize). The countdown bar runs this long.",
                getFunc = function() return (cfg.castTimeMs or 1100) / 1000 end,
                setFunc = function(v) cfg.castTimeMs = math.floor(v * 1000) end }
    o[#o+1] = { type = "slider", name = "Back-to-back window (sec)", min = 1.0, max = 12.0, step = 0.5, decimals = 1, width = "half",
                tooltip = "A second cast within this many seconds of the first shows the back-to-back message/color instead of the first.",
                getFunc = function() return (cfg.backToBackMs or 6000) / 1000 end,
                setFunc = function(v) cfg.backToBackMs = math.floor(v * 1000) end }
    o[#o+1] = { type = "header", name = "Messages" }
    o[#o+1] = { type = "editbox", name = "First cast message",
                getFunc = function() return cfg.firstText or "" end, setFunc = function(v) cfg.firstText = v end }
    o[#o+1] = { type = "colorpicker", name = "First color", getFunc = colorGet(cfg, "firstColor"), setFunc = colorSet(cfg, "firstColor") }
    o[#o+1] = { type = "editbox", name = "Back-to-back message",
                getFunc = function() return cfg.repeatText or "" end, setFunc = function(v) cfg.repeatText = v end }
    o[#o+1] = { type = "colorpicker", name = "Back-to-back color", getFunc = colorGet(cfg, "repeatColor"), setFunc = colorSet(cfg, "repeatColor") }
    o[#o+1] = { type = "checkbox", name = "Suppress while CC immune", width = "full",
                tooltip = "Don't alert if you currently have CC immunity (just broke free / roll-dodged) — the stun can't land anyway.",
                getFunc = function() return cfg.suppressOnImmune ~= false end,
                setFunc = function(v) cfg.suppressOnImmune = v end }
    o[#o+1] = { type = "checkbox", name = "Play sound on detect", width = "half",
                getFunc = function() return cfg.playSound end, setFunc = function(v) cfg.playSound = v end }
    o[#o+1] = SoundDropdown("Alert sound", function() return cfg.sound end,
                function(v) cfg.sound = v; ShoyrUI.PlaySoundAtVolume(v, cfg.soundVolume) end)
end

local KIND_FIELDS = {
    stack        = StackFields,
    cooldown     = CooldownFields,
    uptime       = UptimeFields,
    stackProc    = StackProcFields,
    delayedCast  = DelayedFields,
    incomingCast = IncomingCastFields,
}

-- ---------------------------------------------------------------------------
-- Submenu assembly
-- ---------------------------------------------------------------------------

local function CommonHead(o, cfg, id)
    o[#o+1] = { type = "checkbox", name = "Enabled", width = "half",
                getFunc = function() return cfg.enabled end,
                setFunc = function(v) cfg.enabled = v; ShoyrUI.Router.Refresh() end }
    o[#o+1] = { type = "dropdown", name = "Archetype (set at creation)", choices = KIND_LABELS, choicesValues = KIND_VALUES, width = "half",
                disabled = true,
                tooltip = "Locked to what you chose when creating this tracker. To use a different archetype, delete this tracker and create a new one — switching in place would leave half-migrated settings behind.",
                getFunc = function() return cfg.kind or "stack" end,
                setFunc = function() end }
    if cfg.kind ~= "delayedCast" and cfg.kind ~= "incomingCast" then
        o[#o+1] = { type = "editbox", name = "Ability ID", width = "half",
                    getFunc = function() return tostring((cfg.abilityIds and cfg.abilityIds[1]) or 0) end,
                    setFunc = function(v)
                        cfg.abilityIds = { tonumber(v) or 0 }
                        local t = R(id); if t then t:ResetState(); t:RefreshIcon() end
                        ShoyrUI.Router.Refresh()   -- re-index byAbility for the new id
                    end }
        o[#o+1] = { type = "dropdown", name = "Track as", choices = WATCH_LABELS, choicesValues = WATCH_VALUES, width = "half",
                    tooltip = "Which unit's copy of the effect to follow. Changing this clears the previous mode's stacks so it doesn't keep showing the old unit's effect.",
                    getFunc = function() return cfg.watch end,
                    setFunc = function(v)
                        cfg.watch = v
                        cfg.perTarget = (v == "targetDebuff" or v == "targetBuff")
                        local t = R(id); if t then t:ResetState() end   -- drop stale per-target/self state
                        ShoyrUI.Router.Refresh()
                    end }
    end
end

local function CosmeticTail(o, cfg, id)
    o[#o+1] = { type = "header", name = "Appearance" }
    o[#o+1] = { type = "checkbox", name = "Icon only (minimal)", width = "full",
                tooltip = "Show just the icon with the countdown + stack count on it \226\128\148 no bar, no name text. Tile several with Snap-to-grid (in this panel, or UI Layout) for a compact \"ice-cube tray\" of icons.",
                getFunc = function() return cfg.iconOnly or false end,
                setFunc = function(v)
                    cfg.iconOnly = v
                    if v then
                        cfg._barW = cfg.w                 -- remember the bar-mode width...
                        if cfg.h then cfg.w = cfg.h end   -- ...then square the window for a clean icon
                    else
                        cfg.w = cfg._barW or 220          -- restore the bar-mode width (220 = default)
                        cfg._barW = nil
                    end
                    local t = R(id); if t then t:ApplyLayout() end
                end }
    o[#o+1] = { type = "colorpicker", name = "Bar background", getFunc = colorGet(cfg, "barBgColor"), setFunc = colorSet(cfg, "barBgColor") }
    o[#o+1] = { type = "colorpicker", name = "Border color", getFunc = colorGet(cfg, "borderColor"),
                setFunc = colorSet(cfg, "borderColor", function() local t = R(id); if t then t:ApplyBorder() end end) }
    o[#o+1] = { type = "dropdown", name = "Border thickness", choices = THICK_LABELS, choicesValues = THICK_VALUES, width = "half",
                getFunc = function() return cfg.borderThickness or 2 end,
                setFunc = function(v) cfg.borderThickness = v; local t = R(id); if t then t:ApplyBorder() end end }
    o[#o+1] = { type = "slider", name = "Sound loudness", min = 1, max = 5, step = 1, width = "half",
                getFunc = function() return cfg.soundVolume or 1 end, setFunc = function(v) cfg.soundVolume = v end }
    o[#o+1] = { type = "button", name = "Reset position/size", width = "half",
                func = function()
                    cfg.x, cfg.y, cfg.h, cfg.scale = 0, -260, 56, 1
                    -- Respect the display mode: an icon-only tracker resets to a square, not a wide bar.
                    cfg.w = cfg.iconOnly and 56 or 220
                    cfg._barW = cfg.iconOnly and 220 or nil
                    local t = R(id); if t then t:ApplyLayout() end
                end }
    o[#o+1] = { type = "button", name = "Delete tracker", width = "half", isDangerous = true,
                warning = "Permanently removes this tracker (takes full effect after /reloadui).",
                disabled = function() return cfg.builtin end,
                func = function()
                    if ShoyrUI.DeleteTracker(id) then d("[Shoyru's UI] Deleted " .. (cfg.name or id) .. " \226\128\148 /reloadui to clear its panel.") end
                end }
end

-- The flat control list for ONE tracker (no header/submenu wrapper). Used by the
-- custom ConfigWindow, which hosts these inside its own collapsible row.
function E.BuildOneTracker(cfg)
    local o, id = {}, cfg.id
    CommonHead(o, cfg, id)
    local fields = KIND_FIELDS[cfg.kind or "stack"]
    if fields then fields(o, cfg, id) end
    CosmeticTail(o, cfg, id)
    return o
end

-- Build one submenu control for a tracker config.
function E.BuildSubmenu(cfg)
    local id = cfg.id
    local o = {}
    CommonHead(o, cfg, id)
    local fields = KIND_FIELDS[cfg.kind or "stack"]
    if fields then fields(o, cfg, id) end
    CosmeticTail(o, cfg, id)

    local tag = cfg.builtin and "" or "  *"
    return { type = "submenu", name = (cfg.name or id) .. tag, controls = o }
end

-- Returns { header, submenu, submenu, ... } for splicing into the LAM panel.
function E.BuildSubmenus()
    local out = { { type = "header", name = "Edit trackers  (click to expand)" } }
    for _, id in ipairs(ShoyrUI.trackerOrder or {}) do
        local cfg = ShoyrUI.sv.trackers[id]
        if cfg then out[#out + 1] = E.BuildSubmenu(cfg) end
    end
    return out
end

-- FLAT version: each tracker as a divider + header + its controls, for hosting
-- INSIDE the "Trackers" tab (LAM can't nest a submenu within a submenu). The divider
-- + bold header visually separate each tracker so it isn't one seamless wall.
function E.BuildFlatControls()
    local out = { { type = "header", name = "Your trackers" } }
    local first = true
    for _, id in ipairs(ShoyrUI.trackerOrder or {}) do
        local cfg = ShoyrUI.sv.trackers[id]
        if cfg then
            if not first then out[#out + 1] = { type = "divider", width = "full", height = 12 } end
            first = false
            local tag = cfg.builtin and "" or "  *"
            out[#out + 1] = { type = "header", name = "\226\150\182  " .. (cfg.name or id) .. tag }
            CommonHead(out, cfg, id)
            local fields = KIND_FIELDS[cfg.kind or "stack"]
            if fields then fields(out, cfg, id) end
            CosmeticTail(out, cfg, id)
        end
    end
    return out
end
