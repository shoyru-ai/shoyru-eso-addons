-- ShoyrUI :: Core/Grid.lua
-- A shared snap-to-grid used by every movable element (custom frames, group frame, action bar,
-- base-game movers) to make alignment easy. Works in both UIs — it just rounds a screen
-- coordinate to the nearest grid step. Optional visual grid overlay while you're positioning.

ShoyrUI = ShoyrUI or {}
local Grid = {}
ShoyrUI.Grid = Grid
local WM = WINDOW_MANAGER

Grid.DEFAULTS = { snap = false, size = 20, show = false }

local sv = nil
local overlay = nil

-- Round a screen coordinate to the grid step (no-op unless snap is on).
function Grid.Snap(v)
    if not sv or not sv.snap or (sv.size or 0) < 2 or not v then return v end
    local s = sv.size
    return math.floor(v / s + 0.5) * s
end

local function BuildOverlay()
    if overlay then return end
    overlay = WM:CreateTopLevelWindow("ShoyrUI_Grid")
    overlay:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, 0, 0)
    overlay:SetDimensions(GuiRoot:GetWidth(), GuiRoot:GetHeight())
    overlay:SetMouseEnabled(false)
    overlay:SetDrawTier(DT_LOW)
    overlay.lines = {}
end

-- Show/refresh the grid overlay (only when snap + show are on and the step isn't too dense).
function Grid.UpdateOverlay()
    if not sv or not (sv.snap and sv.show) or (sv.size or 0) < 10 then
        if overlay then overlay:SetHidden(true) end
        return
    end
    BuildOverlay()
    local w, h = GuiRoot:GetWidth(), GuiRoot:GetHeight()
    local s = sv.size
    local idx = 0
    local function line(x, y, lw, lh)
        idx = idx + 1
        local l = overlay.lines[idx]
        if not l then
            l = WM:CreateControl(nil, overlay, CT_BACKDROP)
            l:SetEdgeColor(0, 0, 0, 0)
            l:SetCenterColor(0.4, 0.7, 1, 0.18)
            overlay.lines[idx] = l
        end
        l:ClearAnchors(); l:SetAnchor(TOPLEFT, overlay, TOPLEFT, x, y); l:SetDimensions(lw, lh)
        l:SetHidden(false)
    end
    for x = 0, w, s do line(x, 0, 1, h) end
    for y = 0, h, s do line(0, y, w, 1) end
    for i = idx + 1, #overlay.lines do overlay.lines[i]:SetHidden(true) end
    overlay:SetHidden(false)
end

-- Top-level controls for the UI Layout panel (apply in both UIs).
function Grid.PanelControls()
    return {
        { type = "checkbox", name = "Snap frames to a grid", width = "full",
          tooltip = "When moving any frame / bar, snap its position to a grid so things line up. Works in both UIs.",
          getFunc = function() return sv.snap end,
          setFunc = function(v) sv.snap = v; Grid.UpdateOverlay() end },
        { type = "slider", name = "Grid size", min = 4, max = 100, step = 1, width = "full",
          disabled = function() return not sv.snap end,
          getFunc = function() return sv.size or 20 end,
          setFunc = function(v) sv.size = v; Grid.UpdateOverlay() end },
        { type = "checkbox", name = "Show grid overlay", width = "full",
          tooltip = "Draw the grid on screen while aligning (grid steps under 10px aren't drawn to avoid clutter).",
          disabled = function() return not sv.snap end,
          getFunc = function() return sv.show end,
          setFunc = function(v) sv.show = v; Grid.UpdateOverlay() end },
    }
end

local function FillDefaults(t, d)
    for k, v in pairs(d) do if t[k] == nil then t[k] = v end end
end

function Grid.Init(gridSv)
    sv = gridSv
    FillDefaults(sv, Grid.DEFAULTS)
    Grid.UpdateOverlay()
end
