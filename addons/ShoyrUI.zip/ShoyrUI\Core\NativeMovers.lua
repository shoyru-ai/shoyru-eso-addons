-- ShoyrUI :: Core/NativeMovers.lua
-- Reposition BASE-GAME HUD elements that Shoyru's custom frames would otherwise replace — the self
-- attribute bars (health/mag/stam) and the target frame. These only apply in Base UI (activeUI ==
-- "base"); in Shoyru's UI they're hidden and the custom frames take over, so the movers stand down.
-- A generic Mover drives a draggable holder; on release we set the controls' absolute positions
-- (a group of controls moves together, preserving their relative offsets). The action bar has its
-- own module (ActionBarMove.lua) since it works in both UIs.
--
-- NOTE: the self attribute bars are also nudged by the DurationReminder push-up. That uses overlap
-- detection, so moving the bars away from above the action bar simply stops the push — they compose.

ShoyrUI = ShoyrUI or {}
local NM = {}
ShoyrUI.NativeMovers = NM
local WM = WINDOW_MANAGER

local function BaseUI()
    return not (ShoyrUI.sv and ShoyrUI.sv.layout and ShoyrUI.sv.layout.activeUI == "shoyru")
end

-- ---------------------------------------------------------------------------
-- Mover component
-- ---------------------------------------------------------------------------
local Mover = {}
Mover.__index = Mover

function Mover.New(def, msv)
    return setmetatable({ def = def, sv = msv, touched = false }, Mover)
end

function Mover:CacheOrig()
    if self.orig then return end
    self.orig = {}
    for _, n in ipairs(self.def.controls) do
        local c = _G[n]
        if c then
            local ok, point, relTo, relPoint, ox, oy = c:GetAnchor(0)
            if ok then self.orig[n] = { point = point, relTo = relTo, relPoint = relPoint, ox = ox, oy = oy } end
        end
    end
end

function Mover:BuildHolder()
    if self.holder then return end
    local h = WM:CreateTopLevelWindow("ShoyrUI_Mover_" .. self.def.id)
    h:SetClampedToScreen(true)
    h:SetDrawTier(DT_HIGH)
    h:SetHandler("OnMoveStop", function()
        local snap = ShoyrUI.Grid and ShoyrUI.Grid.Snap or function(v) return v end
        if self.def.anchor == "center" then     -- save the box's CENTRE offset from screen centre
            self.sv.x = snap(h:GetLeft()) + h:GetWidth() / 2 - GuiRoot:GetWidth() / 2
            self.sv.y = snap(h:GetTop()) + h:GetHeight() / 2 - GuiRoot:GetHeight() / 2
        else
            self.sv.x, self.sv.y = snap(h:GetLeft()), snap(h:GetTop())
        end
        -- Moving the resource bars invalidates the duration-reminder's cached push originals —
        -- reset it BEFORE we re-anchor so it re-cascades from the new position (not the old one).
        if self.def.id == "selfframe" and ShoyrUI.DurationReminder and ShoyrUI.DurationReminder.RestorePush then
            ShoyrUI.DurationReminder.RestorePush()
        end
        self:Apply()
    end)
    h.bg = WM:CreateControl(nil, h, CT_BACKDROP)
    h.bg:SetAnchorFill(h)
    h.bg:SetCenterColor(0.10, 0.30, 0.60, 0.30)
    -- Set an edge TEXTURE before the colour: a bare SetEdgeColor with no edge texture renders a
    -- white-box artifact, so the guide would flash white instead of the intended blue.
    h.bg:SetEdgeTexture(nil, 1, 1, 1, 0)
    h.bg:SetEdgeColor(0.35, 0.55, 0.95, 0.9)
    h.label = WM:CreateControl(nil, h, CT_LABEL)
    h.label:SetAnchor(CENTER)
    h.label:SetFont("ZoFontGameOutline")
    h.label:SetColor(1, 1, 1, 1)
    h.label:SetText(self.def.label)
    -- Start hidden: Apply sizes+positions the holder before it decides to show it, so a holder that
    -- is born visible renders one white frame under the (locked) target frame that ghosts until a
    -- redraw. Born hidden, it only ever appears when Apply explicitly unhides it for editing.
    h:SetHidden(true)
    self.holder = h
end

-- Bounding box of the controls in screen coords (nil if none laid out yet).
function Mover:GroupRect()
    local l, t, r, b
    for _, n in ipairs(self.def.controls) do
        local c = _G[n]
        if c then
            local cl, ct, cr, cb = c:GetLeft(), c:GetTop(), c:GetRight(), c:GetBottom()
            l = l and math.min(l, cl) or cl
            t = t and math.min(t, ct) or ct
            r = r and math.max(r, cr) or cr
            b = b and math.max(b, cb) or cb
        end
    end
    return l, t, r, b
end

function Mover:Restore()
    if self.orig then
        for _, n in ipairs(self.def.controls) do
            local c, o = _G[n], self.orig[n]
            if c and o then c:ClearAnchors(); c:SetAnchor(o.point, o.relTo, o.relPoint, o.ox, o.oy) end
        end
    end
    if self.holder then
        self.holder:SetHidden(true); self.holder:SetMouseEnabled(false); self.holder:SetMovable(false)
    end
end

function Mover:Apply()
    if not self.sv then return end
    self:CacheOrig()
    local moved = (self.sv.x ~= nil and self.sv.y ~= nil)
    if not (BaseUI() and (moved or not self.sv.locked)) then
        if self.touched then self:Restore(); self.touched = false end   -- only undo if WE moved it
        return
    end
    -- CENTRE mode (target frame): the frame is centre-anchored and RESIZES per target type (a PvP
    -- player is wider than an NPC). Anchor by CENTRE so the health bar stays put as it resizes, and
    -- size the box to the CURRENT frame each apply (re-asserted on target change).
    if self.def.anchor == "center" then
        local c = _G[self.def.controls[1]]
        if not c then return end
        local cw, ch = c:GetWidth(), c:GetHeight()
        if cw < 8 then return end                                   -- no target / not laid out yet
        if self.sv.x == nil then
            local ccx, ccy = c:GetCenter()
            self.sv.x, self.sv.y = ccx - GuiRoot:GetWidth() / 2, ccy - GuiRoot:GetHeight() / 2
        end
        self:BuildHolder()
        self.holder:ClearAnchors()
        self.holder:SetDimensions(cw, ch)
        self.holder:SetAnchor(CENTER, GuiRoot, CENTER, self.sv.x, self.sv.y)
        c:ClearAnchors()
        c:SetAnchor(CENTER, GuiRoot, CENTER, self.sv.x, self.sv.y)
        self.touched = true
        local editing = not self.sv.locked
        self.holder:SetHidden(not editing)   -- drag guide only; fully hidden when locked (no artifacts)
        self.holder:SetMouseEnabled(editing); self.holder:SetMovable(editing)
        return
    end
    -- Capture each control's offset from the group's top-left + native group position (once).
    if not self.rel then
        local gl, gt, gr, gb = self:GroupRect()
        if not gl or gr - gl < 4 then return end   -- not laid out (e.g. target frame with no target)
        self.rel, self.gw, self.gh = {}, gr - gl, gb - gt
        for _, n in ipairs(self.def.controls) do
            local c = _G[n]
            if c then self.rel[n] = { dx = c:GetLeft() - gl, dy = c:GetTop() - gt } end
        end
        if self.sv.x == nil then self.sv.x, self.sv.y = gl, gt end   -- default = native position
    end
    self:BuildHolder()
    self.holder:ClearAnchors()
    self.holder:SetDimensions(self.gw or 100, self.gh or 40)
    self.holder:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, self.sv.x, self.sv.y)
    -- While the duration-reminder push-up is actively moving the resource bars, DON'T re-anchor
    -- them here — the push-up owns them and restores to our saved position when timers clear.
    -- Otherwise our re-assert (fires on every target change etc.) would yank them back onto the timers.
    local drOwns = self.def.id == "selfframe" and ShoyrUI.DurationReminder
        and ShoyrUI.DurationReminder.IsPushing and ShoyrUI.DurationReminder.IsPushing()
    if not drOwns then
        for _, n in ipairs(self.def.controls) do
            local c, r = _G[n], self.rel[n]
            if c and r then
                c:ClearAnchors()
                c:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, self.sv.x + r.dx, self.sv.y + r.dy)
            end
        end
    end
    self.touched = true
    local editing = not self.sv.locked
    self.holder:SetHidden(not editing)   -- drag guide only; fully hidden when locked (no artifacts)
    self.holder:SetMouseEnabled(editing)
    self.holder:SetMovable(editing)
end

function Mover:Reset()
    self.sv.x, self.sv.y, self.rel = nil, nil, nil
    self:Apply()
end

function Mover:PanelControls()
    local svm = self.sv
    return {
        { type = "description", text = self.def.desc },
        { type = "checkbox", name = "Unlock (drag to move)", width = "full",
          getFunc = function() return not svm.locked end,
          setFunc = function(v) svm.locked = not v; self:Apply() end },
        { type = "button", name = "Reset to default position", width = "full",
          func = function() self:Reset() end },
    }
end

-- ---------------------------------------------------------------------------
-- Module
-- ---------------------------------------------------------------------------
NM.DEFS = {
    { id = "selfframe", label = "Resources",
      controls = { "ZO_PlayerAttributeHealth", "ZO_PlayerAttributeMagicka", "ZO_PlayerAttributeStamina" },
      desc = "Move the base-game health / magicka / stamina bars (your self frame). Base game UI only — in Shoyru's UI the custom player frame replaces these. Unlock, drag the box, then lock." },
    { id = "targetframe", label = "Target frame", anchor = "center",
      controls = { "ZO_TargetUnitFramereticleover" },
      desc = "Move the base-game target frame (top of screen). Base game UI only — in Shoyru's UI the custom target frame replaces it. You need a target on-screen when you first position it. Unlock, drag, then lock. (Centre-anchored so it stays put whether the target is an NPC or a wider PvP-player frame.)" },
    -- (Base-game buffs are handled by the Auras module's Base-UI mode — categorized + movable —
    --  not a plain mover, so there's no "selfbuffs" entry here.)
}
NM.movers = {}

function NM.ApplyAll()
    for _, m in pairs(NM.movers) do m:Apply() end
end

function NM.ControlsFor(id)
    local m = NM.movers[id]
    return m and m:PanelControls()
end

function NM.Init(nmSv)
    nmSv.movers = nmSv.movers or {}
    for _, def in ipairs(NM.DEFS) do
        nmSv.movers[def.id] = nmSv.movers[def.id] or { locked = true }
        NM.movers[def.id] = Mover.New(def, nmSv.movers[def.id])
    end
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_NM_Activated", EVENT_PLAYER_ACTIVATED, NM.ApplyAll)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_NM_Target", EVENT_RETICLE_TARGET_CHANGED, NM.ApplyAll)
    if HUD_SCENE then HUD_SCENE:RegisterCallback("StateChange", NM.ApplyAll) end
    if HUD_UI_SCENE then HUD_UI_SCENE:RegisterCallback("StateChange", NM.ApplyAll) end
    NM.ApplyAll()
end
