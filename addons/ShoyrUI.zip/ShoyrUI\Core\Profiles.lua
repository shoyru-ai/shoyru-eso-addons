-- ShoyrUI :: Core/Profiles.lua
-- Named config profiles for Shoyru's UI. The LIVE ShoyrUI.sv.* IS the active profile;
-- sv.profiles[name] are stored snapshots. Switching snapshots the current live state back
-- into its slot, copies the target snapshot into the live tables, rebuilds trackers, and
-- calls each module's light re-apply — so a switch is INSTANT with no /reloadui for the HUD.
--
-- CRUCIAL: modules capture references to their sv sub-tables (and nested per-frame/per-display
-- tables) at Init and register events once. So we NEVER swap those references or re-Init — we
-- DeepAssign new values INTO the existing tables (preserving identity) and re-apply. Trackers
-- are the exception: they're destroyed and rebuilt from sv.trackers.

ShoyrUI = ShoyrUI or {}
local P = {}
ShoyrUI.Profiles = P

-- Module config tables copied per profile (trackers handled separately — rebuilt).
local MODULE_TABLES = { "layout", "auras", "bars", "nativemovers", "grid" }
-- Global keys that are per-profile; the rest of sv.global (unlocked/recording/colorClip) is
-- runtime/shared and never switches. discovered + setProcs are learned data — also shared.
local GLOBAL_KEYS = { "uniformH", "uniformW", "uniformScale", "timerFormat" }

-- Recursively overwrite dst from src, PRESERVING dst's table identity at every level so
-- long-lived module / frame / display instances that hold references see the new values in place.
local function DeepAssign(dst, src)
    if type(dst) ~= "table" or type(src) ~= "table" then return end
    for k in pairs(dst) do if src[k] == nil then dst[k] = nil end end
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            DeepAssign(dst[k], v)
        else
            dst[k] = v
        end
    end
end
P.DeepAssign = DeepAssign   -- exposed for tests

local function Snapshot()
    local sv = ShoyrUI.sv
    local snap = { trackers = ZO_DeepTableCopy(sv.trackers or {}), global = {} }
    for _, key in ipairs(MODULE_TABLES) do snap[key] = ZO_DeepTableCopy(sv[key] or {}) end
    for _, gk in ipairs(GLOBAL_KEYS) do snap.global[gk] = sv.global[gk] end
    return snap
end

-- A snapshot is only usable if it actually holds trackers (every real profile has at least the
-- three builtins). This is the guard that stops an empty/corrupt snapshot from WIPING live config.
local function ValidSnapshot(snap)
    return type(snap) == "table" and type(snap.trackers) == "table" and next(snap.trackers) ~= nil
end
P.ValidSnapshot = ValidSnapshot

-- Next free "Profile N" name (used when a new profile is created without an explicit name).
function P.NextName()
    local n = 1
    while ShoyrUI.sv.profiles["Profile " .. n] do n = n + 1 end
    return "Profile " .. n
end

function P.List()
    local names = {}
    for name, snap in pairs(ShoyrUI.sv.profiles or {}) do
        if ValidSnapshot(snap) then names[#names + 1] = name end   -- hide empty/corrupt profiles
    end
    table.sort(names)
    return names
end

function P.Current() return ShoyrUI.sv.activeProfile end

function P.Save(name)
    name = name or ShoyrUI.sv.activeProfile
    if not name or name == "" then return false end
    ShoyrUI.sv.profiles[name] = Snapshot()
    return true
end

-- Boot bootstrap. NEVER wipes: purges any corrupt/empty snapshots, and if no valid profile
-- exists yet captures the user's CURRENT setup as "Profile 1" (so existing configs are preserved
-- exactly, no "Default" placeholder). Only fixes the active pointer otherwise — no load.
function P.Bootstrap()
    ShoyrUI.sv.profiles = ShoyrUI.sv.profiles or {}
    for pname, snap in pairs(ShoyrUI.sv.profiles) do
        if not ValidSnapshot(snap) then ShoyrUI.sv.profiles[pname] = nil end   -- can't be allowed to wipe
    end
    if next(ShoyrUI.sv.profiles) == nil then
        ShoyrUI.sv.activeProfile = "Profile 1"
        P.Save("Profile 1")
        return
    end
    if not ShoyrUI.sv.activeProfile or not ShoyrUI.sv.profiles[ShoyrUI.sv.activeProfile] then
        ShoyrUI.sv.activeProfile = P.List()[1]
    end
end

-- Re-apply every module from the (now updated) live sv. NEVER re-Init (would double-register events).
local function ReapplyAll()
    ShoyrUI.Router.Refresh()
    if ShoyrUI.UnitFrames       then ShoyrUI.UnitFrames.Apply() end
    if ShoyrUI.Auras            then ShoyrUI.Auras.ApplyAll() end
    if ShoyrUI.NativeMovers      then ShoyrUI.NativeMovers.ApplyAll() end
    if ShoyrUI.DurationReminder  then ShoyrUI.DurationReminder.Refresh() end
    if ShoyrUI.Grid             then ShoyrUI.Grid.UpdateOverlay() end
    if ShoyrUI.RefreshPanel     then ShoyrUI.RefreshPanel() end
    if ShoyrUI.ConfigWindow and ShoyrUI.ConfigWindow.Refresh then ShoyrUI.ConfigWindow.Refresh() end
end

function P.Load(name)
    local snap = ShoyrUI.sv.profiles[name]
    if not ValidSnapshot(snap) then return false end       -- GUARD: never wipe from an empty/corrupt snapshot
    -- Save the outgoing profile's in-flight edits first — but ONLY if it still exists. Otherwise a
    -- Load triggered by deleting the active profile would RESURRECT the just-deleted profile.
    if ShoyrUI.sv.activeProfile and ShoyrUI.sv.activeProfile ~= name
       and ShoyrUI.sv.profiles[ShoyrUI.sv.activeProfile] then
        P.Save(ShoyrUI.sv.activeProfile)
    end
    -- Everything mutates IN PLACE (DeepAssign preserves table identity) so live module/frame/tracker
    -- instances AND the settings-editor closures stay bound to the current tables instead of detaching
    -- to stale/default copies. Trackers included; then reconcile instances (rebind/create/disable).
    DeepAssign(ShoyrUI.sv.trackers, snap.trackers)
    for _, key in ipairs(MODULE_TABLES) do
        if type(snap[key]) == "table" then DeepAssign(ShoyrUI.sv[key], snap[key]) end
    end
    for _, gk in ipairs(GLOBAL_KEYS) do ShoyrUI.sv.global[gk] = snap.global and snap.global[gk] end
    ShoyrUI.sv.activeProfile = name
    ShoyrUI.RebuildTrackersFromSV()
    ReapplyAll()
    return true
end

-- New clean-slate profile: your frames/auras/bars/grid/general carry over from the current setup
-- (no need to re-lay-out your HUD per profile); the TRACKERS reset to the default seeds with
-- Kjalnar + Bound Armaments DISABLED (Fossilize stays on) and no user trackers. Saved + switched to.
function P.New(name)
    name = (name and name ~= "" and name) or P.NextName()
    if ShoyrUI.sv.profiles[name] then return false end          -- don't overwrite an existing profile
    if ShoyrUI.sv.activeProfile then P.Save(ShoyrUI.sv.activeProfile) end
    ShoyrUI.ResetTrackersClean()                                -- mutates sv.trackers IN PLACE (keeps builtin identity)
    ShoyrUI.RebuildTrackersFromSV()
    ShoyrUI.sv.activeProfile = name
    P.Save(name)
    ReapplyAll()
    return name
end

function P.Delete(name)
    local profs = ShoyrUI.sv.profiles
    if not profs[name] then return false end
    profs[name] = nil
    for n, snap in pairs(profs) do if not ValidSnapshot(snap) then profs[n] = nil end end   -- sweep junk too
    -- Always leave a valid active profile. If we deleted the active one, switch to another valid
    -- profile; if none remain, snapshot the CURRENT live setup as a fresh "Profile 1" (never wipes).
    if not ValidSnapshot(profs[ShoyrUI.sv.activeProfile]) then
        local names = P.List()
        if names[1] then
            P.Load(names[1])
        else
            ShoyrUI.sv.activeProfile = "Profile 1"
            P.Save("Profile 1")
        end
    end
    return true
end

function P.Rename(old, new)
    local profs = ShoyrUI.sv.profiles
    if not profs[old] or not new or new == "" or profs[new] then return false end
    profs[new] = profs[old]; profs[old] = nil
    if ShoyrUI.sv.activeProfile == old then ShoyrUI.sv.activeProfile = new end
    return true
end

-- Diagnostic (/shoyrprofiles): prints every stored profile with its tracker count + validity, the
-- active one, and how many trackers are live right now. Lets us see the real state in-game.
function P.Dump()
    local function line(s) if d then d("[Shoyru's UI] " .. tostring(s)) end end
    line("Active profile: " .. tostring(ShoyrUI.sv.activeProfile))
    for name, snap in pairs(ShoyrUI.sv.profiles or {}) do
        local n = 0
        if type(snap) == "table" and type(snap.trackers) == "table" then
            for _ in pairs(snap.trackers) do n = n + 1 end
        end
        line(("%s%s \226\128\148 %d tracker(s)%s"):format(
            name == ShoyrUI.sv.activeProfile and "> " or "   ", name, n,
            ValidSnapshot(snap) and "" or "  (EMPTY / invalid \226\128\148 will be purged)"))
    end
    local live = 0; for _ in pairs(ShoyrUI.sv.trackers or {}) do live = live + 1 end
    line("Live trackers on screen right now: " .. live)
end
