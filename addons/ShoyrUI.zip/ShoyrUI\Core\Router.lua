-- ShoyrUI :: Core/Router.lua
-- One EVENT_EFFECT_CHANGED registration for the whole addon. Routes each effect
-- to the tracker(s) watching that abilityId, applying the tracker's watch-mode
-- filter. One shared OnUpdate tick drives every active/previewing tracker.

ShoyrUI = ShoyrUI or {}

local Router = {}
ShoyrUI.Router = Router

local NAME = "ShoyrUI_Router"
local UPDATE_INTERVAL_MS = 50
local PREVIEW_STEP_MS = 700

local trackers = {}            -- id -> Tracker
local byAbility = {}           -- abilityId -> { Tracker, ... }
local combatTrackers = {}      -- trackers whose behavior opts into the combat channel
local masterEnabled = true     -- addon-wide on/off (preview ignores this)
local updateRunning = false
local previewAccumMs = 0
local lastTickMs = nil

local function GetNowMs() return GetFrameTimeMilliseconds() end

-- ---------------------------------------------------------------------------
-- Registry
-- ---------------------------------------------------------------------------

local function IndexTracker(tracker)
    local ids = tracker.config.abilityIds
    if not ids then return end
    for _, id in ipairs(ids) do
        byAbility[id] = byAbility[id] or {}
        table.insert(byAbility[id], tracker)
    end
end

local function RebuildIndex()
    byAbility = {}
    combatTrackers = {}
    for _, t in pairs(trackers) do
        if t.config.enabled then
            IndexTracker(t)
            -- Behaviors that need the combat log (incomingCast) opt in with a class
            -- flag; collect them so the combat + player-effect channels can reach them.
            if t.behavior and t.behavior.usesCombatEvent then
                combatTrackers[#combatTrackers + 1] = t
            end
        end
    end
end

function Router.Register(tracker)
    trackers[tracker.id] = tracker
    RebuildIndex()
end

function Router.Unregister(id)
    local t = trackers[id]
    if t then t:Destroy() end
    trackers[id] = nil
    RebuildIndex()
end

function Router.Get(id) return trackers[id] end
function Router.All() return trackers end

-- Call after toggling a tracker's enabled flag or editing abilityIds.
function Router.Refresh()
    RebuildIndex()
    for _, t in pairs(trackers) do
        if not t.config.enabled and not t.preview then t:Hide() end
    end
    Router.EnsureTick()
end

-- ---------------------------------------------------------------------------
-- Effect routing
-- ---------------------------------------------------------------------------

local function Accept(tracker, unitTag, sourceType)
    local watch = tracker.config.watch
    if watch == "selfBuff" then
        return unitTag == "player"            -- any effect on me (buff or debuff)
    elseif watch == "targetBuff" then
        return unitTag == "reticleover"       -- their effect on my target (any source)
    elseif watch == "reticleDebuff" then
        return unitTag == "reticleover" and sourceType == COMBAT_UNIT_TYPE_PLAYER
    else -- targetDebuff
        return sourceType == COMBAT_UNIT_TYPE_PLAYER   -- anything I apply, per target
    end
end

local function OnEffectChanged(
    eventCode, changeType, effectSlot, effectName, unitTag,
    beginTime, endTime, stackCount, iconName, buffType,
    effectType, abilityType, statusEffectType, unitName,
    unitId, abilityId, sourceType)

    if ShoyrUI.Discovered then
        ShoyrUI.Discovered.Note(effectName, unitTag, stackCount, iconName, unitId,
            abilityId, sourceType, effectType, statusEffectType)
    end

    if not masterEnabled then return end

    -- Feed combat-channel behaviors (incomingCast) every player effect — they need
    -- immunity-buff changes and the cast's UPDATED refresh, neither of which is
    -- indexed by their trigger ids in byAbility. Done before the byAbility return.
    if unitTag == "player" and #combatTrackers > 0 then
        for _, t in ipairs(combatTrackers) do
            if t.config.enabled and t.behavior.OnPlayerEffect then
                t.behavior:OnPlayerEffect(changeType, beginTime, endTime, abilityId)
            end
        end
        Router.EnsureTick()
    end

    local list = byAbility[abilityId]
    if not list then return end

    for _, tracker in ipairs(list) do
        if tracker.config.enabled and Accept(tracker, unitTag, sourceType) then
            tracker:OnEffect(changeType, beginTime, endTime, stackCount, unitId, abilityId)
        end
    end
    Router.EnsureTick()
end

-- EVENT_COMBAT_EVENT, filtered to target = player (set up in Router.Init). Drives
-- the incomingCast archetype's cast detection + CC-immunity tracking.
local function OnPlayerCombatEvent(
    eventCode, result, isError, abilityName, abilityGraphic, abilityActionSlotType,
    sourceName, sourceType, targetName, targetType, hitValue, powerType, damageType,
    log, sourceUnitId, targetUnitId, abilityId, overflow)

    if isError or not masterEnabled then return end
    if #combatTrackers == 0 then return end
    for _, t in ipairs(combatTrackers) do
        if t.config.enabled and t.behavior.OnCombatEvent then
            t.behavior:OnCombatEvent(result, abilityId, sourceUnitId, hitValue)
        end
    end
    Router.EnsureTick()
end

-- ---------------------------------------------------------------------------
-- Shared update tick
-- ---------------------------------------------------------------------------

local function Tick()
    local now = GetNowMs()
    local dt = lastTickMs and (now - lastTickMs) or UPDATE_INTERVAL_MS
    lastTickMs = now

    -- Drive preview stack cadence on a slower clock than the render tick.
    previewAccumMs = previewAccumMs + dt
    local stepPreview = false
    if previewAccumMs >= PREVIEW_STEP_MS then
        previewAccumMs = 0
        stepPreview = true
    end

    local anyBusy = false
    for _, t in pairs(trackers) do
        if stepPreview and t.preview then t:PreviewStep() end
        if t.preview or (masterEnabled and t.config.enabled) then
            -- Guard each tracker: one bad config/behavior must not break the render (or spam the
            -- error log) for all the others, every tick. Log the first failure per tracker, skip it,
            -- and let it resume automatically if it stops erroring.
            local ok, busy = pcall(t.Tick, t, now)
            if ok then
                t._tickErr = nil
                if busy then anyBusy = true end
            elseif not t._tickErr then
                t._tickErr = true
                d("[Shoyru's UI] tracker '" .. tostring(t.id) .. "' errored during update; skipping it \226\128\148 " .. tostring(busy))
            end
        end
    end

    if not anyBusy then
        EVENT_MANAGER:UnregisterForUpdate(NAME)
        updateRunning = false
        lastTickMs = nil
    end
end

function Router.EnsureTick()
    if updateRunning then return end
    local now = GetNowMs()
    local needed = false
    for _, t in pairs(trackers) do
        if t:IsBusy(now) then needed = true break end
    end
    if not needed then return end
    updateRunning = true
    lastTickMs = nil
    previewAccumMs = 0
    EVENT_MANAGER:RegisterForUpdate(NAME, UPDATE_INTERVAL_MS, Tick)
end

function Router.SetMaster(on)
    masterEnabled = on
    if not on then
        for _, t in pairs(trackers) do
            if not t.preview then t:Hide() end
        end
    else
        Router.EnsureTick()
    end
end

function Router.Init()
    EVENT_MANAGER:RegisterForEvent(NAME, EVENT_EFFECT_CHANGED, OnEffectChanged)
    -- Combat channel for incomingCast behaviors. One registration, filtered to
    -- effects targeting the player (incoming casts + our own CC-immunity events).
    local combatName = NAME .. "_Combat"
    EVENT_MANAGER:RegisterForEvent(combatName, EVENT_COMBAT_EVENT, OnPlayerCombatEvent)
    EVENT_MANAGER:AddFilterForEvent(combatName, EVENT_COMBAT_EVENT,
        REGISTER_FILTER_TARGET_COMBAT_UNIT_TYPE, COMBAT_UNIT_TYPE_PLAYER)
end
