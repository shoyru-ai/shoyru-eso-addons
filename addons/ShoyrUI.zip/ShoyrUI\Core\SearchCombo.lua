-- ShoyrUI :: Core/SearchCombo.lua
-- A self-contained filterable combobox: one text field that drops a result list
-- right below it, filtering live as you type; scroll with the mouse wheel; click
-- a row to select. Built from primitives because neither LAM's stock dropdown nor
-- this client's ZO_ComboBox expose live filtering. Reused by the ability picker
-- and the set browser.
--
-- The result list is parented to ZO_Menus (the native menu/dropdown layer) so it
-- renders ABOVE the settings window and is never clipped by the scroll pane.
--
-- Attach(parent, opts) -> handle
--   opts.query    = function(text, limit) -> labels[], ids[]   (required; labels
--                   may contain |t..|t inline icon markup)
--   opts.onSelect = function(id) end                            (required)
--   opts.nameFor  = function(id) -> string  (optional; field text after select)
--   opts.width    = field width in px       (optional; default 460)
--   opts.visibleRows = rows shown at once    (optional; default 8)
--   opts.maxResults  = rows requested from query (optional; default 1000 so long
--                      lists like the 700+ set DB are fully browsable, not capped)
-- A scrollbar thumb on the right edge shows your position through long lists.
-- handle:Refresh() / handle:SetText(t) / handle:GetText()

ShoyrUI = ShoyrUI or {}
local SC = {}
ShoyrUI.SearchCombo = SC

local wm = WINDOW_MANAGER
local nextId = 0   -- unique-name counter (virtual templates have named children)

function SC.Attach(parent, opts)
    local visN  = opts.visibleRows or 8
    local rowH  = opts.rowHeight or 26
    local boxW  = opts.width or 460
    nextId = nextId + 1
    local uid = "ShoyrUI_SC" .. nextId

    -- Search field: a bordered backdrop + edit control, fixed width. topOffset lets
    -- the caller drop the box to line up with an adjacent LAM half-width control
    -- (whose input sits below its name label, 28px down).
    local bg = wm:CreateControlFromVirtual(uid .. "_BG", parent, "ZO_DefaultBackdrop")
    bg:ClearAnchors()   -- the virtual template ships with an anchor; clear first
    bg:SetAnchor(TOPLEFT, parent, TOPLEFT, opts.leftOffset or 0, opts.topOffset or 0)
    bg:SetDimensions(boxW, opts.boxHeight or 30)

    local edit = wm:CreateControlFromVirtual(uid .. "_Edit", bg, "ZO_DefaultEditForBackdrop")
    edit:ClearAnchors()
    edit:SetAnchor(TOPLEFT,     bg, TOPLEFT,      6, 2)
    edit:SetAnchor(BOTTOMRIGHT, bg, BOTTOMRIGHT, -6, -2)
    edit:SetMaxInputChars(128)
    edit:SetFont("ZoFontGame")
    edit:SetText("")

    -- Result list on ZO_Menus (above the window, unclipped). Solid CT_BACKDROP so
    -- nothing bleeds through. Width tracks the search field.
    local results = wm:CreateControl(uid .. "_Results", ZO_Menus, CT_BACKDROP)
    results:SetAnchor(TOPLEFT,  bg, BOTTOMLEFT,  0, 2)
    results:SetAnchor(TOPRIGHT, bg, BOTTOMRIGHT, 0, 2)
    results:SetHidden(true)
    results:SetMouseEnabled(true)
    results:SetDrawLayer(DL_OVERLAY)
    results:SetDrawTier(DT_HIGH)
    results:SetDrawLevel(0)   -- children use higher levels on this same tier+layer
    results:SetCenterColor(0.03, 0.03, 0.04, 1)
    results:SetEdgeColor(0.45, 0.45, 0.45, 1)
    results:SetInsets(1, 1, -1, -1)

    local handle = { matches = {}, offset = 0 }

    local function RenderWindow()
        local m = handle.matches
        local total = #m
        local maxOff = math.max(0, total - visN)
        if handle.offset > maxOff then handle.offset = maxOff end
        if handle.offset < 0 then handle.offset = 0 end

        for i = 1, visN do
            local row = handle.rows[i]
            local item = m[handle.offset + i]
            if item then
                row.label:SetText(item.label)
                row.id = item.id
                row:SetHidden(false)
            else
                row.id = nil
                row:SetHidden(true)
            end
        end
        local shown = math.min(visN, total)
        -- Stay shown while the box has focus OR the user is dragging the scrollbar
        -- (the drag steals keyboard focus from the edit; interacting keeps it open).
        if shown > 0 and (edit:HasFocus() or handle.interacting) then
            results:SetHeight(shown * rowH + 4)
            results:SetHidden(false)
            ZO_Menus:BringWindowToTop()
            -- Scroll indicator: thumb sized by (visible / total), positioned by
            -- (offset / maxOffset). Only when the list overflows the window. Geometry
            -- is stashed on `handle` so the drag/click handlers can map mouse->offset.
            if handle.sbThumb then
                if total > visN then
                    local viewH  = shown * rowH
                    local thumbH = math.max(14, viewH * visN / total)
                    local frac   = (maxOff > 0) and (handle.offset / maxOff) or 0
                    local thumbY = 2 + frac * (viewH - thumbH)
                    handle.viewH, handle.thumbH, handle.maxOff = viewH, thumbH, maxOff
                    handle.sbTrack:SetHeight(viewH)
                    handle.sbThumb:SetHeight(thumbH)
                    handle.sbThumb:ClearAnchors()
                    handle.sbThumb:SetAnchor(TOPRIGHT, results, TOPRIGHT, -2, thumbY)
                    handle.sbTrack:SetHidden(false)
                    handle.sbThumb:SetHidden(false)
                else
                    handle.maxOff = 0
                    handle.sbTrack:SetHidden(true)
                    handle.sbThumb:SetHidden(true)
                end
            end
        else
            results:SetHidden(true)
            if handle.sbThumb then handle.sbTrack:SetHidden(true); handle.sbThumb:SetHidden(true) end
        end
    end

    local function Scroll(delta)
        handle.offset = handle.offset - delta   -- wheel up (+1) -> earlier items
        RenderWindow()
    end
    results:SetHandler("OnMouseWheel", function(_, delta) Scroll(delta) end)

    -- Pooled rows.
    handle.rows = {}
    for i = 1, visN do
        local row = wm:CreateControl(uid .. "_Row" .. i, results, CT_CONTROL)
        row:SetHeight(rowH)
        row:SetAnchor(TOPLEFT,  results, TOPLEFT,  2, (i - 1) * rowH + 2)
        row:SetAnchor(TOPRIGHT, results, TOPRIGHT, -2, (i - 1) * rowH + 2)
        row:SetMouseEnabled(true)
        -- Draw order sorts by tier -> layer -> level, none inherited. Keep the whole
        -- subtree on the SAME tier+layer as the backdrop and order by level only,
        -- else the DL_OVERLAY backdrop paints over default-layer children.
        row:SetDrawTier(DT_HIGH)
        row:SetDrawLayer(DL_OVERLAY)
        row:SetDrawLevel(1)

        local hl = wm:CreateControl(nil, row, CT_TEXTURE)
        hl:SetAnchor(TOPLEFT,     row, TOPLEFT,     0, 0)
        hl:SetAnchor(BOTTOMRIGHT, row, BOTTOMRIGHT, 0, 0)
        hl:SetColor(0.9, 0.75, 0.4, 0.20)
        hl:SetDrawTier(DT_HIGH)
        hl:SetDrawLayer(DL_OVERLAY)
        hl:SetDrawLevel(1)
        hl:SetHidden(true)

        local label = wm:CreateControl(nil, row, CT_LABEL)
        label:SetAnchor(LEFT,  row, LEFT,   6, 0)
        label:SetAnchor(RIGHT, row, RIGHT, -6, 0)
        label:SetFont("ZoFontGame")
        label:SetColor(1, 1, 1, 1)
        label:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        label:SetDrawTier(DT_HIGH)
        label:SetDrawLayer(DL_OVERLAY)
        label:SetDrawLevel(2)
        if label.SetMaxLineCount then label:SetMaxLineCount(1) end
        row.label = label

        row:SetHandler("OnMouseEnter", function() hl:SetHidden(false) end)
        row:SetHandler("OnMouseExit",  function() hl:SetHidden(true) end)
        row:SetHandler("OnMouseWheel", function(_, delta) Scroll(delta) end)
        row:SetHandler("OnMouseUp", function(_, button, upInside)
            if upInside and row.id then
                if opts.nameFor then edit:SetText(opts.nameFor(row.id) or "") end
                results:SetHidden(true)
                edit:LoseFocus()
                opts.onSelect(row.id)
            end
        end)
        handle.rows[i] = row
    end

    -- Scrollbar: faint track + a brighter thumb pinned to the right edge. Sized and
    -- positioned each RenderWindow so it reflects how far down a long list you are.
    local SB_W = 4
    local sbTrack = wm:CreateControl(uid .. "_SBTrack", results, CT_TEXTURE)
    sbTrack:SetWidth(SB_W)
    sbTrack:SetAnchor(TOPRIGHT, results, TOPRIGHT, -2, 2)
    sbTrack:SetColor(1, 1, 1, 0.10)
    sbTrack:SetDrawTier(DT_HIGH); sbTrack:SetDrawLayer(DL_OVERLAY); sbTrack:SetDrawLevel(3)
    sbTrack:SetHidden(true)
    local sbThumb = wm:CreateControl(uid .. "_SBThumb", results, CT_TEXTURE)
    sbThumb:SetWidth(SB_W)
    sbThumb:SetAnchor(TOPRIGHT, results, TOPRIGHT, -2, 2)
    sbThumb:SetColor(0.9, 0.75, 0.4, 0.9)
    sbThumb:SetDrawTier(DT_HIGH); sbThumb:SetDrawLayer(DL_OVERLAY); sbThumb:SetDrawLevel(4)
    sbThumb:SetHidden(true)
    handle.sbTrack, handle.sbThumb = sbTrack, sbThumb

    -- Make the thumb draggable and the track click-to-jump. Mouse-down on either
    -- steals keyboard focus from the edit, so we flag `interacting` (keeps the list
    -- open in RenderWindow) and on release re-take focus WITHOUT resetting the scroll
    -- offset (keepOffset tells OnFocusGained to re-render in place, not re-query).
    local function endInteract()
        sbThumb:SetHandler("OnUpdate", nil)
        handle.keepOffset = true
        edit:TakeFocus()            -- focus back first (may fire OnFocusGained now)
        handle.interacting = false
        RenderWindow()
    end

    sbTrack:SetMouseEnabled(true)
    sbThumb:SetMouseEnabled(true)
    sbThumb:SetHandler("OnMouseEnter", function() sbThumb:SetColor(1, 0.92, 0.6, 1) end)
    sbThumb:SetHandler("OnMouseExit",  function() sbThumb:SetColor(0.9, 0.75, 0.4, 0.9) end)

    sbThumb:SetHandler("OnMouseDown", function()
        handle.interacting = true
        local _, my = GetUIMousePosition()
        handle.dragStartY = my
        handle.dragStartOffset = handle.offset
        -- Follow the cursor each frame while held.
        sbThumb:SetHandler("OnUpdate", function()
            local span = (handle.viewH or 0) - (handle.thumbH or 0)
            local maxOff = handle.maxOff or 0
            if span > 0 and maxOff > 0 then
                local _, ny = GetUIMousePosition()
                local newOff = handle.dragStartOffset + ((ny - handle.dragStartY) / span) * maxOff
                newOff = math.floor(newOff + 0.5)
                if newOff < 0 then newOff = 0 elseif newOff > maxOff then newOff = maxOff end
                if newOff ~= handle.offset then handle.offset = newOff; RenderWindow() end
            end
        end)
    end)
    sbThumb:SetHandler("OnMouseUp", function() endInteract() end)

    -- Click anywhere on the track to jump there (centers the thumb on the cursor).
    sbTrack:SetHandler("OnMouseDown", function()
        local maxOff = handle.maxOff or 0
        local h = sbTrack:GetHeight()
        if maxOff > 0 and h > 0 then
            local _, my = GetUIMousePosition()
            local frac = (my - sbTrack:GetTop()) / h
            if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
            handle.offset = math.floor(frac * maxOff + 0.5)
        end
        handle.interacting = true
        RenderWindow()
    end)
    sbTrack:SetHandler("OnMouseUp", function() endInteract() end)

    function handle:Refresh()
        local text = edit:GetText() or ""
        local labels, ids = opts.query(text, opts.maxResults or 1000)
        local m = {}
        if labels then
            for i = 1, #labels do m[i] = { label = labels[i], id = ids[i] } end
        end
        self.matches = m
        self.offset = 0
        RenderWindow()
    end
    function handle:SetText(t) edit:SetText(t or "") end
    function handle:GetText() return edit:GetText() or "" end

    edit:SetHandler("OnTextChanged", function() handle:Refresh() end)
    edit:SetHandler("OnFocusGained", function()
        -- Re-focus that came from finishing a scrollbar drag: keep the scroll
        -- position (just re-render); otherwise it's a fresh focus → (re)query.
        if handle.keepOffset then handle.keepOffset = false; RenderWindow()
        else handle:Refresh() end
    end)
    -- Delay the hide so a click on a result row (or the scrollbar) registers first;
    -- don't hide if we're mid-drag or focus has already returned to the box.
    edit:SetHandler("OnFocusLost", function()
        zo_callLater(function()
            if not handle.interacting and not edit:HasFocus() then results:SetHidden(true) end
        end, 150)
    end)
    -- Hide the floating list if the panel (and thus the search field) goes away.
    bg:SetHandler("OnEffectivelyHidden", function() results:SetHidden(true) end)

    return handle
end
