-- ShoyrUI :: Core/Sets.lua
-- Set Browser back end. Wraps LibSets (optional) for the full set database and
-- resolves a set's proc ability id so "track a set" == track its proc.
--
-- Reality check baked into the design: LibSets knows ~709 set NAMES but proc
-- ability data for only ~71 of them (and not Kjalnar). So proc-id resolution is:
--   learned (saved vars)  ->  curated Defaults.SET_PROC_IDS  ->  LibSets
-- and for everything else the user supplies the id once and we LEARN it.

ShoyrUI = ShoyrUI or {}
local Sets = {}
ShoyrUI.Sets = Sets

local learned = nil       -- sv table: setId -> { abilityId = N, name = "..." }

local function Defaults() return ShoyrUI.Defaults or {} end
local function HasLib() return LibSets ~= nil end
Sets.HasLib = HasLib

-- Register a proc id -> set name so the catalog classifies/labels it as a set.
local function RegisterName(abilityId, name)
    if not abilityId or not name then return end
    local D = Defaults()
    D.SET_NAMES = D.SET_NAMES or {}
    D.SET_NAMES[abilityId] = name
end

function Sets.Init(svSetProcs)
    learned = svSetProcs or {}
    -- Re-apply learned proc names into the live SET_NAMES registry on load.
    for _, entry in pairs(learned) do
        RegisterName(entry.abilityId, entry.name)
    end
end

-- Localized set name: LibSets (localized) -> baked full DB (complete, covers
-- LibSets' gaps like Wretched Vitality) -> learned.
function Sets.GetName(setId)
    if HasLib() and LibSets.GetSetName then
        local n = LibSets.GetSetName(setId)
        if n and n ~= "" then return n end
    end
    local D = Defaults()
    if D.SET_NAME_DB and D.SET_NAME_DB[setId] then return D.SET_NAME_DB[setId] end
    if learned and learned[setId] and learned[setId].name then return learned[setId].name end
    return nil
end

-- Proc ability ids for a set: learned -> curated -> LibSets (flattened, deduped).
function Sets.GetProcIds(setId)
    local out, seen = {}, {}
    local function add(id)
        id = tonumber(id)
        if id and id > 0 and not seen[id] then seen[id] = true; out[#out + 1] = id end
    end

    if learned and learned[setId] and learned[setId].abilityId then
        add(learned[setId].abilityId)
    end
    local curated = Defaults().SET_PROC_IDS
    if curated and curated[setId] then
        for _, id in ipairs(curated[setId]) do add(id) end
    end
    if HasLib() and LibSets.GetSetProcAbilityIds then
        local ids = LibSets.GetSetProcAbilityIds(setId)
        if type(ids) == "table" then
            for _, id in pairs(ids) do add(id) end
        end
    end
    -- Last resort: procs already seen in combat that map to this set (by reverse
    -- set lookup or matching name). Resolves ids LibSets has no proc data for.
    local Disc = ShoyrUI.Discovered
    if Disc and Disc.SetProcIdsFromCatalog then
        local name = Sets.GetName(setId)
        for _, id in ipairs(Disc.SetProcIdsFromCatalog(name)) do add(id) end
    end
    return out
end

-- Substring search over all set names. Returns parallel arrays labels[], setIds[].
-- Each label shows the set's proc/ability id when known (like the buff/debuff
-- list), or "(id?)" when it isn't — paste it once and it's learned.
-- Source is the baked full DB (covers LibSets' name gaps); LibSets is the
-- fallback only if the DB isn't loaded.
function Sets.Search(substr, limit)
    limit = limit or 60
    substr = (substr or ""):lower()
    local D = Defaults()

    local matches = {}
    if D.SET_NAME_DB then
        for setId, name in pairs(D.SET_NAME_DB) do
            if name and (substr == "" or name:lower():find(substr, 1, true)) then
                matches[#matches + 1] = { id = setId, name = Sets.GetName(setId) or name }
            end
        end
    elseif HasLib() and LibSets.GetAllSetIds then
        local all = LibSets.GetAllSetIds()
        if type(all) == "table" then
            for setId, isActive in pairs(all) do
                if isActive == true then
                    local name = Sets.GetName(setId)
                    if name and (substr == "" or name:lower():find(substr, 1, true)) then
                        matches[#matches + 1] = { id = setId, name = name }
                    end
                end
            end
        end
    end
    table.sort(matches, function(a, b) return a.name < b.name end)

    local labels, ids = {}, {}
    for i = 1, math.min(limit, #matches) do
        local m = matches[i]
        local procs = Sets.GetProcIds(m.id)
        -- Icon = the set's proc buff/debuff icon (only known when we have a proc id).
        local prefix = ""
        if procs[1] and GetAbilityIcon then
            local icon = GetAbilityIcon(procs[1])
            if icon and icon ~= "" then prefix = zo_iconFormat(icon, 24, 24) .. " " end
        end
        local idTag = procs[1] and string.format("  (%d)", procs[1]) or "  (id?)"
        labels[i] = prefix .. m.name .. idTag
        ids[i] = m.id
    end
    return labels, ids
end

-- Persist a user-supplied proc id for a set and register its name for the catalog.
function Sets.Learn(setId, abilityId, name)
    abilityId = tonumber(abilityId)
    if not (learned and setId and abilityId) then return end
    name = name or Sets.GetName(setId)
    learned[setId] = { abilityId = abilityId, name = name }
    RegisterName(abilityId, name)
end

-- Create a tracker for a set: resolve (or accept) the proc id, learn it, spawn.
-- Returns trackerId, err.
function Sets.TrackSet(setId, abilityId, watch)
    if not setId then return nil, "No set selected" end
    abilityId = tonumber(abilityId)
    if not abilityId then
        local ids = Sets.GetProcIds(setId)
        abilityId = ids[1]
    end
    if not abilityId or abilityId <= 0 then
        return nil, "No known proc id for this set \226\128\148 paste the ability id"
    end
    local name = Sets.GetName(setId) or ("Set " .. tostring(setId))
    Sets.Learn(setId, abilityId, name)
    return ShoyrUI.CreateTracker(abilityId, name, watch or "targetDebuff")
end
