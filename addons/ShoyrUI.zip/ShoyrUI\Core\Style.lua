-- ShoyrUI :: Core/Style.lua
-- The shared visual vocabulary for the whole addon — fonts, borders, and a
-- StyledBar widget. Extracted from the original Tracker rendering so trackers and
-- the (Phase 3+) UI-Layout unit frames look identical and a future font/texture/
-- color change updates everything from one place. Pure view helpers; no state.

ShoyrUI = ShoyrUI or {}
local Style = {}
ShoyrUI.Style = Style

local WM = WINDOW_MANAGER

Style.FILL_ALPHA   = 0.95                          -- bar fill opacity
Style.BAR_BG       = { r = 0, g = 0, b = 0, a = 0.75 }   -- default bar background
Style.FILL_DEFAULT = { r = 0.85, g = 0.85, b = 0.85 }    -- fill before a color is set

-- Border thickness must be a power of two; SetEdgeTexture errors otherwise.
function Style.ClampBorder(t)
    t = t or 2
    if t >= 8 then return 8 elseif t >= 4 then return 4 else return 2 end
end

-- Font string. kind "text" = bold w/ soft shadow (names, values, timers);
-- "count" = bold outline (small stack/number overlays). Matches the look the
-- standalone trackers shipped with.
function Style.Font(size, kind)
    size = math.max(1, math.floor(size or 12))
    if kind == "count" then
        return string.format("$(BOLD_FONT)|%d|outline", size)
    end
    return string.format("$(BOLD_FONT)|%d|soft-shadow-thick", size)
end

-- Dark-UI edge: a 1px engine line tinted cleanly by SetEdgeColor (no texture art).
function Style.ApplyBorder(control, color, thickness)
    if not control then return end
    local col = color or { r = 0, g = 0, b = 0, a = 1 }
    local t = Style.ClampBorder(thickness)
    control:SetEdgeTexture(nil, t, t, t, 0)
    control:SetEdgeColor(col.r, col.g, col.b, col.a or 1)
end

-- ---------------------------------------------------------------------------
-- StyledBar — a background + left-anchored depleting fill. Width drives the
-- depletion (the proven Kjalnar/Bound-Armaments pattern). The caller anchors
-- `.bg`; the fill is pinned inside it and sized by SetPct.
-- ---------------------------------------------------------------------------

local Bar = {}
Bar.__index = Bar
Style.StyledBar = Bar

local SMOOTH_TAU = 70   -- ms; exponential ease time constant (snappy but smooth)
-- Base-game-style vertical sheen on the fill: brightness multipliers for the top vs bottom
-- edge (full at the top, gently darker at the bottom). Vertex-coloured, no texture needed.
local GLOSS_TOP = 1.0
local GLOSS_BOT = 0.70
local function clamp01(p) if p < 0 then return 0 elseif p > 1 then return 1 end return p end

function Bar.New(parent, name)
    local self = setmetatable({}, Bar)
    self.bg = WM:CreateControl(name, parent, CT_BACKDROP)
    self.bg:SetCenterColor(Style.BAR_BG.r, Style.BAR_BG.g, Style.BAR_BG.b, Style.BAR_BG.a)

    self.fill = WM:CreateControl(name and (name .. "Fill") or nil, self.bg, CT_TEXTURE)
    self.fill:SetColor(Style.FILL_DEFAULT.r, Style.FILL_DEFAULT.g, Style.FILL_DEFAULT.b, Style.FILL_ALPHA)
    self.fill:SetAnchor(TOPLEFT,    self.bg, TOPLEFT,    1, 1)
    self.fill:SetAnchor(BOTTOMLEFT, self.bg, BOTTOMLEFT, 1, -1)

    self._glossOn = false   -- vertical sheen on the fill (vertex-coloured); see SetGloss

    self.current, self.target = 0, 0
    self._gradient, self._falloff = false, 0.55
    return self
end

function Bar:SetBgColor(c)
    c = c or Style.BAR_BG
    self.bg:SetCenterColor(c.r, c.g, c.b, c.a or 0.75)
end

-- Texture for the vertex-color gradient. DISABLED (nil) → bars render flat solid, which
-- is clean and reliable. The gradient needs a single OPAQUE-WHITE fill texture; every
-- candidate tried failed (textbg=dark, progressbar_gloss=invalid, DarkUI's fill texture is
-- only one piece of its multi-texture bar → half-black). The correct fix is to SHIP our own
-- white .dds with the addon, then set this path — until then, flat is the look.
Style.GRADIENT_TEX = nil

function Bar:_applyFillColor()
    local c = self._fill or { r = 1, g = 1, b = 1 }
    local a = Style.FILL_ALPHA
    if self._glossOn then
        -- Base-game-style vertical sheen: full colour along the top edge, fading gently
        -- darker toward the bottom. Vertex-coloured on the fill's own quad (no texture),
        -- so it holds at any fill width as the bar depletes.
        local t, b = GLOSS_TOP, GLOSS_BOT
        self.fill:SetVertexColors(VERTEX_POINTS_TOPLEFT,     c.r * t, c.g * t, c.b * t, a)
        self.fill:SetVertexColors(VERTEX_POINTS_TOPRIGHT,    c.r * t, c.g * t, c.b * t, a)
        self.fill:SetVertexColors(VERTEX_POINTS_BOTTOMLEFT,  c.r * b, c.g * b, c.b * b, a)
        self.fill:SetVertexColors(VERTEX_POINTS_BOTTOMRIGHT, c.r * b, c.g * b, c.b * b, a)
    else
        self.fill:SetColor(c.r, c.g, c.b, a)   -- flat solid
    end
end

function Bar:SetFillColor(c)
    self._fill = c or { r = 1, g = 1, b = 1 }
    self:_applyFillColor()
end

-- Horizontal gradient: full color left, darkened (× falloff) right. falloff ~0.5-0.7.
function Bar:SetGradient(on, falloff)
    self._gradient = on and true or false
    if falloff then self._falloff = falloff end
    if self._fill then self:_applyFillColor() end
end

function Bar:_apply(pct)
    local w = math.max(2, self.bg:GetWidth() - 2)
    self.fill:SetWidth(w * pct)
    self.fill:SetHidden(pct <= 0)
end

-- Base-game-style vertical sheen on the fill (opt-in; off = clean flat bar).
function Bar:SetGloss(on)
    self._glossOn = on and true or false
    if self._fill then self:_applyFillColor() end
end

-- Frame-rate-independent exponential ease toward target; self-stops when settled.
function Bar:_tick()
    local now = GetFrameTimeMilliseconds()
    local dt = self._t and (now - self._t) or 16
    self._t = now
    local d = self.target - self.current
    if math.abs(d) < 0.003 then
        self.current = self.target
        self:_apply(self.current)
        self.bg:SetHandler("OnUpdate", nil)
        self._anim, self._t = false, nil
        return
    end
    self.current = self.current + d * (1 - math.exp(-dt / SMOOTH_TAU))
    self:_apply(self.current)
end

-- Instant fill fraction 0..1 (used by trackers, whose bars already tick smoothly).
function Bar:SetPct(pct)
    pct = clamp01(pct or 0)
    self.current, self.target = pct, pct
    self.bg:SetHandler("OnUpdate", nil)
    self._anim, self._t = false, nil
    self:_apply(pct)
end

-- Eased fill toward `pct` (used by unit frames, where power events arrive in jumps).
function Bar:SetPctSmooth(pct)
    self.target = clamp01(pct or 0)
    if not self._anim then
        self._anim, self._t = true, nil
        self.bg:SetHandler("OnUpdate", function() self:_tick() end)
    end
end

function Bar:SetBorder(color, thickness)
    Style.ApplyBorder(self.bg, color, thickness)
end
