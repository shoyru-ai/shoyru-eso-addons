-- ShoyrUI :: Core/Tracker.lua
-- The HUD widget. ONE config table in, one self-contained icon+bar+label widget
-- out. Tracker is now purely the RENDERER + window chrome; all archetype state
-- logic lives in a behavior module (Core/Behaviors/<kind>.lua) selected by
-- config.kind. Tracker asks the behavior what to draw (a displayState) and draws
-- it — see Behaviors/Stack.lua for the behavior interface + displayState fields.

ShoyrUI = ShoyrUI or {}

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style          -- shared fonts/border/bar (loaded before us)
local Tracker = {}
Tracker.__index = Tracker
ShoyrUI.Tracker = Tracker

local MIN_W, MIN_H = 80, 24
local MAX_W, MAX_H = 1200, 400

-- ---------------------------------------------------------------------------
-- Construction
-- ---------------------------------------------------------------------------

function Tracker.New(config)
    local self = setmetatable({}, Tracker)
    self.config = config
    self.id     = config.id

    local kind = config.kind or "stack"
    local BClass = ShoyrUI.Behaviors and ShoyrUI.Behaviors[kind]
    if not BClass then
        d("[Shoyru's UI] unknown tracker kind '" .. tostring(kind) .. "' for " ..
          tostring(self.id) .. "; using stack")
        BClass = ShoyrUI.Behaviors and ShoyrUI.Behaviors.stack
    end
    self.behavior = BClass.New(config)

    self.preview     = false
    self.previewStep = 1

    self:CreateUI()
    self:ApplyLayout()
    return self
end

-- ---------------------------------------------------------------------------
-- UI
-- ---------------------------------------------------------------------------

function Tracker:CreateUI()
    local c = self.config
    local win = WM:CreateTopLevelWindow("ShoyrUI_" .. self.id .. "_Window")
    win:SetDimensions(c.w or 220, c.h or 56)
    win:SetClampedToScreen(true)
    win:SetDimensionConstraints(MIN_W, MIN_H, MAX_W, MAX_H)
    win:SetDrawTier(DT_HIGH)
    win:SetDrawLayer(DL_OVERLAY)
    win:SetMovable(false)
    win:SetMouseEnabled(false)
    win:SetHidden(true)
    win:SetHandler("OnMoveStop", function() self:SavePosition() end)
    win:SetHandler("OnResizeStop", function() self:SaveDimensions(); self:SavePosition() end)
    self.win = win

    local icon = WM:CreateControl(nil, win, CT_TEXTURE)
    local iconPath = c.abilityIds and c.abilityIds[1] and GetAbilityIcon and GetAbilityIcon(c.abilityIds[1])
    if iconPath and iconPath ~= "" then icon:SetTexture(iconPath) end
    self.icon = icon

    local iconBorder = WM:CreateControl(nil, win, CT_BACKDROP)
    iconBorder:SetAnchor(TOPLEFT, icon, TOPLEFT, 0, 0)
    iconBorder:SetAnchor(BOTTOMRIGHT, icon, BOTTOMRIGHT, 0, 0)
    iconBorder:SetCenterColor(0, 0, 0, 0)
    self.iconBorder = iconBorder

    local stackLabel = WM:CreateControl(nil, icon, CT_LABEL)
    stackLabel:SetColor(1, 1, 1, 1)
    stackLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    stackLabel:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
    stackLabel:SetText("")
    self.stackLabel = stackLabel

    self.bar = Style.StyledBar.New(win, "ShoyrUI_" .. self.id .. "_Bar")
    self.barBg = self.bar.bg     -- alias: LayoutChildren anchors the bar background

    local nameLabel = WM:CreateControl(nil, win, CT_LABEL)
    nameLabel:SetColor(1, 1, 1, 1)
    nameLabel:SetText(c.name or "")
    self.nameLabel = nameLabel

    local timerLabel = WM:CreateControl(nil, win, CT_LABEL)
    timerLabel:SetColor(1, 1, 1, 1)
    timerLabel:SetText("")
    timerLabel:SetHidden(true)
    self.timerLabel = timerLabel

    self:LayoutChildren()
    self:ApplyBorder()
end

function Tracker:LayoutChildren()
    if not self.win then return end
    local h = self.win:GetHeight()
    local w = self.win:GetWidth()
    local iconSize = h
    local pad = 4

    self.icon:ClearAnchors()
    self.icon:SetAnchor(LEFT, self.win, LEFT, 0, 0)
    self.icon:SetDimensions(iconSize, iconSize)

    self.stackLabel:ClearAnchors()
    self.stackLabel:SetAnchor(BOTTOMRIGHT, self.icon, BOTTOMRIGHT, -2, -2)
    self.stackLabel:SetDimensions(iconSize - 4, iconSize - 4)

    local barX = iconSize + pad
    local barW = math.max(20, w - barX)
    local barH = math.max(8, math.floor(h * 0.35))
    self.barBg:ClearAnchors()
    self.barBg:SetAnchor(BOTTOMLEFT, self.win, BOTTOMLEFT, barX, 0)
    self.barBg:SetDimensions(barW, barH)
    -- (The fill is pinned inside the bar bg by StyledBar; width drives depletion.)

    self.nameLabel:ClearAnchors()
    self.nameLabel:SetAnchor(TOPLEFT, self.win, TOPLEFT, barX, 0)
    self.nameLabel:SetAnchor(BOTTOMRIGHT, self.barBg, TOPRIGHT, 0, -2)
    self.nameLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    self.nameLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)

    self.timerLabel:ClearAnchors()
    self.timerLabel:SetAnchor(RIGHT, self.barBg, RIGHT, -4, 0)
    self.timerLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    self.timerLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)

    self:ApplyFonts()
end

function Tracker:ApplyFonts()
    local h = self.win:GetHeight()
    local w = self.win:GetWidth()
    local fontSize = math.max(12, math.floor(math.min(h * 0.40, w * 0.10)))
    local font = Style.Font(fontSize, "text")
    self.nameLabel:SetFont(font)
    self.timerLabel:SetFont(font)
    self.stackLabel:SetFont(Style.Font(math.max(14, math.floor(h * 0.55)), "count"))
end

function Tracker:ApplyBorder()
    local c = self.config
    local col = c.borderColor or { r = 0, g = 0, b = 0, a = 1 }
    Style.ApplyBorder(self.iconBorder, col, c.borderThickness)
    Style.ApplyBorder(self.barBg, col, c.borderThickness)
end

function Tracker:ApplyLayout()
    local c = self.config
    self.win:ClearAnchors()
    self.win:SetAnchor(CENTER, GuiRoot, CENTER, c.x or 0, c.y or -260)
    self.win:SetDimensions(c.w or 220, c.h or 56)
    self.win:SetScale(c.scale or 1)
    self:LayoutChildren()
end

function Tracker:SavePosition()
    local c = self.config
    local cx, cy = self.win:GetCenter()
    c.x = cx - GuiRoot:GetWidth() / 2
    c.y = cy - GuiRoot:GetHeight() / 2
end

function Tracker:SaveDimensions()
    local c = self.config
    c.w = self.win:GetWidth()
    c.h = self.win:GetHeight()
    self:LayoutChildren()
end

function Tracker:SetInteractive(on)
    self.win:SetMovable(on)
    self.win:SetMouseEnabled(on)
    self.win:SetResizeHandleSize(on and 12 or 0)
end

-- Rebuild the behavior when the archetype changes in the editor. New per-kind
-- editor fields appear after the next panel rebuild (/reloadui).
function Tracker:SetKind(kind)
    self.config.kind = kind
    local BClass = (ShoyrUI.Behaviors and ShoyrUI.Behaviors[kind]) or (ShoyrUI.Behaviors and ShoyrUI.Behaviors.stack)
    if BClass then self.behavior = BClass.New(self.config) end
    self:Hide()
end

-- Clear the behavior's accumulated runtime state and hide. Call when something
-- changes WHAT the tracker watches (watch mode / perTarget / abilityIds), so stale
-- per-target or self stacks from the previous mode don't keep displaying.
function Tracker:ResetState()
    if self.behavior and self.behavior.Reset then self.behavior:Reset() end
    self:Hide()
end

-- Refresh the icon (e.g. after abilityIds change in the editor).
function Tracker:RefreshIcon()
    local c = self.config
    local iconPath = c.abilityIds and c.abilityIds[1] and GetAbilityIcon and GetAbilityIcon(c.abilityIds[1])
    if iconPath and iconPath ~= "" then self.icon:SetTexture(iconPath) end
end

-- ---------------------------------------------------------------------------
-- Rendering — consume a behavior displayState
-- ---------------------------------------------------------------------------

function Tracker:Hide()
    if self.win then self.win:SetHidden(true) end
end

function Tracker:Render(st)
    if not st then self:Hide() return end
    local c = self.config
    local color = st.color or { r = 1, g = 1, b = 1, a = 1 }
    local a = color.a or 1

    self.win:SetHidden(false)

    self.nameLabel:SetText(st.text or "")
    self.nameLabel:SetColor(color.r, color.g, color.b, a)

    if st.stacks then
        self.stackLabel:SetText(tostring(st.stacks))
        self.stackLabel:SetColor(color.r, color.g, color.b, a)
    else
        self.stackLabel:SetText("")
    end

    self.bar:SetBgColor(c.barBgColor or Style.BAR_BG)
    self.bar:SetPct(st.barPct or 0)
    self.bar:SetFillColor(color)

    if st.timerText then
        self.timerLabel:SetText(st.timerText)
        self.timerLabel:SetColor(color.r, color.g, color.b, a)
        self.timerLabel:SetHidden(false)
    else
        self.timerLabel:SetHidden(true)
    end
end

-- ---------------------------------------------------------------------------
-- Behavior delegation (called by Router)
-- ---------------------------------------------------------------------------

function Tracker:OnEffect(changeType, beginTime, endTime, stackCount, unitId, abilityId)
    self.behavior:OnEffect(changeType, beginTime, endTime, stackCount, unitId, abilityId)
end

-- Called by Router's shared tick. Returns true while the tracker still needs ticks.
function Tracker:Tick(now)
    if self.preview then
        self:Render(self.behavior:PreviewState(self.previewStep, now))
        return true
    end
    local st = self.behavior:Compute(now)
    if st then self:Render(st) else self:Hide() end
    return self.behavior:IsBusy(now)
end

function Tracker:IsBusy(now)
    if self.preview then return true end
    return self.behavior:IsBusy(now)
end

-- ---------------------------------------------------------------------------
-- Preview / unlock
-- ---------------------------------------------------------------------------

function Tracker:StartPreview()
    self.preview = true
    self.previewStep = 1
    self:SetInteractive(true)
end

function Tracker:StopPreview()
    self.preview = false
    self:SetInteractive(false)
    self:Hide()
end

-- Advance the synthetic preview phase; called from the Router tick on a slow clock.
function Tracker:PreviewStep()
    if not self.preview then return end
    local n = self.behavior:PreviewSteps()
    if not n or n < 1 then n = 1 end
    self.previewStep = self.previewStep + 1
    if self.previewStep > n then self.previewStep = 1 end
end

function Tracker:Destroy()
    if self.win then
        self.win:SetHidden(true)
        self.win:SetMouseEnabled(false)
    end
end
