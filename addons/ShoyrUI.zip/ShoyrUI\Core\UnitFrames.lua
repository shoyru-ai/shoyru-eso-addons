-- ShoyrUI :: Core/UnitFrames.lua
-- UI Layout module — custom unit frames. ONE generic Frame component parameterized by
-- which unit it watches and which power bars it shows; instantiated for Player and
-- Target (group/boss next). Built on the shared StyledBar so it matches the trackers.
-- Power-event driven, drag-to-move + LIVE drag-resize, per-bar color/text, "Off"
-- passthrough that restores the base-game frame.

ShoyrUI = ShoyrUI or {}
local UF = {}
ShoyrUI.UnitFrames = UF

local WM = WINDOW_MANAGER
local Style = ShoyrUI.Style

local STYLE_VERSION = 5   -- bump to re-apply cosmetic defaults / migrate the schema

-- Deep, flat DarkUI-style power colors.
local PCOLOR = {
    [POWERTYPE_HEALTH]  = { r = 0.58, g = 0.10, b = 0.12, a = 1 },
    [POWERTYPE_MAGICKA] = { r = 0.15, g = 0.30, b = 0.68, a = 1 },
    [POWERTYPE_STAMINA] = { r = 0.16, g = 0.48, b = 0.26, a = 1 },
}
local function P(pt, key) return { key = key, pt = pt, color = PCOLOR[pt] } end

-- Thousands-separated number ("27,057"), locale-aware via ESO's helper.
local function Commafy(n)
    if ZO_CommaDelimitNumber then return ZO_CommaDelimitNumber(n) end
    return tostring(n)
end

-- Static per-frame definitions (order = display order in the panel).
local FRAME_DEFS = {
    { id = "player", label = "Player", unit = "player", showName = true,
      powers = { P(POWERTYPE_HEALTH, "health"), P(POWERTYPE_MAGICKA, "magicka"), P(POWERTYPE_STAMINA, "stamina") },
      native = { "ZO_PlayerAttributeHealth", "ZO_PlayerAttributeMagicka", "ZO_PlayerAttributeStamina" },
      pos = { x = 0, y = 290, w = 300, h = 132 }, con = { 150, 64, 600, 240 } },
    -- Target: only Health is readable for arbitrary/enemy units; show their name.
    { id = "target", label = "Target", unit = "reticleover", showName = true,
      powers = { P(POWERTYPE_HEALTH, "health") },
      native = { "ZO_TargetUnitFramereticleover", "ZO_TargetUnitFrameGroupreticleover" },
      pos = { x = 0, y = -360, w = 340, h = 70 }, con = { 150, 40, 560, 110 } },
}

local function FrameDefaults(d)
    return {
        show = true, locked = true,
        showText = true, textMode = "value", gloss = true,
        x = d.pos.x, y = d.pos.y, w = d.pos.w, h = d.pos.h, scale = 1,
        barBgColor = { r = 0.035, g = 0.035, b = 0.045, a = 0.9 },
        borderColor = { r = 0, g = 0, b = 0, a = 1 }, borderThickness = 2,
        colors = {},
    }
end

-- "@account" + character name like the base UI.
local function UnitNameText(unit)
    local cn = GetUnitName(unit) or ""
    local acc = (GetUnitDisplayName and GetUnitDisplayName(unit)) or ""
    if acc ~= "" and acc:lower() ~= cn:lower() then return cn .. "   " .. acc end
    return cn
end

-- classId -> keyboard class icon path (built lazily in Init from GetClassInfo).
local CLASS_ICON = {}
local function BuildClassIcons()
    if next(CLASS_ICON) ~= nil then return end
    if not (GetNumClasses and GetClassInfo) then return end
    -- GetClassInfo()[1]=classId, [8]=the COLORED class icon (LUI uses [8]; [3] is a
    -- white silhouette, which is why our icons looked bland).
    for i = 1, GetNumClasses() do
        local info = { GetClassInfo(i) }
        if info[1] and info[8] and info[8] ~= "" then CLASS_ICON[info[1]] = info[8] end
    end
end

-- Level for sub-50, else champion points ("CP1234").
local function LevelText(unit)
    local cp = (GetUnitChampionPoints and GetUnitChampionPoints(unit)) or 0
    if cp and cp > 0 then return "CP " .. cp end
    return tostring((GetUnitLevel and GetUnitLevel(unit)) or 1)
end

local function ClassIconFor(unit)
    return CLASS_ICON[(GetUnitClassId and GetUnitClassId(unit)) or 0]
end
local function RankIconFor(unit)
    local rank = (GetUnitAvARank and GetUnitAvARank(unit)) or 0
    if rank > 0 and GetAvARankIcon then return GetAvARankIcon(rank) end
    return nil
end

-- Group frames: distinguishable per-CLASS bar colors (ESO exposes no class-color API, so
-- we ship a built-in flat palette) and per-ROLE colors. classId → color / roleId → color.
local CLASS_COLOR = {
    [1]   = { r = 0.80, g = 0.38, b = 0.16, a = 1 },  -- Dragonknight (ember)
    [2]   = { r = 0.42, g = 0.46, b = 0.86, a = 1 },  -- Sorcerer (arcane blue)
    [3]   = { r = 0.74, g = 0.20, b = 0.24, a = 1 },  -- Nightblade (crimson)
    [4]   = { r = 0.46, g = 0.70, b = 0.32, a = 1 },  -- Warden (green)
    [5]   = { r = 0.30, g = 0.64, b = 0.52, a = 1 },  -- Necromancer (bone teal)
    [6]   = { r = 0.84, g = 0.72, b = 0.32, a = 1 },  -- Templar (gold)
    [117] = { r = 0.26, g = 0.64, b = 0.64, a = 1 },  -- Arcanist (cyan)
}
local ROLE_COLOR = {
    [LFG_ROLE_DPS]  = { r = 0.70, g = 0.25, b = 0.25, a = 1 },
    [LFG_ROLE_TANK] = { r = 0.30, g = 0.45, b = 0.80, a = 1 },
    [LFG_ROLE_HEAL] = { r = 0.35, g = 0.70, b = 0.42, a = 1 },
}
local UNIFORM_HEALTH = { r = 0.58, g = 0.10, b = 0.12, a = 1 }   -- same red as player health
local OFFLINE_COLOR  = { r = 0.34, g = 0.34, b = 0.40, a = 1 }   -- desaturated grey for offline members

local function MemberColor(unitTag, mode)
    if mode == "role" then
        return ROLE_COLOR[GetGroupMemberSelectedRole(unitTag)] or UNIFORM_HEALTH
    elseif mode == "class" then
        return CLASS_COLOR[(GetUnitClassId and GetUnitClassId(unitTag)) or 0] or UNIFORM_HEALTH
    end
    return UNIFORM_HEALTH
end

-- The bootstrap merges this as the default for ShoyrUI.sv.layout. `activeUI` is the
-- universal switch — pick which UI is in use: "base" (base-game HUD) or "shoyru" (replace
-- it with Shoyru's frames). Extensible later (e.g. "lui"). No mixing. Per-frame sub-tables
-- are filled in Init so old saves migrate cleanly.
UF.DEFAULTS = { styleVersion = STYLE_VERSION, activeUI = "base", frames = {} }

local sv = nil           -- ShoyrUI.sv.layout  { styleVersion, frames = { player=…, target=… } }
UF.frames = {}           -- id -> Frame instance

-- ===========================================================================
-- Frame component
-- ===========================================================================

local Frame = {}
Frame.__index = Frame

function Frame.New(def, fsv)
    local self = setmetatable({}, Frame)
    self.def = def
    self.sv = fsv
    self.bars = {}        -- key -> { bar = StyledBar, label }
    self.nativeHidden = false
    return self
end

function Frame:FillColor(p)
    return (self.sv.colors and self.sv.colors[p.key]) or p.color
end

function Frame:SetBarValue(b, p, cur, max, smooth)
    cur = cur or 0                              -- GetUnitPower returns nil for an absent unit
    max = (max and max > 0) and max or 1
    b.lastMax = max                             -- remembered so SyncMax can detect a max change
    local pct = cur / max
    if smooth then b.bar:SetPctSmooth(pct) else b.bar:SetPct(pct) end
    if self.sv.showText then
        if self.sv.textMode == "percent" then
            b.label:SetText(string.format("%d%%", math.floor(pct * 100 + 0.5)))
        else
            b.label:SetText(Commafy(cur) .. " / " .. Commafy(max))
        end
        b.label:SetHidden(false)
    else
        b.label:SetHidden(true)
    end
end

function Frame:RefreshAll()
    if not self.frame then return end
    local u = self.def.unit
    -- Unit absent (e.g. an unlocked target frame with no reticle target) → show demo
    -- data so the frame is visible and can be positioned/resized.
    local preview = not self:UnitPresent()
    for _, p in ipairs(self.def.powers) do
        local b = self.bars[p.key]
        if b then
            if preview then
                self:SetBarValue(b, p, 72, 100)
            else
                local cur, mx, eff = GetUnitPower(self.def.unit, p.pt)
                self:SetBarValue(b, p, cur, (eff and eff > 0) and eff or mx)
            end
        end
    end
    if self.nameLabel then
        -- Show the @account handle only (the PvP identifier). NPCs/monsters have no
        -- @account → fall back to the character name so the label is never blank.
        local disp
        if preview then
            disp = "@" .. self.def.label
        else
            local acc = (GetUnitDisplayName and GetUnitDisplayName(u)) or ""
            disp = (acc ~= "" and acc) or (GetUnitName(u) or "")
        end
        self.nameLabel:SetText(disp)
        if self.acctLabel then self.acctLabel:SetHidden(true); self.acctLabel:SetText("") end
        -- Single name line → use the FULL header height; font ~0.9x it (floor 9) so it
        -- scales with the frame and stays inside the header (never spills onto the bar).
        local hh = self.headerH or 0
        if hh > 0 then
            self.nameLabel:SetHeight(hh)
            self.nameLabel:SetFont(Style.Font(math.max(10, math.floor(hh * 0.48)), "text"))
        end
        if self.levelLabel then self.levelLabel:SetText(preview and "" or LevelText(u)) end
        if self.classIcon then
            local icon = (not preview) and ClassIconFor(u) or nil
            self.classIcon:SetTexture(icon or "")
            self.classIcon:SetColor(1, 1, 1, 1)        -- [8] icon is already colored
            self.classIcon:SetHidden(not icon)
        end
        if self.rankIcon then
            local icon = (not preview) and RankIconFor(u) or nil
            self.rankIcon:SetTexture(icon or "")
            self.rankIcon:SetHidden(not icon)
            if icon and GetAllianceColor and GetUnitAlliance then
                local col = GetAllianceColor(GetUnitAlliance(u))   -- chevron is grayscale → tint it
                if col then self.rankIcon:SetColor(col:UnpackRGBA()) end
            end
        end
    end
end

-- Live-safe bar layout (runs every frame during a resize drag).
function Frame:LayoutBars(w, h)
    if not self.frame then return end
    local n = #self.def.powers
    local gap = (n > 1) and 1 or 0   -- tight stack for the player H/M/S bars
    -- Header (name/class/rank/level area) height is tied to the BAR THICKNESS, not the total
    -- frame height. So the target frame (1 bar) and the player frame (3 bars) get an IDENTICAL
    -- header — same fonts, icons, and layout — whenever their health bars are dragged to the
    -- same size, regardless of the frames' (necessarily different) total heights. Bars are also
    -- capped so a very tall frame grows the NAME instead of ballooning a bar into a slab.
    local MAX_BAR_H = 36
    local HEADER_RATIO = 1.4          -- header height ≈ this × bar thickness
    local barH, top
    if self.def.showName then
        -- Solve h = header + n·barH + gap·(n-1) with header = HEADER_RATIO·barH, so header (hence
        -- every header font) is a function of barH alone — equal bars ⇒ equal header across frames.
        barH = math.floor((h - gap * (n - 1)) / (HEADER_RATIO + n))
        barH = math.max(1, math.min(barH, MAX_BAR_H))
        top  = math.max(16, h - (barH * n + gap * (n - 1)))   -- header absorbs the remainder
    else
        barH = math.max(1, math.min(MAX_BAR_H, math.floor((h - gap * (n - 1)) / n)))
        top  = 0
    end
    local fontSize = math.max(13, math.floor(barH * 0.56))   -- bar value font scales with bar height
    if self.nameLabel then
        local hh = top
        self.headerH = hh
        -- Class icon, alliance-rank icon and the CP/level text all share ONE size (`elem`) and sit
        -- vertically CENTRED in the header, so they read as equal and stay in proportion as the
        -- frame is resized (everything is derived from the header height `hh`).
        local elem = math.max(10, math.floor(hh * 0.55))
        local midY = math.floor(hh / 2)
        local lvlFont = elem
        -- LEFT/RIGHT anchors reference each control's vertical centre, so pinning them at `midY`
        -- centres the icons AND the text on the same line.
        self.classIcon:ClearAnchors()
        self.classIcon:SetAnchor(LEFT, self.frame, TOPLEFT, 4, midY)
        self.classIcon:SetDimensions(elem, elem)
        self.levelLabel:ClearAnchors()
        self.levelLabel:SetAnchor(RIGHT, self.frame, TOPRIGHT, -4, midY)
        self.levelLabel:SetDimensions(math.max(60, math.floor(lvlFont * 4.6)), hh)   -- room for "CP 3600"; text vertically centred
        self.levelLabel:SetFont(Style.Font(lvlFont, "text"))
        self.rankIcon:ClearAnchors()
        self.rankIcon:SetAnchor(RIGHT, self.levelLabel, LEFT, -2, 0)
        self.rankIcon:SetDimensions(elem, elem)
        -- Name spans between the class icon and the rank icon, vertically centred. Its height/font
        -- are set in RefreshAll (which knows whether @account is shown) so text fits inside `hh`.
        self.nameLabel:ClearAnchors()
        self.nameLabel:SetAnchor(LEFT,  self.classIcon, RIGHT, 4, 0)
        self.nameLabel:SetAnchor(RIGHT, self.rankIcon,  LEFT, -4, 0)
        self.acctLabel:ClearAnchors()
        self.acctLabel:SetAnchor(TOPLEFT,  self.nameLabel, BOTTOMLEFT, 0, -1)
        self.acctLabel:SetAnchor(TOPRIGHT, self.nameLabel, BOTTOMRIGHT, 0, -1)
    end
    for i, p in ipairs(self.def.powers) do
        local b = self.bars[p.key]
        if b then
            b.bar.bg:ClearAnchors()
            b.bar.bg:SetAnchor(TOPLEFT, self.frame, TOPLEFT, 0, top + (i - 1) * (barH + gap))
            b.bar.bg:SetDimensions(w, barH)
            b.bar:SetBgColor(self.sv.barBgColor)
            b.bar:SetBorder(self.sv.borderColor, self.sv.borderThickness)
            b.bar:SetGloss(self.sv.gloss ~= false)
            b.bar:SetFillColor(self:FillColor(p))
            b.label:ClearAnchors()
            b.label:SetAnchor(LEFT,  b.bar.bg, LEFT,   6, 0)
            b.label:SetAnchor(RIGHT, b.bar.bg, RIGHT, -6, 0)
            b.label:SetFont(Style.Font(fontSize, "text"))
        end
    end
    self:RefreshAll()
end

function Frame:SavePosition()
    if not self.frame then return end
    -- Snap the on-screen top-left to the grid (if enabled), then store as a centre offset.
    local snap = ShoyrUI.Grid and ShoyrUI.Grid.Snap or function(v) return v end
    local left, top = snap(self.frame:GetLeft()), snap(self.frame:GetTop())
    local cx, cy = left + self.frame:GetWidth() / 2, top + self.frame:GetHeight() / 2
    self.sv.x = cx - GuiRoot:GetWidth() / 2
    self.sv.y = cy - GuiRoot:GetHeight() / 2
    self.frame:ClearAnchors()
    self.frame:SetAnchor(CENTER, GuiRoot, CENTER, self.sv.x, self.sv.y)   -- snap into place visually
end

function Frame:SaveDimensions()
    if not self.frame then return end
    self.sv.w, self.sv.h = self.frame:GetWidth(), self.frame:GetHeight()
    self:SavePosition()
    self:LayoutBars(self.sv.w, self.sv.h)
end

function Frame:ApplyNativeHidden()
    for _, n in ipairs(self.def.native or {}) do
        local c = _G[n]
        if c then
            -- Use OUR hide reason (like the group frame) so ESO re-showing its own frame on a HUD-scene
            -- transition (closing the map/inventory/settings) can't reveal it back over ours.
            if c.SetHiddenForReason then c:SetHiddenForReason("ShoyrUIFrame", self.nativeHidden) end
            c:SetHidden(self.nativeHidden)
        end
    end
end

function Frame:Build()
    if self.frame then return end
    local f = WM:CreateTopLevelWindow("ShoyrUI_Frame_" .. self.def.id)
    self.frame = f
    f:SetClampedToScreen(true)
    f:SetMovable(false)
    f:SetMouseEnabled(false)
    f:SetResizeHandleSize(0)
    local c = self.def.con or { 120, 28, 800, 360 }
    f:SetDimensionConstraints(c[1], c[2], c[3], c[4])
    f:SetDrawTier(DT_LOW)
    f:SetHandler("OnMoveStop", function() self:SavePosition() end)
    f:SetHandler("OnResizeStart", function()
        f:SetHandler("OnUpdate", function() self:LayoutBars(f:GetWidth(), f:GetHeight()) end)
    end)
    f:SetHandler("OnResizeStop", function()
        f:SetHandler("OnUpdate", nil); self:SaveDimensions()
    end)

    if self.def.showName then
        self.classIcon = WM:CreateControl(nil, f, CT_TEXTURE)
        self.rankIcon = WM:CreateControl(nil, f, CT_TEXTURE)
        self.nameLabel = WM:CreateControl(nil, f, CT_LABEL)
        self.nameLabel:SetColor(1, 1, 1, 1)
        self.nameLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        self.nameLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        self.nameLabel:SetMaxLineCount(1)                       -- never wrap to 2 lines
        if self.nameLabel.SetWrapMode then self.nameLabel:SetWrapMode(TEXT_WRAP_MODE_ELLIPSIS) end   -- truncate over-long handles
        self.acctLabel = WM:CreateControl(nil, f, CT_LABEL)   -- @account, stacked under name
        self.acctLabel:SetColor(0.7, 0.7, 0.78, 1)
        self.acctLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        self.acctLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        self.levelLabel = WM:CreateControl(nil, f, CT_LABEL)
        self.levelLabel:SetColor(0.9, 0.9, 0.95, 1)
        self.levelLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
        self.levelLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    end
    for _, p in ipairs(self.def.powers) do
        local b = {}
        b.bar = Style.StyledBar.New(f, "ShoyrUI_" .. self.def.id .. "_" .. p.key)
        b.label = WM:CreateControl(nil, b.bar.bg, CT_LABEL)
        b.label:SetColor(1, 1, 1, 1)
        b.label:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
        b.label:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        b.label:SetDrawLayer(DL_OVERLAY)
        self.bars[p.key] = b
    end
    self.editFrame = Style.CreateEditFrame(f)   -- shared "unlocked = draggable" affordance
    self:ApplyLayout()
end

function Frame:ApplyLayout()
    if not self.frame then return end
    local c = self.def.con   -- clamp a previously-saved oversize back into range
    if c then
        self.sv.w = math.max(c[1], math.min(c[3], self.sv.w or c[1]))
        self.sv.h = math.max(c[2], math.min(c[4], self.sv.h or c[2]))
    end
    self.frame:ClearAnchors()
    self.frame:SetAnchor(CENTER, GuiRoot, CENTER, self.sv.x, self.sv.y)
    self.frame:SetDimensions(self.sv.w, self.sv.h)
    self.frame:SetScale(self.sv.scale or 1)
    self:LayoutBars(self.sv.w, self.sv.h)
end

-- "Showing in normal (locked) play": our UI is the active one AND this frame isn't
-- individually hidden. Unlocking overrides this for editing (see UpdateVisibility).
function Frame:Active()
    return sv.activeUI == "shoyru" and self.sv.show ~= false
end

-- Hide ESO's native frame when ours takes its place: when our UI is active AND either
-- the frame shows in play OR we're editing it (unlocked) — so editing never leaves the
-- base frame overlapping our preview, and turning a frame off restores the base one.
function Frame:WantsNativeHidden()
    return sv.activeUI == "shoyru" and (self.sv.show ~= false or self.sv.locked == false)
end

-- For dynamic units (target), the frame is only shown when the unit exists.
function Frame:UnitPresent()
    if self.def.unit == "player" then return true end
    return DoesUnitExist(self.def.unit)
end

function Frame:Apply()
    if sv.activeUI == "shoyru" then
        self:Build()
        self:SetLocked(self.sv.locked ~= false)   -- applies movability + native-hide + visibility + refresh
    else
        if self.frame then self.frame:SetHidden(true) end
        self.nativeHidden = false                 -- not using our UI → restore ESO's frame
        self:ApplyNativeHidden()
    end
end

function Frame:SetLocked(locked)
    self.sv.locked = locked
    if not self.frame then return end
    self.frame:SetMovable(not locked)
    self.frame:SetMouseEnabled(not locked)
    self.frame:SetResizeHandleSize(locked and 0 or 12)
    Style.SetEditFrame(self.editFrame, not locked, self.sv.h)
    self.nativeHidden = self:WantsNativeHidden()   -- editing (unlocked) also hides the base frame
    self:ApplyNativeHidden()
    self:UpdateVisibility()
    self:RefreshAll()   -- show the demo preview immediately when unlocked with no target
end

function Frame:ResetPosition()
    local d = self.def.pos
    self.sv.x, self.sv.y, self.sv.w, self.sv.h, self.sv.scale = d.x, d.y, d.w, d.h, 1
    self:ApplyLayout()
end

-- Power-update / target-change inputs (routed by UF).
function Frame:OnPower(powerType, value, max)
    if not self.frame or self.frame:IsHidden() then return end
    for _, p in ipairs(self.def.powers) do
        if p.pt == powerType then
            self:SetBarValue(self.bars[p.key], p, value, max, true)
            return
        end
    end
end

-- Re-sync the bars when an EFFECTIVE MAX changed (food/buff/mundus applied or dropped). EVENT_POWER_
-- UPDATE doesn't reliably fire for a max-only change while the current value is unchanged, so the bar
-- would keep the stale max until the next power tick (Base UI stays in sync because it re-reads too).
-- Gated on an actual max change so it never fights the smooth value animation during combat.
function Frame:SyncMax()
    if not self.frame or self.frame:IsHidden() or not self:UnitPresent() then return end
    for _, p in ipairs(self.def.powers) do
        local b = self.bars[p.key]
        if b then
            local cur, mx, eff = GetUnitPower(self.def.unit, p.pt)
            local m = (eff and eff > 0) and eff or mx
            if m ~= b.lastMax then self:SetBarValue(b, p, cur, m, true) end
        end
    end
end

-- UNLOCKED (editing): always visible so you can position/resize it, regardless of
-- "Show this frame" or whether a unit exists (shows demo data via RefreshAll).
-- LOCKED (normal play): visible only when our UI is active, the frame is shown, AND the
-- unit exists — so the target frame appears only while you're looking at a target.
function Frame:UpdateVisibility()
    if not self.frame then return end
    local editing = sv.activeUI == "shoyru" and self.sv.locked == false
    -- In a menu (inventory/map/settings) hide like the native HUD — but keep UNLOCKED frames
    -- visible so they're still positionable from the settings panel.
    local normal = self:Active() and self:UnitPresent() and not UF.menuOpen
    self.frame:SetHidden(not (editing or normal))
end

function Frame:OnTargetChanged()
    if sv.activeUI ~= "shoyru" or not self.frame then return end
    self.nativeHidden = self:WantsNativeHidden()   -- ESO re-shows its target frame on a new target; re-assert
    self:ApplyNativeHidden()
    self:UpdateVisibility()        -- hide (locked) when no target, stay shown when editing
    self:RefreshAll()              -- always refresh so a new/absent target replaces stale data
end

-- ---------------------------------------------------------------------------
-- Per-frame settings (a submenu in the UI Layout panel)
-- ---------------------------------------------------------------------------

function Frame:DefaultColor(key)
    for _, p in ipairs(self.def.powers) do if p.key == key then return p.color end end
    return { r = 1, g = 1, b = 1, a = 1 }
end

function Frame:PanelControls()
    local svf = self.sv
    local function colorGet(key) return function()
        local c = (svf.colors and svf.colors[key]) or self:DefaultColor(key)
        return c.r, c.g, c.b, c.a or 1
    end end
    local function colorSet(key) return function(r, g, b, a)
        svf.colors[key] = { r = r, g = g, b = b, a = a or 1 }; self:ApplyLayout()
    end end

    local o = {
        { type = "checkbox", name = "Show this frame", width = "half",
          tooltip = "Show this frame during normal play. (While Unlock is on it stays visible regardless, so you can position it.)",
          getFunc = function() return svf.show ~= false end,
          setFunc = function(v) svf.show = v; self:Apply() end },
        { type = "checkbox", name = "Unlock (move + resize)", width = "half",
          tooltip = "Edit mode: the frame is always visible (even with no target) so you can drag to move and drag a corner to resize. Lock when done.",
          getFunc = function() return not svf.locked end,
          setFunc = function(v) self:SetLocked(not v) end },
        { type = "checkbox", name = "Show numbers", width = "half",
          getFunc = function() return svf.showText end,
          setFunc = function(v) svf.showText = v; self:RefreshAll() end },
        { type = "dropdown", name = "Number style", choices = { "Value", "Percent" }, choicesValues = { "value", "percent" }, width = "half",
          getFunc = function() return svf.textMode end,
          setFunc = function(v) svf.textMode = v; self:RefreshAll() end },
        { type = "checkbox", name = "Glossy bars", width = "half",
          tooltip = "A subtle sheen over the top of each bar.",
          getFunc = function() return svf.gloss ~= false end,
          setFunc = function(v) svf.gloss = v; self:ApplyLayout() end },
        { type = "header", name = "Colors" },
    }
    for _, p in ipairs(self.def.powers) do
        local key = p.key
        o[#o + 1] = { type = "colorpicker", name = key:gsub("^%l", string.upper),
                      getFunc = colorGet(key), setFunc = colorSet(key) }
    end
    o[#o + 1] = { type = "colorpicker", name = "Bar background",
                  getFunc = function() local c = svf.barBgColor; return c.r, c.g, c.b, c.a or 0.9 end,
                  setFunc = function(r, g, b, a) svf.barBgColor = { r = r, g = g, b = b, a = a or 0.9 }; self:ApplyLayout() end }
    o[#o + 1] = { type = "colorpicker", name = "Border",
                  getFunc = function() local c = svf.borderColor; return c.r, c.g, c.b, c.a or 1 end,
                  setFunc = function(r, g, b, a) svf.borderColor = { r = r, g = g, b = b, a = a or 1 }; self:ApplyLayout() end }
    o[#o + 1] = { type = "dropdown", name = "Border thickness", choices = { "Thin", "Medium", "Thick" }, choicesValues = { 2, 4, 8 }, width = "half",
                  getFunc = function() return svf.borderThickness or 2 end,
                  setFunc = function(v) svf.borderThickness = v; self:ApplyLayout() end }
    o[#o + 1] = { type = "button", name = "Reset position/size", width = "half", func = function() self:ResetPosition() end }
    return o
end

-- ===========================================================================
-- Group frame: a draggable container holding up to 12 dynamic member rows. The
-- container box == ONE row (width × rowH); rows 2..N stack downward as children, so
-- resizing the box sets the per-member width + height and the list grows with the group.
-- Each row = class icon + health bar (colored by class/role/uniform) + @name (+ value).
-- ===========================================================================

local GROUP_MAX = 12
local GROUP_PREVIEW = 4   -- demo rows shown when unlocked while solo, for positioning

local GROUP_DEF = {
    id = "group", label = "Group",
    native = { "ZO_SmallGroupAnchorFrame", "ZO_LargeGroupAnchorFrame" },
    pos = { x = -640, y = -120, w = 240, rowH = 30 }, con = { 120, 18, 480, 64 },
}

local function GroupDefaults()
    return {
        show = true, locked = true, showText = true, textMode = "percent",
        colorMode = "uniform", spacing = 2, gloss = true,
        x = GROUP_DEF.pos.x, y = GROUP_DEF.pos.y, w = GROUP_DEF.pos.w, rowH = GROUP_DEF.pos.rowH, scale = 1,
        barBgColor = { r = 0.035, g = 0.035, b = 0.045, a = 0.9 },
        borderColor = { r = 0, g = 0, b = 0, a = 1 }, borderThickness = 2,
    }
end

local GroupFrame = {}
GroupFrame.__index = GroupFrame

function GroupFrame.New(def, gsv)
    local self = setmetatable({}, GroupFrame)
    self.def = def
    self.sv = gsv
    self.members = {}        -- index → { bar, classIcon, nameLabel, valueLabel, unitTag }
    self.nativeHidden = false
    return self
end

function GroupFrame:Active() return sv.activeUI == "shoyru" and self.sv.show ~= false end
function GroupFrame:WantsNativeHidden()
    return sv.activeUI == "shoyru" and (self.sv.show ~= false or self.sv.locked == false)
end
local function HideControl(c, hidden, reason)
    if not c then return end
    -- SetHiddenForReason adds OUR hide reason — effective-hidden if ANY reason is set, so
    -- ESO toggling its own visibility (HUD scene re-show) can't reveal it.
    if c.SetHiddenForReason then c:SetHiddenForReason(reason or "ShoyrUIGroup", hidden) end
    c:SetHidden(hidden)
end

function GroupFrame:ApplyNativeHidden()
    local hidden = self.nativeHidden
    -- (1) the anchor containers, and (2) each default group unit frame directly — the small-
    -- group member frames aren't children of the anchor, so hiding the anchor alone isn't
    -- enough. ZO_UnitFrames_GetUnitFrame is the same global LuiExtended uses for unit frames.
    for _, n in ipairs(self.def.native or {}) do HideControl(_G[n], hidden) end
    if ZO_UnitFrames_GetUnitFrame then
        for i = 1, GROUP_MAX do
            local uf = ZO_UnitFrames_GetUnitFrame("group" .. i)
            if uf then HideControl(uf.frame or uf.control, hidden) end
        end
    end
end

function GroupFrame:Build()
    if self.frame then return end
    local f = WM:CreateTopLevelWindow("ShoyrUI_GroupFrame")
    self.frame = f
    f:SetClampedToScreen(true)
    f:SetMovable(false); f:SetMouseEnabled(false); f:SetResizeHandleSize(0)
    local c = self.def.con
    f:SetDimensionConstraints(c[1], c[2], c[3], c[4])
    f:SetDrawTier(DT_LOW)
    f:SetHandler("OnMoveStop", function() self:SavePosition() end)
    f:SetHandler("OnResizeStart", function() f:SetHandler("OnUpdate", function() self:LayoutDuringResize() end) end)
    f:SetHandler("OnResizeStop", function() f:SetHandler("OnUpdate", nil); self:SaveDimensions() end)
    for i = 1, GROUP_MAX do
        local m = {}
        m.bar = Style.StyledBar.New(f, "ShoyrUI_Group_" .. i)
        m.classIcon = WM:CreateControl(nil, m.bar.bg, CT_TEXTURE)
        m.classIcon:SetDrawLayer(DL_OVERLAY)
        -- Group-leader crown, hung just left of the row (positioned in PositionRows).
        m.leaderIcon = WM:CreateControl(nil, m.bar.bg, CT_TEXTURE)
        m.leaderIcon:SetTexture("/esoui/art/lfg/lfg_leader_icon.dds")
        m.leaderIcon:SetDrawLayer(DL_OVERLAY)
        m.leaderIcon:SetDrawLevel(2)   -- above the class icon
        m.leaderIcon:SetHidden(true)
        m.nameLabel = WM:CreateControl(nil, m.bar.bg, CT_LABEL)
        m.nameLabel:SetColor(1, 1, 1, 1)
        m.nameLabel:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
        m.nameLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        m.nameLabel:SetMaxLineCount(1)
        if m.nameLabel.SetWrapMode then m.nameLabel:SetWrapMode(TEXT_WRAP_MODE_ELLIPSIS) end
        m.nameLabel:SetDrawLayer(DL_OVERLAY)
        m.valueLabel = WM:CreateControl(nil, m.bar.bg, CT_LABEL)
        m.valueLabel:SetColor(1, 1, 1, 1)
        m.valueLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
        m.valueLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        m.valueLabel:SetDrawLayer(DL_OVERLAY)
        self.members[i] = m
    end
    self.editFrame = Style.CreateEditFrame(f)   -- shared "unlocked = draggable" affordance
    self:ApplyLayout()
end

-- How many rows are laid out right now: demo count when editing solo, else the group
-- size (floored at 1 so geometry never divides by zero — the frame is hidden when solo).
function GroupFrame:LayoutRowCount()
    local editing = sv.activeUI == "shoyru" and self.sv.locked == false
    local size = GetGroupSize()
    if editing and size <= 1 then return GROUP_PREVIEW end
    return math.max(1, size)
end

-- Anchor + size every member row for a given per-row width/height. Does NOT touch the
-- container's own dimensions (so it's safe to call live during a resize drag).
function GroupFrame:PositionRows(w, rowH)
    local spacing = self.sv.spacing or 2
    local ico = math.max(8, rowH - 4)
    local font = math.max(10, math.floor(rowH * 0.42))
    local valW = math.max(36, math.floor(font * 3))
    for i, m in ipairs(self.members) do
        local y = (i - 1) * (rowH + spacing)
        m.bar.bg:ClearAnchors()
        m.bar.bg:SetAnchor(TOPLEFT, self.frame, TOPLEFT, 0, y)
        m.bar.bg:SetDimensions(w, rowH)
        m.bar:SetBgColor(self.sv.barBgColor)
        m.bar:SetBorder(self.sv.borderColor, self.sv.borderThickness)
        m.bar:SetGloss(self.sv.gloss ~= false)
        m.classIcon:ClearAnchors()
        m.classIcon:SetAnchor(LEFT, m.bar.bg, LEFT, 3, 0)
        m.classIcon:SetDimensions(ico, ico)
        -- Leader crown hangs just LEFT of the row (clean background) so the big class
        -- icon doesn't bury it; vertically centred, no layout shift on non-leader rows.
        local crown = math.max(12, math.floor(rowH * 0.85))
        m.leaderIcon:ClearAnchors()
        m.leaderIcon:SetAnchor(RIGHT, m.bar.bg, LEFT, -3, 0)
        m.leaderIcon:SetDimensions(crown, crown)
        m.nameLabel:ClearAnchors()
        m.nameLabel:SetAnchor(LEFT, m.classIcon, RIGHT, 4, 0)
        m.nameLabel:SetAnchor(RIGHT, m.bar.bg, RIGHT, -(valW + 6), 0)
        m.nameLabel:SetHeight(rowH)
        m.nameLabel:SetFont(Style.Font(font, "text"))
        m.valueLabel:ClearAnchors()
        m.valueLabel:SetAnchor(RIGHT, m.bar.bg, RIGHT, -5, 0)
        m.valueLabel:SetDimensions(valW, rowH)
        m.valueLabel:SetFont(Style.Font(font, "text"))
    end
end

-- Authoritative layout: size the container to hold ALL shown rows at the saved rowH,
-- constrain the resize handle so a drag keeps rowH within range, then position + refresh.
function GroupFrame:LayoutMembers()
    if not self.frame then return end
    local c = self.def.con   -- { minW, minRowH, maxW, maxRowH }
    local shown = self:LayoutRowCount()
    local spacing = self.sv.spacing or 2
    self.sv.w = math.max(c[1], math.min(c[3], self.sv.w or 240))
    self.sv.rowH = math.max(c[2], math.min(c[4], self.sv.rowH or 30))
    local extra = spacing * (shown - 1)
    self.frame:SetDimensionConstraints(c[1], c[2] * shown + extra, c[3], c[4] * shown + extra)
    self.frame:SetDimensions(self.sv.w, self.sv.rowH * shown + extra)
    self:PositionRows(self.sv.w, self.sv.rowH)
    self:Refresh()
end

-- Live during a resize drag: derive the per-row width/height from the container's CURRENT
-- size (the user is dragging it) and lay rows out to fill — don't re-set container dims.
function GroupFrame:LayoutDuringResize()
    if not self.frame then return end
    local c = self.def.con
    local shown = self:LayoutRowCount()
    local spacing = self.sv.spacing or 2
    local rowH = math.max(c[2], math.min(c[4], math.floor((self.frame:GetHeight() - spacing * (shown - 1)) / shown)))
    self:PositionRows(self.frame:GetWidth(), rowH)
    self:Refresh()
end

function GroupFrame:SetMemberHealth(m, cur, mx, smooth)
    cur = cur or 0; mx = (mx and mx > 0) and mx or 1
    local pct = cur / mx
    if smooth then m.bar:SetPctSmooth(pct) else m.bar:SetPct(pct) end
    if self.sv.showText then
        if self.sv.textMode == "percent" then
            m.valueLabel:SetText(string.format("%d%%", math.floor(pct * 100 + 0.5)))
        else
            m.valueLabel:SetText(Commafy(cur))
        end
        m.valueLabel:SetHidden(false)
    else
        m.valueLabel:SetHidden(true)
    end
end

function GroupFrame:SetMemberLive(m, tag)
    local acc = (GetUnitDisplayName and GetUnitDisplayName(tag)) or ""
    m.nameLabel:SetText((acc ~= "" and acc) or (GetUnitName(tag) or tag))
    local icon = ClassIconFor(tag)
    m.classIcon:SetTexture(icon or ""); m.classIcon:SetHidden(not icon)
    m.leaderIcon:SetHidden(not (IsUnitGroupLeader and IsUnitGroupLeader(tag)))
    local cur, mx = GetUnitPower(tag, POWERTYPE_HEALTH)
    local online = (IsUnitOnline == nil) or IsUnitOnline(tag)
    local dead = IsUnitDead and IsUnitDead(tag)
    -- Offline members read as inactive like base game / LUI: grey bar + greyed class icon, an
    -- "Offline" status in place of a stale health value, and a dimmed row. Dead-but-online keeps
    -- the class/role colour but is dimmed and labelled "Dead".
    if not online then
        m.bar:SetFillColor(OFFLINE_COLOR)
        m.classIcon:SetColor(0.5, 0.5, 0.5, 1)
    else
        m.bar:SetFillColor(MemberColor(tag, self.sv.colorMode))
        m.classIcon:SetColor(1, 1, 1, 1)
    end
    self:SetMemberHealth(m, cur, mx, false)
    if self.sv.showText then
        if not online then m.valueLabel:SetText("Offline"); m.valueLabel:SetHidden(false)
        elseif dead then m.valueLabel:SetText("Dead"); m.valueLabel:SetHidden(false) end
    end
    local alpha = 1
    if not online then alpha = 0.5 elseif dead then alpha = 0.4 end
    m.bar.bg:SetAlpha(alpha)
end

function GroupFrame:SetMemberPreview(m, i)
    m.nameLabel:SetText("@GroupMember" .. i)
    m.classIcon:SetHidden(true)
    m.leaderIcon:SetHidden(i ~= 1)   -- demo the crown on the first row while positioning
    m.bar:SetFillColor(UNIFORM_HEALTH)
    local demo = { 100, 72, 45, 90 }
    self:SetMemberHealth(m, demo[i] or 80, 100, false)
    m.bar.bg:SetAlpha(1)
end

function GroupFrame:Refresh()
    if not self.frame then return end
    local editing = sv.activeUI == "shoyru" and self.sv.locked == false
    local size = GetGroupSize()
    local preview = editing and (size <= 1)         -- solo while editing → demo rows
    local shown = preview and GROUP_PREVIEW or size
    for i, m in ipairs(self.members) do
        if i <= shown then
            m.bar.bg:SetHidden(false)
            if preview then
                m.unitTag = nil; self:SetMemberPreview(m, i)
            else
                local tag = GetGroupUnitTagByIndex(i)
                m.unitTag = tag
                if tag and DoesUnitExist(tag) then self:SetMemberLive(m, tag) else m.bar.bg:SetHidden(true) end
            end
        else
            m.bar.bg:SetHidden(true); m.unitTag = nil
        end
    end
end

function GroupFrame:OnGroupPower(tag, value, max)
    if not self.frame or self.frame:IsHidden() then return end
    for _, m in ipairs(self.members) do
        if m.unitTag == tag and not m.bar.bg:IsHidden() then
            self:SetMemberHealth(m, value, max, true); return
        end
    end
end

-- Top-left anchored (offset from screen center) so the list grows DOWNWARD and members
-- joining/leaving don't shift the whole block around a center point.
function GroupFrame:SavePosition()
    if not self.frame then return end
    local snap = ShoyrUI.Grid and ShoyrUI.Grid.Snap or function(v) return v end
    local left, top = snap(self.frame:GetLeft()), snap(self.frame:GetTop())
    self.sv.x = left - GuiRoot:GetWidth() / 2
    self.sv.y = top - GuiRoot:GetHeight() / 2
    self.frame:ClearAnchors()
    self.frame:SetAnchor(TOPLEFT, GuiRoot, CENTER, self.sv.x, self.sv.y)   -- snap into place visually
end

function GroupFrame:SaveDimensions()
    if not self.frame then return end
    local c = self.def.con
    local shown = self:LayoutRowCount()
    local spacing = self.sv.spacing or 2
    self.sv.w = math.max(c[1], math.min(c[3], self.frame:GetWidth()))
    self.sv.rowH = math.max(c[2], math.min(c[4], math.floor((self.frame:GetHeight() - spacing * (shown - 1)) / shown)))
    self:SavePosition()
    self:LayoutMembers()   -- snap container to the exact block height for the saved rowH
end

function GroupFrame:ApplyLayout()
    if not self.frame then return end
    self.frame:ClearAnchors()
    self.frame:SetAnchor(TOPLEFT, GuiRoot, CENTER, self.sv.x, self.sv.y)
    self.frame:SetScale(self.sv.scale or 1)
    self:LayoutMembers()   -- clamps w/rowH, sets constraints + dimensions, positions rows
end

function GroupFrame:UpdateVisibility()
    if not self.frame then return end
    local editing = sv.activeUI == "shoyru" and self.sv.locked == false
    local normal = self:Active() and GetGroupSize() > 1 and not UF.menuOpen
    self.frame:SetHidden(not (editing or normal))
end

function GroupFrame:SetLocked(locked)
    self.sv.locked = locked
    if not self.frame then return end
    self.frame:SetMovable(not locked)
    self.frame:SetMouseEnabled(not locked)
    self.frame:SetResizeHandleSize(locked and 0 or 12)
    Style.SetEditFrame(self.editFrame, not locked, self.sv.h)
    self.nativeHidden = self:WantsNativeHidden()
    self:ApplyNativeHidden()
    self:UpdateVisibility()
    self:LayoutMembers()   -- re-layout + Refresh (demo rows when unlocked solo)
end

function GroupFrame:Apply()
    if sv.activeUI == "shoyru" then
        self:Build()
        self:SetLocked(self.sv.locked ~= false)
    else
        if self.frame then self.frame:SetHidden(true) end
        self.nativeHidden = false
        self:ApplyNativeHidden()
    end
end

function GroupFrame:ResetPosition()
    local d = self.def.pos
    self.sv.x, self.sv.y, self.sv.w, self.sv.rowH, self.sv.scale = d.x, d.y, d.w, d.rowH, 1
    self:ApplyLayout()
end

function GroupFrame:OnGroupChanged()
    if sv.activeUI ~= "shoyru" or not self.frame then return end
    self.nativeHidden = self:WantsNativeHidden()
    self:ApplyNativeHidden()       -- ESO re-shows its group frames on group changes; re-assert
    self:UpdateVisibility()
    self:LayoutMembers()           -- relayout so the container resizes to the new member count
    -- ESO can (re)create a native member frame a frame or two AFTER the group event fires (a member
    -- joining, or reconnecting from offline). A one-shot deferred re-assert catches that async case
    -- so a native frame never lingers beside ours.
    zo_callLater(function()
        if self.frame and sv.activeUI == "shoyru" then self.nativeHidden = self:WantsNativeHidden(); self:ApplyNativeHidden() end
    end, 250)
end

-- Re-assert only the native-frame hide (no relayout). Used by the delayed post-zone sweep, because
-- Battlegrounds (and some scene loads) set up ESO's group frames a moment AFTER EVENT_PLAYER_ACTIVATED,
-- so the single hide during UF.Apply doesn't stick.
function GroupFrame:ReassertNative()
    if sv.activeUI ~= "shoyru" or not self.frame then return end
    self.nativeHidden = self:WantsNativeHidden()
    self:ApplyNativeHidden()
end

function GroupFrame:PanelControls()
    local svf = self.sv
    return {
        { type = "checkbox", name = "Show this frame", width = "half",
          tooltip = "Show the group frame in normal play (only while you're in a group). While Unlock is on it stays visible for positioning.",
          getFunc = function() return svf.show ~= false end,
          setFunc = function(v) svf.show = v; self:Apply() end },
        { type = "checkbox", name = "Unlock (move + resize)", width = "half",
          tooltip = "Edit mode: shows demo members so you can drag to move and resize a row (the list grows downward). Lock when done.",
          getFunc = function() return not svf.locked end,
          setFunc = function(v) self:SetLocked(not v) end },
        { type = "dropdown", name = "Bar color", width = "half",
          choices = { "Class", "Role", "Health (uniform)" }, choicesValues = { "class", "role", "uniform" },
          getFunc = function() return svf.colorMode or "class" end,
          setFunc = function(v) svf.colorMode = v; self:Refresh() end },
        { type = "slider", name = "Row spacing", min = 0, max = 12, step = 1, width = "half",
          getFunc = function() return svf.spacing or 2 end,
          setFunc = function(v) svf.spacing = v; self:LayoutMembers() end },
        { type = "checkbox", name = "Show numbers", width = "half",
          getFunc = function() return svf.showText end,
          setFunc = function(v) svf.showText = v; self:Refresh() end },
        { type = "dropdown", name = "Number style", choices = { "Percent", "Value" }, choicesValues = { "percent", "value" }, width = "half",
          getFunc = function() return svf.textMode end,
          setFunc = function(v) svf.textMode = v; self:Refresh() end },
        { type = "checkbox", name = "Glossy bars", width = "half",
          tooltip = "A subtle sheen over the top of each bar.",
          getFunc = function() return svf.gloss ~= false end,
          setFunc = function(v) svf.gloss = v; self:LayoutMembers() end },
        { type = "header", name = "Colors" },
        { type = "colorpicker", name = "Bar background",
          getFunc = function() local c = svf.barBgColor; return c.r, c.g, c.b, c.a or 0.9 end,
          setFunc = function(r, g, b, a) svf.barBgColor = { r = r, g = g, b = b, a = a or 0.9 }; self:LayoutMembers() end },
        { type = "colorpicker", name = "Border",
          getFunc = function() local c = svf.borderColor; return c.r, c.g, c.b, c.a or 1 end,
          setFunc = function(r, g, b, a) svf.borderColor = { r = r, g = g, b = b, a = a or 1 }; self:LayoutMembers() end },
        { type = "dropdown", name = "Border thickness", choices = { "Thin", "Medium", "Thick" }, choicesValues = { 2, 4, 8 }, width = "half",
          getFunc = function() return svf.borderThickness or 2 end,
          setFunc = function(v) svf.borderThickness = v; self:LayoutMembers() end },
        { type = "button", name = "Reset position/size", width = "half", func = function() self:ResetPosition() end },
    }
end

-- ===========================================================================
-- Module: settings panel + bootstrap
-- ===========================================================================

-- Gray out a control list unless the given UI is active (wraps any existing disabled fn), so the
-- UI Layout panel reflects which UI you're in: Shoyru custom-frame settings vs base-game movers.
local function GateControls(controls, wantUI)
    for _, c in ipairs(controls) do
        local t = c.type
        if t ~= "description" and t ~= "header" and t ~= "submenu" then
            local prev = c.disabled
            c.disabled = function()
                if (sv.activeUI or "base") ~= wantUI then return true end
                return (prev and prev()) or false
            end
        end
    end
    return controls
end

function UF.PanelOptions()
    local out = {
        { type = "description",
          text = "Clean, movable frames for your player, target, and group \226\128\148 health/magicka/stamina, class icons, names, and offline/dead states \226\128\148 plus each frame's buffs & debuffs in categorised rows.\n\n"
              .. "|cFFD700Active UI|r (below) picks your HUD:\n"
              .. "\226\128\162  Shoyru's UI \226\128\148 replaces the base-game frames wholesale (all-or-nothing; no mixing).\n"
              .. "\226\128\162  Base game \226\128\148 restores ESO's frames, and instead lets you reposition the native ones.\n\n"
              .. "The |cFFD700Both UIs|r section works either way: reposition ESO's action bar, and turn on Ability duration reminders (the current bar's timer sits on its own icon; your other bar's icon + timer appear above it).\n\n"
              .. "Unlock any element to drag-move / drag-resize, and enable Snap-to-grid to line everything up. Settings for the UI you're not using are greyed out." },
        { type = "dropdown", name = "Active UI", width = "full",
          choices = { "Shoyru's UI", "Base game" }, choicesValues = { "shoyru", "base" },
          tooltip = "Shoyru's UI = hide ESO's HUD frames and show ours. Base game = the default ESO UI.",
          getFunc = function() return sv.activeUI or "base" end,
          setFunc = function(v)
              sv.activeUI = v; UF.Apply()
              if ShoyrUI.RefreshLayoutPanel then ShoyrUI.RefreshLayoutPanel() end   -- re-eval disabled() live
          end },
    }
    -- Vertical separation between sections (divider carries its own padding, so it reads as spacing).
    local function section(name)
        out[#out + 1] = { type = "divider", width = "full", height = 24 }
        out[#out + 1] = { type = "header", name = name }
    end

    -- Alignment grid — applies in BOTH UIs (snaps whatever you drag).
    if ShoyrUI.Grid then
        section("Alignment")
        for _, c in ipairs(ShoyrUI.Grid.PanelControls()) do out[#out + 1] = c end
    end

    -- ===== Frames (Shoyru's UI) — custom replacement frames; greyed out unless Active UI = Shoyru's =====
    -- No master show-toggles here: each frame has its own "Show this frame" inside its submenu.
    section("Frames (Shoyru's UI)")
    for _, d in ipairs(FRAME_DEFS) do
        local f = UF.frames[d.id]
        if f then
            local controls = f:PanelControls()
            -- Fold this frame's buff/debuff (aura) settings into its own submenu.
            if ShoyrUI.Auras and ShoyrUI.Auras.ControlsForFrame then
                local ac = ShoyrUI.Auras.ControlsForFrame(d.id)
                if ac then for _, c in ipairs(ac) do controls[#controls + 1] = c end end
            end
            out[#out + 1] = { type = "submenu", name = d.label .. " frame", controls = GateControls(controls, "shoyru") }
        end
    end
    if UF.group then
        out[#out + 1] = { type = "submenu", name = "Group frame", controls = GateControls(UF.group:PanelControls(), "shoyru") }
    end

    -- ===== Frames (Base game UI) — reposition/replace native elements; greyed out unless Active UI = Base =====
    section("Frames (Base game UI)")
    if ShoyrUI.NativeMovers then
        out[#out + 1] = { type = "submenu", name = "Player frame (resources)", controls = GateControls(ShoyrUI.NativeMovers.ControlsFor("selfframe"), "base") }
        out[#out + 1] = { type = "submenu", name = "Target frame", controls = GateControls(ShoyrUI.NativeMovers.ControlsFor("targetframe"), "base") }
    end
    if ShoyrUI.Auras and ShoyrUI.Auras.BaseControlsFor then
        out[#out + 1] = { type = "submenu", name = "Player buffs", controls = GateControls(ShoyrUI.Auras.BaseControlsFor("player"), "base") }
        out[#out + 1] = { type = "submenu", name = "Target buffs", controls = GateControls(ShoyrUI.Auras.BaseControlsFor("target"), "base") }
    end

    -- ===== Both UIs — the action bar is native in either UI, so it lives here. The ability
    -- duration reminders draw ON the action bar, so their options are folded into this same
    -- submenu (rather than a separate "Bars" panel). =====
    if ShoyrUI.ActionBar or ShoyrUI.DurationReminder then
        section("Both UIs")
        local ab = (ShoyrUI.ActionBar and ShoyrUI.ActionBar.PanelControls()) or {}
        if ShoyrUI.DurationReminder then
            if #ab > 0 then ab[#ab + 1] = { type = "divider", width = "full" } end
            ab[#ab + 1] = { type = "header", name = "Ability duration reminders" }
            for _, c in ipairs(ShoyrUI.DurationReminder.PanelOptions()) do ab[#ab + 1] = c end
        end
        out[#out + 1] = { type = "submenu", name = "Action bar", controls = ab }
    end
    return out
end

-- Hide ESO's native on-screen buff/debuff bar while "Shoyru's UI" is active — our aura
-- displays (attached under each frame) replace it, so the vanilla bar would just be a
-- duplicate elsewhere on screen. Reversible: "Base game" restores it. BUFF_DEBUFF is the
-- vanilla system (BUFF_DEBUFF.control = the top-level window; .containerObjectsByUnitTag =
-- the per-unit-tag containers), same globals LuiExtended suppresses. Hiding via our own
-- reason keeps ESO's own show/hide of the widget from fighting us.
function UF.ApplyNativeBuffs()
    if not BUFF_DEBUFF then return end
    local byTag = BUFF_DEBUFF.containerObjectsByUnitTag
    local AU = ShoyrUI.Auras
    if sv.activeUI == "shoyru" then
        -- Shoyru's UI: our attached auras replace the WHOLE native buff HUD (if any are shown).
        local hidden = not AU or not AU.AnyDisplayShown or AU.AnyDisplayShown()
        HideControl(BUFF_DEBUFF.control, hidden, "ShoyrUIBuffs")
        if byTag then
            for _, obj in pairs(byTag) do
                if obj and obj.GetControl then HideControl(obj:GetControl(), hidden, "ShoyrUIBuffs") end
            end
        end
    else
        -- Base UI: NEVER hide the whole bar — hide each unit's native buffs only if THAT unit's
        -- display opted into our auras (so the player and target toggles are independent).
        HideControl(BUFF_DEBUFF.control, false, "ShoyrUIBuffs")
        if byTag then
            for tag, obj in pairs(byTag) do
                if obj and obj.GetControl then
                    local h = AU and AU.ShowInBaseForUnit and AU.ShowInBaseForUnit(tag)
                    HideControl(obj:GetControl(), h and true or false, "ShoyrUIBuffs")
                end
            end
        end
    end
end

function UF.Apply()
    for _, f in pairs(UF.frames) do f:Apply() end
    if UF.group then UF.group:Apply() end
    UF.ApplyNativeBuffs()
    if ShoyrUI.ActionBar then ShoyrUI.ActionBar.Apply() end       -- action bar move follows the Active UI switch
    if ShoyrUI.NativeMovers then ShoyrUI.NativeMovers.ApplyAll() end   -- base-game movers stand down in Shoyru UI
    -- Re-evaluate the duration-reminder push-up now (after the movers have re-anchored the native
    -- bars), so switching UIs immediately lifts the health bar above the timer strip instead of
    -- waiting for the next 100ms tick / next cast.
    if ShoyrUI.DurationReminder and ShoyrUI.DurationReminder.Refresh then ShoyrUI.DurationReminder.Refresh() end
end

-- Zone-load handler: apply immediately, then re-assert the group native-hide a few times as the
-- scene settles. Battlegrounds build ESO's native group frames AFTER EVENT_PLAYER_ACTIVATED, so a
-- single hide leaks (the "group1 / group2 top-left" seen in BGs).
local function OnActivated()
    UF.Apply()
    if UF.group then
        for _, delay in ipairs({ 400, 1200, 3000 }) do
            zo_callLater(function() if UF.group then UF.group:ReassertNative() end end, delay)
        end
    end
end
-- Back-compat for the bootstrap's "Enable UI Layout"-style callers.
function UF.ApplyLayout()
    for _, f in pairs(UF.frames) do f:ApplyLayout() end
    if UF.group then UF.group:ApplyLayout() end
end

-- Lightweight visibility-only refresh (used on HUD scene changes — no rebuild/relayout).
function UF.UpdateAllVisibility()
    for _, f in pairs(UF.frames) do if f.frame then f:UpdateVisibility() end end
    if UF.group and UF.group.frame then UF.group:UpdateVisibility() end
end

local function DarkUIEnabled()
    local mgr = GetAddOnManager and GetAddOnManager()
    if not mgr then return false end
    for i = 1, mgr:GetNumAddOns() do
        local name, _, _, _, enabled = mgr:GetAddOnInfo(i)
        if name == "DarkUI" and enabled then return true end
    end
    return false
end

local function FillDefaults(t, d)
    for k, v in pairs(d) do
        if t[k] == nil then t[k] = (type(v) == "table") and ZO_DeepTableCopy(v) or v end
    end
end

-- Diagnostic: /shoyrgroupdump — prints the default group-frame controls + state so we can
-- target the right ones if any still show through.
function UF.DumpGroup()
    local function line(s) d("[Shoyru's UI] " .. s) end
    line("GetGroupSize = " .. tostring(GetGroupSize()) .. ", activeUI = " .. tostring(sv and sv.activeUI))
    for _, n in ipairs({ "ZO_SmallGroupAnchorFrame", "ZO_LargeGroupAnchorFrame" }) do
        local c = _G[n]
        line(n .. ": " .. (c and ("exists, hidden=" .. tostring(c:IsHidden())) or "NIL"))
    end
    if ZO_UnitFrames_GetUnitFrame then
        for i = 1, math.max(1, GetGroupSize()) do
            local uf = ZO_UnitFrames_GetUnitFrame("group" .. i)
            local ctrl = uf and (uf.frame or uf.control)
            if ctrl then
                local p = ctrl.GetParent and ctrl:GetParent()
                line(("group%d: frame=%s hidden=%s parent=%s"):format(i,
                    (ctrl.GetName and ctrl:GetName()) or "?", tostring(ctrl:IsHidden()),
                    (p and p.GetName and p:GetName()) or "?"))
            else
                line("group" .. i .. ": no unit frame object")
            end
        end
    else
        line("ZO_UnitFrames_GetUnitFrame = NIL (can't reach unit frames)")
    end
end

function UF.Init(layoutSv)
    sv = layoutSv
    BuildClassIcons()
    if Style and not DarkUIEnabled() then Style.GRADIENT_TEX = nil end

    -- Migrate the old flat (player-only) schema → frames.player. (ZO_SavedVars may have
    -- already added an empty frames={} from the default, so key off the old flat marker
    -- sv.enabled rather than the presence of sv.frames.)
    sv.frames = sv.frames or {}
    if sv.enabled ~= nil and not sv.frames.player then
        local wasEnabled = sv.enabled
        local old = {}
        for k, v in pairs(sv) do
            if k ~= "styleVersion" and k ~= "frames" and k ~= "activeUI" then old[k] = v; sv[k] = nil end
        end
        sv.frames.player = old
        if wasEnabled then sv.activeUI = "shoyru" end   -- preserve "was using our frame"
    end
    if sv.activeUI == nil then sv.activeUI = "base" end

    local restyle = (sv.styleVersion ~= STYLE_VERSION)
    for _, d in ipairs(FRAME_DEFS) do
        sv.frames[d.id] = sv.frames[d.id] or {}
        local fsv = sv.frames[d.id]
        FillDefaults(fsv, FrameDefaults(d))
        if restyle then        -- re-apply the deep/flat palette, keep position/size/prefs
            local dd = FrameDefaults(d)
            fsv.barBgColor, fsv.borderColor, fsv.borderThickness = dd.barBgColor, dd.borderColor, dd.borderThickness
            fsv.colors, fsv.gradient = {}, true
        end
        UF.frames[d.id] = Frame.New(d, fsv)
    end

    -- Group frame (separate component — a container of dynamic member rows).
    sv.frames.group = sv.frames.group or {}
    FillDefaults(sv.frames.group, GroupDefaults())
    if restyle then
        local gd = GroupDefaults()
        sv.frames.group.barBgColor, sv.frames.group.borderColor = gd.barBgColor, gd.borderColor
        sv.frames.group.borderThickness, sv.frames.group.gradient = gd.borderThickness, true
    end
    UF.group = GroupFrame.New(GROUP_DEF, sv.frames.group)

    sv.styleVersion = STYLE_VERSION

    -- One power-update registration per watched unit, routed to that frame.
    for _, d in ipairs(FRAME_DEFS) do
        local id, unit = d.id, d.unit
        local name = "ShoyrUI_Power_" .. id
        EVENT_MANAGER:RegisterForEvent(name, EVENT_POWER_UPDATE, function(_, _, _, pt, val, mx, eff)
            local f = UF.frames[id]
            if f then f:OnPower(pt, val, (eff and eff > 0) and eff or mx) end
        end)
        EVENT_MANAGER:AddFilterForEvent(name, EVENT_POWER_UPDATE, REGISTER_FILTER_UNIT_TAG, unit)
        -- Max health/mag/stam change when food/buffs/mundus are applied or drop — re-sync off effect
        -- changes on this unit (EVENT_POWER_UPDATE alone misses effective-max-only changes).
        local sname = "ShoyrUI_MaxSync_" .. id
        EVENT_MANAGER:RegisterForEvent(sname, EVENT_EFFECT_CHANGED, function()
            local f = UF.frames[id]; if f then f:SyncMax() end
        end)
        EVENT_MANAGER:AddFilterForEvent(sname, EVENT_EFFECT_CHANGED, REGISTER_FILTER_UNIT_TAG, unit)
    end
    -- Target frame follows the reticle target.
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_Reticle", EVENT_RETICLE_TARGET_CHANGED, function()
        local f = UF.frames.target; if f then f:OnTargetChanged() end
    end)

    -- Group frame: one health-power feed for ALL group units (prefix filter), plus the
    -- membership / connection / death events that change who's shown.
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_GroupPower", EVENT_POWER_UPDATE, function(_, unitTag, _, _, val, mx)
        if UF.group then UF.group:OnGroupPower(unitTag, val, mx) end
    end)
    EVENT_MANAGER:AddFilterForEvent("ShoyrUI_GroupPower", EVENT_POWER_UPDATE,
        REGISTER_FILTER_UNIT_TAG_PREFIX, "group", REGISTER_FILTER_POWER_TYPE, POWERTYPE_HEALTH)
    local function groupChanged() if UF.group then UF.group:OnGroupChanged() end end
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_GroupJoin",    EVENT_GROUP_MEMBER_JOINED,           groupChanged)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_GroupLeft",    EVENT_GROUP_MEMBER_LEFT,             groupChanged)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_GroupUpdate",  EVENT_GROUP_UPDATE,                  groupChanged)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_GroupConn",    EVENT_GROUP_MEMBER_CONNECTED_STATUS, groupChanged)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_GroupDeath",   EVENT_UNIT_DEATH_STATE_CHANGED,      groupChanged)
    EVENT_MANAGER:AddFilterForEvent("ShoyrUI_GroupDeath", EVENT_UNIT_DEATH_STATE_CHANGED,
        REGISTER_FILTER_UNIT_TAG_PREFIX, "group")
    -- Re-assert native-bar hiding when ESO re-shows its frames. The gamepad/keyboard
    -- mode toggle rebuilds ESO's HUD (same control names in both modes — verified vs
    -- LuiExtended), so re-Apply there too or the base frames pop back over ours.
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_NativeBars", EVENT_PLAYER_COMBAT_STATE, UF.Apply)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_NativeBars2", EVENT_PLAYER_ACTIVATED, OnActivated)
    EVENT_MANAGER:RegisterForEvent("ShoyrUI_NativeBars3", EVENT_GAMEPAD_PREFERRED_MODE_CHANGED, UF.Apply)

    SLASH_COMMANDS["/shoyrgroupdump"] = UF.DumpGroup   -- diagnostic for default group-frame hiding

    -- Hide our frames in menus (inventory/map/addon settings) like ESO's native HUD; UNLOCKED
    -- frames stay shown so they're still positionable from the settings panel.
    local function onHudScene()
        UF.menuOpen = not ((HUD_SCENE and HUD_SCENE:IsShowing()) or (HUD_UI_SCENE and HUD_UI_SCENE:IsShowing()))
        UF.UpdateAllVisibility()
    end
    if HUD_SCENE then HUD_SCENE:RegisterCallback("StateChange", onHudScene) end
    if HUD_UI_SCENE then HUD_UI_SCENE:RegisterCallback("StateChange", onHudScene) end

    UF.Apply()
end
