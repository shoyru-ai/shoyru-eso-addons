# ShoyrUI — Design

An all-inclusive ESO UI/tracking addon. The goal: one addon that replaces the
pile of one-off Shoyru trackers (Fossilize, Bound Armaments, Kjalnar, Oakfather,
ProxDet, UltTracker, DeepFissure, Slippery, ...) AND gives a simple, opinionated
front end for the things LUIExtended does well (swappable bars, buff/debuff
tracking, ability/set tracking) without LUI's overwhelming configurability.

Author: Shoyru. PvP-focused (Cyrodiil / IC / BGs / duels).

## The core thesis

Every tracker Shoyru has ever built is **the same engine with different
parameters**: watch an ability id on a unit, count stacks / time remaining,
render an icon + bar + label, escalate color/sound at thresholds. So ShoyrUI is:

1. **One generic Tracker engine** — instances are created from plain config
   tables, not bespoke code.
2. **A data + search layer** — search any ability or set in the game and spawn a
   tracker for it, so you never hand-write another tracker addon.
3. **A bar-skinning layer** — swap unit-frame styles (default / stacked / etc.).
4. **A unified, tabbed config UI** over all of the above.

Build order is bottom-up: engine first (this is the foundation everything plugs
into), then data/search, then bars, with a migration pass folding the old
addons in as seed config.

---

## Tracker config schema (the contract)

This is the single most important data structure in the addon. Everything —
search results, the config UI, migration, saved variables — produces or consumes
one of these. Stored in SavedVariables under `sv.trackers[id]`.

```lua
{
  id          = "boundArmaments",   -- unique key (also SV key)
  name        = "Bound Armaments",  -- display name
  enabled     = true,
  builtin     = true,               -- seeded by the addon (vs user-created via search)

  -- WHAT to watch -----------------------------------------------------------
  abilityIds  = { 203447 },         -- one or more ability ids that drive this tracker
  watch       = "selfBuff",         -- selfBuff | targetDebuff | reticleDebuff
                                    --   selfBuff      : effect on player (unitTag == "player")
                                    --   targetDebuff  : effect I apply (sourceType == PLAYER), keyed per target
                                    --   reticleDebuff : like targetDebuff but display only the reticle target
  perTarget   = false,              -- keep separate state per enemy unitId (targetDebuff)
  maxStacks   = 8,                  -- cap displayed stacks (nil = uncapped)
  defaultDurationMs = 5000,         -- fallback when the game reports no duration

  -- WHEN to show ------------------------------------------------------------
  showWhenIdle = true,              -- show any time the effect is up (else only at threshold 1)
  idleText     = "BOUND ARMAMENTS",
  idleColor    = { r=.85, g=.85, b=.85, a=1 },

  -- Thresholds: ascending by stacks. The HIGHEST threshold whose `stacks` is
  -- <= current stacks wins. Sound fires once on the rising edge into a threshold.
  thresholds = {
    { stacks=4, text="BUILDING",   color={...}, sound="DUEL_INVITE_RECEIVED", playSound=true },
    { stacks=8, text="MAX STACKS", color={...}, sound="DUEL_START",           playSound=true,
      -- Optional time-based escalation, applied only while this is the active
      -- threshold (covers Kjalnar's fresh -> warn -> urgent stun coloring).
      escalate = {
        { atSec=2.0, color={...} },   -- when remaining <= 2.0s
        { atSec=1.0, color={...} },   -- when remaining <= 1.0s  (smaller atSec wins)
      },
    },
  },

  -- Cosmetics ---------------------------------------------------------------
  barBgColor      = { r=0, g=0, b=0, a=.75 },
  borderColor     = { r=0, g=0, b=0, a=1 },
  borderThickness = 2,              -- power of two: 2 | 4 | 8 (SetEdgeTexture rule)
  soundVolume     = 1,              -- 1 = normal; N layers the sound N times (no volume API)

  -- Layout (offset from GuiRoot center) ------------------------------------
  x = 0, y = -260, w = 220, h = 56, scale = 1,
}
```

### Why this schema covers the existing addons
- **Bound Armaments** → `watch=selfBuff`, two stack thresholds. Exact match.
- **Kjalnar** → `watch=targetDebuff`, `perTarget=true`, threshold at stacks 4
  with `escalate` for the stun warn/urgent stages. Exact match.
- **Fossilize / DeepFissure / ProxDet / Slippery / Oakfather / UltTracker** →
  all are "watch ability id(s), alert on apply/threshold" — same schema, mostly
  single-threshold `targetDebuff` or `selfBuff` cases. Folded in during migration.

---

## Module layout

```
ShoyrUI/
  ShoyrUI.txt        manifest (load order matters)
  DESIGN.md          this file
  Core/
    Defaults.lua     shared constants (sound lists, color presets) + seed trackers
    Tracker.lua      the generic Tracker class (UI + state + threshold logic)
    Router.lua       one EVENT_EFFECT_CHANGED registration -> dispatch by abilityId;
                     one shared OnUpdate tick driving all active/previewing trackers
  ShoyrUI.lua        bootstrap: SV, merge defaults, instantiate trackers, slash cmd, LAM
  Data/              (Phase 2) Abilities.lua, Sets.lua (LibSets), Discovered.lua catalog
  Bars/              (Phase 3) Skins.lua — default / stacked / srendarr / dark presets
  UI/                (Phase 2-3) tabbed config: Bars | Abilities | Sets | Buffs | Layout | Search
  Migrate/           (Phase 4) Import.lua — pull settings from the old standalone addons
```

### Event routing decision
Register **one** unfiltered `EVENT_EFFECT_CHANGED` and route in Lua via an
`abilityId -> {trackers}` map (first line of the handler is an O(1) lookup that
bails on uninteresting ids). This is how LUI does it and avoids N per-ability
registrations churning as trackers are added/removed at runtime. One shared
`RegisterForUpdate` tick (50ms) iterates only trackers that are active or in
preview, mirroring the per-addon update loops but consolidated.

---

## Phased roadmap

- **Phase 1 — Engine (current).** Tracker class + Router + bootstrap. Seed with
  Bound Armaments and Kjalnar as data to prove the schema renders both. Minimal
  LAM (master enable, unlock-all preview, per-tracker enable).
- **Phase 2 — Data & search.** Ability index (bundled snapshot generated from
  LuiData's AbilityTables, NOT a live dependency) + a self-growing "Discovered"
  catalog of abilities seen in combat (the `/skippy`-style capture pattern from
  TrueHealth). Search bar → pick watch mode → spawn a tracker. Add LibSets for
  the Set Browser; "track a set" = track its proc ability id(s).
- **Phase 3 — Bars.** One bar renderer + skin presets (default / LUI-stacked /
  Srendarr / dark). Hide native frames, draw ours, drag to reposition.
- **Phase 4 — Migration & polish.** Import old addons' SV into seed trackers;
  full tabbed config UI; profiles (reuse the ShoyruCrosshair multi-profile
  pattern); publish via the existing publish.ps1 + esoui.com.

## Open questions / notes
- Enemy **gear**-set detection in PvP is not possible (can't read enemy
  equipment). Set *procs* are trackable as buff/debuff ability ids — that's what
  the Set Browser "track" action will hook. Own/group sets via LibSetDetection.
- LibSets must be added as a dependency for the full set database (browse all
  sets + bonus text + zones). Not currently installed.
- API version pinned to current live (verify against pChat manifest each patch).

---

## Phase 3 — Bars / Skins (detailed design)  [planned, 2026-06-24]

**Status of bars today:** they already render. `Tracker:Render` draws one depleting
horizontal fill from `displayState.barPct`, plus icon + name + timer + stack count,
in ONE hardcoded layout (`Tracker:LayoutChildren`). Per-tracker cosmetics today =
bar-bg color, border color/thickness, size, scale, position. So Phase 3 is NOT
"add bars" — it's making the *presentation* a swappable **skin** without touching
behavior. The `displayState` contract (`{text,color,stacks,barPct,timerText}`) stays
the view's only input; skins are pure view, archetype-agnostic.

### Architecture
- New `Core/Skins.lua`: `ShoyrUI.Skins = { default=…, compact=…, barOnly=…, textOnly=… }`.
  A skin is mostly **flags + a layout function**, not a full re-implementation of
  render (keeps them small and consistent):
  ```
  skin = {
    id, label,
    hasIcon   = true,            -- draw the ability icon
    hasBar    = true,            -- draw the timer bar
    barMode   = "deplete"|"fill",-- width shrinks vs grows with barPct
    orient    = "h"|"v",         -- horizontal (default) or vertical bar
    timer     = "right"|"center"|"none",
    Layout(tracker)              -- arranges the existing child controls
  }
  ```
- `Tracker.config.skin = "<id>"` (default "default"; missing → "default", so existing
  trackers are visually unchanged — zero-risk migration).
- `Tracker:LayoutChildren` delegates to `skin.Layout(self)`; `Tracker:Render` reads the
  skin flags (hasIcon/hasBar/timer/barMode/orient) to show/hide + fill direction. No
  per-skin render duplication.

### Preset skins (initial set)
- **default** — current look (icon left, horizontal deplete bar, name over bar, timer
  right). Extracted verbatim from today's LayoutChildren so nothing changes.
- **compact** — icon + text on one line, thin bar beneath; small height for stacking
  many trackers (the LUI "lots of small bars" density).
- **barOnly** — no icon; full-width bar, centered text + timer (LUI-stacked feel).
- **textOnly** — big colored text only, no icon/bar (pure alerts like a stack "MAX!"
  or Fossilize "Roll Now!" where a bar is noise).

### New per-tracker cosmetic options (editor "Appearance" section)
- **Skin** dropdown (the presets above) — live-applied (re-run skin.Layout + re-render).
- Show icon / show bar / timer position toggles (override the skin defaults).
- **Bar texture** via LibMediaProvider-1.0 (already an OptionalDependsOn) — gradient /
  smooth / Srendarr / LUI statusbar textures instead of the flat fill.
- Bar fill **direction** (deplete vs fill) and **orientation** (h/v).
- Optional fixed **fill color** (today fill always = state color; some users want a
  constant bar color with only the text recoloring on escalation).

### Phasing within Phase 3 (each independently shippable)
- **3a** — Skin abstraction: extract current layout as the `default` skin, add the
  `skin` field + editor dropdown. Pure refactor, no visual change. (Low risk, do first.)
- **3b** — Add `compact` / `barOnly` / `textOnly` presets.
- **3c** — Bar textures (LibMediaProvider) + fill direction/orientation + fixed fill color.
- **3d (stretch, maybe defer to Phase 5)** — the roadmap's "hide native frames, draw
  ours": replacing ESO's player/target UNIT frames with custom bars is a much larger,
  separate feature than tracker skinning (it's a unit-frame addon, not a tracker view).
  Recommend treating tracker skins (3a-c) as the real Phase 3 and unit-frame replacement
  as its own track.

### Edge cases to handle when implementing
- Missing `skin` / unknown skin id → fall back to `default` (like the behavior fallback).
- Live skin switch must re-layout AND re-render the current displayState (not wait for
  the next combat event) — call ApplyLayout + a forced Render of the last state, or Hide
  if idle.
- Skins that hide the icon must still resolve `abilityIds[1]` for nothing (no crash) and
  not leave a stale icon control visible.
- Preview/unlock mode must respect the active skin (drag handles, sizing).
- LibMediaProvider absent → fall back to the flat fill texture (it's optional).

---

## Architecture v2 — Modules & Tabs  [vision, 2026-06-24]

Shoyru's UI grows from "a tracker addon" into a **UI suite** with top-level modules,
each its own tab in the addon settings. Decided with Shoyru:

1. **Trackers** ("All-Inclusive Tracker") — everything built through v0.9 (Create a
   tracker, per-tracker archetype editors, catalog, set browser). This is our
   Srendarr-equivalent: aura/buff/debuff/proc/stack/cooldown/incoming-cast tracking.
2. **UI Layout** — custom **unit frames / HUD** (the LUIExtended territory): player
   health+magicka+stamina + target frame, with selectable base presets. NEW module.
3. **PvP** — placeholder tab, contents TBD (candidate features listed below).

All modules coexist: any UI Layout works alongside all trackers. Tabs are independent
layers, not mutually exclusive.

**Reference grounding (researched 2026-06-24):** LUIExtended = custom unit frames
(player/target/group/raid), per-bar texture/color/alignment, stacked or separate bars,
hide native frames. Srendarr = aura windows you position freely (player buffs / debuffs
/ target / castbars), per-window in/out-of-combat opacity — i.e. our Tracker module's
job. So "pick a UI like LUI/Srendarr" really means: UI Layout presets emulate LUI's
unit-frame styles; the Srendarr-style aura look is a Tracker **skin** (Phase 3), not a
unit-frame preset.

### Settings shell (how the tabs exist)
- **Near term (low risk):** register one LAM panel per module — "Shoyru's UI · Trackers",
  "· Layout", "· PvP" — so they appear as sibling entries. Zero new UI tech.
- **Long term (Phase 4 "full tabbed config UI"):** a single custom window with a top
  tab bar (LUI-style), each tab hosting that module's controls. More work, nicer feel.

### UI Layout module — design
Custom unit frames driven by power events, replacing/hiding ESO's default attribute
bars. Shares the **bar-rendering primitive** with Phase 3 tracker skins (build once,
use in both — LibMediaProvider textures, fill direction, colors, fonts).

**Shared style tokens (visual consistency — Shoyru's requirement):** the unit frames
must look like the trackers, so the shared primitive owns the common style vocabulary,
pulled from today's Tracker rendering:
- **Fonts:** `$(BOLD_FONT)|<size>|soft-shadow-thick` for value/name text, `…|outline`
  for small counters (matches `Tracker:ApplyFonts`). One `Style.Font(size, kind)` helper.
- **Borders:** `SetEdgeTexture(nil, t, t, t, 0)` 1px solid tinted by `SetEdgeColor`
  (matches `Tracker:ApplyBorder`), thickness presets 2/4/8.
- **Bar:** CT_BACKDROP bg (`barBgColor`, default black .75) + CT_TEXTURE fill, left-
  anchored width = pct. Same border treatment.
- One `Core/Style.lua` (tokens + a StyledBar widget) consumed by both Tracker skins and
  UI-Layout frames, so a future font/texture/color change updates everything at once.

- **Player frame** — Health / Magicka / Stamina bars. Arrangements:
  - *Stacked* (LUI-style: 3 bars stacked, health top) · *Row* (side-by-side) ·
    *Default passthrough* (don't touch ESO frames) · *Shoyru signature* (below).
  - Per-bar: texture, color, current/max/% text, shield overlay, regen ticks, size, drag.
- **Target frame** — health + name + class/role, execute-range highlight (<X% glows),
  and the debuffs YOU applied shown inline (hooks the Tracker module).
- **Ultimate** — small radial/bar near the reticle, flash when ready.

### Signature "Shoyru's UI" layout — concept (creative latitude, iterate)
**Core constraint (from Shoyru):** keep Magicka and Stamina **stacked & aligned** so you
can compare their fill instantly ("mag fuller than stam → don't press a stam ability").
That comparison is the #1 job, so the signature is a **stacked layout** (NOT reticle-
flanking slivers — those break the side-by-side read). PvP enhancements layer on top:
- **Stacked, aligned bars:** Health on top; Magicka and Stamina directly below it, same
  left edge + same width, so the right-edge fill of mag vs stam is a single glance.
- **Affordance / cost markers (signature feature):** optional tick marks on the mag &
  stam bars at key ability costs (break-free, roll-dodge, your priciest slotted ability),
  so the bar answers "can I afford this *right now*?" — directly serves the don't-press-a-
  stam-ability decision, generalized.
- **Shield overlay** on the Health bar; **burst-incoming flash** when HP drops fast.
- **Ultimate** pip/bar inline with the stack.
- Fully **draggable/scalable** — default a touch higher/centered than ESO's, but the user
  places it (near-reticle optional). Numbers: current / max / % toggle per bar.
- **Enemy/target** frame separate: health + your applied debuffs inline + execute glow.

### Technical feasibility / risks
- Attributes: `GetUnitPower`/`EVENT_POWER_UPDATE` (h/m/s), `GetUnitName`, reaction/class.
  Straightforward.
- **Shields**: no direct shield-amount API — must estimate (track damage-shield buff
  values / combat events). Known hard spot; note as its own task.
- **Hiding native frames**: ESO re-shows attribute bars on some state changes; need to
  hook the HUD fragments (LUI does this). Fiddly but proven possible.
- This is a substantial module — it's the "Phase 3d" unit-frame work promoted to a pillar.

### Recommended build order
1. **Tab/module scaffolding** — split settings into Trackers / UI Layout / PvP panels.
2. **UI Layout MVP** — player resource frame (h/m/s) with *Stacked* + *Passthrough*
   presets, drag/size/color/texture. Proves the power-event → bar pipeline.
3. **Target frame** + the **Shoyru signature** reticle-centric preset.
4. **Integrate**: tracker anchoring to frames, shields, ultimate, execute-range.
- Synergy: do **Phase 3a (skin/bar primitive) first** so the same bar widget powers both
  tracker skins and unit frames.

### PvP tab — candidate features (to define later)
Incoming-CC/burst alerts (Fossilize already qualifies) · break-free/dodge resource pips ·
purge/cleanse reminders · enemy execute-range · range/LoS to target · focus-target debuff
panel · one-click PvP tracker preset packs (common sets/procs) · ult-ready + enemy-ult
guesswork. Pick a starting set when we get here.
