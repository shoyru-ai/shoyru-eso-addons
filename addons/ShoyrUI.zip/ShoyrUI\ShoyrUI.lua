-- ShoyrUI :: bootstrap
-- Loads saved vars, merges seed trackers, instantiates one Tracker per config via
-- the Router, feeds the Discovered catalog, and registers the LAM panel.
-- Phase 2: create/delete trackers at runtime from the catalog (no code per
-- ability). Deep per-tracker styling + a real search browser come with the
-- custom tabbed UI (see DESIGN.md).

ShoyrUI = ShoyrUI or {}
ShoyrUI.name    = "ShoyrUI"
ShoyrUI.version = "0.28"

local ADDON = ShoyrUI.name
local D, Router, Tracker, Disc, Sets   -- resolved at load

local defaults = {
    global   = { masterEnabled = true, unlocked = false, recording = true },
    trackers = {},
    discovered = {},
    setProcs  = {},   -- learned setId -> { abilityId, name } (Set Browser)
    layout    = ShoyrUI.UnitFrames and ZO_DeepTableCopy(ShoyrUI.UnitFrames.DEFAULTS) or {},
    auras     = ShoyrUI.Auras and ZO_DeepTableCopy(ShoyrUI.Auras.DEFAULTS) or {},
}

-- Archetype picker for the Create form (mirrors Editor.lua's KIND_*). Default is
-- "uptime": most ad-hoc tracking is "how long is this buff/debuff up" (e.g. Vigor),
-- NOT a stacking mechanic — so new trackers stop being born with threshold slots.
local KIND_LABELS = { "Uptime (duration)", "Stack mechanic", "Cooldown (proc/ICD)", "Stack + Proc", "Delayed cast", "Incoming cast (roll dodge)" }
local KIND_VALUES = { "uptime", "stack", "cooldown", "stackProc", "delayedCast", "incomingCast" }

-- Catalog filter. These are GROUPS: "buff" also shows ability-tagged effects,
-- "debuff" also shows status effects (see Disc.GetChoices). The category also
-- drives what "Track as" means (see ResolveWatch).
local CAT_FILTER_LABELS = { "Buffs", "Debuffs", "Sets" }
local CAT_FILTER_VALUES = { "buff", "debuff", "set" }

-- "Track as" is a simple who-axis; the actual watch filter is derived from the
-- category + who so only sensible combinations exist (no "Vigor as a debuff").
local WHO_LABELS = { "On myself", "On my target" }
local WHO_VALUES = { "me", "target" }
local function ResolveWatch(cat, who)
    if who == "me" then return "selfBuff" end       -- buff or debuff, on me
    if cat == "buff" then return "targetBuff" end    -- their buff on my target
    return "targetDebuff"                            -- my debuff / set proc on them
end

-- ---------------------------------------------------------------------------
-- Saved-var merge
-- ---------------------------------------------------------------------------

-- Fill only MISSING keys (forward-compat: never clobber user edits).
local function FillDefaults(target, src)
    for k, v in pairs(src) do
        if target[k] == nil then
            target[k] = (type(v) == "table") and ZO_DeepTableCopy(v) or v
        elseif type(v) == "table" and type(target[k]) == "table" then
            FillDefaults(target[k], v)
        end
    end
end

-- Deep overlay where SRC WINS (used when first creating a seed: TRACKER_COMMON is
-- the base, the seed's explicit fields override). Copies values so SV never
-- aliases the Defaults tables.
local function Overlay(target, src)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(target[k]) ~= "table" then target[k] = {} end
            Overlay(target[k], v)
        else
            target[k] = v
        end
    end
end

-- Per-archetype config fixups that must run before a Tracker is built.
local function Normalize(cfg)
    if cfg.kind == "delayedCast" and cfg.phases then
        local ids, seen = {}, {}
        for _, p in ipairs(cfg.phases) do
            local tid = p.triggerId
            if tid and tid ~= 0 and not seen[tid] then
                seen[tid] = true
                table.insert(ids, tid)
            end
        end
        cfg.abilityIds = ids
    end
end

local function SeedTrackers()
    ShoyrUI.trackerOrder = {}

    -- Prune orphaned built-in trackers: any builtin still in SV that is no longer
    -- in the seed list (e.g. the removed example trackers). User-created trackers
    -- (builtin=false) are never pruned.
    local seedIds = {}
    for _, seed in ipairs(D.SEED_TRACKERS) do seedIds[seed.id] = true end
    for id, cfg in pairs(ShoyrUI.sv.trackers) do
        if cfg.builtin and not seedIds[id] then ShoyrUI.sv.trackers[id] = nil end
    end

    -- Seed built-ins first (stable order), then any user-created trackers.
    for _, seed in ipairs(D.SEED_TRACKERS) do
        local id = seed.id
        local cfg = ShoyrUI.sv.trackers[id]
        if not cfg then
            cfg = ZO_DeepTableCopy(D.TRACKER_COMMON)
            Overlay(cfg, seed)                 -- seed wins over common defaults
            ShoyrUI.sv.trackers[id] = cfg
        else
            FillDefaults(cfg, D.TRACKER_COMMON)
            FillDefaults(cfg, seed)            -- add any new seed fields, keep user edits
        end
        Normalize(cfg)
        table.insert(ShoyrUI.trackerOrder, id)
        Router.Register(Tracker.New(cfg))
    end
    for id, cfg in pairs(ShoyrUI.sv.trackers) do
        if not cfg.builtin and not Router.Get(id) then
            FillDefaults(cfg, D.TRACKER_COMMON)
            Normalize(cfg)
            table.insert(ShoyrUI.trackerOrder, id)
            Router.Register(Tracker.New(cfg))
        end
    end
end

-- ---------------------------------------------------------------------------
-- Runtime tracker create / delete
-- ---------------------------------------------------------------------------

local function UniqueId(abilityId)
    local base = "custom_" .. tostring(abilityId)
    local id, n = base, 2
    while ShoyrUI.sv.trackers[id] do
        id = base .. "_" .. n
        n = n + 1
    end
    return id
end

function ShoyrUI.CreateTracker(abilityId, name, watch, kind)
    abilityId = tonumber(abilityId)
    if not abilityId or abilityId <= 0 then return nil, "Invalid ability ID" end
    watch = watch or "targetDebuff"
    kind = kind or "uptime"

    if (not name) or name == "" then
        name = Disc.GetName(abilityId)
            or (GetAbilityName and GetAbilityName(abilityId))
            or ("Ability " .. abilityId)
        if name == "" then name = "Ability " .. abilityId end
    end

    local id = UniqueId(abilityId)
    local cfg = ZO_DeepTableCopy(D.TRACKER_COMMON)
    cfg.id         = id
    cfg.name       = name
    cfg.builtin    = false
    cfg.kind       = kind
    cfg.abilityIds = { abilityId }
    cfg.watch      = watch
    cfg.perTarget  = (watch == "targetDebuff" or watch == "targetBuff")
    cfg.showWhenIdle = true
    cfg.idleText   = name
    cfg.idleColor  = ZO_DeepTableCopy(D.GOLD)
    cfg.thresholds = {}   -- only consulted by the stack archetype
    -- Seed the chosen archetype's display fields so it renders immediately
    -- (each behavior reads its cfg live; the editor refines the rest).
    if kind == "uptime" then
        cfg.text  = name
        cfg.color = ZO_DeepTableCopy(D.GOLD)
    elseif kind == "cooldown" then
        cfg.activeText, cfg.cooldownText, cfg.readyText = name, "CD", "READY"
        cfg.activeColor   = ZO_DeepTableCopy(D.GREEN)
        cfg.cooldownColor = ZO_DeepTableCopy(D.GREY)
        cfg.readyColor    = ZO_DeepTableCopy(D.GOLD)
    end
    cfg.y          = -260 - 40 * (#ShoyrUI.trackerOrder)

    ShoyrUI.sv.trackers[id] = cfg
    table.insert(ShoyrUI.trackerOrder, id)
    local t = Tracker.New(cfg)
    Router.Register(t)
    if ShoyrUI.sv.global.unlocked then t:StartPreview() end
    Router.Refresh()
    return id
end

function ShoyrUI.DeleteTracker(id)
    local cfg = ShoyrUI.sv.trackers[id]
    if not cfg or cfg.builtin then return false end
    Router.Unregister(id)
    ShoyrUI.sv.trackers[id] = nil
    for i, v in ipairs(ShoyrUI.trackerOrder) do
        if v == id then table.remove(ShoyrUI.trackerOrder, i) break end
    end
    return true
end

-- ---------------------------------------------------------------------------
-- LAM panel
-- ---------------------------------------------------------------------------

local MANAGE_REF = "ShoyrUI_ManageDropdown"

-- transient create-form state
local pendingId     = nil
local pendingName   = ""
local pendingWho    = "me"     -- "me" | "target" (resolved to a watch at create)
local pendingKind   = "uptime" -- archetype (auto-defaulted on pick, override-able)
local pendingCooldownMs = nil  -- ICD carried from a picked cooldown set
local pendingCat    = "buff"   -- catalog filter category (Buffs | Debuffs | Sets)
-- manage selection
local selectedId   = nil
-- Set carried from the Create search when the category filter is "Sets", so the
-- Create button can learn the set's proc id mapping.
local setBrowseId  = nil
-- custom filterable-combobox handle + LAM panel ref (for RefreshPanel)
local abilityCombo, lamPanel

local function TrackerChoices()
    local labels, ids = {}, {}
    for i, id in ipairs(ShoyrUI.trackerOrder) do
        local cfg = ShoyrUI.sv.trackers[id]
        labels[i] = cfg.name .. (cfg.builtin and "" or " *")
        ids[i] = id
    end
    return labels, ids
end

local function SelectedCfg()
    return selectedId and ShoyrUI.sv.trackers[selectedId] or nil
end

-- The ability/set pickers are now self-filtering custom comboboxes that manage
-- their own contents; only the Manage tracker dropdown needs pushing here.
local function RefreshDropdowns()
    local manage = _G[MANAGE_REF]
    if manage and manage.UpdateChoices then
        local labels, ids = TrackerChoices()
        manage:UpdateChoices(labels, ids)
    end
end

-- Ask LAM to re-read every control's getFunc/disabled (reflects pending values we
-- set from the custom comboboxes, and re-evaluates disabled() gates live — e.g. the
-- per-tracker editor's "use a third threshold" toggle). Exposed for Editor.lua.
local function RefreshPanel()
    if lamPanel then CALLBACK_MANAGER:FireCallbacks("LAM-RefreshPanel", lamPanel) end
end
ShoyrUI.RefreshPanel = RefreshPanel

local function SetUnlocked(on)
    ShoyrUI.sv.global.unlocked = on
    for _, id in ipairs(ShoyrUI.trackerOrder) do
        local t = Router.Get(id)
        if t then if on then t:StartPreview() else t:StopPreview() end end
    end
    Router.EnsureTick()
end

local function BuildSettings()
    local LAM = LibAddonMenu2
    if not LAM then return end

    local panel = {
        type = "panel", name = "Shoyru's UI \226\128\148 Trackers", displayName = "Shoyru's UI \226\128\148 Trackers",
        author = "Shoyru", version = ShoyrUI.version, slashCommand = "/shoyrui",
        registerForRefresh = true, registerForDefaults = true,
    }
    local panelControl = LAM:RegisterAddonPanel("ShoyrUIPanel", panel)
    lamPanel = panelControl

    -- Refresh the manage dropdown whenever the panel opens (trackers change live).
    CALLBACK_MANAGER:RegisterCallback("LAM-PanelControlsCreated", function(p)
        if p == panelControl then RefreshDropdowns() end
    end)
    panelControl:SetHandler("OnShow", RefreshDropdowns)

    -- Separate-module settings (LUI-style): this main panel is the Trackers module;
    -- UI Layout and PvP are their own entries (registered below). Within Trackers each
    -- tracker is its own COLLAPSIBLE submenu — which only works cleanly when they're
    -- top-level in this panel (LAM can't nest a submenu inside a submenu).
    local options = {
        { type = "description",
          text = "Shoyru's UI \226\128\148 Trackers. Create a tracker for any ability/set, then tune it in its collapsible editor below. UI Layout (player frame) and PvP are separate entries in this Settings list. Pairs with DarkUI for menus." },
        { type = "checkbox", name = "Master enable", width = "full",
          getFunc = function() return ShoyrUI.sv.global.masterEnabled end,
          setFunc = function(v) ShoyrUI.sv.global.masterEnabled = v; Router.SetMaster(v) end },
        { type = "checkbox", name = "Unlock all (move + preview)", width = "full",
          tooltip = "Show every tracker with cycling preview stacks and make them draggable/resizable. Disable when done positioning.",
          getFunc = function() return ShoyrUI.sv.global.unlocked end,
          setFunc = SetUnlocked },
        { type = "button", name = "Reload UI", width = "full",
          tooltip = "Reload the interface — needed for newly created trackers to get their editor section.",
          func = function() ReloadUI("ingame") end },

        -- Create -------------------------------------------------------------
        { type = "header", name = "Create a tracker" },
        { type = "description", text = "Pick a filter, then search. Buffs/Debuffs search effects you've seen; Sets searches the full game set database — picking a set fills in its proc id (paste it once if unknown). Then Create." },
        { type = "custom", reference = "ShoyrUI_AbilityCombo", width = "full", minHeight = 34,
          createFunc = function(ctrl)
              local wm = WINDOW_MANAGER
              -- Category picker = a real ZO_ComboBox (same widget LAM dropdowns use),
              -- so it matches their styling, kept left-aligned in this custom row.
              local catContainer = wm:CreateControlFromVirtual(ctrl:GetName() .. "Cat", ctrl, "ZO_ComboBox")
              catContainer:SetAnchor(TOPLEFT, ctrl, TOPLEFT, 0, 2)
              catContainer:SetDimensions(130, 26)
              local catCombo = ZO_ComboBox_ObjectFromContainer(catContainer)
              catCombo:SetSortsItems(false)
              for i, label in ipairs(CAT_FILTER_LABELS) do
                  catCombo:AddItem(catCombo:CreateItemEntry(label, function()
                      pendingCat = CAT_FILTER_VALUES[i]
                      -- Sensible default side: buffs default to me, debuffs/sets to target.
                      pendingWho = (pendingCat == "buff") and "me" or "target"
                      if abilityCombo then abilityCombo:Refresh() end
                      RefreshPanel()
                  end), ZO_COMBOBOX_SUPPRESS_UPDATE)
              end
              catCombo:SetSelectedItem(CAT_FILTER_LABELS[1])   -- "Buffs" (pendingCat already "buff")
              -- Search box beside it. The query/select source switches by category:
              -- Sets => full LibSets DB, else the seen-effect catalog.
              abilityCombo = ShoyrUI.SearchCombo.Attach(ctrl, {
                  width = 360, leftOffset = 142, boxHeight = 26,
                  query = function(text, limit)
                      if pendingCat == "set" then return Sets.Search(text, limit) end
                      local cat = (pendingCat ~= "all") and pendingCat or nil
                      return Disc.GetChoices(nil, limit, cat, text)
                  end,
                  onSelect = function(id)
                      if pendingCat == "set" then
                          setBrowseId  = id
                          pendingName  = Sets.GetName(id) or ""
                          pendingId    = Sets.GetProcIds(id)[1]   -- nil if unknown; paste below
                          -- Auto-default the archetype from the set's classification,
                          -- and carry its internal cooldown for cooldown sets.
                          pendingKind  = (D.SET_KINDS and D.SET_KINDS[id]) or "uptime"
                          local icd = D.SET_COOLDOWN_SEC and D.SET_COOLDOWN_SEC[id]
                          pendingCooldownMs = (pendingKind == "cooldown" and icd) and (icd * 1000) or nil
                      else
                          setBrowseId  = nil
                          pendingId    = id
                          pendingName  = Disc.GetName(id) or ""
                          pendingKind  = Disc.SuggestKind(id)   -- stack if seen stacking, else uptime
                          pendingCooldownMs = nil
                      end
                      RefreshPanel()
                  end,
                  nameFor = function(id)
                      if pendingCat == "set" then return Sets.GetName(id) or tostring(id) end
                      return Disc.GetName(id) or tostring(id)
                  end,
              })
          end },
        { type = "editbox", name = "...or ability / proc ID", width = "half",
          tooltip = "Paste an ability ID if it's not in the list yet. For a Set whose proc isn't known, paste its proc ability id here — it's remembered after you Create.",
          getFunc = function() return pendingId and tostring(pendingId) or "" end,
          setFunc = function(v) pendingId = tonumber(v) end },
        { type = "editbox", name = "Name (optional)", width = "half",
          getFunc = function() return pendingName end,
          setFunc = function(v) pendingName = v or "" end },
        { type = "dropdown", name = "Archetype", choices = KIND_LABELS, choicesValues = KIND_VALUES, width = "half",
          tooltip = "Auto-detected when you pick something (sets use their classification; abilities use whether they've been seen stacking) — override here if it guessed wrong. Uptime = duration of a buff/debuff (e.g. Vigor). Stack = a stacking mechanic with per-stack alerts (Bound Armaments, Kjalnar). Cooldown = a proc with an internal cooldown (auto-filled for known sets). Stack + Proc = builds then procs (Kinras). Delayed cast = lands after a delay (shalks, proxy det).",
          getFunc = function() return pendingKind end,
          setFunc = function(v) pendingKind = v end },
        { type = "dropdown", name = "Track as", choices = WHO_LABELS, choicesValues = WHO_VALUES, width = "half",
          tooltip = "Where the effect lives. On myself = on me (a buff on me, or a debuff someone put on me). On my target = on my reticle target (an enemy's buff, or a debuff/proc I apply to them). The category above decides which.",
          getFunc = function() return pendingWho end,
          setFunc = function(v) pendingWho = v end },
        { type = "button", name = "Create tracker", width = "half",
          disabled = function() return not pendingId end,
          func = function()
              if setBrowseId then Sets.Learn(setBrowseId, pendingId, pendingName) end
              local watch = ResolveWatch(pendingCat, pendingWho)
              local id, err = ShoyrUI.CreateTracker(pendingId, pendingName, watch, pendingKind)
              if id then
                  -- Seed the curated internal cooldown when a cooldown set was picked.
                  if pendingCooldownMs then ShoyrUI.sv.trackers[id].cooldownMs = pendingCooldownMs end
                  selectedId = id
                  pendingId, pendingName, setBrowseId, pendingCooldownMs = nil, "", nil, nil
                  RefreshDropdowns()
                  d("[Shoyru's UI] Created tracker: " .. ShoyrUI.sv.trackers[id].name)
              else
                  d("[Shoyru's UI] " .. tostring(err))
              end
          end },

        -- (Manage trackers + the separate Set Browser are both folded into the
        --  Create form above and the per-tracker "Edit trackers" submenus below.)

        -- Catalog ------------------------------------------------------------
        { type = "header", name = "Ability catalog" },
        { type = "checkbox", name = "Record seen abilities", width = "full",
          tooltip = "Builds the picker list above from abilities you encounter. Leave on so new abilities become trackable.",
          getFunc = function() return ShoyrUI.sv.global.recording end,
          setFunc = function(v) ShoyrUI.sv.global.recording = v; Disc.SetRecording(v) end },
        { type = "button", name = "Clear catalog", isDangerous = true,
          warning = "Permanently empties the seen-ability list used by the Create search. Your trackers are NOT affected, but the catalog rebuilds only as you re-encounter abilities. Are you sure?",
          func = function() Disc.Clear(); RefreshDropdowns() end },
    }
    -- Per-tracker COLLAPSIBLE editors (one LAM submenu each) appended to this panel.
    if ShoyrUI.Editor then
        for _, c in ipairs(ShoyrUI.Editor.BuildSubmenus()) do
            options[#options + 1] = c
        end
    end
    LAM:RegisterOptionControls("ShoyrUIPanel", options)

    -- UI Layout and PvP as their OWN settings entries (LUI-style separate modules,
    -- grouped by the "Shoyru's UI —" prefix in the addon settings list).
    local function subPanel(ref, label, opts)
        LAM:RegisterAddonPanel(ref, {
            type = "panel", name = label, displayName = label,
            author = "Shoyru", version = ShoyrUI.version,
            registerForRefresh = true, registerForDefaults = true,
        })
        LAM:RegisterOptionControls(ref, opts)
    end
    if ShoyrUI.UnitFrames then
        subPanel("ShoyrUILayoutPanel", "Shoyru's UI \226\128\148 UI Layout", ShoyrUI.UnitFrames.PanelOptions())
    end
    if ShoyrUI.Auras then
        subPanel("ShoyrUIAurasPanel", "Shoyru's UI \226\128\148 Auras", ShoyrUI.Auras.PanelOptions())
    end
    subPanel("ShoyrUIPvPPanel", "Shoyru's UI \226\128\148 PvP", {
        { type = "description", text = "PvP module \226\128\148 coming soon. Planned: incoming-CC/burst alerts, break-free & roll-dodge resource pips, purge/cleanse reminders, enemy execute-range, focus-target debuff panel, and one-click PvP tracker preset packs." },
    })
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------

local function OnAddonLoaded(event, addonName)
    if addonName ~= ADDON then return end
    EVENT_MANAGER:UnregisterForEvent(ADDON, EVENT_ADD_ON_LOADED)

    D       = ShoyrUI.Defaults
    Router  = ShoyrUI.Router
    Tracker = ShoyrUI.Tracker
    Disc    = ShoyrUI.Discovered
    Sets    = ShoyrUI.Sets

    ShoyrUI.sv = ZO_SavedVars:NewAccountWide("ShoyrUISavedVariables", 1, nil, defaults)

    Disc.Init(ShoyrUI.sv.discovered, ShoyrUI.sv.global.recording)
    Sets.Init(ShoyrUI.sv.setProcs)
    Router.Init()
    SeedTrackers()
    selectedId = ShoyrUI.trackerOrder[1]
    Router.SetMaster(ShoyrUI.sv.global.masterEnabled)
    if ShoyrUI.UnitFrames then ShoyrUI.UnitFrames.Init(ShoyrUI.sv.layout) end
    if ShoyrUI.Auras then ShoyrUI.Auras.Init(ShoyrUI.sv.auras) end
    BuildSettings()

    if ShoyrUI.sv.global.unlocked then SetUnlocked(true) end
end

EVENT_MANAGER:RegisterForEvent(ADDON, EVENT_ADD_ON_LOADED, OnAddonLoaded)
