-- Minimal ESO API stubs so Shoyru's UI Core modules can boot + run headless (outside the game).
-- The real files touch a lot of the ESO UI/event API; we mock enough to construct controls, seed
-- trackers, assemble the LAM panels, and run the behavior/threshold logic. NOT loaded in-game
-- (tests/ is not in the .txt manifest). Anything unstubbed auto-resolves: ALL_CAPS -> unique
-- constant, else -> benign function returning nil.

-- Pre-declare the addon's global bucket so the real files' `ShoyrUI = ShoyrUI or {}` sees a table
-- (not the auto-stub function) at load.
ShoyrUI = {}

-- ---- deep copy (ESO builtin the addon relies on for defaults/seeds) --------------------------
function ZO_DeepTableCopy(t, target)
    target = target or {}
    if type(t) ~= "table" then return target end
    for k, v in pairs(t) do
        if type(v) == "table" then target[k] = ZO_DeepTableCopy(v) else target[k] = v end
    end
    return target
end

-- ---- controllable clock ----------------------------------------------------------------------
_CLOCK = 100000
function GetFrameTimeMilliseconds() return _CLOCK end
function GetGameTimeMilliseconds() return _CLOCK end
function GetFrameTimeSeconds() return _CLOCK / 1000 end
function GetGameTimeSeconds() return _CLOCK / 1000 end
function AdvanceClock(ms) _CLOCK = _CLOCK + (ms or 0) end

-- ---- universal mock: any method returns a sensible default; usable as a control/window --------
local UMT = {}
local function umock(text) return setmetatable({ __text = text or "" }, UMT) end
_G._umock = umock
UMT.__index = function(self, k)
    return function(_, ...)
        if type(k) == "string" then
            if k == "GetText" then return self.__text end
            if k == "SetText" then self.__text = tostring(select(1, ...) or ""); return end
            if k == "GetCenter" then return 0, 0 end
            if k == "GetDimensions" then return 100, 100 end
            if k == "GetName" then return "MockControl" end
            if k == "GetTextWidth" or k == "GetStringWidth" then return #self.__text * 8 end
            if k == "GetWidth" or k == "GetHeight" or k == "GetDesiredWidth" or k == "GetDesiredHeight" then return 100 end
            if k == "GetLeft" or k == "GetTop" or k == "GetRight" or k == "GetBottom" then return 0 end
            if k == "GetScale" then return 1 end
            if k == "GetAnchor" then return true, 0, self, 0, 0, 0 end
            if k == "GetNumChildren" or k:find("^GetNum") then return 0 end   -- 0 => walk loops terminate
            if k == "IsHidden" or k == "IsControlHidden" then return self.__hidden == true end
            if k == "SetHidden" then self.__hidden = (select(1, ...) == true); return end
        end
        return self   -- default: chainable no-op returning the same mock
    end
end
UMT.__call = function() return umock() end

WINDOW_MANAGER, SCENE_MANAGER, GuiRoot = umock(), umock(), umock()
HUD_SCENE, HUD_UI_SCENE = umock(), umock()   -- scene objects with RegisterCallback/IsShowing
-- ALL_CAPS globals that are OBJECTS (not enums) — the auto-stub would make these bare ints.
BUFF_DEBUFF = { control = umock(), containerObjectsByUnitTag = {} }
SLASH_COMMANDS = {}

-- ---- event manager that RECORDS handlers so the test can fire EVENT_ADD_ON_LOADED etc. --------
EVENT_MANAGER = {
    _events = {}, _updates = {},
    RegisterForEvent = function(self, name, event, fn) self._events[event] = self._events[event] or {}; table.insert(self._events[event], fn) end,
    UnregisterForEvent = function() end,
    AddFilterForEvent = function() end,
    RegisterForUpdate = function(self, name, ms, fn) self._updates[name] = fn end,
    UnregisterForUpdate = function() end,
    Fire = function(self, event, ...) for _, fn in ipairs(self._events[event] or {}) do fn(event, ...) end end,
}

-- ---- callback manager (LAM refresh hooks) ----------------------------------------------------
CALLBACK_MANAGER = { RegisterCallback = function() end, FireCallbacks = function() end }

-- ---- SavedVars: return a defaults-merged fresh table -----------------------------------------
ZO_SavedVars = {
    NewAccountWide = function(self, name, version, namespace, defaults) return ZO_DeepTableCopy(defaults or {}) end,
    NewCharacterIdSettings = function(self, name, version, namespace, defaults) return ZO_DeepTableCopy(defaults or {}) end,
}

-- ---- LibAddonMenu2: capture registered option controls for the test to walk ------------------
_LAM_PANELS = {}
LibAddonMenu2 = {
    RegisterAddonPanel = function(_, ref, data) return umock() end,
    RegisterOptionControls = function(_, ref, controls) _LAM_PANELS[#_LAM_PANELS + 1] = { ref = ref, controls = controls } end,
}

-- ---- chat print: capture ---------------------------------------------------------------------
_DLOG = {}
function d(s) _DLOG[#_DLOG + 1] = tostring(s) end

-- ---- game info the modules read --------------------------------------------------------------
function GetAbilityName(id) return "Ability " .. tostring(id or 0) end
function GetAbilityIcon(id) return "/esoui/art/icons/ability_" .. tostring(id or 0) .. ".dds" end
function GetAbilityDuration(id) return 5000 end
_HOTBAR = 0
function GetActiveHotbarCategory() return _HOTBAR end     -- PRIMARY(0)/BACKUP(1); test can flip _HOTBAR
function GetSlotBoundId(slot, hotbar) return 2000 + (slot or 0) end
function GetSlotTexture(slot, hotbar) return "/esoui/art/icons/slot_" .. tostring(slot or 0) .. ".dds" end
function GetUnitPower(tag, pt) return 1500, 2000, 2000 end
function GetGroupSize() return 0 end
function GetGroupUnitTagByIndex(i) return "group" .. i end
function GetUnitDisplayName(tag) return "@Member" .. tostring(tag) end
function GetUnitName(tag) return "Member " .. tostring(tag) end
function GetUnitClassId(tag) return 3 end
function GetNumClasses() return 7 end
function GetUnitChampionPoints(tag) return 1600 end
function GetUnitLevel(tag) return 50 end
function GetUnitAvARank(tag) return 0 end
function GetAvARankIcon(rank) return "/esoui/art/rank.dds" end
function GetUnitReactionColor() return 1, 1, 1, 1 end
function GetClassInfo(i) return i, "Class" .. i, "n", "/classicon" .. i .. "_white.dds", "n", "n", "n", "/classicon" .. i .. ".dds" end
function GetGroupMemberSelectedRole(tag) return 1 end
function DoesUnitExist(tag) return tag == "player" end
function IsUnitGroupLeader(tag) return tag == "group1" end
function IsUnitOnline(tag) return true end
function IsUnitDead(tag) return false end
function IsUnitInCombat(tag) return false end
function GetUnitZoneIndex() return 1 end
function GetNumBuffs(tag) return 0 end
function GetUnitBuffInfo() return "", 0, 0, 0, 0, 0, 0, 0, false, 0, 0 end
function ZO_ActionBar_GetButton(slot) return { slot = umock() } end
function ZO_UnitFrames_GetUnitFrame(tag) return { frame = umock() } end
function ZO_ComboBox_ObjectFromContainer() return umock() end
function GetControl(n) return umock() end
function zo_callLater(fn, ms) return 1 end                -- do not auto-run (avoids reentrancy in tests)
function zo_strformat(fmt, a) return tostring(a or fmt or "") end
function ReloadUI() end
function PlaySound() end
-- Stateful ESO iterators used in generic-for: MUST return nil (else the for-loop never ends, since
-- the auto-stub mock is truthy forever). Empty iteration is correct for a headless run.
ZO_GetNextActiveArtificialEffectIdIter = function() return nil end
function GetArtificialEffectInfo() return "Effect", 0, 0, 0, 0, 0 end
function ZO_CommaDelimitNumber(n) return tostring(n) end
SOUNDS = {}   -- SOUNDS[key] -> nil (PlaySoundAtVolume no-ops); real table so it's indexable
unpack = unpack or table.unpack

-- ---- auto-stub everything else: ALL_CAPS enum -> unique int; else -> universal mock ----------
-- (a umock is both callable (missing function -> returns a mock) and indexable (missing control
-- name like _G["ZO_PlayerAttributeHealth"] -> a control whose methods no-op), which covers the
-- addon's heavy control/window usage without enumerating every native frame name.)
local constCache, nextConst = {}, 5000
setmetatable(_G, { __index = function(_, k)
    if type(k) == "string" and k:match("^[A-Z][A-Z0-9_]*$") then
        if not constCache[k] then nextConst = nextConst + 1; constCache[k] = nextConst end
        return constCache[k]
    end
    return umock()
end })
