-- Upgrade-safety check: boot the addon against the REAL on-disk SavedVariables (an existing player
-- config) to confirm the v1.8x changes (idle-display removal, 3rd-alert removal, seed changes,
-- uniformSize -> uniformH/W/scale) merge cleanly and every tracker still builds. Skips gracefully
-- (exit 0) if no live SavedVariables file is found, so it's safe to run on any machine.
--   Run:  lua real_sv_check.lua
local here = (arg[0]:match("^(.*)[/\\]") or ".")
package.path = here .. "/?.lua;" .. package.path
require("env")

-- Locate the live ShoyrUI SavedVariables (file is named after the addon: ShoyrUI.lua).
local CANDIDATES = {
    (os.getenv("USERPROFILE") or "") .. "/Documents/Elder Scrolls Online/live/SavedVariables/ShoyrUI.lua",
    (os.getenv("HOME") or "") .. "/Documents/Elder Scrolls Online/live/SavedVariables/ShoyrUI.lua",
}
local svPath
for _, p in ipairs(CANDIDATES) do local f = io.open(p, "r"); if f then f:close(); svPath = p; break end end
if not svPath then print("SKIP: no live ShoyrUI SavedVariables found (nothing to migrate-test)."); os.exit(0) end
print("Using live SavedVariables: " .. svPath)

assert(loadfile(svPath))()   -- sets global ShoyrUISavedVariables = { Default = { ["@acct"] = { ["$AccountWide"] = {...} } } }

-- Pull the account-wide slice, and make NewAccountWide hand the addon THAT real data (defaults
-- filled for any keys added since the file was written — like ESO's real ZO_SavedVars does).
local function fillMissing(target, src)
    for k, v in pairs(src) do
        if target[k] == nil then target[k] = (type(v) == "table") and ZO_DeepTableCopy(v) or v
        elseif type(v) == "table" and type(target[k]) == "table" then fillMissing(target[k], v) end
    end
end
local acct
for _, prof in pairs(ShoyrUISavedVariables and ShoyrUISavedVariables.Default or {}) do
    if type(prof) == "table" and prof["$AccountWide"] then acct = prof["$AccountWide"]; break end
end
assert(acct, "could not find an $AccountWide slice in the SavedVariables")
local realTrackerCount = 0
for _ in pairs(acct.trackers or {}) do realTrackerCount = realTrackerCount + 1 end
print(("Real config: %d trackers, %d SV keys"):format(realTrackerCount, (function() local n=0 for _ in pairs(acct) do n=n+1 end return n end)()))

ZO_SavedVars.NewAccountWide = function(_, _, _, defaults) fillMissing(acct, defaults or {}); return acct end

local CORE, ROOT = here .. "/../Core", here .. "/.."
local function load(p) assert(loadfile(p))() end
for _, f in ipairs({
    "Defaults.lua", "SetKinds.lua", "Style.lua", "Discovered.lua",
    "Behaviors/Stack.lua", "Behaviors/Uptime.lua", "Behaviors/Cooldown.lua",
    "Behaviors/StackProc.lua", "Behaviors/DelayedCast.lua", "Behaviors/IncomingCast.lua",
    "Tracker.lua", "Router.lua", "Sets.lua", "SearchCombo.lua", "Editor.lua",
    "UnitFrames.lua", "AuraCategories.lua", "Auras.lua", "Grid.lua",
    "DurationReminder.lua", "ActionBarMove.lua", "NativeMovers.lua",
}) do load(CORE .. "/" .. f) end
load(ROOT .. "/ShoyrUI.lua")

local pass, fail = 0, 0
local function check(c, m) if c then pass = pass + 1 else fail = fail + 1; print("  FAIL: " .. m) end end

local ok, err = pcall(function() EVENT_MANAGER:Fire(EVENT_ADD_ON_LOADED, "ShoyrUI") end)
check(ok, "addon boots against the real config" .. (ok and "" or (" -> " .. tostring(err))))
check(ShoyrUI.trackerOrder and #ShoyrUI.trackerOrder >= 1, "trackers registered from real config: " .. tostring(ShoyrUI.trackerOrder and #ShoyrUI.trackerOrder))

-- Every tracker in the real config must have a live instance + tick without error.
if ShoyrUI.trackerOrder then
    local rendered, errd = 0, 0
    for _, id in ipairs(ShoyrUI.trackerOrder) do
        local t = ShoyrUI.Router.Get(id)
        if t then local o = pcall(function() t:StartPreview(); t:Tick(_CLOCK); t:StopPreview() end); if o then rendered = rendered + 1 else errd = errd + 1 end end
    end
    check(errd == 0, ("all %d real trackers render without error (%d errored)"):format(rendered + errd, errd))
end

-- Rebuild the settings panel over the real config (exercises the editor closures on real data).
check(pcall(function()
    for _, p in ipairs(_LAM_PANELS) do
        for _, c in ipairs(p.controls) do if c.getFunc then pcall(c.getFunc) end end
    end
end), "settings panels read real config without error")

print(("\n== REAL-SV RESULT: %d passed, %d failed =="):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
