# Runs the Shoyru's UI headless integration suite. Finds a Lua 5.x interpreter, then runs the test.
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

$lua = $null
foreach ($c in @(
    "$env:LOCALAPPDATA\Programs\Lua\bin\lua.exe",
    "lua.exe", "lua54.exe", "lua5.4.exe", "lua"
)) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $lua = $cmd.Source; break }
    if (Test-Path $c) { $lua = $c; break }
}
if (-not $lua) { Write-Error "No Lua interpreter found. Install Lua 5.x or add it to PATH."; exit 2 }

Write-Host "Using Lua: $lua"
& $lua "$here\shoyrui_test.lua"
exit $LASTEXITCODE
