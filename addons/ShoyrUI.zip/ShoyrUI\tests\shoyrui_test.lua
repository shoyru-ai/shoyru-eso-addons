-- Shoyru's UI headless integration suite.
-- Boots the REAL addon (all Core modules + ShoyrUI.lua) under a mocked ESO API by firing
-- EVENT_ADD_ON_LOADED, then: (A) smoke-exercises every LAM settings control's get/set closures
-- across all panels, (B) unit-tests the stack threshold engine, (C) drives every archetype through
-- preview + render in both bar and icon-only modes, and (D) checks specific regression points.
--   Run:  lua shoyrui_test.lua   (from tests/)   or   powershell -File run.ps1
-- Exit 0 = all pass, 1 = failures. Does NOT test pixel layout or live game events.
local here = (arg[0]:match("^(.*)[/\\]") or ".")
package.path = here .. "/?.lua;" .. package.path
require("env")

local CORE = here .. "/../Core"
local ROOT = here .. "/.."
local function load(path) local c = assert(loadfile(path)); assert(pcall(c)) end
for _, f in ipairs({
    "Defaults.lua", "SetKinds.lua", "Style.lua", "Discovered.lua",
    "Behaviors/Stack.lua", "Behaviors/Uptime.lua", "Behaviors/Cooldown.lua",
    "Behaviors/StackProc.lua", "Behaviors/DelayedCast.lua", "Behaviors/IncomingCast.lua",
    "Tracker.lua", "Router.lua", "Sets.lua", "SearchCombo.lua", "Editor.lua",
    "UnitFrames.lua", "AuraCategories.lua", "Auras.lua", "Grid.lua",
    "DurationReminder.lua", "ActionBarMove.lua", "NativeMovers.lua",
}) do load(CORE .. "/" .. f) end
load(ROOT .. "/ShoyrUI.lua")

local pass, fail = 0, 0
local function check(cond, msg) if cond then pass = pass + 1 else fail = fail + 1; print("  FAIL: " .. msg) end end
local errs = {}
local function safe(label, fn) local ok, e = pcall(fn); if not ok then errs[#errs + 1] = label .. ": " .. tostring(e) end return ok end

-- ============================================================================
print("== BOOT: fire EVENT_ADD_ON_LOADED ==")
check(safe("boot", function() EVENT_MANAGER:Fire(EVENT_ADD_ON_LOADED, "ShoyrUI") end), "addon boots without error")
check(ShoyrUI.sv ~= nil, "SavedVars created")
check(type(ShoyrUI.trackerOrder) == "table" and #ShoyrUI.trackerOrder >= 3, "seed trackers registered (>=3)")
check(ShoyrUI.sv.trackers.boundArmaments ~= nil, "boundArmaments seed present")
check(ShoyrUI.sv.trackers.kjalnar ~= nil, "kjalnar seed present")
check(ShoyrUI.sv.trackers.fossilize ~= nil, "fossilize seed present")
check(#_LAM_PANELS >= 2, "LAM panels registered (>=2): got " .. #_LAM_PANELS)

-- No "PvP" panel should be registered anymore.
do
    local pvp = false
    for _, p in ipairs(_LAM_PANELS) do if tostring(p.ref):find("PvP") then pvp = true end end
    check(not pvp, "no PvP settings panel registered")
end

-- ============================================================================
print("== A: exercise every settings-control closure across all panels ==")
local function exercise(controls, path)
    for i, c in ipairs(controls or {}) do
        local id = path .. "/" .. (c.name or c.type or ("#" .. i))
        local t = c.type
        if t == "submenu" then
            exercise(c.controls, id)
        elseif t == "custom" and c.createFunc then
            safe("custom:" .. id, function() c.createFunc(_umock()) end)
        else
            if c.getFunc then safe("get:" .. id, function() c.getFunc() end) end
            if c.setFunc then
                if t == "checkbox" then safe("set:" .. id, function() c.setFunc(true); c.setFunc(false) end)
                elseif t == "slider" then safe("set:" .. id, function() c.setFunc(c.min or 1) end)
                elseif t == "dropdown" then safe("set:" .. id, function() c.setFunc((c.choicesValues or {})[1]) end)
                elseif t == "colorpicker" then safe("set:" .. id, function() c.setFunc(0.5, 0.5, 0.5, 1) end)
                elseif t == "editbox" then safe("set:" .. id, function() c.setFunc("42") end)
                end
            end
            if c.func and t == "button" then safe("func:" .. id, function() c.func() end) end
        end
    end
end
for _, p in ipairs(_LAM_PANELS) do exercise(p.controls, tostring(p.ref)) end
check(#errs == 0, "all settings-control closures run without error (" .. #errs .. " errors)")
for _, e in ipairs(errs) do print("     ! " .. e) end

-- ============================================================================
print("== B: stack threshold engine ==")
local B = ShoyrUI.Behaviors.stack
local FADED = EFFECT_RESULT_FADED
local function stackCfg(thresholds, maxStacks)
    return { kind = "stack", perTarget = false, maxStacks = maxStacks,
             name = "T", thresholds = thresholds, defaultDurationMs = 5000 }
end
local function gained(b, stacks) b:OnEffect(EFFECT_RESULT_GAINED, 0, 5, stacks, 1, 99) end

do
    local cfg = stackCfg({ { stacks = 1, text = "A" }, { stacks = 4, text = "B" } }, 5)
    local b = B.New(cfg)
    check(b:Compute(_CLOCK) == nil, "stack hidden at 0 stacks")
    gained(b, 2); local s = b:Compute(_CLOCK)
    check(s and s.text == "A", "stack shows first alert text at 2 stacks")
    gained(b, 4); s = b:Compute(_CLOCK)
    check(s and s.text == "B", "stack shows second alert text at 4 stacks")
    gained(b, 99); s = b:Compute(_CLOCK)
    check(s and s.stacks == 5, "stack count clamped to maxStacks=5 (got " .. tostring(s and s.stacks) .. ")")
end
do  -- hidden below first alert (idle-display removal)
    local b = B.New(stackCfg({ { stacks = 4, text = "B" } }, 5))
    gained(b, 2)
    check(b:Compute(_CLOCK) == nil, "stack hidden when below the first alert (no idle display)")
    gained(b, 4)
    check(b:Compute(_CLOCK) ~= nil, "stack shows once first alert reached")
end

-- ============================================================================
print("== C: every archetype -> create, preview + render, bar & icon-only ==")
local KINDS = { "uptime", "stack", "cooldown", "stackProc", "delayedCast", "incomingCast" }
for n, kind in ipairs(KINDS) do
    local id = ShoyrUI.CreateTracker(3000 + n, "Test_" .. kind, "selfBuff", kind)
    check(id ~= nil, "CreateTracker(" .. kind .. ") returns an id")
    if id then
        local cfg = ShoyrUI.sv.trackers[id]
        local t = ShoyrUI.Router.Get(id)
        check(t ~= nil, "tracker instance registered for " .. kind)
        if t then
            safe("preview:" .. kind, function()
                t:StartPreview()
                for step = 1, 3 do t.previewStep = step; t:Tick(_CLOCK) end
                t:StopPreview()
            end)
            -- icon-only round-trip
            safe("iconOnly:" .. kind, function()
                cfg.iconOnly = true; t:ApplyLayout(); t:StartPreview(); t:Tick(_CLOCK); t:StopPreview()
                cfg.iconOnly = false; t:ApplyLayout()
            end)
        end
    end
end
check(#errs == 0, "archetype preview/render/icon-only run without error (total errors " .. #errs .. ")")
for i = 1, #errs do if i > 12 then break end print("     ! " .. errs[i]) end

-- ============================================================================
print("== D: regression checks ==")
-- D1: creating a stack tracker seeds a stack-1 alert so it's visible from the first stack.
do
    local id = ShoyrUI.CreateTracker(4001, "Stk", "selfBuff", "stack")
    local cfg = ShoyrUI.sv.trackers[id]
    check(cfg.thresholds and cfg.thresholds[1] and (cfg.thresholds[1].stacks == 1),
        "new stack tracker seeded with a first alert at 1 stack")
end
-- D2: icon-only toggle round-trips the width (enable squares, disable restores).
do
    local id = ShoyrUI.CreateTracker(4002, "Icon", "selfBuff", "uptime")
    local cfg = ShoyrUI.sv.trackers[id]
    cfg.w, cfg.h = 220, 56
    -- emulate the editor toggle logic
    cfg._barW = cfg.w; cfg.w = cfg.h; cfg.iconOnly = true
    check(cfg.w == 56, "icon-only enable squares width to height")
    cfg.w = cfg._barW or 220; cfg._barW = nil; cfg.iconOnly = false
    check(cfg.w == 220, "icon-only disable restores bar width")
end
-- D3: uniform size equalizes height + bar width + scale across ALL trackers (icon-only stays square).
do
    local sliders = {}
    for _, p in ipairs(_LAM_PANELS) do
        for _, c in ipairs(p.controls) do
            if c.type == "slider" then
                if c.name == "Height (all trackers)" then sliders.h = c
                elseif c.name:find("Bar width", 1, true) then sliders.w = c
                elseif c.name == "Scale (all trackers)" then sliders.scale = c end
            end
        end
    end
    check(sliders.h and sliders.w and sliders.scale, "uniform height/width/scale sliders present")
    if sliders.h and sliders.w and sliders.scale then
        local barId = ShoyrUI.CreateTracker(4003, "Bar", "selfBuff", "uptime")
        local iconId = ShoyrUI.CreateTracker(4004, "Ico", "selfBuff", "uptime")
        ShoyrUI.sv.trackers[iconId].iconOnly = true
        ShoyrUI.sv.trackers[barId].w = 300   -- deliberately off, should be overwritten
        safe("uniform", function() sliders.h.setFunc(48); sliders.w.setFunc(180); sliders.scale.setFunc(1.25) end)
        local bar, ico = ShoyrUI.sv.trackers[barId], ShoyrUI.sv.trackers[iconId]
        check(bar.h == 48 and bar.w == 180 and bar.scale == 1.25,
            "uniform sets height+width+scale on a bar tracker (h/w/scale = " .. bar.h .. "/" .. bar.w .. "/" .. bar.scale .. ")")
        check(ico.h == 48 and ico.w == 48 and ico.scale == 1.25 and ico._barW == 180,
            "uniform squares an icon-only tracker (h==w==48), sets scale, stashes bar width")
    end
end

-- D4: delayedCast created from the form seeds a phase (else it would be inert).
do
    local id = ShoyrUI.CreateTracker(4101, "Shalk", "targetDebuff", "delayedCast")
    local cfg = ShoyrUI.sv.trackers[id]
    check(cfg.phases and cfg.phases[1] and cfg.phases[1].triggerId == 4101,
        "new delayedCast tracker seeds a phase off the ability id")
end
-- D5: "Reset position/size" keeps an icon-only tracker square (not a wide bar).
do
    local id = ShoyrUI.CreateTracker(4102, "Rst", "selfBuff", "uptime")
    local cfg = ShoyrUI.sv.trackers[id]
    cfg.iconOnly, cfg.w, cfg.h = true, 40, 40
    local controls = ShoyrUI.Editor.BuildOneTracker(cfg)
    local reset
    for _, c in ipairs(controls) do if c.type == "button" and c.name == "Reset position/size" then reset = c end end
    check(reset ~= nil, "reset button present in tracker editor")
    if reset then
        reset.func()
        check(cfg.iconOnly and cfg.w == cfg.h, "reset keeps an icon-only tracker square (w==h)")
    end
end

-- D6: duration reminder renders active-bar (on-icon) vs other-bar (above) casts without error.
do
    ShoyrUI.sv.bars.enabled = true
    _HOTBAR = 0
    -- cast on the primary bar (slot 4), then swap to backup so that cast becomes the OTHER bar,
    -- and cast on the backup bar (slot 5) as the ACTIVE-bar case.
    safe("DR-cast-primary", function() EVENT_MANAGER:Fire(EVENT_ACTION_SLOT_ABILITY_USED, 4) end)
    _HOTBAR = 1
    safe("DR-swap", function() EVENT_MANAGER:Fire(EVENT_ACTIVE_WEAPON_PAIR_CHANGED) end)
    safe("DR-cast-backup", function() EVENT_MANAGER:Fire(EVENT_ACTION_SLOT_ABILITY_USED, 5) end)
    local ok = safe("DR-refresh", function() ShoyrUI.DurationReminder.Refresh() end)
    check(ok, "duration reminder renders both bar cases (active on-icon + other above) without error")
    ShoyrUI.sv.bars.enabled = false
    _HOTBAR = 0
end

-- D7: one tracker erroring in its tick must NOT break the others (Router tick is guarded).
do
    local goodId = ShoyrUI.CreateTracker(4301, "Good", "selfBuff", "uptime")
    local badId  = ShoyrUI.CreateTracker(4302, "Bad",  "selfBuff", "uptime")
    local good, bad = ShoyrUI.Router.Get(goodId), ShoyrUI.Router.Get(badId)
    bad.behavior.Compute = function() error("boom") end
    local goodTicked = false
    local origCompute = good.behavior.Compute
    good.behavior.Compute = function(...) goodTicked = true; return origCompute(...) end
    ShoyrUI.sv.global.masterEnabled = true
    ShoyrUI.Router.SetMaster(true)
    ShoyrUI.Router.EnsureTick()
    local tickOk = true
    for _, fn in pairs(EVENT_MANAGER._updates) do local o = pcall(fn); tickOk = tickOk and o end
    check(tickOk, "Router tick survives a tracker that throws in Compute")
    check(goodTicked, "the healthy tracker still ticked despite the bad one erroring")
end

-- D8: "Unlock all" preview must respect each tracker's Enabled flag — a disabled
-- tracker stays hidden while unlocked, and toggling Enabled reconciles the preview
-- immediately, so users never have to see/reposition trackers they aren't using.
do
    local ba = ShoyrUI.Router.Get("boundArmaments")
    local kj = ShoyrUI.Router.Get("kjalnar")
    ShoyrUI.sv.global.unlocked = false
    ShoyrUI.Router.Refresh()
    -- disable Kjalnar, keep Bound Armaments on, then unlock everything
    kj.config.enabled = false
    ba.config.enabled = true
    ShoyrUI.sv.global.unlocked = true
    ShoyrUI.Router.Refresh()
    check(ba.preview == true, "unlock-all previews an ENABLED tracker (Bound Armaments)")
    check(kj.preview ~= true, "unlock-all does NOT preview a DISABLED tracker (Kjalnar)")
    -- re-enable Kjalnar while still unlocked -> joins the preview immediately
    kj.config.enabled = true
    ShoyrUI.Router.Refresh()
    check(kj.preview == true, "re-enabling a tracker while unlocked previews it immediately")
    -- disable Bound Armaments while unlocked -> drops out immediately
    ba.config.enabled = false
    ShoyrUI.Router.Refresh()
    check(ba.preview ~= true, "disabling a tracker while unlocked hides it immediately")
    -- restore state + lock: all previews stop
    ba.config.enabled = true
    ShoyrUI.sv.global.unlocked = false
    ShoyrUI.Router.Refresh()
    check(ba.preview ~= true and kj.preview ~= true, "locking stops every tracker's preview")
end

-- D9: trackers hide while a full-screen menu/HUD-hiding scene is open (fixes bars
-- floating over menus on keyboard + gamepad), but unlocked/preview trackers stay
-- shown so they're still positionable from the settings panel.
-- (Spy on Hide() rather than the mock window: env.lua's universal mock makes every
--  tracker share one control, so a real SetHidden can't be observed per-tracker.)
do
    ShoyrUI.Router.SetMenuOpen(false)
    local h = ShoyrUI.Router.Get(ShoyrUI.CreateTracker(4401, "MenuHide", "selfBuff", "uptime"))
    local p = ShoyrUI.Router.Get(ShoyrUI.CreateTracker(4402, "MenuPrev", "selfBuff", "uptime"))
    p:StartPreview()                                   -- unlocked / previewing
    local hHidden, pHidden = false, false
    h.Hide = function() hHidden = true end
    p.Hide = function() pHidden = true end
    ShoyrUI.Router.SetMenuOpen(true)
    check(hHidden, "opening a menu hides a normal tracker")
    check(not pHidden, "an unlocked/preview tracker is NOT hidden in menus (still positionable)")
    ShoyrUI.Router.SetMenuOpen(false)                  -- restore
end

-- D10: the group frame badges the leader ("host") with a crown icon. env mock makes
-- "group1" the leader; stub the one control (shared-mock caveat) and assert it toggles.
do
    local UF = ShoyrUI.UnitFrames
    local g = UF and UF.group
    check(g ~= nil, "group frame instance exists")
    if g then
        g:Build()
        local m = g.members[1]
        local rec = {}
        function rec:SetHidden(h) self.h = h end
        m.leaderIcon = rec                       -- stub past the shared universal mock
        g:SetMemberLive(m, "group1")             -- leader per env mock
        check(rec.h == false, "group leader row shows the crown")
        g:SetMemberLive(m, "group2")             -- not the leader
        check(rec.h == true, "a non-leader row hides the crown")
    end
end

-- ============================================================================
print(string.format("\n== RESULT: %d passed, %d failed ==", pass, fail))
os.exit(fail == 0 and 0 or 1)
