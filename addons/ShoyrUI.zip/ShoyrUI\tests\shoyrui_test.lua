-- Shoyru's UI headless integration suite.
-- Boots the REAL addon (all Core modules + ShoyrUI.lua) under a mocked ESO API by firing
-- EVENT_ADD_ON_LOADED, then: (A) smoke-exercises every LAM settings control's get/set closures
-- across all panels, (B) unit-tests the stack threshold engine, (C) drives every archetype through
-- preview + render in both bar and icon-only modes, and (D) checks specific regression points.
--   Run:  lua shoyrui_test.lua   (from tests/)   or   powershell -File run.ps1
-- Exit 0 = all pass, 1 = failures. Does NOT test pixel layout or live game events.
local here = (arg[0]:match("^(.*)[/\\]") or ".")
package.path = here .. "/?.lua;" .. package.path
require("env")

local CORE = here .. "/../Core"
local ROOT = here .. "/.."
local function load(path) local c = assert(loadfile(path)); assert(pcall(c)) end
for _, f in ipairs({
    "Defaults.lua", "SetKinds.lua", "Style.lua", "Discovered.lua",
    "Behaviors/Stack.lua", "Behaviors/Uptime.lua", "Behaviors/Cooldown.lua",
    "Behaviors/StackProc.lua", "Behaviors/DelayedCast.lua", "Behaviors/IncomingCast.lua",
    "Tracker.lua", "Router.lua", "Sets.lua", "SearchCombo.lua", "Editor.lua",
    "UnitFrames.lua", "AuraCategories.lua", "Auras.lua", "Grid.lua",
    "DurationReminder.lua", "ActionBarMove.lua", "NativeMovers.lua", "Profiles.lua",
}) do load(CORE .. "/" .. f) end
load(ROOT .. "/ShoyrUI.lua")

local pass, fail = 0, 0
local function check(cond, msg) if cond then pass = pass + 1 else fail = fail + 1; print("  FAIL: " .. msg) end end
local errs = {}
local function safe(label, fn) local ok, e = pcall(fn); if not ok then errs[#errs + 1] = label .. ": " .. tostring(e) end return ok end

-- ============================================================================
print("== BOOT: fire EVENT_ADD_ON_LOADED ==")
check(safe("boot", function() EVENT_MANAGER:Fire(EVENT_ADD_ON_LOADED, "ShoyrUI") end), "addon boots without error")
check(ShoyrUI.sv ~= nil, "SavedVars created")
check(type(ShoyrUI.trackerOrder) == "table" and #ShoyrUI.trackerOrder >= 3, "seed trackers registered (>=3)")
check(ShoyrUI.sv.trackers.boundArmaments ~= nil, "boundArmaments seed present")
check(ShoyrUI.sv.trackers.kjalnar ~= nil, "kjalnar seed present")
check(ShoyrUI.sv.trackers.fossilize ~= nil, "fossilize seed present")
check(#_LAM_PANELS >= 2, "LAM panels registered (>=2): got " .. #_LAM_PANELS)

-- No "PvP" panel should be registered anymore.
do
    local pvp = false
    for _, p in ipairs(_LAM_PANELS) do if tostring(p.ref):find("PvP") then pvp = true end end
    check(not pvp, "no PvP settings panel registered")
end

-- ============================================================================
print("== A: exercise every settings-control closure across all panels ==")
local function exercise(controls, path)
    for i, c in ipairs(controls or {}) do
        local id = path .. "/" .. (c.name or c.type or ("#" .. i))
        local t = c.type
        if t == "submenu" then
            exercise(c.controls, id)
        elseif t == "custom" and c.createFunc then
            safe("custom:" .. id, function() c.createFunc(_umock()) end)
        else
            if c.getFunc then safe("get:" .. id, function() c.getFunc() end) end
            if c.setFunc then
                if t == "checkbox" then safe("set:" .. id, function() c.setFunc(true); c.setFunc(false) end)
                elseif t == "slider" then safe("set:" .. id, function() c.setFunc(c.min or 1) end)
                elseif t == "dropdown" then safe("set:" .. id, function() c.setFunc((c.choicesValues or {})[1]) end)
                elseif t == "colorpicker" then safe("set:" .. id, function() c.setFunc(0.5, 0.5, 0.5, 1) end)
                elseif t == "editbox" then safe("set:" .. id, function() c.setFunc("42") end)
                end
            end
            if c.func and t == "button" then safe("func:" .. id, function() c.func() end) end
        end
    end
end
for _, p in ipairs(_LAM_PANELS) do exercise(p.controls, tostring(p.ref)) end
check(#errs == 0, "all settings-control closures run without error (" .. #errs .. " errors)")
for _, e in ipairs(errs) do print("     ! " .. e) end

-- ============================================================================
print("== B: stack threshold engine ==")
local B = ShoyrUI.Behaviors.stack
local FADED = EFFECT_RESULT_FADED
local function stackCfg(thresholds, maxStacks)
    return { kind = "stack", perTarget = false, maxStacks = maxStacks,
             name = "T", thresholds = thresholds, defaultDurationMs = 5000 }
end
local function gained(b, stacks) b:OnEffect(EFFECT_RESULT_GAINED, 0, 5, stacks, 1, 99) end

do
    local cfg = stackCfg({ { stacks = 1, text = "A" }, { stacks = 4, text = "B" } }, 5)
    local b = B.New(cfg)
    check(b:Compute(_CLOCK) == nil, "stack hidden at 0 stacks")
    gained(b, 2); local s = b:Compute(_CLOCK)
    check(s and s.text == "A", "stack shows first alert text at 2 stacks")
    gained(b, 4); s = b:Compute(_CLOCK)
    check(s and s.text == "B", "stack shows second alert text at 4 stacks")
    gained(b, 99); s = b:Compute(_CLOCK)
    check(s and s.stacks == 5, "stack count clamped to maxStacks=5 (got " .. tostring(s and s.stacks) .. ")")
end
do  -- hidden below first alert (idle-display removal)
    local b = B.New(stackCfg({ { stacks = 4, text = "B" } }, 5))
    gained(b, 2)
    check(b:Compute(_CLOCK) == nil, "stack hidden when below the first alert (no idle display)")
    gained(b, 4)
    check(b:Compute(_CLOCK) ~= nil, "stack shows once first alert reached")
end

-- ============================================================================
print("== C: every archetype -> create, preview + render, bar & icon-only ==")
local KINDS = { "uptime", "stack", "cooldown", "stackProc", "delayedCast", "incomingCast" }
for n, kind in ipairs(KINDS) do
    local id = ShoyrUI.CreateTracker(3000 + n, "Test_" .. kind, "selfBuff", kind)
    check(id ~= nil, "CreateTracker(" .. kind .. ") returns an id")
    if id then
        local cfg = ShoyrUI.sv.trackers[id]
        local t = ShoyrUI.Router.Get(id)
        check(t ~= nil, "tracker instance registered for " .. kind)
        if t then
            safe("preview:" .. kind, function()
                t:StartPreview()
                for step = 1, 3 do t.previewStep = step; t:Tick(_CLOCK) end
                t:StopPreview()
            end)
            -- icon-only round-trip
            safe("iconOnly:" .. kind, function()
                cfg.iconOnly = true; t:ApplyLayout(); t:StartPreview(); t:Tick(_CLOCK); t:StopPreview()
                cfg.iconOnly = false; t:ApplyLayout()
            end)
        end
    end
end
check(#errs == 0, "archetype preview/render/icon-only run without error (total errors " .. #errs .. ")")
for i = 1, #errs do if i > 12 then break end print("     ! " .. errs[i]) end

-- ============================================================================
print("== D: regression checks ==")
-- D1: creating a stack tracker seeds a stack-1 alert so it's visible from the first stack.
do
    local id = ShoyrUI.CreateTracker(4001, "Stk", "selfBuff", "stack")
    local cfg = ShoyrUI.sv.trackers[id]
    check(cfg.thresholds and cfg.thresholds[1] and (cfg.thresholds[1].stacks == 1),
        "new stack tracker seeded with a first alert at 1 stack")
end
-- D2: icon-only toggle round-trips the width (enable squares, disable restores).
do
    local id = ShoyrUI.CreateTracker(4002, "Icon", "selfBuff", "uptime")
    local cfg = ShoyrUI.sv.trackers[id]
    cfg.w, cfg.h = 220, 56
    -- emulate the editor toggle logic
    cfg._barW = cfg.w; cfg.w = cfg.h; cfg.iconOnly = true
    check(cfg.w == 56, "icon-only enable squares width to height")
    cfg.w = cfg._barW or 220; cfg._barW = nil; cfg.iconOnly = false
    check(cfg.w == 220, "icon-only disable restores bar width")
end
-- D3: uniform size equalizes height + bar width + scale across ALL trackers (icon-only stays square).
do
    local sliders = {}
    for _, p in ipairs(_LAM_PANELS) do
        for _, c in ipairs(p.controls) do
            if c.type == "slider" then
                if c.name == "Height (all trackers)" then sliders.h = c
                elseif c.name:find("Bar width", 1, true) then sliders.w = c
                elseif c.name == "Scale (all trackers)" then sliders.scale = c end
            end
        end
    end
    check(sliders.h and sliders.w and sliders.scale, "uniform height/width/scale sliders present")
    if sliders.h and sliders.w and sliders.scale then
        local barId = ShoyrUI.CreateTracker(4003, "Bar", "selfBuff", "uptime")
        local iconId = ShoyrUI.CreateTracker(4004, "Ico", "selfBuff", "uptime")
        ShoyrUI.sv.trackers[iconId].iconOnly = true
        ShoyrUI.sv.trackers[barId].w = 300   -- deliberately off, should be overwritten
        safe("uniform", function() sliders.h.setFunc(48); sliders.w.setFunc(180); sliders.scale.setFunc(1.25) end)
        local bar, ico = ShoyrUI.sv.trackers[barId], ShoyrUI.sv.trackers[iconId]
        check(bar.h == 48 and bar.w == 180 and bar.scale == 1.25,
            "uniform sets height+width+scale on a bar tracker (h/w/scale = " .. bar.h .. "/" .. bar.w .. "/" .. bar.scale .. ")")
        check(ico.h == 48 and ico.w == 48 and ico.scale == 1.25 and ico._barW == 180,
            "uniform squares an icon-only tracker (h==w==48), sets scale, stashes bar width")
    end
end

-- D4: delayedCast created from the form seeds a phase (else it would be inert).
do
    local id = ShoyrUI.CreateTracker(4101, "Shalk", "targetDebuff", "delayedCast")
    local cfg = ShoyrUI.sv.trackers[id]
    check(cfg.phases and cfg.phases[1] and cfg.phases[1].triggerId == 4101,
        "new delayedCast tracker seeds a phase off the ability id")
end
-- D5: "Reset position/size" keeps an icon-only tracker square (not a wide bar).
do
    local id = ShoyrUI.CreateTracker(4102, "Rst", "selfBuff", "uptime")
    local cfg = ShoyrUI.sv.trackers[id]
    cfg.iconOnly, cfg.w, cfg.h = true, 40, 40
    local controls = ShoyrUI.Editor.BuildOneTracker(cfg)
    local reset
    for _, c in ipairs(controls) do if c.type == "button" and c.name == "Reset position/size" then reset = c end end
    check(reset ~= nil, "reset button present in tracker editor")
    if reset then
        reset.func()
        check(cfg.iconOnly and cfg.w == cfg.h, "reset keeps an icon-only tracker square (w==h)")
    end
end

-- D6: duration reminder renders active-bar (on-icon) vs other-bar (above) casts without error.
do
    ShoyrUI.sv.bars.enabled = true
    _HOTBAR = 0
    -- cast on the primary bar (slot 4), then swap to backup so that cast becomes the OTHER bar,
    -- and cast on the backup bar (slot 5) as the ACTIVE-bar case.
    safe("DR-cast-primary", function() EVENT_MANAGER:Fire(EVENT_ACTION_SLOT_ABILITY_USED, 4) end)
    _HOTBAR = 1
    safe("DR-swap", function() EVENT_MANAGER:Fire(EVENT_ACTIVE_WEAPON_PAIR_CHANGED) end)
    safe("DR-cast-backup", function() EVENT_MANAGER:Fire(EVENT_ACTION_SLOT_ABILITY_USED, 5) end)
    local ok = safe("DR-refresh", function() ShoyrUI.DurationReminder.Refresh() end)
    check(ok, "duration reminder renders both bar cases (active on-icon + other above) without error")
    ShoyrUI.sv.bars.enabled = false
    _HOTBAR = 0
end

-- D7: one tracker erroring in its tick must NOT break the others (Router tick is guarded).
do
    local goodId = ShoyrUI.CreateTracker(4301, "Good", "selfBuff", "uptime")
    local badId  = ShoyrUI.CreateTracker(4302, "Bad",  "selfBuff", "uptime")
    local good, bad = ShoyrUI.Router.Get(goodId), ShoyrUI.Router.Get(badId)
    bad.behavior.Compute = function() error("boom") end
    local goodTicked = false
    local origCompute = good.behavior.Compute
    good.behavior.Compute = function(...) goodTicked = true; return origCompute(...) end
    ShoyrUI.Router.EnsureTick()
    local tickOk = true
    for _, fn in pairs(EVENT_MANAGER._updates) do local o = pcall(fn); tickOk = tickOk and o end
    check(tickOk, "Router tick survives a tracker that throws in Compute")
    check(goodTicked, "the healthy tracker still ticked despite the bad one erroring")
end

-- D8: "Unlock all" preview must respect each tracker's Enabled flag — a disabled
-- tracker stays hidden while unlocked, and toggling Enabled reconciles the preview
-- immediately, so users never have to see/reposition trackers they aren't using.
do
    local ba = ShoyrUI.Router.Get("boundArmaments")
    local kj = ShoyrUI.Router.Get("kjalnar")
    ShoyrUI.sv.global.unlocked = false
    ShoyrUI.Router.Refresh()
    -- disable Kjalnar, keep Bound Armaments on, then unlock everything
    kj.config.enabled = false
    ba.config.enabled = true
    ShoyrUI.sv.global.unlocked = true
    ShoyrUI.Router.Refresh()
    check(ba.preview == true, "unlock-all previews an ENABLED tracker (Bound Armaments)")
    check(kj.preview ~= true, "unlock-all does NOT preview a DISABLED tracker (Kjalnar)")
    -- re-enable Kjalnar while still unlocked -> joins the preview immediately
    kj.config.enabled = true
    ShoyrUI.Router.Refresh()
    check(kj.preview == true, "re-enabling a tracker while unlocked previews it immediately")
    -- disable Bound Armaments while unlocked -> drops out immediately
    ba.config.enabled = false
    ShoyrUI.Router.Refresh()
    check(ba.preview ~= true, "disabling a tracker while unlocked hides it immediately")
    -- restore state + lock: all previews stop
    ba.config.enabled = true
    ShoyrUI.sv.global.unlocked = false
    ShoyrUI.Router.Refresh()
    check(ba.preview ~= true and kj.preview ~= true, "locking stops every tracker's preview")
end

-- D9: trackers hide while a full-screen menu/HUD-hiding scene is open (fixes bars
-- floating over menus on keyboard + gamepad), but unlocked/preview trackers stay
-- shown so they're still positionable from the settings panel.
-- (Spy on Hide() rather than the mock window: env.lua's universal mock makes every
--  tracker share one control, so a real SetHidden can't be observed per-tracker.)
do
    ShoyrUI.Router.SetMenuOpen(false)
    local h = ShoyrUI.Router.Get(ShoyrUI.CreateTracker(4401, "MenuHide", "selfBuff", "uptime"))
    local p = ShoyrUI.Router.Get(ShoyrUI.CreateTracker(4402, "MenuPrev", "selfBuff", "uptime"))
    p:StartPreview()                                   -- unlocked / previewing
    local hHidden, pHidden = false, false
    h.Hide = function() hHidden = true end
    p.Hide = function() pHidden = true end
    ShoyrUI.Router.SetMenuOpen(true)
    check(hHidden, "opening a menu hides a normal tracker")
    check(not pHidden, "an unlocked/preview tracker is NOT hidden in menus (still positionable)")
    ShoyrUI.Router.SetMenuOpen(false)                  -- restore
end

-- D10: the group frame badges the leader ("host") with a crown icon. env mock makes
-- "group1" the leader; stub the one control (shared-mock caveat) and assert it toggles.
do
    local UF = ShoyrUI.UnitFrames
    local g = UF and UF.group
    check(g ~= nil, "group frame instance exists")
    if g then
        g:Build()
        local m = g.members[1]
        local rec = {}
        function rec:SetHidden(h) self.h = h end
        m.leaderIcon = rec                       -- stub past the shared universal mock
        g:SetMemberLive(m, "group1")             -- leader per env mock
        check(rec.h == false, "group leader row shows the crown")
        g:SetMemberLive(m, "group2")             -- not the leader
        check(rec.h == true, "a non-leader row hides the crown")
    end
end

-- D11: free-float (Base UI) auras show the shared blue unlock box; locked ones hide it.
do
    local d = ShoyrUI.Auras and ShoyrUI.Auras.displays and ShoyrUI.Auras.displays.player
    check(d ~= nil, "player aura display exists")
    if d then
        d:Build()
        check(d.editFrame ~= nil, "aura display creates an unlock edit frame")
        local rec = {}
        function rec:SetHidden(h) rec.shown = (h ~= true) end
        d.editFrame = rec
        ShoyrUI.sv.layout.activeUI = "base"
        d.sv.showInBase = true
        d.sv.baseLocked = false
        d:UpdateEditFrame()
        check(rec.shown == true, "unlocked free-float auras show the blue edit box")
        d.sv.baseLocked = true
        d:UpdateEditFrame()
        check(rec.shown == false, "locked auras hide the edit box")
        d.sv.showInBase = false
    end
end

-- D12: free-float auras centre each row (base-game style); attached auras stay left-aligned.
do
    local d = ShoyrUI.Auras and ShoyrUI.Auras.displays and ShoyrUI.Auras.displays.player
    if d then
        d:Build()
        local rec = {}
        function rec:ClearAnchors() end
        function rec:SetAnchor(p, rel, rp, x, y) rec.x = x end
        function rec:SetDimensions() end
        function rec:SetHidden() end
        d.icons[1].bg = rec
        d.list = { { icon = "", remaining = 0, stacks = 0 } }
        ShoyrUI.sv.layout.activeUI = "base"; d.sv.showInBase = true; d.sv.baseWidth = 320
        d:LayoutIcons()
        check((rec.x or 0) > 0, "free-float auras centre the row (x offset > 0)")
        ShoyrUI.sv.layout.activeUI = "shoyru"
        d:LayoutIcons()
        check(rec.x == 0, "attached auras stay left-aligned (x offset == 0)")
        ShoyrUI.sv.layout.activeUI = "base"; d.sv.showInBase = false; d.list = {}
    end
end

-- D13: re-showing native group frames (Base UI) must NOT force base SetHidden(false) — that used
-- to re-reveal empty/stale member frames ESO had hidden after you left a group.
do
    local g = ShoyrUI.UnitFrames and ShoyrUI.UnitFrames.group
    if g then
        local rec = {}
        function rec:SetHidden() rec.forced = true end
        function rec:SetHiddenForReason(reason, h) rec.reason = h end
        local saved = ZO_UnitFrames_GetUnitFrame
        ZO_UnitFrames_GetUnitFrame = function() return { frame = rec } end
        g.nativeHidden = false
        g:ApplyNativeHidden()
        ZO_UnitFrames_GetUnitFrame = saved
        check(rec.forced ~= true, "re-showing native group frames doesn't force base SetHidden (no stale members)")
        check(rec.reason == false, "re-showing just clears our hide reason and lets ESO govern")
    end
end

-- D14: payload-proc id (Kjalnar 133506) is hidden from the trackable picker; stack id (133505) stays.
do
    local Disc = ShoyrUI.Discovered
    ShoyrUI.sv.discovered[133505] = { name = "Bone", onTarget = true, effectType = 2, lastSeen = 100 }
    ShoyrUI.sv.discovered[133506] = { name = "Kjalnar's Nightmare", onTarget = true, effectType = 2, lastSeen = 100 }
    local _, ids = Disc.GetChoices(nil, 250, nil, nil)
    local has505, has506 = false, false
    for _, id in ipairs(ids) do
        if id == 133505 then has505 = true elseif id == 133506 then has506 = true end
    end
    check(has505, "stack id 133505 is offered in the trackable picker")
    check(not has506, "payload-proc id 133506 is hidden from the trackable picker")
    ShoyrUI.sv.discovered[133505] = nil; ShoyrUI.sv.discovered[133506] = nil
end

-- D15: the create-form Archetype control is display-only (auto-mapped, no user override).
do
    local found, disabledOk = false, false
    for _, p in ipairs(_LAM_PANELS) do
        for _, c in ipairs(p.controls or {}) do
            if type(c) == "table" and type(c.name) == "string" and c.name:find("^Archetype") then
                found = true; disabledOk = (c.disabled == true)
            end
        end
    end
    check(found, "create-form Archetype control present")
    check(disabledOk, "Archetype control is disabled (display-only, no manual override)")
end

-- D16: name-display mode (@account / character / both) drives the frame + group labels.
do
    local UF = ShoyrUI.UnitFrames
    local f = UF and UF.frames and UF.frames.target
    check(f ~= nil, "target frame exists for name-mode test")
    if f then
        f:Build()                                   -- no reticle target → RefreshAll takes the preview path
        -- Mock CreateControl aliases every label to one shared window mock, so a dedicated recording
        -- label is needed to read back just the name (other labels clobber the shared __text).
        local rec = _umock(); rec.SetText = function(_, t) rec.txt = tostring(t or "") end
        f.nameLabel = rec
        local cases = {
            { "account",   "@Target" },
            { "character", "Target" },
            { "both",      "Target  @Target" },
        }
        for _, c in ipairs(cases) do
            ShoyrUI.sv.layout.nameMode = c[1]
            check(UF.NameMode() == c[1], "NameMode() reports '" .. c[1] .. "'")
            f:RefreshAll()
            check(rec.txt == c[2], "preview name in '" .. c[1] .. "' mode is '" .. c[2] .. "' (got '" .. tostring(rec.txt) .. "')")
        end
        -- Live group member honours the mode too (env: char "Member group1", acct "@Membergroup1").
        local g = UF.group
        if g then
            g:Build()
            local m = g.members[1]
            local rec2 = _umock(); rec2.SetText = function(_, t) rec2.txt = tostring(t or "") end
            m.nameLabel = rec2
            ShoyrUI.sv.layout.nameMode = "character"; g:SetMemberLive(m, "group1")
            check(rec2.txt == "Member group1", "group member shows character name (got '" .. tostring(rec2.txt) .. "')")
            ShoyrUI.sv.layout.nameMode = "account";   g:SetMemberLive(m, "group1")
            check(rec2.txt == "@Membergroup1", "group member shows @account name (got '" .. tostring(rec2.txt) .. "')")
        end
        ShoyrUI.sv.layout.nameMode = "account"
    end
end

-- D17: colour copy/paste — each picker gets a Copy button (grabs THIS picker's colour) and a
-- Paste button (writes the clipboard into this slot); picking no longer auto-copies; Paste
-- disables with an empty clipboard.
do
    ShoyrUI.sv.colorClip = nil
    local cfg = ShoyrUI.sv.trackers.kjalnar
    local ctrls = ShoyrUI.Editor.BuildOneTracker(cfg)
    local cp, copy, paste
    for i, c in ipairs(ctrls) do
        if type(c) == "table" and c.type == "colorpicker" and c.name == "Bar background" then
            cp, copy, paste = c, ctrls[i + 1], ctrls[i + 2]; break
        end
    end
    check(cp ~= nil, "tracker editor exposes the Bar background colourpicker")
    check(copy and copy.name == "Copy colour", "a colourpicker is followed by a Copy button")
    check(paste and paste.name == "Paste colour", "a colourpicker is followed by a Paste button")
    if cp and copy and paste then
        check(paste.disabled() == true, "Paste is disabled with an empty clipboard")
        cp.setFunc(0.1, 0.2, 0.3, 1)                    -- set this slot's colour
        check(ShoyrUI.sv.colorClip == nil, "picking a colour no longer auto-copies")
        copy.func()                                     -- Copy grabs THIS picker's colour
        local clip = ShoyrUI.sv.colorClip
        check(clip and math.abs(clip.r - 0.1) < 1e-6 and math.abs(clip.b - 0.3) < 1e-6,
              "Copy stores this picker's colour to the clipboard")
        ShoyrUI.sv.colorClip = { r = 0.9, g = 0.8, b = 0.7, a = 1 }
        paste.func()
        local r, g, b = cp.getFunc()
        check(math.abs(r - 0.9) < 1e-6 and math.abs(g - 0.8) < 1e-6 and math.abs(b - 0.7) < 1e-6,
              "Paste writes the clipboard colour into the slot")
    end
end

-- D18: uptime warn sound fires once on crossing into the warn window, latches (no repeat), and
-- re-arms after the buff is refreshed above the threshold.
do
    local B = ShoyrUI.Behaviors and ShoyrUI.Behaviors.uptime
    check(B ~= nil, "uptime behavior exists")
    if B then
        local plays = 0
        local real = ShoyrUI.PlaySoundAtVolume
        ShoyrUI.PlaySoundAtVolume = function() plays = plays + 1 end
        local inst = B.New({ warnSec = 2, warnPlaySound = true, warnSound = "DUEL_START",
                             soundVolume = 1, defaultDurationMs = 5000 })
        local now = GetFrameTimeMilliseconds()
        inst.active.endMs, inst.active.durationMs, inst.warnFired = now + 1500, 5000, false
        inst:Compute(now);            check(plays == 1, "warn sound fires when inside the warn window")
        inst:Compute(now);            check(plays == 1, "warn sound does not repeat while latched")
        inst.active.endMs = now + 4000                       -- refreshed above the warn window
        inst:Compute(now);            check(plays == 1, "no warn sound above the warn window")
        inst.active.endMs = now + 900                        -- drops back into warn → re-armed
        inst:Compute(now);            check(plays == 2, "warn sound fires again after re-arm")
        -- Silent when the toggle is off.
        local off = B.New({ warnSec = 2, warnPlaySound = false, warnSound = "DUEL_START", defaultDurationMs = 5000 })
        off.active.endMs, off.active.durationMs = now + 500, 5000
        off:Compute(now);             check(plays == 2, "no warn sound when the toggle is off")
        ShoyrUI.PlaySoundAtVolume = real
    end
end

-- D19: global timer format — FmtTimer integer/decimal, consumed live by a behavior.
do
    ShoyrUI.sv.global.timerFormat = "decimal"
    check(ShoyrUI.FmtTimer(4400) == "4.4s", "FmtTimer decimal -> 4.4s")
    ShoyrUI.sv.global.timerFormat = "integer"
    check(ShoyrUI.FmtTimer(4400) == "5s", "FmtTimer integer ceils 4.4s -> 5s")
    check(ShoyrUI.FmtTimer(4000) == "4s", "FmtTimer integer 4.0s -> 4s")
    local b = ShoyrUI.Behaviors.uptime.New({ defaultDurationMs = 5000 })
    local now = GetFrameTimeMilliseconds()
    b.active.endMs, b.active.durationMs = now + 4400, 5000
    local st = b:Compute(now)
    check(st and st.timerText == "5s", "uptime timerText honors the integer format live")
    ShoyrUI.sv.global.timerFormat = "decimal"
end

-- D20: state-driven border chooses active/idle colour by st.active; alwaysShow renders an idle
-- state (active=false) when the effect is down instead of hiding.
do
    local id = ShoyrUI.CreateTracker(4501, "BorderT", "selfBuff", "uptime")
    local t = ShoyrUI.Router.Get(id)
    check(t ~= nil, "border test tracker created")
    if t then
        local cfg = t.config
        cfg.borderStateEnabled = true
        cfg.borderActiveColor = { r = 0, g = 1, b = 0, a = 1 }
        cfg.borderIdleColor   = { r = 0, g = 0, b = 0, a = 1 }
        local got
        t.SetBorderColor = function(_, c) got = c end
        t:Render({ text = "x", color = { r=1,g=1,b=1,a=1 }, barPct = 0.5, active = true })
        check(got and got.g == 1 and got.r == 0, "state border uses Active colour when st.active")
        t:Render({ text = "x", color = { r=1,g=1,b=1,a=1 }, barPct = 0, active = false })
        check(got and got.g == 0 and got.r == 0, "state border uses Idle colour when not active")
        cfg.borderStateEnabled = false
        got = "SENTINEL"
        t:Render({ text = "x", color = { r=1,g=1,b=1,a=1 }, barPct = 0, active = true })
        check(got == "SENTINEL", "static border: Render doesn't override the border colour")
        ShoyrUI.DeleteTracker(id)
    end
    local now = GetFrameTimeMilliseconds()
    local up = ShoyrUI.Behaviors.uptime.New({ alwaysShow = true, name = "R", defaultDurationMs = 5000 })
    local ist = up:Compute(now)
    check(ist ~= nil and ist.active == false, "alwaysShow uptime renders an idle state (active=false) when down")
    check(up:IsBusy(now) == true, "alwaysShow uptime stays busy so the idle border keeps painting")
    local up2 = ShoyrUI.Behaviors.uptime.New({ defaultDurationMs = 5000 })
    check(up2:Compute(now) == nil, "uptime without alwaysShow hides when down")
end

-- D21: profile Save/Load round-trips a user tracker (cfg + instance + order) and keeps builtins.
do
    local P = ShoyrUI.Profiles
    check(P ~= nil, "Profiles module exists")
    local uid = ShoyrUI.CreateTracker(4601, "ProfUser", "selfBuff", "uptime")
    check(ShoyrUI.Router.Get(uid) ~= nil, "user tracker created for profile test")
    P.Save("RT")                                   -- snapshot WITH the user tracker
    ShoyrUI.DeleteTracker(uid)                      -- diverge live state
    check(ShoyrUI.Router.Get(uid) == nil, "user tracker removed before load")
    local kInst = ShoyrUI.Router.Get("kjalnar")    -- must be REBOUND (not recreated) across a load
    check(P.Load("RT") == true, "Load returns true")
    check(ShoyrUI.Router.Get("kjalnar") == kInst,
        "profile Load rebinds builtins in place (same instance — no duplicate-window crash)")
    check(ShoyrUI.sv.trackers[uid] ~= nil, "Load restores the user tracker cfg")
    check(ShoyrUI.Router.Get(uid) ~= nil, "Load rebuilds the tracker instance")
    local inOrder = false
    for _, tid in ipairs(ShoyrUI.trackerOrder) do if tid == uid then inOrder = true end end
    check(inOrder, "Load rebuilds trackerOrder with the user tracker")
    check(ShoyrUI.Router.Get("kjalnar") ~= nil, "builtins survive a profile load")
    ShoyrUI.DeleteTracker(uid)
end

-- D22: New clean-slate disables Kjalnar + Bound Armaments, keeps Fossilize, no user trackers.
do
    local P = ShoyrUI.Profiles
    P.New("Clean")
    check(ShoyrUI.sv.activeProfile == "Clean", "New switches active profile to Clean")
    check(ShoyrUI.sv.trackers.boundArmaments and ShoyrUI.sv.trackers.boundArmaments.enabled == false,
        "clean slate disables Bound Armaments")
    check(ShoyrUI.sv.trackers.kjalnar and ShoyrUI.sv.trackers.kjalnar.enabled == false,
        "clean slate disables Kjalnar")
    check(ShoyrUI.sv.trackers.fossilize and ShoyrUI.sv.trackers.fossilize.enabled == false,
        "clean slate disables Fossilize too (nothing shows until opted in)")
    local userCount = 0
    for _, c in pairs(ShoyrUI.sv.trackers) do if not c.builtin then userCount = userCount + 1 end end
    check(userCount == 0, "clean slate has no user trackers")
    check(ShoyrUI.Router.Get("kjalnar") ~= nil, "clean slate rebuilds builtin instances")
end

-- D23: END-TO-END profile lifecycle (the in-game flow) — customize, make a NEW clean profile,
-- switch back, and the customization must be restored (not reset to defaults); no wipe/crash.
do
    local P = ShoyrUI.Profiles
    P.Bootstrap()                                     -- idempotent
    local first = ShoyrUI.sv.activeProfile
    check(first ~= nil, "a profile is active after bootstrap")
    -- Customize a builtin on the active profile.
    ShoyrUI.sv.trackers.kjalnar.borderThickness = 8
    ShoyrUI.sv.trackers.kjalnar.enabled = true
    P.Save(first)
    -- New clean profile (auto-named): trackers reset, Kjal/BA disabled, custom value gone HERE.
    local clean = P.New()
    check(clean and clean ~= first, "New() creates + auto-names a distinct clean profile")
    check(ShoyrUI.sv.trackers.kjalnar.enabled == false, "clean profile disables Kjalnar")
    check(ShoyrUI.sv.trackers.kjalnar.borderThickness ~= 8, "clean profile reset the custom border value")
    check(ShoyrUI.Router.Get("kjalnar") ~= nil, "clean profile keeps a live kjalnar instance (no duplicate-window crash)")
    -- Switch BACK — the customization must return intact.
    check(P.Load(first) == true, "switch back to the first profile")
    check(ShoyrUI.sv.trackers.kjalnar.borderThickness == 8, "first profile restores the custom value (config NOT lost to defaults)")
    check(ShoyrUI.sv.trackers.kjalnar.enabled == true, "first profile restores kjalnar enabled")
    check(ShoyrUI.Router.Get("kjalnar").config.borderThickness == 8, "live instance is bound to the restored config")
    -- Repeated switching must not crash on duplicate control names (env now enforces ESO's rule).
    check(P.Load(clean) == true and P.Load(first) == true, "repeated profile switches don't crash")
    -- GUARD: an empty/corrupt snapshot must never wipe live trackers.
    ShoyrUI.sv.profiles["Corrupt"] = {}
    local kref = ShoyrUI.sv.trackers.kjalnar
    check(P.Load("Corrupt") == false, "Load refuses an empty/corrupt snapshot")
    check(ShoyrUI.sv.trackers.kjalnar == kref, "live trackers untouched after a refused load (no wipe)")
end

-- D24: Bootstrap self-heal — an empty "Default" (the shape that wiped a user) is purged and the
-- CURRENT live setup is captured as "Profile 1" without ever wiping live trackers.
do
    local P = ShoyrUI.Profiles
    ShoyrUI.sv.profiles = { ["Default"] = {} }        -- corrupted state
    ShoyrUI.sv.activeProfile = "Default"
    check(ShoyrUI.sv.trackers.kjalnar ~= nil, "precondition: live builtins present")
    P.Bootstrap()
    check(ShoyrUI.sv.profiles["Default"] == nil, "Bootstrap purges the empty/corrupt snapshot")
    check(ShoyrUI.sv.profiles["Profile 1"] ~= nil, "Bootstrap captures the current setup as Profile 1")
    check(ShoyrUI.sv.activeProfile == "Profile 1", "Bootstrap makes Profile 1 active")
    check(P.ValidSnapshot(ShoyrUI.sv.profiles["Profile 1"]), "Profile 1 snapshot is valid (has trackers)")
    check(ShoyrUI.sv.trackers.kjalnar ~= nil, "Bootstrap never wiped live trackers")
end

-- D25: Delete is self-healing — hides/sweeps corrupt profiles, and deleting the active profile
-- always leaves a VALID active profile (never a silent no-op, never a wipe).
do
    local P = ShoyrUI.Profiles
    P.Save("Keep")
    ShoyrUI.sv.profiles["Junk"] = {}                       -- corrupt snapshot
    local names, hasJunk = P.List(), false
    for _, n in ipairs(names) do if n == "Junk" then hasJunk = true end end
    check(not hasJunk, "List() hides empty/corrupt profiles")
    P.Load("Keep")
    check(ShoyrUI.sv.activeProfile == "Keep", "switched to Keep")
    check(P.Delete("Keep") == true, "Delete active profile succeeds")
    check(ShoyrUI.sv.activeProfile ~= "Keep", "Delete switched away from the deleted profile")
    check(P.ValidSnapshot(ShoyrUI.sv.profiles[ShoyrUI.sv.activeProfile]),
        "active profile is valid after delete (no invalid-active dead end)")
    check(ShoyrUI.sv.profiles["Junk"] == nil, "Delete also swept the corrupt profile")
    check(ShoyrUI.sv.trackers.kjalnar ~= nil, "live trackers intact after delete")
end

-- D26: deleting the ACTIVE profile must not resurrect it (Load re-saving the outgoing profile was
-- re-creating the one just deleted — so it reappeared in the dropdown).
do
    local P = ShoyrUI.Profiles
    P.Save("Alpha"); P.Save("Beta")
    P.Load("Alpha")
    check(ShoyrUI.sv.activeProfile == "Alpha", "on Alpha")
    check(P.Delete("Alpha") == true, "delete active Alpha")
    check(ShoyrUI.sv.profiles["Alpha"] == nil, "deleted profile does NOT reappear (no resurrection)")
    check(ShoyrUI.sv.activeProfile ~= "Alpha" and P.ValidSnapshot(ShoyrUI.sv.profiles[ShoyrUI.sv.activeProfile]),
        "switched to a valid profile after deleting the active one")
    local names, hasAlpha = P.List(), false
    for _, n in ipairs(names) do if n == "Alpha" then hasAlpha = true end end
    check(not hasAlpha, "deleted profile is gone from List() (dropdown)")
end

-- D27: a DISABLED tracker must not render even when its tracked effect is active (route through
-- the real Router tick loop, not a direct t:Tick which doesn't gate on enabled).
do
    local id = ShoyrUI.CreateTracker(4801, "DisTest", "selfBuff", "uptime")
    local t = ShoyrUI.Router.Get(id)
    ShoyrUI.sv.global.unlocked = false
    t.config.enabled = false
    ShoyrUI.Router.Refresh()
    local rendered = false
    local realRender = t.Render
    t.Render = function(self, st) if st then rendered = true end; return realRender(self, st) end
    t.behavior:OnEffect(EFFECT_RESULT_GAINED, 0, 5, 1, 1)   -- effect now "up" (active state available)
    ShoyrUI.Router.EnsureTick()
    for _, fn in pairs(EVENT_MANAGER._updates) do pcall(fn) end
    check(not rendered, "a DISABLED tracker does NOT render when its effect is active")
    t.Render = realRender
    ShoyrUI.DeleteTracker(id)
end

-- ============================================================================
print(string.format("\n== RESULT: %d passed, %d failed ==", pass, fail))
os.exit(fail == 0 and 0 or 1)
