ShoyruBoundArmaments = {}
ShoyruBoundArmaments.name    = "ShoyruBoundArmaments"
ShoyruBoundArmaments.version = "1.1"

local BA  = ShoyruBoundArmaments
local WM  = WINDOW_MANAGER
-- LibAddonMenu2 global, NOT LibStub: LAM only OptionalDependsOn LibStub, so
-- LibStub("LibAddonMenu-2.0") only worked here because another addon's
-- bundled LibStub leaked the global.
local LAM = LibAddonMenu2

-- Bound Armaments stacks buff on the player. Verified via debug mode.
local BA_ABILITY_ID = 203447

-- ---------------------------------------------------------------------------
-- Defaults
-- ---------------------------------------------------------------------------

local DEFAULTS = {
    enabled         = true,
    debug           = false,

    -- Window position and size, saved as offset from GuiRoot center.
    x               = 0,
    y               = -260,
    width           = 220,
    height          = 56,

    -- Visibility behavior
    showWhenIdle    = true,   -- show window any time buff is active
                              -- (otherwise only show at/above threshold1)

    -- Threshold 1 — "build" alert (default 4 stacks)
    t1Stacks        = 4,
    t1Text          = "BUILDING",
    t1Color         = { r = 0.95, g = 0.83, b = 0.49, a = 1 }, -- ESO gold
    t1Sound         = "DUEL_INVITE_RECEIVED",
    t1PlaySound     = true,

    -- Threshold 2 — max stacks alert (default 8 stacks)
    t2Stacks        = 8,
    t2Text          = "MAX STACKS",
    t2Color         = { r = 0.91, g = 0.32, b = 0.32, a = 1 }, -- alert red
    t2Sound         = "DUEL_START",
    t2PlaySound     = true,

    -- Below-threshold color (1..t1-1 stacks) when showWhenIdle is on
    idleText        = "BOUND ARMAMENTS",
    idleColor       = { r = 0.85, g = 0.85, b = 0.85, a = 1 },

    -- Bar — fill color tracks the active threshold color; only the bg is configurable.
    barBgColor      = { r = 0, g = 0, b = 0, a = 0.75 },

    -- Border — thin black by default; reads cleanly against any HUD background.
    borderColor     = { r = 0, g = 0, b = 0, a = 1 },
    borderThickness = 2,

    -- Sound loudness: 1 = normal; higher stacks the sound for extra volume.
    soundVolume     = 1,

    -- Layout
    locked          = true,
}

-- Curated set of audible alert sounds — see memory: ABILITY_MAJOR_BUFF is too
-- quiet to use as a combat cue.
local SOUND_OPTIONS = {
    "DUEL_INVITE_RECEIVED",
    "DUEL_START",
    "NEW_NOTIFICATION",
    "ABILITY_ULTIMATE_READY",
    "GROUP_INVITE",
    "GENERAL_ALERT_ERROR",
}

local UPDATE_INTERVAL_MS  = 50
local TEST_TICK_INTERVAL  = 700
local TEST_CYCLE_MAX_PAD  = 1     -- hold on max stacks for an extra tick
local MIN_W, MIN_H        = 80, 28
local MAX_W, MAX_H        = 1200, 400

-- ---------------------------------------------------------------------------
-- Module state
-- ---------------------------------------------------------------------------

local alertWindow, iconTexture, iconBorder, stackCountLabel
local barBg, barFill, alertLabel, timerLabel
local updateRunning  = false
local currentState   = { stacks = 0, beginMs = nil, endMs = nil }
local lastReportedStacks = 0
local testMode       = nil  -- { stacks = N, until = ms } or nil

local function GetNowMs() return GetFrameTimeMilliseconds() end

local function Log(fmt, ...)
    if BA.sv and BA.sv.debug then
        d("[BA] " .. string.format(fmt, ...))
    end
end

-- ---------------------------------------------------------------------------
-- Display logic
-- ---------------------------------------------------------------------------

local function GetActiveStacks()
    if testMode then return testMode.stacks end
    return currentState.stacks
end

local function GetRemainingMs()
    if testMode then return 5000 end
    if not currentState.endMs then return 0 end
    local rem = currentState.endMs - GetNowMs()
    if rem < 0 then return 0 end
    return rem
end

local function GetDurationMs()
    if testMode then return 8000 end
    if currentState.beginMs and currentState.endMs then
        return currentState.endMs - currentState.beginMs
    end
    return 0
end

local function GetThresholdState(stacks)
    local sv = BA.sv
    if stacks >= sv.t2Stacks then return 2 end
    if stacks >= sv.t1Stacks then return 1 end
    return 0
end

local function GetLabelTextAndColor(stacks)
    local sv = BA.sv
    local state = GetThresholdState(stacks)
    if state == 2 then return sv.t2Text, sv.t2Color end
    if state == 1 then return sv.t1Text, sv.t1Color end
    return sv.idleText, sv.idleColor
end

local function ApplyLabelStyle()
    if not alertLabel or not alertWindow then return end
    local h = alertWindow:GetHeight()
    local w = alertWindow:GetWidth()
    local fontSize = math.max(12, math.floor(math.min(h * 0.40, w * 0.10)))
    local font = string.format("$(BOLD_FONT)|%d|soft-shadow-thick", fontSize)
    alertLabel:SetFont(font)
    timerLabel:SetFont(font)
    local stackFont = string.format("$(BOLD_FONT)|%d|outline", math.max(14, math.floor(h * 0.55)))
    stackCountLabel:SetFont(stackFont)
end

local function ApplyBorderStyle()
    if not iconBorder or not barBg then return end
    local c = BA.sv.borderColor
    local t = BA.sv.borderThickness
    -- SetEdgeTexture numeric args must be powers of two.
    if     t >= 8 then t = 8
    elseif t >= 4 then t = 4
    else                t = 2 end
    iconBorder:SetEdgeTexture(nil, t, t, t, 0)
    iconBorder:SetEdgeColor(c.r, c.g, c.b, c.a or 1)
    barBg:SetEdgeTexture(nil, t, t, t, 0)
    barBg:SetEdgeColor(c.r, c.g, c.b, c.a or 1)
end

local function RenderHidden()
    if alertWindow then alertWindow:SetHidden(true) end
end

local function RenderForStacks(stacks, remainingMs, durationMs)
    if not alertWindow then return end

    local sv = BA.sv
    local visible = stacks > 0 and (sv.showWhenIdle or stacks >= sv.t1Stacks)
    if not visible then
        alertWindow:SetHidden(true)
        return
    end
    alertWindow:SetHidden(false)

    local text, color = GetLabelTextAndColor(stacks)
    alertLabel:SetText(text)
    alertLabel:SetColor(color.r, color.g, color.b, color.a or 1)

    stackCountLabel:SetText(tostring(stacks))
    stackCountLabel:SetColor(color.r, color.g, color.b, color.a or 1)

    -- Bar fill — matches Kjalnar/Fossilize: fill color tracks the threshold
    -- label color, width drives from a single left anchor (see LayoutChildren).
    local pct = 0
    if durationMs and durationMs > 0 then
        pct = math.max(0, math.min(1, remainingMs / durationMs))
    end
    local barWidth = math.max(2, barBg:GetWidth() - 2)
    barFill:SetWidth(barWidth * pct)
    barFill:SetHidden(pct <= 0)
    barFill:SetColor(color.r, color.g, color.b, 0.95)
    barBg:SetCenterColor(sv.barBgColor.r, sv.barBgColor.g, sv.barBgColor.b, sv.barBgColor.a or 1)

    if remainingMs > 0 then
        timerLabel:SetText(string.format("%.1fs", remainingMs / 1000))
        timerLabel:SetColor(color.r, color.g, color.b, color.a or 1)
        timerLabel:SetHidden(false)
    else
        timerLabel:SetHidden(true)
    end
end

local function UpdateDisplay()
    local stacks = GetActiveStacks()
    if stacks <= 0 then RenderHidden() return end
    RenderForStacks(stacks, GetRemainingMs(), GetDurationMs())
end

-- ---------------------------------------------------------------------------
-- Threshold edge alerts (sound + only-on-rising-edge)
-- ---------------------------------------------------------------------------

-- ESO's PlaySound has no volume parameter; playing the same sound multiple
-- times in one frame sums amplitude, so soundVolume > 1 means louder.
local function PlaySoundAtVolume(key, fallback)
    local s = (key and SOUNDS[key]) or fallback
    if not s then return end
    local volume = math.max(1, math.floor((BA.sv and BA.sv.soundVolume) or 1))
    for _ = 1, volume do
        PlaySound(s)
    end
end

local function MaybeFireThresholdAlerts(prevStacks, newStacks)
    local sv = BA.sv
    if newStacks > prevStacks then
        if prevStacks < sv.t2Stacks and newStacks >= sv.t2Stacks and sv.t2PlaySound then
            PlaySoundAtVolume(sv.t2Sound, SOUNDS.DUEL_START)
        elseif prevStacks < sv.t1Stacks and newStacks >= sv.t1Stacks and sv.t1PlaySound then
            PlaySoundAtVolume(sv.t1Sound, SOUNDS.DUEL_INVITE_RECEIVED)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Update loop / test mode
-- ---------------------------------------------------------------------------

local function StopUpdateLoopIfIdle()
    if testMode then return end
    if currentState.stacks <= 0 then
        EVENT_MANAGER:UnregisterForUpdate(BA.name .. "_Update")
        updateRunning = false
    end
end

local function TickUpdate()
    UpdateDisplay()
    if not testMode and currentState.endMs and GetNowMs() >= currentState.endMs then
        currentState.stacks  = 0
        currentState.beginMs = nil
        currentState.endMs   = nil
        UpdateDisplay()
        StopUpdateLoopIfIdle()
    end
end

local function EnsureUpdateLoop()
    if updateRunning then return end
    updateRunning = true
    EVENT_MANAGER:RegisterForUpdate(BA.name .. "_Update", UPDATE_INTERVAL_MS, TickUpdate)
end

local function TestTick()
    if not testMode then return end
    local sv = BA.sv
    local maxStacks = math.max(sv.t2Stacks, sv.t1Stacks, 1)
    testMode.stacks = testMode.stacks + 1
    if testMode.stacks > maxStacks + TEST_CYCLE_MAX_PAD then
        testMode.stacks = 0
    end
    UpdateDisplay()
end

local function StartTestMode()
    testMode = { stacks = 0 }
    EnsureUpdateLoop()
    EVENT_MANAGER:RegisterForUpdate(BA.name .. "_Test", TEST_TICK_INTERVAL, TestTick)
    UpdateDisplay()
end

local function StopTestMode()
    testMode = nil
    EVENT_MANAGER:UnregisterForUpdate(BA.name .. "_Test")
    UpdateDisplay()
    StopUpdateLoopIfIdle()
end

-- ---------------------------------------------------------------------------
-- Effect handler
-- ---------------------------------------------------------------------------

local function RecordStackChange(stacks, beginMs, endMs)
    local prev = lastReportedStacks
    currentState.stacks  = stacks or 0
    currentState.beginMs = beginMs
    currentState.endMs   = endMs

    Log("stacks=%d (prev=%d) dur=%dms", stacks or 0, prev, (endMs and beginMs) and (endMs - beginMs) or 0)

    MaybeFireThresholdAlerts(prev, stacks or 0)
    lastReportedStacks = stacks or 0

    if currentState.stacks > 0 then
        EnsureUpdateLoop()
    end
    UpdateDisplay()
end

local function ClearBuff()
    Log("buff faded")
    lastReportedStacks   = 0
    currentState.stacks  = 0
    currentState.beginMs = nil
    currentState.endMs   = nil
    UpdateDisplay()
    StopUpdateLoopIfIdle()
end

local function OnEffectChanged(
    eventCode, changeType, effectSlot, effectName, unitTag,
    beginTime, endTime, stackCount, iconName, buffType,
    effectType, abilityType, statusEffectType, unitName,
    unitId, abilityId, sourceType)

    if not BA.sv or not BA.sv.enabled then return end

    -- Debug mode: log every player buff change so the user can discover the
    -- correct abilityId if the hardcoded one is wrong.
    if BA.sv.debug and unitTag == "player" then
        d(string.format("[BA debug] %s id=%d stacks=%s ch=%s",
            tostring(effectName), abilityId or 0, tostring(stackCount), tostring(changeType)))
    end

    if abilityId ~= BA_ABILITY_ID then return end
    if unitTag ~= "player" then return end

    if changeType == EFFECT_RESULT_FADED then
        ClearBuff()
        return
    end

    -- EVENT_EFFECT_CHANGED fires the moment the buff starts or refreshes, so
    -- treating "now" as the new begin time is accurate enough — and avoids
    -- depending on GetGameTimeSeconds which has moved around between patches.
    local beginMs, endMs
    if beginTime and endTime and endTime > beginTime then
        local nowMs = GetNowMs()
        beginMs = nowMs
        endMs   = nowMs + (endTime - beginTime) * 1000
    end

    RecordStackChange(stackCount, beginMs, endMs)
end

-- ---------------------------------------------------------------------------
-- UI
-- ---------------------------------------------------------------------------

local function SaveWindowPosition()
    if not alertWindow or not BA.sv then return end
    local cx, cy   = alertWindow:GetCenter()
    local gw, gh   = GuiRoot:GetWidth(), GuiRoot:GetHeight()
    BA.sv.x = cx - gw / 2
    BA.sv.y = cy - gh / 2
end

local function SaveWindowDimensions()
    if not alertWindow or not BA.sv then return end
    BA.sv.width  = alertWindow:GetWidth()
    BA.sv.height = alertWindow:GetHeight()
    ApplyLabelStyle()
end

local function SetWindowInteractive(interactive)
    if not alertWindow then return end
    alertWindow:SetMovable(interactive)
    alertWindow:SetMouseEnabled(interactive)
    alertWindow:SetResizeHandleSize(interactive and 12 or 0)
end

local function CreateUI()
    alertWindow = WM:CreateTopLevelWindow("ShoyruBoundArmamentsWindow")
    alertWindow:SetDimensions(BA.sv.width, BA.sv.height)
    alertWindow:SetClampedToScreen(true)
    alertWindow:SetDimensionConstraints(MIN_W, MIN_H, MAX_W, MAX_H)
    alertWindow:SetDrawTier(DT_HIGH)
    alertWindow:SetDrawLayer(DL_OVERLAY)
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, BA.sv.x, BA.sv.y)
    alertWindow:SetMovable(false)
    alertWindow:SetMouseEnabled(false)
    alertWindow:SetHidden(true)

    alertWindow:SetHandler("OnMoveStop", SaveWindowPosition)
    alertWindow:SetHandler("OnResizeStop", function()
        SaveWindowDimensions()
        SaveWindowPosition()
    end)

    -- Ability icon on the left.
    iconTexture = WM:CreateControl(nil, alertWindow, CT_TEXTURE)
    local iconPath = GetAbilityIcon and GetAbilityIcon(BA_ABILITY_ID)
    if iconPath and iconPath ~= "" then
        iconTexture:SetTexture(iconPath)
    end

    iconBorder = WM:CreateControl(nil, alertWindow, CT_BACKDROP)
    iconBorder:SetAnchor(TOPLEFT,     iconTexture, TOPLEFT,     0, 0)
    iconBorder:SetAnchor(BOTTOMRIGHT, iconTexture, BOTTOMRIGHT, 0, 0)
    iconBorder:SetCenterColor(0, 0, 0, 0)

    stackCountLabel = WM:CreateControl(nil, iconTexture, CT_LABEL)
    stackCountLabel:SetColor(1, 1, 1, 1)
    stackCountLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    stackCountLabel:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
    stackCountLabel:SetText("")

    barBg = WM:CreateControl(nil, alertWindow, CT_BACKDROP)
    barBg:SetCenterColor(0, 0, 0, 0.75)

    barFill = WM:CreateControl(nil, barBg, CT_TEXTURE)
    barFill:SetColor(0.85, 0.85, 0.85, 0.95)

    alertLabel = WM:CreateControl(nil, alertWindow, CT_LABEL)
    alertLabel:SetColor(1, 1, 1, 1)
    alertLabel:SetText("BOUND ARMAMENTS")

    timerLabel = WM:CreateControl(nil, alertWindow, CT_LABEL)
    timerLabel:SetColor(1, 1, 1, 1)
    timerLabel:SetText("")
    timerLabel:SetHidden(true)
end

local function LayoutChildren()
    if not alertWindow then return end
    local h = alertWindow:GetHeight()
    local w = alertWindow:GetWidth()
    local iconSize = h
    local pad      = 4

    iconTexture:ClearAnchors()
    iconTexture:SetAnchor(LEFT, alertWindow, LEFT, 0, 0)
    iconTexture:SetDimensions(iconSize, iconSize)

    stackCountLabel:ClearAnchors()
    stackCountLabel:SetAnchor(BOTTOMRIGHT, iconTexture, BOTTOMRIGHT, -2, -2)
    stackCountLabel:SetDimensions(iconSize - 4, iconSize - 4)

    local barX     = iconSize + pad
    local barW     = math.max(20, w - barX)
    local barH     = math.max(8, math.floor(h * 0.35))
    barBg:ClearAnchors()
    barBg:SetAnchor(BOTTOMLEFT, alertWindow, BOTTOMLEFT, barX, 0)
    barBg:SetDimensions(barW, barH)

    -- Left-anchored only (top-left + bottom-left) so width drives shrinkage,
    -- matching Kjalnar/Fossilize. 1px inset gives a thin visible bar border.
    barFill:ClearAnchors()
    barFill:SetAnchor(TOPLEFT,    barBg, TOPLEFT,    1,  1)
    barFill:SetAnchor(BOTTOMLEFT, barBg, BOTTOMLEFT, 1, -1)

    alertLabel:ClearAnchors()
    alertLabel:SetAnchor(TOPLEFT,     alertWindow, TOPLEFT,     barX, 0)
    alertLabel:SetAnchor(BOTTOMRIGHT, barBg,       TOPRIGHT,    0,    -2)
    alertLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    alertLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)

    timerLabel:ClearAnchors()
    timerLabel:SetAnchor(RIGHT, barBg, RIGHT, -4, 0)
    timerLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    timerLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)

    ApplyLabelStyle()
    ApplyBorderStyle()
end

-- ---------------------------------------------------------------------------
-- LAM panel
-- ---------------------------------------------------------------------------

local function colorGet(field)
    return function()
        local c = BA.sv[field]
        return c.r, c.g, c.b, c.a or 1
    end
end
local function colorSet(field)
    return function(r, g, b, a)
        local c = BA.sv[field]
        c.r, c.g, c.b, c.a = r, g, b, a
        UpdateDisplay()
        ApplyBorderStyle()
    end
end

local function BuildSettings()
    local panelData = {
        type                = "panel",
        name                = "Shoyru's Bound Armaments",
        displayName         = "Shoyru's Bound Armaments",
        author              = "Shoyru",
        version             = BA.version,
        slashCommand        = "/boundarmaments",
        registerForRefresh  = true,
        registerForDefaults = true,
    }

    local options = {
        {
            type = "description",
            text = "Tracks the Bound Armaments stack buff on you (abilityId 203447). Fires a sound + label color at the first threshold (default 4 stacks) and again at max (default 8 stacks). The bar shows time remaining on the buff; the icon overlays the current stack count. Unlock under Layout to drag/resize — that also previews cycling stack counts so you can tune colors and thresholds without combat.",
        },
        {
            type    = "checkbox",
            name    = "Enabled",
            getFunc = function() return BA.sv.enabled end,
            setFunc = function(v) BA.sv.enabled = v end,
            width   = "full",
        },

        -- Idle label
        { type = "header", name = "Idle (below first threshold)" },
        { type = "editbox", name = "Label text",
          getFunc = function() return BA.sv.idleText end,
          setFunc = function(v) BA.sv.idleText = v; UpdateDisplay() end },
        { type = "colorpicker", name = "Label color",
          getFunc = colorGet("idleColor"), setFunc = colorSet("idleColor") },

        -- Threshold 1
        { type = "header", name = "Threshold 1 (build)" },
        { type = "slider", name = "Stacks", min = 1, max = 20, step = 1,
          getFunc = function() return BA.sv.t1Stacks end,
          setFunc = function(v) BA.sv.t1Stacks = v; UpdateDisplay() end,
          width   = "full" },
        { type = "editbox", name = "Label text",
          getFunc = function() return BA.sv.t1Text end,
          setFunc = function(v) BA.sv.t1Text = v; UpdateDisplay() end },
        { type = "colorpicker", name = "Label color",
          getFunc = colorGet("t1Color"), setFunc = colorSet("t1Color") },
        { type = "checkbox", name = "Play sound at this threshold",
          getFunc = function() return BA.sv.t1PlaySound end,
          setFunc = function(v) BA.sv.t1PlaySound = v end,
          width   = "half" },
        { type = "dropdown", name = "Sound",
          choices = SOUND_OPTIONS,
          getFunc = function() return BA.sv.t1Sound end,
          setFunc = function(v) BA.sv.t1Sound = v; PlaySoundAtVolume(v) end,
          width   = "half" },

        -- Threshold 2
        { type = "header", name = "Threshold 2 (max stacks)" },
        { type = "slider", name = "Stacks", min = 1, max = 20, step = 1,
          getFunc = function() return BA.sv.t2Stacks end,
          setFunc = function(v) BA.sv.t2Stacks = v; UpdateDisplay() end,
          width   = "full" },
        { type = "editbox", name = "Label text",
          getFunc = function() return BA.sv.t2Text end,
          setFunc = function(v) BA.sv.t2Text = v; UpdateDisplay() end },
        { type = "colorpicker", name = "Label color",
          getFunc = colorGet("t2Color"), setFunc = colorSet("t2Color") },
        { type = "checkbox", name = "Play sound at this threshold",
          getFunc = function() return BA.sv.t2PlaySound end,
          setFunc = function(v) BA.sv.t2PlaySound = v end,
          width   = "half" },
        { type = "dropdown", name = "Sound",
          choices = SOUND_OPTIONS,
          getFunc = function() return BA.sv.t2Sound end,
          setFunc = function(v) BA.sv.t2Sound = v; PlaySoundAtVolume(v) end,
          width   = "half" },

        -- Sound
        { type = "header", name = "Sound" },
        { type = "slider", name = "Alert loudness",
          tooltip = "Applies to both threshold sounds. 1 is normal volume; higher values layer the sound to make it louder. Previews with the threshold 1 sound when adjusted. ESO can't play sounds quieter than normal — lower Audio > Interface Sounds for that.",
          min = 1, max = 5, step = 1,
          getFunc = function() return BA.sv.soundVolume or 1 end,
          setFunc = function(v) BA.sv.soundVolume = v; PlaySoundAtVolume(BA.sv.t1Sound, SOUNDS.DUEL_INVITE_RECEIVED) end,
          width   = "full" },

        -- Bar / Border. Bar fill color tracks the active threshold color
        -- (same pattern as Kjalnar/Fossilize), so there's no separate slider.
        { type = "header", name = "Bar & Border" },
        { type = "colorpicker", name = "Bar background color",
          getFunc = colorGet("barBgColor"), setFunc = colorSet("barBgColor") },
        { type = "colorpicker", name = "Border color",
          getFunc = colorGet("borderColor"), setFunc = colorSet("borderColor") },
        { type = "slider", name = "Border thickness", min = 2, max = 8, step = 2,
          getFunc = function() return BA.sv.borderThickness end,
          setFunc = function(v) BA.sv.borderThickness = v; ApplyBorderStyle() end,
          width   = "full" },

        -- Layout (near the bottom — preview/unlock here matches the other Shoyru addons)
        { type = "header", name = "Layout" },
        {
            type    = "checkbox",
            name    = "Unlock (move + resize, force visible for preview)",
            getFunc = function() return not BA.sv.locked end,
            setFunc = function(v)
                BA.sv.locked = not v
                SetWindowInteractive(v)
                if v then
                    StartTestMode()
                else
                    StopTestMode()
                end
            end,
            width   = "full",
        },
        {
            type    = "button",
            name    = "Reset position",
            func    = function()
                BA.sv.x, BA.sv.y = 0, -260
                BA.sv.width, BA.sv.height = 220, 56
                alertWindow:ClearAnchors()
                alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, BA.sv.x, BA.sv.y)
                alertWindow:SetDimensions(BA.sv.width, BA.sv.height)
                LayoutChildren()
            end,
            width   = "half",
        },
        {
            type    = "checkbox",
            name    = "Show window any time buff is active",
            tooltip = "If off, the window only appears once you cross the first threshold.",
            getFunc = function() return BA.sv.showWhenIdle end,
            setFunc = function(v) BA.sv.showWhenIdle = v; UpdateDisplay() end,
            width   = "half",
        },

        -- Debug
        { type = "header", name = "Debug" },
        { type = "checkbox", name = "Debug mode (log player buffs to chat)",
          tooltip = "Logs every effect change on the player. Use this to find the right abilityId if 203447 isn't right for the current patch.",
          getFunc = function() return BA.sv.debug end,
          setFunc = function(v) BA.sv.debug = v; BA.UpdateDebugListener() end,
          width   = "full" },

        -- Reset
        { type = "header", name = "Reset" },
        { type = "button", name = "Reset all settings to defaults",
          warning = "Wipes every setting in this addon's saved variables.",
          isDangerous = true,
          func    = function()
              for k, v in pairs(DEFAULTS) do
                  if type(v) == "table" then
                      BA.sv[k] = ZO_DeepTableCopy(v)
                  else
                      BA.sv[k] = v
                  end
              end
              alertWindow:ClearAnchors()
              alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, BA.sv.x, BA.sv.y)
              alertWindow:SetDimensions(BA.sv.width, BA.sv.height)
              LayoutChildren()
              UpdateDisplay()
          end,
          width   = "full" },
    }

    LAM:RegisterAddonPanel("ShoyruBoundArmamentsPanel", panelData)
    LAM:RegisterOptionControls("ShoyruBoundArmamentsPanel", options)
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------

local function RegisterEvents()
    EVENT_MANAGER:RegisterForEvent(BA.name, EVENT_EFFECT_CHANGED, OnEffectChanged)
    EVENT_MANAGER:AddFilterForEvent(BA.name, EVENT_EFFECT_CHANGED,
        REGISTER_FILTER_ABILITY_ID, BA_ABILITY_ID,
        REGISTER_FILTER_UNIT_TAG, "player")
end

-- Unfiltered listener used in debug mode to discover the right abilityId.
local debugListenerActive = false
function BA.UpdateDebugListener()
    if BA.sv and BA.sv.debug and not debugListenerActive then
        EVENT_MANAGER:RegisterForEvent(BA.name .. "_DebugAll", EVENT_EFFECT_CHANGED,
            function(_, _, _, en, ut, _, _, sc, _, _, _, _, _, _, _, aid)
                if ut == "player" and sc and sc > 0 then
                    d(string.format("[BA debug-all] %s id=%d stacks=%d", tostring(en), aid or 0, sc))
                end
            end)
        EVENT_MANAGER:AddFilterForEvent(BA.name .. "_DebugAll", EVENT_EFFECT_CHANGED,
            REGISTER_FILTER_UNIT_TAG, "player")
        debugListenerActive = true
    elseif (not BA.sv or not BA.sv.debug) and debugListenerActive then
        EVENT_MANAGER:UnregisterForEvent(BA.name .. "_DebugAll", EVENT_EFFECT_CHANGED)
        debugListenerActive = false
    end
end

-- One-shot migration: original v1.0 shipped with a gold border default. We
-- now default to thin black. If the user is still on the exact old default,
-- swap them to black. Any user-customized border is preserved.
local function MigrateOldGoldBorder()
    local b = BA.sv and BA.sv.borderColor
    if not b then return end
    if b.r == 0.95 and b.g == 0.83 and b.b == 0.49 then
        BA.sv.borderColor = ZO_DeepTableCopy(DEFAULTS.borderColor)
    end
end

local function OnAddonLoaded(event, addonName)
    if addonName ~= BA.name then return end
    EVENT_MANAGER:UnregisterForEvent(BA.name, EVENT_ADD_ON_LOADED)

    BA.sv = ZO_SavedVars:NewAccountWide("ShoyruBoundArmamentsSavedVariables", 1, nil, DEFAULTS)
    MigrateOldGoldBorder()

    CreateUI()
    LayoutChildren()
    BuildSettings()
    RegisterEvents()
    BA.UpdateDebugListener()
end

EVENT_MANAGER:RegisterForEvent(BA.name, EVENT_ADD_ON_LOADED, OnAddonLoaded)
