ShoyruCombatReticle = {}
ShoyruCombatReticle.name    = "ShoyruCombatReticle"
ShoyruCombatReticle.version = "1.2"

local SC  = ShoyruCombatReticle
local WM  = WINDOW_MANAGER
-- Modern LibAddonMenu-2.0 exposes the global `LibAddonMenu2`; LibStub was deprecated and newer
-- LAM builds don't register it (calling LibStub() then crashed even when LAM was installed).
local LAM = LibAddonMenu2 or (LibStub and LibStub("LibAddonMenu-2.0"))

-- ---------------------------------------------------------------------------
-- Hitmarker sound + damage-result tables
-- ---------------------------------------------------------------------------

-- ESO can't import custom audio, so these are the game's own built-in sounds.
-- "NONE" is handled specially (no sound).
local SOUND_CHOICES = {
    "NONE",
    "ACHIEVEMENT_AWARDED",
    "DEATH_RECAP_KILLING_BLOW_SHOWN",
    "JUSTICE_NOW_KOS",
    "DUEL_WON",
    "GROUP_FINDER_ALERT",
    "LEVEL_UP",
    "ABILITY_MORPH_PURCHASE",
    "TELVAR_GAINED",
    "SKILL_LINE_LEVELED_UP",
}

-- Which combat results count as "the player landed damage" (used by the
-- all-damage trigger). CRIT_RESULTS is the subset that is a critical hit.
local DAMAGE_RESULTS = {
    [ACTION_RESULT_DAMAGE]            = true,
    [ACTION_RESULT_CRITICAL_DAMAGE]   = true,
    [ACTION_RESULT_DOT_TICK]          = true,
    [ACTION_RESULT_DOT_TICK_CRITICAL] = true,
    [ACTION_RESULT_DAMAGE_SHIELDED]   = true,
    [ACTION_RESULT_BLOCKED_DAMAGE]    = true,
}
local CRIT_RESULTS = {
    [ACTION_RESULT_CRITICAL_DAMAGE]   = true,
    [ACTION_RESULT_DOT_TICK_CRITICAL] = true,
}

-- ---------------------------------------------------------------------------
-- Defaults
-- ---------------------------------------------------------------------------

local DEFAULT_PROFILE = {
    style              = "lines_dot",     -- "lines" | "dot" | "lines_dot"

    -- Lines
    lineLength         = 8,
    lineThickness      = 2,
    lineGap            = 4,
    lineColor          = { r = 1, g = 1, b = 1, a = 1 },

    -- Outline (drawn as a slightly-larger colored rect behind each fill)
    outlineEnabled     = true,
    outlineThickness   = 1,
    outlineColor       = { r = 0, g = 0, b = 0, a = 1 },

    -- Center dot
    dotShape           = "circle",        -- "circle" | "square"
    dotSize            = 2,
    dotColor           = { r = 1, g = 1, b = 1, a = 1 },
    dotUseOutline      = true,

    -- Visibility
    hideOnMenus        = true,
    hideOnDeath        = true,
    hideInNonCombat    = false,

    -- ---------- Hitmarker ----------
    hmEnabled          = false,
    hmStyle            = "cross",    -- "cross" (adjustable +) | "marks" (X texture)
    hmTrigger          = "crit",     -- "crit" (crits only) | "all" (all damage)

    -- Cross-style geometry (adjustable + shape drawn from rects)
    hmSize             = 10,         -- arm length
    hmThickness        = 3,          -- arm thickness
    hmGap              = 5,          -- gap from center
    hmOutline          = true,       -- outline behind arms (uses crosshair outline color)

    -- Marks-style geometry (X hitmarker.dds texture)
    hmTextureSize      = 48,

    -- Colors
    hmColor            = { r = 1, g = 1, b = 1, a = 1 },
    hmCritDistinct     = true,       -- use a separate color when the hit was a crit
    hmCritColor        = { r = 1, g = 0.85, b = 0.1, a = 1 },

    -- Feel
    hmDuration         = 250,        -- ms the marker holds before fading
    hmThrottleMs       = 0,          -- min gap between markers (0 = every hit)

    -- Sound
    hmSound            = "NONE",     -- name from SOUND_CHOICES, or "NONE"
    hmVolume           = 1,          -- layered plays (1..5) to make it louder/fuller
}

local DEFAULTS = {
    profiles      = { ["Default"] = ZO_DeepTableCopy(DEFAULT_PROFILE) },
    activeProfile = "Default",
    testMode      = false,
    pendingName   = "",
}

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function MergeDefaults(target, source)
    for k, v in pairs(source) do
        if type(v) == "table" then
            if type(target[k]) ~= "table" then target[k] = {} end
            MergeDefaults(target[k], v)
        elseif target[k] == nil then
            target[k] = v
        end
    end
end

function SC:GetActiveProfile()
    local sv = self.sv
    local p  = sv.profiles[sv.activeProfile]
    if not p then
        -- Active profile was deleted externally; recreate Default.
        sv.profiles["Default"] = ZO_DeepTableCopy(DEFAULT_PROFILE)
        sv.activeProfile = "Default"
        p = sv.profiles["Default"]
    end
    MergeDefaults(p, DEFAULT_PROFILE)
    return p
end

function SC:GetProfileNames()
    local names = {}
    for name in pairs(self.sv.profiles) do
        table.insert(names, name)
    end
    table.sort(names)
    return names
end

-- ---------------------------------------------------------------------------
-- Crosshair rendering
-- ---------------------------------------------------------------------------

local function MakeRect(parent, name, drawLayer)
    local t = WM:CreateControl(name, parent, CT_TEXTURE)
    t:SetDrawLayer(drawLayer or DL_OVERLAY)
    return t
end

function SC:BuildUI()
    if self.container then return end

    local c = WM:CreateTopLevelWindow("ShoyruCombatReticleContainer")
    c:SetClampedToScreen(false)
    c:SetMouseEnabled(false)
    c:SetMovable(false)
    c:SetDrawTier(DT_HIGH)
    c:SetDrawLayer(DL_OVERLAY)
    c:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0)
    c:SetDimensions(256, 256)
    self.container = c

    self.lines = {}
    for _, dir in ipairs({ "top", "bottom", "left", "right" }) do
        self.lines[dir] = {
            outline = MakeRect(c, "ShoyruCH_"..dir.."_outline", DL_BACKGROUND),
            fill    = MakeRect(c, "ShoyruCH_"..dir.."_fill",    DL_OVERLAY),
        }
    end

    self.dot = {
        outline = MakeRect(c, "ShoyruCH_dot_outline", DL_BACKGROUND),
        fill    = MakeRect(c, "ShoyruCH_dot_fill",    DL_OVERLAY),
    }

    self:BuildHitmarker()
end

-- ---------------------------------------------------------------------------
-- Hitmarker rendering
-- ---------------------------------------------------------------------------

function SC:BuildHitmarker()
    -- Separate top-level window so the marker's pop/fade animation is fully
    -- independent of the always-on crosshair.
    local h = WM:CreateTopLevelWindow("ShoyruCombatReticleHitmarker")
    h:SetClampedToScreen(false)
    h:SetMouseEnabled(false)
    h:SetMovable(false)
    h:SetDrawTier(DT_HIGH)
    h:SetDrawLayer(DL_OVERLAY)
    h:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0)
    h:SetDimensions(256, 256)
    h:SetAlpha(0)
    self.hmTLW = h

    self.hm = { arms = {} }

    -- "cross" style: four rects (with optional outline) forming a + .
    for _, dir in ipairs({ "top", "bottom", "left", "right" }) do
        self.hm.arms[dir] = {
            outline = MakeRect(h, "ShoyruHM_"..dir.."_outline", DL_BACKGROUND),
            fill    = MakeRect(h, "ShoyruHM_"..dir.."_fill",    DL_OVERLAY),
        }
    end

    -- "marks" style: the X hitmarker texture (tintable + scalable).
    local m = MakeRect(h, "ShoyruHM_marks", DL_OVERLAY)
    m:SetTexture("ShoyruCombatReticle/hitmarker.dds")
    m:SetAnchor(CENTER, h, CENTER, 0, 0)
    self.hm.marks = m

    self:BuildHitmarkerAnim()
end

-- Rebuilt whenever the hold duration changes so the fade timing tracks it.
function SC:BuildHitmarkerAnim()
    local p  = self:GetActiveProfile()
    local tl = ANIMATION_MANAGER:CreateTimeline()

    local aIn = tl:InsertAnimation(ANIMATION_ALPHA, self.hmTLW, 0)
    aIn:SetAlphaValues(0, 1); aIn:SetDuration(40)

    local sc = tl:InsertAnimation(ANIMATION_SCALE, self.hmTLW, 0)
    sc:SetScaleValues(1.5, 1.0); sc:SetDuration(120)

    local aOut = tl:InsertAnimation(ANIMATION_ALPHA, self.hmTLW, p.hmDuration or 250)
    aOut:SetAlphaValues(1, 0); aOut:SetDuration(180)

    self.hmTimeline = tl
end

-- Tint every visible marker piece. Called on redraw (base color) and again on
-- each trigger so crits can flash their own color.
function SC:ApplyHitmarkerColor(c)
    self.hm.marks:SetColor(c.r, c.g, c.b, c.a or 1)
    for _, arm in pairs(self.hm.arms) do
        arm.fill:SetColor(c.r, c.g, c.b, c.a or 1)
    end
end

function SC:RedrawHitmarker()
    if not self.hmTLW then return end
    local p = self:GetActiveProfile()

    local isCross = (p.hmStyle == "cross")
    local oc = p.outlineColor
    local OT = (p.hmOutline and p.outlineEnabled and p.outlineThickness > 0)
               and p.outlineThickness or 0

    -- Marks (X texture)
    self.hm.marks:ClearAnchors()
    self.hm.marks:SetDimensions(p.hmTextureSize, p.hmTextureSize)
    self.hm.marks:SetAnchor(CENTER, self.hmTLW, CENTER, 0, 0)
    self.hm.marks:SetHidden(isCross)

    -- Cross (+ rects)
    local L, T, G = p.hmSize, p.hmThickness, p.hmGap
    local armOffset = G + L / 2

    local function placeVert(pair, yOffset)
        pair.outline:SetDimensions(T + 2*OT, L + 2*OT)
        pair.outline:SetColor(oc.r, oc.g, oc.b, oc.a or 1)
        pair.outline:ClearAnchors()
        pair.outline:SetAnchor(CENTER, self.hmTLW, CENTER, 0, yOffset)
        pair.outline:SetHidden(not (isCross and OT > 0))

        pair.fill:SetDimensions(T, L)
        pair.fill:ClearAnchors()
        pair.fill:SetAnchor(CENTER, self.hmTLW, CENTER, 0, yOffset)
        pair.fill:SetHidden(not isCross)
    end

    local function placeHorz(pair, xOffset)
        pair.outline:SetDimensions(L + 2*OT, T + 2*OT)
        pair.outline:SetColor(oc.r, oc.g, oc.b, oc.a or 1)
        pair.outline:ClearAnchors()
        pair.outline:SetAnchor(CENTER, self.hmTLW, CENTER, xOffset, 0)
        pair.outline:SetHidden(not (isCross and OT > 0))

        pair.fill:SetDimensions(L, T)
        pair.fill:ClearAnchors()
        pair.fill:SetAnchor(CENTER, self.hmTLW, CENTER, xOffset, 0)
        pair.fill:SetHidden(not isCross)
    end

    placeVert(self.hm.arms.top,    -armOffset)
    placeVert(self.hm.arms.bottom,  armOffset)
    placeHorz(self.hm.arms.left,   -armOffset)
    placeHorz(self.hm.arms.right,   armOffset)

    -- Rest tint = normal color (so live tests show your color choices).
    self:ApplyHitmarkerColor(p.hmColor)
end

-- ---------------------------------------------------------------------------
-- Hitmarker trigger + combat hookup
-- ---------------------------------------------------------------------------

local function IsGameplayScene()
    local scene = SCENE_MANAGER and SCENE_MANAGER:GetCurrentScene()
    local name  = scene and scene:GetName() or ""
    return name == "hud" or name == "hudui"
end

-- Hit sound. Fires immediately on every call so each hitmarker gets its own
-- sound, and RESETS on a new hit: any still-pending layered plays from the
-- previous hitmarker are cancelled so rapid successive hits don't pile up /
-- echo — it always sounds like one clean hit per marker.
local SOUND_STACK = "ShoyruCombatReticle_SoundStack"
function SC:PlayHitSound()
    EVENT_MANAGER:UnregisterForUpdate(SOUND_STACK)   -- reset the previous hit's tail

    local p = self:GetActiveProfile()
    local name = p.hmSound
    if not name or name == "NONE" then return end
    local id = SOUNDS and SOUNDS[name]
    if not id then return end

    PlaySound(id)   -- always at least one play, right now

    -- ESO has no per-sound volume; stacking staggered plays reads louder/fuller.
    local remaining = (p.hmVolume or 1) - 1
    if remaining > 0 then
        local done = 0
        EVENT_MANAGER:RegisterForUpdate(SOUND_STACK, 12, function()
            PlaySound(id)
            done = done + 1
            if done >= remaining then
                EVENT_MANAGER:UnregisterForUpdate(SOUND_STACK)
            end
        end)
    end
end

function SC:TriggerHitmarker(isCrit, force)
    if not self.hmTLW then return end
    local p = self:GetActiveProfile()

    if not force then
        if not p.hmEnabled then return end
        if p.hmThrottleMs > 0 then
            local now = GetGameTimeMilliseconds()
            if now - (self.hmLast or 0) < p.hmThrottleMs then return end
            self.hmLast = now
        end
        -- Don't flash markers while the player is buried in a menu.
        if p.hideOnMenus and not IsGameplayScene() then return end
    end

    local color = (isCrit and p.hmCritDistinct) and p.hmCritColor or p.hmColor
    self:ApplyHitmarkerColor(color)

    self.hmTimeline:Stop()
    self.hmTLW:SetAlpha(0)
    self.hmTimeline:PlayFromStart()

    self:PlayHitSound()
end

function SC:OnHit(result)
    local p = self:GetActiveProfile()
    local isCrit
    if p.hmTrigger == "crit" then
        isCrit = true   -- event filter already guarantees a crit
    else
        if not DAMAGE_RESULTS[result] then return end
        isCrit = CRIT_RESULTS[result] or false
    end
    self:TriggerHitmarker(isCrit, false)
end

-- (Re)register the combat hook to match the current enable/trigger settings.
function SC:UpdateCombatRegistration()
    local ns = self.name .. "_HM"
    EVENT_MANAGER:UnregisterForEvent(ns, EVENT_COMBAT_EVENT)

    local p = self:GetActiveProfile()
    if not p.hmEnabled then return end

    EVENT_MANAGER:RegisterForEvent(ns, EVENT_COMBAT_EVENT, function(_, result)
        self:OnHit(result)
    end)

    if p.hmTrigger == "crit" then
        EVENT_MANAGER:AddFilterForEvent(ns, EVENT_COMBAT_EVENT,
            REGISTER_FILTER_COMBAT_RESULT, ACTION_RESULT_CRITICAL_DAMAGE,
            REGISTER_FILTER_SOURCE_COMBAT_UNIT_TYPE, COMBAT_UNIT_TYPE_PLAYER,
            REGISTER_FILTER_IS_ERROR, false)
    else
        EVENT_MANAGER:AddFilterForEvent(ns, EVENT_COMBAT_EVENT,
            REGISTER_FILTER_SOURCE_COMBAT_UNIT_TYPE, COMBAT_UNIT_TYPE_PLAYER,
            REGISTER_FILTER_IS_ERROR, false)
    end
end

local function ApplyRect(ctrl, w, h, color, hidden)
    ctrl:SetDimensions(w, h)
    ctrl:SetColor(color.r, color.g, color.b, color.a or 1)
    ctrl:ClearAnchors()
end

function SC:Redraw()
    if not self.container then return end
    local p = self:GetActiveProfile()

    local showLines = (p.style == "lines" or p.style == "lines_dot")
    local showDot   = (p.style == "dot"   or p.style == "lines_dot")

    local L  = p.lineLength
    local T  = p.lineThickness
    local G  = p.lineGap
    local OT = (p.outlineEnabled and p.outlineThickness > 0) and p.outlineThickness or 0

    local lc = p.lineColor
    local oc = p.outlineColor

    -- Each arm of the cross: position the center of the line at distance
    -- (G + L/2) from screen center along its axis.
    local armOffset = G + L / 2

    -- Vertical lines (top / bottom): width = T, height = L
    local function placeVert(pair, yOffset)
        ApplyRect(pair.outline, T + 2*OT, L + 2*OT, oc)
        pair.outline:SetAnchor(CENTER, self.container, CENTER, 0, yOffset)
        pair.outline:SetHidden(not (showLines and OT > 0))

        ApplyRect(pair.fill, T, L, lc)
        pair.fill:SetAnchor(CENTER, self.container, CENTER, 0, yOffset)
        pair.fill:SetHidden(not showLines)
    end

    -- Horizontal lines (left / right): width = L, height = T
    local function placeHorz(pair, xOffset)
        ApplyRect(pair.outline, L + 2*OT, T + 2*OT, oc)
        pair.outline:SetAnchor(CENTER, self.container, CENTER, xOffset, 0)
        pair.outline:SetHidden(not (showLines and OT > 0))

        ApplyRect(pair.fill, L, T, lc)
        pair.fill:SetAnchor(CENTER, self.container, CENTER, xOffset, 0)
        pair.fill:SetHidden(not showLines)
    end

    placeVert(self.lines.top,    -armOffset)
    placeVert(self.lines.bottom,  armOffset)
    placeHorz(self.lines.left,   -armOffset)
    placeHorz(self.lines.right,   armOffset)

    -- Center dot. CT_TEXTURE renders as a rect by default; tinting a circular
    -- DDS gives a real circle when "circle" shape is selected.
    local dc       = p.dotColor
    local ds       = p.dotSize
    local dotOT    = (p.dotUseOutline and OT > 0) and OT or 0
    local dotTex   = (p.dotShape == "circle") and "ShoyruCombatReticle/circle.dds" or ""

    self.dot.outline:SetTexture(dotTex)
    ApplyRect(self.dot.outline, ds + 2*dotOT, ds + 2*dotOT, oc)
    self.dot.outline:SetAnchor(CENTER, self.container, CENTER, 0, 0)
    self.dot.outline:SetHidden(not (showDot and dotOT > 0))

    self.dot.fill:SetTexture(dotTex)
    ApplyRect(self.dot.fill, ds, ds, dc)
    self.dot.fill:SetAnchor(CENTER, self.container, CENTER, 0, 0)
    self.dot.fill:SetHidden(not showDot)
end

-- ---------------------------------------------------------------------------
-- Visibility
-- ---------------------------------------------------------------------------

function SC:UpdateVisibility()
    if not self.container then return end
    local p = self:GetActiveProfile()

    -- Test mode and the open settings panel both force the crosshair visible
    -- so the user can see edits land in real time.
    if self.sv.testMode or self.settingsOpen then
        self.container:SetHidden(false)
        return
    end

    local hidden = false

    if p.hideOnMenus then
        local scene = SCENE_MANAGER and SCENE_MANAGER:GetCurrentScene()
        local name  = scene and scene:GetName() or ""
        if name ~= "hud" and name ~= "hudui" then
            hidden = true
        end
    end

    if not hidden and p.hideOnDeath and IsUnitDead("player") then
        hidden = true
    end

    if not hidden and p.hideInNonCombat and not IsUnitInCombat("player") then
        hidden = true
    end

    self.container:SetHidden(hidden)
end

-- ---------------------------------------------------------------------------
-- Profile operations
-- ---------------------------------------------------------------------------

local function SanitizeName(name)
    if type(name) ~= "string" then return "" end
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    if #name > 32 then name = name:sub(1, 32) end
    return name
end

function SC:SwitchProfile(name)
    if not self.sv.profiles[name] then return end
    self.sv.activeProfile = name
    self:Redraw()
    self:BuildHitmarkerAnim()
    self:RedrawHitmarker()
    self:UpdateCombatRegistration()
    self:UpdateVisibility()
end

function SC:SaveAsNew(name)
    name = SanitizeName(name)
    if name == "" or self.sv.profiles[name] then return false end
    self.sv.profiles[name] = ZO_DeepTableCopy(self:GetActiveProfile())
    self.sv.activeProfile  = name
    self:RefreshProfileDropdown()
    self:Redraw()
    return true
end

function SC:RenameActive(name)
    name = SanitizeName(name)
    local old = self.sv.activeProfile
    if name == "" or name == old or self.sv.profiles[name] then return false end
    self.sv.profiles[name] = self.sv.profiles[old]
    self.sv.profiles[old]  = nil
    self.sv.activeProfile  = name
    self:RefreshProfileDropdown()
    return true
end

function SC:DeleteActive()
    local name = self.sv.activeProfile
    if name == "Default" then
        -- Reset Default instead of deleting it so there's always one profile.
        self.sv.profiles["Default"] = ZO_DeepTableCopy(DEFAULT_PROFILE)
    else
        self.sv.profiles[name] = nil
        self.sv.activeProfile = "Default"
        if not self.sv.profiles["Default"] then
            self.sv.profiles["Default"] = ZO_DeepTableCopy(DEFAULT_PROFILE)
        end
    end
    self:RefreshProfileDropdown()
    self:Redraw()
    self:BuildHitmarkerAnim()
    self:RedrawHitmarker()
    self:UpdateCombatRegistration()
end

function SC:ResetActive()
    self.sv.profiles[self.sv.activeProfile] = ZO_DeepTableCopy(DEFAULT_PROFILE)
    self:Redraw()
    self:BuildHitmarkerAnim()
    self:RedrawHitmarker()
    self:UpdateCombatRegistration()
end

function SC:RefreshProfileDropdown()
    local widget = _G["ShoyruCombatReticle_ProfileDropdown"]
    if widget and widget.UpdateChoices then
        local names = self:GetProfileNames()
        widget:UpdateChoices(names, names)
        if widget.UpdateValue then widget:UpdateValue() end
    end
end

-- ---------------------------------------------------------------------------
-- LAM panel
-- ---------------------------------------------------------------------------

local function pget(field) return function() return SC:GetActiveProfile()[field] end end
local function pset(field)
    return function(value)
        SC:GetActiveProfile()[field] = value
        SC:Redraw()
        SC:UpdateVisibility()
    end
end

local function colorGet(field)
    return function()
        local c = SC:GetActiveProfile()[field]
        return c.r, c.g, c.b, c.a or 1
    end
end
local function colorSet(field)
    return function(r, g, b, a)
        local c = SC:GetActiveProfile()[field]
        c.r, c.g, c.b, c.a = r, g, b, a
        SC:Redraw()
    end
end

-- Hitmarker setters: redraw the marker (not the crosshair) after a change.
local function hmset(field)
    return function(value)
        SC:GetActiveProfile()[field] = value
        SC:RedrawHitmarker()
    end
end
local function hmColorSet(field)
    return function(r, g, b, a)
        local c = SC:GetActiveProfile()[field]
        c.r, c.g, c.b, c.a = r, g, b, a
        SC:RedrawHitmarker()
    end
end

function SC:BuildSettings()
    if not LAM then return end   -- no settings panel without LibAddonMenu-2.0; crosshair still works
    local panelData = {
        type                = "panel",
        name                = "Shoyru's Combat Reticle",
        displayName         = "Shoyru's Combat Reticle",
        author              = "Shoyru",
        version             = self.version,
        slashCommand        = "/reticle",
        registerForRefresh  = true,
        registerForDefaults = true,
    }

    -- Disabled helpers — used to grey out sections that don't apply to the
    -- current style. LAM has no native "hide on condition", so we lean on
    -- disabled+tooltip as the consistent visual signal.
    local function linesUnused()
        return SC:GetActiveProfile().style == "dot"
    end
    local function dotUnused()
        return SC:GetActiveProfile().style == "lines"
    end
    local function outlineUnused()
        return not SC:GetActiveProfile().outlineEnabled
    end

    -- Hitmarker section: grey out what doesn't apply to the current state.
    local function hmOff()       return not SC:GetActiveProfile().hmEnabled end
    local function hmNotCross()  return hmOff() or SC:GetActiveProfile().hmStyle ~= "cross" end
    local function hmNotMarks()  return hmOff() or SC:GetActiveProfile().hmStyle ~= "marks" end
    local function hmNoOutline()
        local p = SC:GetActiveProfile()
        return hmNotCross() or not p.hmOutline or not p.outlineEnabled
    end
    local function hmNoCrit()    return hmOff() or not SC:GetActiveProfile().hmCritDistinct end
    local function hmNoSound()   return hmOff() or SC:GetActiveProfile().hmSound == "NONE" end

    local options = {
        -- ---------- Style (first; drives what else is relevant) ----------
        {
            type = "header",
            name = "Crosshair style",
        },
        {
            type          = "dropdown",
            name          = "Type",
            tooltip       = "Choose which elements make up the crosshair. Other sections grey out when they don't apply.",
            choices       = { "Lines only", "Dot only", "Lines + Dot" },
            choicesValues = { "lines",       "dot",       "lines_dot" },
            getFunc       = pget("style"),
            setFunc       = pset("style"),
            width         = "full",
        },
        {
            type    = "checkbox",
            name    = "Test mode (force crosshair visible)",
            tooltip = "Keeps the crosshair drawn even in menus while you tune settings.",
            getFunc = function() return self.sv.testMode end,
            setFunc = function(v)
                self.sv.testMode = v
                self:UpdateVisibility()
            end,
            width   = "full",
        },

        -- ---------- Profile management ----------
        {
            type = "header",
            name = "Profile",
        },
        {
            type      = "dropdown",
            name      = "Active profile",
            tooltip   = "Switch between saved crosshair profiles.",
            choices   = self:GetProfileNames(),
            getFunc   = function() return self.sv.activeProfile end,
            setFunc   = function(v) self:SwitchProfile(v) end,
            reference = "ShoyruCombatReticle_ProfileDropdown",
            width     = "full",
        },
        {
            type    = "editbox",
            name    = "Profile name (for save/rename below)",
            getFunc = function() return self.sv.pendingName or "" end,
            setFunc = function(v) self.sv.pendingName = v end,
            width   = "full",
        },
        {
            type    = "button",
            name    = "Save as new profile",
            tooltip = "Create a new profile with the name above, copying current settings.",
            func    = function()
                if self:SaveAsNew(self.sv.pendingName) then
                    self.sv.pendingName = ""
                end
            end,
            width   = "half",
        },
        {
            type    = "button",
            name    = "Rename current",
            tooltip = "Rename the active profile to the name above.",
            func    = function()
                if self:RenameActive(self.sv.pendingName) then
                    self.sv.pendingName = ""
                end
            end,
            width   = "half",
        },
        {
            type        = "button",
            name        = "Delete current profile",
            tooltip     = "Delete the active profile. Default is reset rather than removed.",
            func        = function() self:DeleteActive() end,
            warning     = "This cannot be undone.",
            isDangerous = true,
            width       = "half",
        },
        {
            type    = "button",
            name    = "Reset active to defaults",
            tooltip = "Reset every setting in the active profile to default values.",
            func    = function() self:ResetActive() end,
            warning = "Resets all settings for the active profile.",
            width   = "half",
        },

        -- ---------- Lines (greyed if style == "dot") ----------
        {
            type = "header",
            name = "Lines",
        },
        { type = "slider", name = "Length", min = 0, max = 40, step = 1,
          getFunc = pget("lineLength"), setFunc = pset("lineLength"),
          disabled = linesUnused, width = "full" },
        { type = "slider", name = "Thickness", min = 1, max = 10, step = 1,
          getFunc = pget("lineThickness"), setFunc = pset("lineThickness"),
          disabled = linesUnused, width = "full" },
        { type = "slider", name = "Gap from center", min = 0, max = 40, step = 1,
          getFunc = pget("lineGap"), setFunc = pset("lineGap"),
          disabled = linesUnused, width = "full" },
        { type = "colorpicker", name = "Line color",
          getFunc = colorGet("lineColor"), setFunc = colorSet("lineColor"),
          disabled = linesUnused, width = "half" },
        { type = "slider", name = "Line opacity", min = 0, max = 100, step = 5,
          getFunc = function() return math.floor((SC:GetActiveProfile().lineColor.a or 1) * 100 + 0.5) end,
          setFunc = function(v)
              SC:GetActiveProfile().lineColor.a = v / 100
              SC:Redraw()
          end,
          disabled = linesUnused, width = "half" },

        -- ---------- Outline / Border ----------
        {
            type = "header",
            name = "Outline / Border",
        },
        { type = "checkbox", name = "Enable outline",
          getFunc = pget("outlineEnabled"), setFunc = pset("outlineEnabled"),
          width = "full" },
        { type = "slider", name = "Outline thickness", min = 0, max = 6, step = 1,
          getFunc = pget("outlineThickness"), setFunc = pset("outlineThickness"),
          disabled = outlineUnused, width = "full" },
        { type = "colorpicker", name = "Outline color",
          getFunc = colorGet("outlineColor"), setFunc = colorSet("outlineColor"),
          disabled = outlineUnused, width = "half" },
        { type = "slider", name = "Outline opacity", min = 0, max = 100, step = 5,
          getFunc = function() return math.floor((SC:GetActiveProfile().outlineColor.a or 1) * 100 + 0.5) end,
          setFunc = function(v)
              SC:GetActiveProfile().outlineColor.a = v / 100
              SC:Redraw()
          end,
          disabled = outlineUnused, width = "half" },

        -- ---------- Center Dot (greyed if style == "lines") ----------
        {
            type = "header",
            name = "Center dot",
        },
        { type = "dropdown", name = "Dot shape",
          choices       = { "Round",  "Square" },
          choicesValues = { "circle", "square" },
          getFunc = pget("dotShape"), setFunc = pset("dotShape"),
          disabled = dotUnused, width = "full" },
        { type = "slider", name = "Size", min = 1, max = 64, step = 1,
          getFunc = pget("dotSize"), setFunc = pset("dotSize"),
          disabled = dotUnused, width = "full" },
        { type = "colorpicker", name = "Dot color",
          getFunc = colorGet("dotColor"), setFunc = colorSet("dotColor"),
          disabled = dotUnused, width = "half" },
        { type = "slider", name = "Dot opacity", min = 0, max = 100, step = 5,
          getFunc = function() return math.floor((SC:GetActiveProfile().dotColor.a or 1) * 100 + 0.5) end,
          setFunc = function(v)
              SC:GetActiveProfile().dotColor.a = v / 100
              SC:Redraw()
          end,
          disabled = dotUnused, width = "half" },
        { type = "checkbox", name = "Use outline on dot",
          getFunc = pget("dotUseOutline"), setFunc = pset("dotUseOutline"),
          disabled = function() return dotUnused() or outlineUnused() end,
          width = "full" },

        -- ---------- Visibility ----------
        {
            type = "header",
            name = "Visibility",
        },
        { type = "checkbox", name = "Hide when in menus / cursor mode",
          getFunc = pget("hideOnMenus"),  setFunc = pset("hideOnMenus"),  width = "full" },
        { type = "checkbox", name = "Hide while dead",
          getFunc = pget("hideOnDeath"),  setFunc = pset("hideOnDeath"),  width = "full" },
        { type = "checkbox", name = "Hide outside of combat",
          getFunc = pget("hideInNonCombat"), setFunc = pset("hideInNonCombat"), width = "full" },

        -- ---------- Hitmarker ----------
        {
            type = "header",
            name = "Hitmarker",
        },
        {
            type    = "description",
            text    = "Flash a marker (and optional sound) on the reticle when you land damage. "
                    .. "Saved per profile, so each crosshair can have its own hitmarker.",
        },
        { type = "checkbox", name = "Enable hitmarker",
          tooltip = "Master on/off for the hitmarker.",
          getFunc = pget("hmEnabled"),
          setFunc = function(v)
              SC:GetActiveProfile().hmEnabled = v
              SC:UpdateCombatRegistration()
              SC:RedrawHitmarker()
          end,
          width = "full" },
        {
            type    = "dropdown",
            name    = "Trigger on",
            tooltip = "Critical hits only, or every point of damage you deal (including DoT ticks).",
            choices       = { "Critical damage only", "All damage" },
            choicesValues = { "crit",                  "all" },
            getFunc = pget("hmTrigger"),
            setFunc = function(v)
                SC:GetActiveProfile().hmTrigger = v
                SC:UpdateCombatRegistration()
            end,
            disabled = hmOff, width = "full",
        },
        {
            type    = "dropdown",
            name    = "Style",
            tooltip = "Cross = adjustable + drawn from lines (full size/thickness/gap control). "
                    .. "Marks = the classic angled X texture (scalable + tintable).",
            choices       = { "Cross (+)", "Marks (X)" },
            choicesValues = { "cross",     "marks" },
            getFunc = pget("hmStyle"), setFunc = hmset("hmStyle"),
            disabled = hmOff, width = "full",
        },
        { type = "button", name = "Test hitmarker",
          tooltip = "Fire the marker once using the normal color.",
          func = function() SC:TriggerHitmarker(false, true) end,
          disabled = hmOff, width = "half" },
        { type = "button", name = "Test crit hitmarker",
          tooltip = "Fire the marker once using the crit color.",
          func = function() SC:TriggerHitmarker(true, true) end,
          disabled = hmOff, width = "half" },

        -- Cross geometry
        { type = "slider", name = "Cross: arm length", min = 1, max = 40, step = 1,
          getFunc = pget("hmSize"), setFunc = hmset("hmSize"),
          disabled = hmNotCross, width = "full" },
        { type = "slider", name = "Cross: thickness", min = 1, max = 12, step = 1,
          getFunc = pget("hmThickness"), setFunc = hmset("hmThickness"),
          disabled = hmNotCross, width = "full" },
        { type = "slider", name = "Cross: gap from center", min = 0, max = 40, step = 1,
          getFunc = pget("hmGap"), setFunc = hmset("hmGap"),
          disabled = hmNotCross, width = "full" },
        { type = "checkbox", name = "Cross: outline",
          tooltip = "Draw a border behind the cross using the crosshair's outline color. "
                  .. "Requires 'Enable outline' above.",
          getFunc = pget("hmOutline"), setFunc = hmset("hmOutline"),
          disabled = hmNotCross, width = "full" },

        -- Marks geometry
        { type = "slider", name = "Marks: size", min = 12, max = 128, step = 2,
          getFunc = pget("hmTextureSize"), setFunc = hmset("hmTextureSize"),
          disabled = hmNotMarks, width = "full" },

        -- Colors
        { type = "colorpicker", name = "Color",
          tooltip = "Color of the hitmarker on a normal hit.",
          getFunc = colorGet("hmColor"), setFunc = hmColorSet("hmColor"),
          disabled = hmOff, width = "half" },
        { type = "slider", name = "Opacity", min = 0, max = 100, step = 5,
          getFunc = function() return math.floor((SC:GetActiveProfile().hmColor.a or 1) * 100 + 0.5) end,
          setFunc = function(v)
              SC:GetActiveProfile().hmColor.a = v / 100
              SC:RedrawHitmarker()
          end,
          disabled = hmOff, width = "half" },
        { type = "checkbox", name = "Use a separate color for crits",
          tooltip = "When on, critical hits flash the crit color below instead of the normal color.",
          getFunc = pget("hmCritDistinct"), setFunc = hmset("hmCritDistinct"),
          disabled = hmOff, width = "full" },
        { type = "colorpicker", name = "Crit color",
          getFunc = colorGet("hmCritColor"), setFunc = hmColorSet("hmCritColor"),
          disabled = hmNoCrit, width = "full" },

        -- Feel
        { type = "slider", name = "Hold time (ms)", min = 60, max = 1000, step = 20,
          tooltip = "How long the marker stays before it fades out.",
          getFunc = pget("hmDuration"),
          setFunc = function(v)
              SC:GetActiveProfile().hmDuration = v
              SC:BuildHitmarkerAnim()
          end,
          disabled = hmOff, width = "full" },
        { type = "slider", name = "Throttle (ms)", min = 0, max = 1000, step = 50,
          tooltip = "Minimum gap between markers so rapid hits (e.g. DoT ticks) don't spam. 0 = show every hit.",
          getFunc = pget("hmThrottleMs"), setFunc = hmset("hmThrottleMs"),
          disabled = hmOff, width = "full" },

        -- Sound
        {
            type    = "dropdown",
            name    = "Sound",
            tooltip = "Built-in ESO sound played on a hit (custom audio can't be imported). NONE = silent.",
            choices = SOUND_CHOICES,
            getFunc = pget("hmSound"),
            setFunc = function(v)
                SC:GetActiveProfile().hmSound = v
                SC:PlayHitSound()   -- preview the pick
            end,
            disabled = hmOff, width = "full",
        },
        { type = "slider", name = "Sound volume (layered)", min = 1, max = 5, step = 1,
          tooltip = "ESO has no true volume control, so higher values stack the sound a few ms apart "
                  .. "to read as louder/fuller. Preview by re-selecting the sound above.",
          getFunc = pget("hmVolume"), setFunc = hmset("hmVolume"),
          disabled = hmNoSound, width = "full" },
    }

    self.lamPanel = LAM:RegisterAddonPanel("ShoyruCombatReticlePanel", panelData)
    LAM:RegisterOptionControls("ShoyruCombatReticlePanel", options)

    -- Force crosshair visible while user is in the settings panel.
    CALLBACK_MANAGER:RegisterCallback("LAM-PanelOpened", function(panel)
        if panel == self.lamPanel then
            self.settingsOpen = true
            self:UpdateVisibility()
        end
    end)
    CALLBACK_MANAGER:RegisterCallback("LAM-PanelClosed", function(panel)
        if panel == self.lamPanel then
            self.settingsOpen = false
            self:UpdateVisibility()
        end
    end)
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------

function SC:OnLoaded(addonName)
    if addonName ~= self.name then return end
    EVENT_MANAGER:UnregisterForEvent(self.name, EVENT_ADD_ON_LOADED)

    -- Saved-variables key deliberately kept as the old "ShoyruCrosshair..." name
    -- (addon was renamed from ShoyruCrosshair) so existing profiles migrate over.
    self.sv = ZO_SavedVars:NewAccountWide("ShoyruCrosshairSavedVariables", 1, nil, DEFAULTS)

    -- Ensure every profile carries every default field (new fields added in
    -- future versions get filled in for existing saved profiles).
    for _, profile in pairs(self.sv.profiles) do
        MergeDefaults(profile, DEFAULT_PROFILE)
    end
    if not self.sv.profiles[self.sv.activeProfile] then
        self.sv.activeProfile = "Default"
    end

    self:BuildUI()
    self:BuildSettings()

    -- Keep the old /crosshair slash as an alias for /reticle (muscle memory).
    if LAM and self.lamPanel then
        SLASH_COMMANDS["/crosshair"] = function() LAM:OpenToPanel(self.lamPanel) end
    end

    -- Hide the game's built-in reticle so only our custom crosshair is drawn.
    -- RETICLE re-shows it on most frames, so we re-hide on a short interval.
    if ZO_ReticleContainerReticle then
        ZO_ReticleContainerReticle:SetHidden(true)
        EVENT_MANAGER:RegisterForUpdate(self.name .. "_HideReticle", 100, function()
            if ZO_ReticleContainerReticle and not ZO_ReticleContainerReticle:IsHidden() then
                ZO_ReticleContainerReticle:SetHidden(true)
            end
        end)
    end

    -- Hook visibility-relevant state changes.
    local function vis() self:UpdateVisibility() end
    if SCENE_MANAGER and SCENE_MANAGER.RegisterCallback then
        SCENE_MANAGER:RegisterCallback("SceneStateChanged", vis)
    end
    EVENT_MANAGER:RegisterForEvent(self.name, EVENT_PLAYER_ALIVE,         vis)
    EVENT_MANAGER:RegisterForEvent(self.name, EVENT_PLAYER_DEAD,          vis)
    EVENT_MANAGER:RegisterForEvent(self.name, EVENT_PLAYER_COMBAT_STATE,  vis)
    EVENT_MANAGER:RegisterForEvent(self.name, EVENT_PLAYER_ACTIVATED,     vis)

    self:Redraw()
    self:RedrawHitmarker()
    self:UpdateCombatRegistration()
    self:UpdateVisibility()
end

EVENT_MANAGER:RegisterForEvent(SC.name, EVENT_ADD_ON_LOADED, function(_, name)
    SC:OnLoaded(name)
end)
