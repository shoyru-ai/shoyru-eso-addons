-- ShoyruSounds - reusable categorized sound picker for ESO addons.
--
-- Copy this file into any addon and list it ABOVE your main .lua in the manifest
-- (.txt) so the global `ShoyruSounds` exists before your settings build. The
-- sound lists are generated from the live game SOUNDS table, so only real,
-- playable sounds ever appear (a misremembered name simply doesn't show up) and
-- it stays current across game patches.
--
-- Drop-in usage from any addon's LibAddonMenu options:
--   local sel = ShoyruSounds:BuildSelector({
--       reference = "MyAddon_HitSound",              -- unique per selector
--       name      = "Hit sound",
--       get       = function() return sv.sound end,  -- returns a SOUNDS key or "NONE"
--       set       = function(v) sv.sound = v end,
--       preview   = function() MyAddon:PlaySound() end, -- optional; else plays raw
--       disabled  = function() return not sv.enabled end, -- optional
--   })
--   for _, control in ipairs(sel) do table.insert(options, control) end
--
-- Store a single string field (a SOUNDS key, or ShoyruSounds.NONE for silence).

local MODULE_VERSION = 1

-- If another addon already loaded a same-or-newer copy, keep that one.
if ShoyruSounds and ShoyruSounds.version and ShoyruSounds.version >= MODULE_VERSION then
    return
end

ShoyruSounds = ShoyruSounds or {}
local S = ShoyruSounds
S.version = MODULE_VERSION
S.NONE    = "NONE"   -- sentinel stored when the user wants silence

-- Ordered category definitions. Each sound NAME (a SOUNDS key) is bucketed into
-- the FIRST category whose patterns it contains; leftovers go to "Other".
-- "Recommended" (an explicit shortlist) and "All" (everything) are added around
-- these in Build().
local CATEGORY_DEFS = {
    { name = "Abilities",         pat = { "ABILITY", "MORPH", "SLOTTED", "ULTIMATE", "SYNERGY", "WEAPON_SWAP" } },
    { name = "Combat & Death",    pat = { "COMBAT", "DEATH", "KILL", "DUEL", "RESURRECT", "SIEGE", "AVENGE", "BATTLE" } },
    { name = "Justice & Stealth", pat = { "JUSTICE", "STEAL", "PICKPOCKET", "LOCKPICK", "TRESPASS", "HIDEYHOLE", "BOUNTY" } },
    { name = "UI & Clicks",       pat = { "CLICK", "MENU", "DIALOG", "WINDOW", "TABS", "SCROLL", "CHECKBOX", "SPINNER", "SLIDER", "KEYBIND", "EDIT_", "TOGGLE", "RADIO" } },
    { name = "Alerts & Mail",     pat = { "ALERT", "NOTIFICATION", "MAIL", "WARNING", "ERROR", "COUNTDOWN", "TIMER", "PROMPT" } },
    { name = "Loot & Items",      pat = { "LOOT", "ITEM", "INVENTORY", "TREASURE", "BOOK", "GOLD", "MONEY", "CURRENCY", "TELVAR", "CRAFT", "ENCHANT", "TROPHY", "STOLEN", "REPAIR", "BANK" } },
    { name = "Social & Group",    pat = { "GROUP", "GUILD", "FRIEND", "CHAT", "WHISPER", "TRADE", "LFG", "PLEDGE", "VOICE", "DUEL_INVITE" } },
    { name = "Progression",       pat = { "LEVEL", "ACHIEVEMENT", "CHAMPION", "QUEST", "SKILL", "XP", "COLLECTIBLE", "ANTIQUIT", "ENDEAVOR", "RIDING", "PROVISIONER", "DYE", "TITLE" } },
}

-- Punchy, distinct sounds that work well for hit / alert feedback. Validated
-- against the live table in Build(), so any name not present is silently dropped.
local RECOMMENDED = {
    "ACHIEVEMENT_AWARDED", "DEATH_RECAP_KILLING_BLOW_SHOWN", "DUEL_WON",
    "DUEL_START", "DUEL_FORFEIT", "JUSTICE_NOW_KOS", "JUSTICE_PICKPOCKET_BONUS",
    "LEVEL_UP", "CHAMPION_POINTS_COMMITTED", "ABILITY_MORPH_PURCHASE",
    "GROUP_FINDER_ALERT", "GROUP_JOIN", "NEW_NOTIFICATION", "BOOK_ACQUIRED",
    "QUEST_COMPLETED", "TELVAR_GAINED", "TELVAR_LOST", "SKILL_LINE_LEVELED_UP",
    "MAIL_SENT", "TRADE_ITEM_ADDED", "OBJECTIVE_ACCEPTED",
}

local function soundExists(name)
    if type(SOUNDS) ~= "table" then return false end
    local v = rawget(SOUNDS, name)
    return v ~= nil and v ~= ""
end

-- Build the category -> sorted-names index once, lazily (after SOUNDS exists).
function S:Build()
    if self._built then return end
    self._built = true

    local all = {}
    if type(SOUNDS) == "table" then
        for name, val in pairs(SOUNDS) do
            if type(name) == "string" and val ~= nil and val ~= "" and name ~= "NONE" then
                all[#all + 1] = name
            end
        end
    end
    table.sort(all)

    local buckets = {}
    local order   = { "Recommended" }
    for _, def in ipairs(CATEGORY_DEFS) do
        buckets[def.name] = {}
        order[#order + 1] = def.name
    end
    buckets["Other"] = {}
    order[#order + 1] = "Other"
    order[#order + 1] = "All"
    buckets["All"]    = all

    local rec = {}
    for _, n in ipairs(RECOMMENDED) do
        if soundExists(n) then rec[#rec + 1] = n end
    end
    buckets["Recommended"] = rec

    local function categoryFor(name)
        for _, def in ipairs(CATEGORY_DEFS) do
            for _, p in ipairs(def.pat) do
                if string.find(name, p, 1, true) then return def.name end
            end
        end
        return "Other"
    end
    -- `all` is already sorted, so each bucket stays alphabetical.
    for _, name in ipairs(all) do
        local b = buckets[categoryFor(name)]
        b[#b + 1] = name
    end

    self._order   = order
    self._buckets = buckets
end

-- Category names that actually contain sounds ("All" always included).
function S:GetCategories()
    self:Build()
    local out = {}
    for _, name in ipairs(self._order) do
        if name == "All" or (self._buckets[name] and #self._buckets[name] > 0) then
            out[#out + 1] = name
        end
    end
    return out
end

-- display list + value list for a category, with a leading "None".
function S:GetChoices(category)
    self:Build()
    local names = self._buckets[category] or self._buckets["All"] or {}
    local disp, vals = { "None" }, { self.NONE }
    for _, n in ipairs(names) do
        disp[#disp + 1] = n
        vals[#vals + 1] = n
    end
    return disp, vals
end

function S:CategoryOf(soundName)
    self:Build()
    if not soundName or soundName == self.NONE then
        if self._buckets["Recommended"] and #self._buckets["Recommended"] > 0 then return "Recommended" end
        return "All"
    end
    for _, cat in ipairs(self._order) do
        if cat ~= "All" then
            for _, n in ipairs(self._buckets[cat] or {}) do
                if n == soundName then return cat end
            end
        end
    end
    return "All"
end

function S:Play(soundName)
    if not soundName or soundName == self.NONE then return end
    if type(SOUNDS) ~= "table" then return end
    local id = rawget(SOUNDS, soundName)
    if id and id ~= "" then PlaySound(id) end
end

-- Returns { categoryDropdown, soundDropdown, previewButton } ready to insert
-- into a LibAddonMenu options table.
function S:BuildSelector(opts)
    self:Build()
    local S2       = self
    local ref      = opts.reference
    local soundRef = ref .. "_Sound"
    local width    = opts.width or "full"
    local disabled = opts.disabled

    S2._uiCat = S2._uiCat or {}
    local function curCat()
        if not S2._uiCat[ref] then S2._uiCat[ref] = S2:CategoryOf(opts.get()) end
        return S2._uiCat[ref]
    end
    local function refreshSounds()
        local w = _G[soundRef]
        if w and w.UpdateChoices then
            local disp, vals = S2:GetChoices(curCat())
            w:UpdateChoices(disp, vals)
            if w.UpdateValue then w:UpdateValue() end
        end
    end

    local disp0, vals0 = S2:GetChoices(curCat())

    local categoryDropdown = {
        type    = "dropdown",
        name    = (opts.name or "Sound") .. " - category",
        tooltip = "Filter the sound list. 'Recommended' is a punchy shortlist; 'All' lists every game sound.",
        choices = S2:GetCategories(),
        getFunc = function() return curCat() end,
        setFunc = function(v) S2._uiCat[ref] = v; refreshSounds() end,
        disabled = disabled,
        width   = width,
    }
    local soundDropdown = {
        type          = "dropdown",
        name          = opts.name or "Sound",
        tooltip       = opts.tooltip or "Pick a sound (previews when selected). 'None' = silent.",
        scrollable    = true,
        choices       = disp0,
        choicesValues = vals0,
        getFunc       = function() return opts.get() end,
        setFunc       = function(v)
            opts.set(v)
            if opts.preview then opts.preview() else S2:Play(v) end
        end,
        reference = soundRef,
        disabled  = disabled,
        width     = width,
    }
    local previewButton = {
        type  = "button",
        name  = "Preview sound",
        func  = function() if opts.preview then opts.preview() else S2:Play(opts.get()) end end,
        disabled = disabled,
        width = "half",
    }
    return { categoryDropdown, soundDropdown, previewButton }
end
