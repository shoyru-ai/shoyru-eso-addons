ShoyruFossilizeAlert = {}
ShoyruFossilizeAlert.name = "ShoyruFossilizeAlert"
ShoyruFossilizeAlert.version = "1.1"

local ADDON_NAME = ShoyruFossilizeAlert.name
local COMBAT_EVENT_NAME = ADDON_NAME .. "_Combat"
local EFFECT_EVENT_NAME = ADDON_NAME .. "_Effect"
local TIMER_NAME = ADDON_NAME .. "_Timer"
local TEST_TIMER_NAME = ADDON_NAME .. "_TestTimer"
local LOAD_EVENT_NAME = ADDON_NAME .. "_Loaded"

-- Synthetic result code used when EVENT_EFFECT_CHANGED fires an UPDATED
-- (refresh) event. Negative to never collide with real ACTION_RESULT_* codes.
local SYNTHETIC_RESULT_REFRESH = -1

-- Known CC-immunity buff IDs in ESO. Used to suppress alerts when the player
-- can't be CC'd anyway (post break-free, roll dodge, etc).
local IMMUNITY_BUFF_IDS = {
    [28301]  = true, -- Crowd Control Immunity (confirmed via debug)
    [21558]  = true, -- Stun Immunity (legacy)
    [21577]  = true, -- Disorient Immunity (legacy)
    [21587]  = true, -- Fear Immunity (legacy)
    [21597]  = true, -- Silence Immunity (legacy)
    [21606]  = true, -- Snare/Root Immunity (legacy)
    [76618]  = true, -- Stun Immunity (PvP refinement)
    [99830]  = true, -- Persistence (after roll dodge)
    [123653] = true, -- Universal CC Immunity
}

-- Tracked timestamp; ACTION_RESULT_IMMUNE / DODGED targeting us extends it.
-- CC immunity in ESO is ~7 seconds after a successful break-free.
local immuneUntilMs = 0
local IMMUNITY_FLAG_MS = 7000

-- The ability ID of the CC Immunity buff itself; used to lock our immunity
-- timestamp to the exact duration ESO reports.
local CC_IMMUNITY_ABILITY_ID = 28301

-- All variants of the DK Earthen Heart cast-time stun. We treat them as the
-- same threat — any of them landing on the player triggers the alert.
-- If you ever get stunned and the alert doesn't fire, type "/sfadebug" in
-- chat to log every combat event targeting you; the ability ID it prints
-- can be added here.
local TRACKED_IDS = {
    [29037] = true, -- Petrify (base)
    [32685] = true, -- Fossilize (morph)
    [32678] = true, -- Shattering Rocks (morph)
}

local debugEnabled = false
-- Icon source. All three variants share roughly the same icon, but Fossilize's
-- icon is the most recognizable and what most players associate with the
-- ability. Used by GetAbilityIcon as a fallback if a variant has no icon.
local ICON_ABILITY_ID = 32685

-- Default windup time between the cast-begin event firing on the target and
-- the stun actually landing. Empirically ~1.1s for Fossilize.
local DEFAULT_CAST_TIME_MS = 1100
-- If a second cast is detected within this window of the previous one we
-- switch the message to the "back-to-back" version.
local DEFAULT_BACK_TO_BACK_MS = 6000

local DEFAULT_SOUND_KEY = "DUEL_INVITE_RECEIVED"

local SOUND_DISPLAY_NAMES = {
    "Duel Invite",
    "Duel Start",
    "New Notification",
    "Major Buff",
    "Ultimate Ready",
    "Group Invite",
    "Alert Error",
    "Quest Accepted",
    "Objective Complete",
    "Medal Earned",
    "Champion Points",
    "Death Recap",
}
local SOUND_KEYS = {
    "DUEL_INVITE_RECEIVED",
    "DUEL_START",
    "NEW_NOTIFICATION",
    "ABILITY_MAJOR_BUFF",
    "ABILITY_ULTIMATE_READY",
    "GROUP_INVITE",
    "GENERAL_ALERT_ERROR",
    "QUEST_ACCEPTED",
    "OBJECTIVE_COMPLETED",
    "BATTLEGROUND_MEDAL_EARNED",
    "CHAMPION_POINTS_COMMITTED",
    "DEATH_RECAP_KILLING_BLOW_SHOWN",
}

local defaults = {
    enabled = true,
    suppressOnImmune = true,

    -- Messages
    firstMessage  = "Roll Now!",
    repeatMessage = "Roll Again!",

    -- Behavior
    castTimeMs       = DEFAULT_CAST_TIME_MS,
    backToBackMs     = DEFAULT_BACK_TO_BACK_MS,

    -- Colors
    colorFirst  = { r = 0.95, g = 0.83, b = 0.49, a = 1 }, -- ESO gold (first cast)
    colorRepeat = { r = 0.91, g = 0.32, b = 0.32, a = 1 }, -- ESO alert red (back-to-back)

    -- Border
    borderColor = { r = 0, g = 0, b = 0, a = 1 },
    borderThickness = 2, -- power of two: 2, 4, or 8

    -- Sound
    soundAlert = true,
    soundName  = DEFAULT_SOUND_KEY,
    soundVolume = 1, -- 1 = normal; higher stacks the sound for extra loudness

    -- Layout (drag/resize while unlocked)
    offsetX = 0,
    offsetY = -200,
    width   = 220,
    height  = 56,
    scale   = 1.0,

    -- Test/preview
    showTestAlert = false,
    testMode = "cycle", -- "cycle" or "repeatOnly"
}

local function GetNowMs()
    return GetFrameTimeMilliseconds()
end

-- Returns the longest CC-immunity duration remaining (in ms) across all
-- known sources: our tracked IMMUNE/DODGED flag and the player's active
-- immunity buffs (which expose timeEnding). 0 means no immunity.
local function GetImmunityRemainingMs()
    local now = GetNowMs()
    local maxRemaining = math.max(0, immuneUntilMs - now)

    -- Buff scan fallback. Buff timeEnding is in frame-time seconds, so
    -- prefer GetFrameTimeSeconds; sanity-cap the result so a time-domain
    -- shift in a game update can never cause permanent suppression (the
    -- longest real CC immunity, immovability potions, is ~16s).
    local nowSecFn = GetFrameTimeSeconds or GetGameTimeSeconds
    if GetNumBuffs and GetUnitBuffInfo and nowSecFn then
        local n = GetNumBuffs("player")
        local nowSec = nowSecFn()
        for i = 1, n do
            local _, _, timeEnding, _, _, _, _, _, _, _, abilityId = GetUnitBuffInfo("player", i)
            if abilityId and IMMUNITY_BUFF_IDS[abilityId] and timeEnding then
                local remainingMs = (timeEnding - nowSec) * 1000
                if remainingMs > 20000 then remainingMs = 0 end -- bogus time domain; ignore
                if remainingMs > maxRemaining then
                    maxRemaining = remainingMs
                end
            end
        end
    end

    return maxRemaining
end

-- ESO's PlaySound has no volume parameter — sounds play on the Interface
-- audio channel at a fixed level. The one lever available is stacking:
-- playing the same sound multiple times in the same frame sums amplitude,
-- so values above 1 mean louder. Quieter than 1x isn't possible from Lua;
-- that's the game's Audio > Interface Sounds slider.
local function PlaySoundAtVolume(key)
    local s = SOUNDS and SOUNDS[key]
    if not s then return end
    local sv = ShoyruFossilizeAlert.savedVariables
    local volume = math.max(1, math.floor((sv and sv.soundVolume) or defaults.soundVolume))
    for _ = 1, volume do
        PlaySound(s)
    end
end

local function PlayAlertSound()
    local sv = ShoyruFossilizeAlert.savedVariables
    if not sv or not sv.soundAlert then return end
    PlaySoundAtVolume((sv and sv.soundName) or defaults.soundName)
end

-- Controls
local alertWindow = nil
local alertLabel = nil
local timerLabel = nil
local iconTexture = nil
local iconBorder = nil
local barBg = nil
local barFill = nil

-- Active cast state.
local castActive = false
local castStartedMs = 0
local castEndTimeMs = 0
local castDurationMs = 0
local lastCastEndedMs = 0
local isRepeatCast = false
local lastTriggerResult = 0
local lastTriggerSourceUnitId = 0
local lastTriggerMs = 0

-- Test mode state
local testStateRepeat = false
local testLastTickMs = 0

local function GetActiveColor(repeatCast)
    local sv = ShoyruFossilizeAlert.savedVariables
    local c
    if repeatCast then
        c = (sv and sv.colorRepeat) or defaults.colorRepeat
    else
        c = (sv and sv.colorFirst) or defaults.colorFirst
    end
    return { c.r, c.g, c.b, c.a or 1 }
end

local function GetActiveMessage(repeatCast)
    local sv = ShoyruFossilizeAlert.savedVariables
    if repeatCast then
        return (sv and sv.repeatMessage) or defaults.repeatMessage
    end
    return (sv and sv.firstMessage) or defaults.firstMessage
end

local ApplyLabelStyle -- forward declaration

local function ApplyAlertLayout()
    if not alertWindow or not ShoyruFossilizeAlert.savedVariables then return end
    local sv = ShoyruFossilizeAlert.savedVariables

    alertWindow:ClearAnchors()
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, sv.offsetX or 0, sv.offsetY or -200)
    alertWindow:SetDimensions(sv.width or 220, sv.height or 56)
    alertWindow:SetScale(sv.scale or 1.0)

    if ApplyLabelStyle then ApplyLabelStyle() end
end

local function RenderDisplay(repeatCast, remainingMs, durationMs)
    if not alertLabel or not alertWindow or not barBg or not barFill then return end

    local color = GetActiveColor(repeatCast)
    alertLabel:SetText(GetActiveMessage(repeatCast))
    alertLabel:SetColor(color[1], color[2], color[3], color[4])
    barFill:SetColor(color[1], color[2], color[3], 0.95)

    local total = (durationMs and durationMs > 0) and durationMs or DEFAULT_CAST_TIME_MS
    local progress = (remainingMs and remainingMs > 0) and (remainingMs / total) or 0
    if progress > 1 then progress = 1 end
    local barWidth = math.max(2, barBg:GetWidth() - 2)
    barFill:SetWidth(barWidth * progress)
    barFill:SetHidden(progress <= 0)

    if remainingMs and remainingMs > 0 then
        timerLabel:SetText(string.format("%.1fs", remainingMs / 1000))
        timerLabel:SetHidden(false)
    else
        timerLabel:SetText("")
        timerLabel:SetHidden(true)
    end

    alertWindow:SetHidden(false)
end

local function UpdateDisplayedAlert()
    if not alertWindow then return end
    local sv = ShoyruFossilizeAlert.savedVariables

    if sv and sv.showTestAlert then
        local elapsed = GetNowMs() - testLastTickMs
        local castTime = (sv and sv.castTimeMs) or defaults.castTimeMs
        local remaining = math.max(0, castTime - elapsed)
        RenderDisplay(testStateRepeat, remaining, castTime)
        return
    end

    local now = GetNowMs()
    if not castActive or now >= castEndTimeMs then
        alertWindow:SetHidden(true)
        return
    end

    RenderDisplay(isRepeatCast, castEndTimeMs - now, castDurationMs)
end

local function StopUpdateLoopIfIdle()
    local sv = ShoyruFossilizeAlert.savedVariables
    if not castActive and not (sv and sv.showTestAlert) then
        EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    end
end

local function TickUpdate()
    local now = GetNowMs()
    if castActive and now >= castEndTimeMs then
        lastCastEndedMs = castEndTimeMs
        castActive = false
        castEndTimeMs = 0
        castDurationMs = 0
    end
    UpdateDisplayedAlert()
    StopUpdateLoopIfIdle()
end

local function EnsureUpdateLoop()
    EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    EVENT_MANAGER:RegisterForUpdate(TIMER_NAME, 50, TickUpdate)
end

local function StartCastAlert(result, sourceUnitId)
    local sv = ShoyruFossilizeAlert.savedVariables
    local now = GetNowMs()
    local castTime = (sv and sv.castTimeMs) or defaults.castTimeMs
    local window   = (sv and sv.backToBackMs) or defaults.backToBackMs

    -- Unconditional diagnostic so we always see when StartCastAlert is
    -- reached, regardless of which settings are enabled.
    local immunityRemainingMs = GetImmunityRemainingMs()
    if debugEnabled then
        d(string.format("[SFA] cast detected; result=%s; CC immunity remaining=%.2fs; suppressOnImmune=%s",
            tostring(result), immunityRemainingMs / 1000,
            tostring(sv and sv.suppressOnImmune)))
    end

    -- Suppress only when the immunity will still be active when the stun
    -- actually LANDS (cast start + windup). A cast that begins during the
    -- tail of immunity but lands after it expires is the classic bait — the
    -- whole point of the back-to-back warning — so it must alert.
    if sv and sv.suppressOnImmune and immunityRemainingMs > castTime + 200 then
        -- Remember the suppressed cast so the first alert after immunity
        -- drops is flagged back-to-back instead of reading as a fresh opener.
        lastCastEndedMs = now + castTime
        return
    end

    -- Dedup: ESO always fires EFFECT_GAINED + EFFECT_GAINED_DURATION as a
    -- pair (within a few ms) for the same cast. Collapse that specific pair.
    -- Anything else — including a second EFFECT_GAINED, a refresh via
    -- EVENT_EFFECT_CHANGED, a STUNNED, or a BEGIN — counts as a real new cast.
    local sameSource = (sourceUnitId == nil)
        or (lastTriggerSourceUnitId == 0)
        or (sourceUnitId == lastTriggerSourceUnitId)
    local isPairedSameCast =
        ((lastTriggerResult == ACTION_RESULT_EFFECT_GAINED and result == ACTION_RESULT_EFFECT_GAINED_DURATION)
         or (lastTriggerResult == ACTION_RESULT_EFFECT_GAINED_DURATION and result == ACTION_RESULT_EFFECT_GAINED))
    local isContinuation = castActive
        and isPairedSameCast
        and (now - lastTriggerMs) < 300
        and sameSource

    lastTriggerResult = result or 0
    lastTriggerSourceUnitId = sourceUnitId or lastTriggerSourceUnitId
    lastTriggerMs = now

    if isContinuation then
        EnsureUpdateLoop()
        UpdateDisplayedAlert()
        return
    end

    -- Genuinely a new cast. It's back-to-back if either the previous alert
    -- is still on screen OR it ended within the configured window.
    local repeatCast = false
    if castActive then
        repeatCast = true
    elseif lastCastEndedMs > 0 and (now - lastCastEndedMs) <= window then
        repeatCast = true
    end

    isRepeatCast = repeatCast
    castActive = true
    castStartedMs = now
    castEndTimeMs = now + castTime
    castDurationMs = castTime

    EnsureUpdateLoop()
    UpdateDisplayedAlert()
    PlayAlertSound()
end

local function ClearAll()
    castActive = false
    castEndTimeMs = 0
    castDurationMs = 0
    isRepeatCast = false
    lastCastEndedMs = 0
    EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    if alertWindow and not (ShoyruFossilizeAlert.savedVariables and ShoyruFossilizeAlert.savedVariables.showTestAlert) then
        alertWindow:SetHidden(true)
    end
end

local function SaveWindowPosition()
    if not alertWindow or not ShoyruFossilizeAlert.savedVariables then return end
    local sv = ShoyruFossilizeAlert.savedVariables
    local cx, cy = alertWindow:GetCenter()
    local gw, gh = GuiRoot:GetWidth(), GuiRoot:GetHeight()
    sv.offsetX = cx - gw / 2
    sv.offsetY = cy - gh / 2
end

local function ApplyBorderStyle()
    if not iconBorder or not barBg then return end
    local sv = ShoyruFossilizeAlert.savedVariables
    local c = (sv and sv.borderColor) or defaults.borderColor

    local t = (sv and sv.borderThickness) or defaults.borderThickness
    if     t >= 8 then t = 8
    elseif t >= 4 then t = 4
    else                t = 2
    end

    iconBorder:SetEdgeTexture(nil, t, t, t, 0)
    iconBorder:SetEdgeColor(c.r, c.g, c.b, c.a or 1)
    barBg:SetEdgeTexture(nil, t, t, t, 0)
    barBg:SetEdgeColor(c.r, c.g, c.b, c.a or 1)
end

function ApplyLabelStyle()
    if not alertWindow or not iconTexture or not alertLabel or not timerLabel or not barBg then
        return
    end
    local w = alertWindow:GetWidth()
    local h = alertWindow:GetHeight()

    local iconSize = h
    iconTexture:ClearAnchors()
    iconTexture:SetAnchor(LEFT, alertWindow, LEFT, 0, 0)
    iconTexture:SetDimensions(iconSize, iconSize)

    local gap = math.max(2, math.floor(h * 0.06))
    local rightX = iconSize + gap
    local rightWidth = math.max(20, w - rightX)

    local mainSize = math.max(8, math.floor(math.min(h * 0.42, rightWidth * 0.18)))
    alertLabel:SetFont(string.format("$(BOLD_FONT)|%d|soft-shadow-thick", mainSize))
    alertLabel:ClearAnchors()
    alertLabel:SetAnchor(TOPLEFT, alertWindow, TOPLEFT, rightX + 2, math.floor(h * 0.05))
    alertLabel:SetAnchor(BOTTOMRIGHT, alertWindow, TOPRIGHT, -2, math.floor(h * 0.5))
    alertLabel:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
    alertLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)

    local barInset = math.max(1, math.floor(h * 0.06))
    barBg:ClearAnchors()
    barBg:SetAnchor(TOPLEFT, alertWindow, LEFT, rightX, math.floor(h * 0.1))
    barBg:SetAnchor(BOTTOMRIGHT, alertWindow, BOTTOMRIGHT, -barInset, -barInset)

    barFill:ClearAnchors()
    barFill:SetAnchor(TOPLEFT, barBg, TOPLEFT, 1, 1)
    barFill:SetAnchor(BOTTOMLEFT, barBg, BOTTOMLEFT, 1, -1)

    local timerSize = math.max(7, math.floor(math.min(h * 0.26, rightWidth * 0.10)))
    timerLabel:SetFont(string.format("$(MEDIUM_FONT)|%d|outline", timerSize))
    timerLabel:ClearAnchors()
    timerLabel:SetAnchor(RIGHT, barBg, RIGHT, -3, 0)
    timerLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    timerLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
end

local function SaveWindowDimensions()
    if not alertWindow or not ShoyruFossilizeAlert.savedVariables then return end
    local sv = ShoyruFossilizeAlert.savedVariables
    sv.width = alertWindow:GetWidth()
    sv.height = alertWindow:GetHeight()
    ApplyLabelStyle()
end

local function SetWindowInteractive(interactive)
    if not alertWindow then return end
    alertWindow:SetMovable(interactive)
    alertWindow:SetMouseEnabled(interactive)
    alertWindow:SetResizeHandleSize(interactive and 12 or 0)
end

local function CreateUI()
    alertWindow = WINDOW_MANAGER:CreateTopLevelWindow("ShoyruFossilizeAlertWindow")
    alertWindow:SetDimensions(220, 56)
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, 0, -200)
    alertWindow:SetMovable(false)
    alertWindow:SetMouseEnabled(false)
    alertWindow:SetClampedToScreen(true)
    alertWindow:SetDimensionConstraints(60, 20, 1200, 400)
    alertWindow:SetHidden(true)
    alertWindow:SetDrawTier(DT_HIGH)
    alertWindow:SetDrawLayer(DL_OVERLAY)

    alertWindow:SetHandler("OnMoveStop", SaveWindowPosition)
    alertWindow:SetHandler("OnResizeStop", function()
        SaveWindowDimensions()
        SaveWindowPosition()
    end)

    iconTexture = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_TEXTURE)
    local iconPath = GetAbilityIcon and GetAbilityIcon(ICON_ABILITY_ID)
    if iconPath and iconPath ~= "" then
        iconTexture:SetTexture(iconPath)
    end

    iconBorder = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_BACKDROP)
    iconBorder:SetAnchor(TOPLEFT, iconTexture, TOPLEFT, 0, 0)
    iconBorder:SetAnchor(BOTTOMRIGHT, iconTexture, BOTTOMRIGHT, 0, 0)
    iconBorder:SetCenterColor(0, 0, 0, 0)

    barBg = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_BACKDROP)
    barBg:SetCenterColor(0, 0, 0, 0.75)

    barFill = WINDOW_MANAGER:CreateControl(nil, barBg, CT_TEXTURE)
    barFill:SetColor(0.85, 0.85, 0.85, 0.95)

    alertLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    alertLabel:SetColor(1, 1, 1, 1)
    alertLabel:SetText(defaults.firstMessage)

    timerLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    timerLabel:SetColor(1, 1, 1, 1)
    timerLabel:SetText("")
    timerLabel:SetHidden(true)

    ApplyLabelStyle()
    ApplyBorderStyle()
end

local function TestTick()
    local sv = ShoyruFossilizeAlert.savedVariables
    local now = GetNowMs()
    local castTime = (sv and sv.castTimeMs) or defaults.castTimeMs
    if now - testLastTickMs >= castTime then
        testLastTickMs = now
        local mode = (sv and sv.testMode) or defaults.testMode
        if mode == "repeatOnly" then
            testStateRepeat = true
        else
            testStateRepeat = not testStateRepeat
        end
    end
    UpdateDisplayedAlert()
end

local function StartTestMode()
    local sv = ShoyruFossilizeAlert.savedVariables
    local mode = (sv and sv.testMode) or defaults.testMode
    testStateRepeat = (mode == "repeatOnly")
    testLastTickMs = GetNowMs()
    EVENT_MANAGER:UnregisterForUpdate(TEST_TIMER_NAME)
    EVENT_MANAGER:RegisterForUpdate(TEST_TIMER_NAME, 50, TestTick)
    UpdateDisplayedAlert()
end

local function StopTestMode()
    EVENT_MANAGER:UnregisterForUpdate(TEST_TIMER_NAME)
    UpdateDisplayedAlert()
end

local function OnCombatEvent(
    eventCode,
    result,
    isError,
    abilityName,
    abilityGraphic,
    abilityActionSlotType,
    sourceName,
    sourceType,
    targetName,
    targetType,
    hitValue,
    powerType,
    damageType,
    log,
    sourceUnitId,
    targetUnitId,
    abilityId,
    overflow
)
    local sv = ShoyruFossilizeAlert.savedVariables
    if not sv or not sv.enabled then return end
    if isError then return end
    if targetType ~= COMBAT_UNIT_TYPE_PLAYER then return end

    -- ACTION_RESULT_IMMUNE on us proves we're immune *right now*, but says
    -- nothing about how long — extend the flag only briefly and let the
    -- immunity buff events supply the real end time. DODGED is deliberately
    -- NOT treated as immunity: roll-dodging an attack does not grant CC
    -- immunity, and flagging 7s here suppressed the legitimate back-to-back
    -- alert after every dodged first cast.
    if result == ACTION_RESULT_IMMUNE then
        immuneUntilMs = math.max(immuneUntilMs, GetNowMs() + 1000)
    end

    -- The Crowd Control Immunity buff itself firing on us is the most precise
    -- signal we get. hitValue carries the buff duration in ms.
    if abilityId == CC_IMMUNITY_ABILITY_ID
        and (result == ACTION_RESULT_EFFECT_GAINED
             or result == ACTION_RESULT_EFFECT_GAINED_DURATION) then
        local duration = (hitValue and hitValue > 0) and hitValue or IMMUNITY_FLAG_MS
        immuneUntilMs = math.max(immuneUntilMs, GetNowMs() + duration)
    end

    -- Diagnostic logging for finding the right ability IDs / result codes.
    if debugEnabled then
        d(string.format("[SFA] result=%d ability=%s id=%d source=%s",
            result, tostring(abilityName), abilityId, tostring(sourceName)))
    end

    if not TRACKED_IDS[abilityId] then return end

    if result == ACTION_RESULT_BEGIN
        or result == ACTION_RESULT_EFFECT_GAINED
        or result == ACTION_RESULT_EFFECT_GAINED_DURATION
        or result == ACTION_RESULT_STUNNED then
        StartCastAlert(result, sourceUnitId)
    end
end

-- ESO can suppress EFFECT_GAINED on EVENT_COMBAT_EVENT when the same debuff
-- is re-applied to a target already affected; the refresh fires through
-- EVENT_EFFECT_CHANGED with EFFECT_RESULT_UPDATED instead. Listen for it so
-- back-to-back casts always register.
local function OnEffectChanged(
    eventCode, changeType, effectSlot, effectName, unitTag,
    beginTime, endTime, stackCount, iconName, buffType,
    effectType, abilityType, statusEffectType, unitName,
    unitId, abilityId, sourceType
)
    local sv = ShoyruFossilizeAlert.savedVariables
    if not sv or not sv.enabled then return end
    if unitTag ~= "player" then return end

    if debugEnabled then
        d(string.format("[SFA-effect] changeType=%d ability=%s id=%d",
            changeType, tostring(effectName), abilityId))
    end

    -- Any known immunity buff: lock our immunity timestamp to the buff's
    -- reported duration. EVENT_EFFECT_CHANGED is more reliable than COMBAT
    -- for buff application/refresh events on the player. Match "anything
    -- except fading" rather than specific constants, because the numeric
    -- values of EFFECT_RESULT_GAINED / _UPDATED have shifted across ESO
    -- versions and we've seen changeType=2 in practice not match either.
    if IMMUNITY_BUFF_IDS[abilityId] then
        if changeType == EFFECT_RESULT_FADED then
            -- Immunity ended (possibly early): drop the flag to "now" so a
            -- cast that starts right after break-free immunity falls off
            -- alerts immediately. If another immunity buff is still up, the
            -- buff scan in GetImmunityRemainingMs still reports it.
            immuneUntilMs = math.min(immuneUntilMs, GetNowMs())
            if debugEnabled then
                d(string.format("[SFA] immunity buff %d faded", abilityId))
            end
        else
            local durMs = IMMUNITY_FLAG_MS
            if beginTime and endTime and endTime > beginTime then
                durMs = (endTime - beginTime) * 1000
            end
            immuneUntilMs = math.max(immuneUntilMs, GetNowMs() + durMs)
            if debugEnabled then
                d(string.format("[SFA] CC immunity ON: %.1fs remaining (id=%d changeType=%d)",
                    durMs / 1000, abilityId, changeType))
            end
        end
        return
    end

    if not TRACKED_IDS[abilityId] then return end

    -- We only need UPDATED here. GAINED is already handled by EVENT_COMBAT_EVENT
    -- via ACTION_RESULT_EFFECT_GAINED on first application; double-firing it
    -- would defeat the dedup.
    if changeType == EFFECT_RESULT_UPDATED then
        StartCastAlert(SYNTHETIC_RESULT_REFRESH, nil)
    end
end

function ShoyruFossilizeAlert:CreateSettings()
    local LAM = LibAddonMenu2
    if not LAM then return end

    local panelData = {
        type = "panel",
        name = "Shoyru's Fossilize Alert",
        displayName = "Shoyru's Fossilize Alert",
        author = "Shoyru",
        version = ShoyruFossilizeAlert.version,
        registerForRefresh = true,
        registerForDefaults = true,
    }

    LAM:RegisterAddonPanel("ShoyruFossilizeAlertOptions", panelData)

    local optionsTable = {
        {
            type = "description",
            text = "Tracks incoming Fossilize, Petrify, and Shattering Rocks casts from enemy Dragonknights. The instant the windup is detected, the alert pops up with a countdown bar so you can time your roll dodge before the stun lands. If a second cast is detected within the back-to-back window (set below), the message and color switch to the back-to-back set — the bait follow-up players use when they expect you to dodge the first one.\n\nUnlock the alert in the Layout section to drag/resize it. Custom mp3 sounds are not supported by ESO; only built-in game sounds.",
            width = "full",
        },
        {
            type = "checkbox",
            name = "Activate Addon",
            tooltip = "Enable or disable Fossilize/Petrify/Shattering Rocks tracking.",
            getFunc = function() return ShoyruFossilizeAlert.savedVariables.enabled end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.enabled = value
                if not value then ClearAll() end
            end,
            default = defaults.enabled,
        },
        {
            type = "checkbox",
            name = "Suppress while CC immune",
            tooltip = "Don't show the alert if you currently have CC immunity (just broke free, just roll-dodged, etc.). The stun won't land anyway, so the alert would be noise.",
            getFunc = function()
                return ShoyruFossilizeAlert.savedVariables.suppressOnImmune
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.suppressOnImmune = value
            end,
            default = defaults.suppressOnImmune,
        },
        {
            type = "header",
            name = "Messages",
        },
        {
            type = "editbox",
            name = "First cast message",
            tooltip = "Shown the moment an enemy starts casting Fossilize on you.",
            getFunc = function() return ShoyruFossilizeAlert.savedVariables.firstMessage end,
            setFunc = function(value)
                if value == nil or value == "" then value = defaults.firstMessage end
                ShoyruFossilizeAlert.savedVariables.firstMessage = value
                UpdateDisplayedAlert()
            end,
            default = defaults.firstMessage,
            isMultiline = false,
        },
        {
            type = "editbox",
            name = "Back-to-back cast message",
            tooltip = "Shown when a second Fossilize cast is detected shortly after the first (the caster is baiting your roll dodge).",
            getFunc = function() return ShoyruFossilizeAlert.savedVariables.repeatMessage end,
            setFunc = function(value)
                if value == nil or value == "" then value = defaults.repeatMessage end
                ShoyruFossilizeAlert.savedVariables.repeatMessage = value
                UpdateDisplayedAlert()
            end,
            default = defaults.repeatMessage,
            isMultiline = false,
        },
        {
            type = "slider",
            name = "Back-to-back window (seconds)",
            tooltip = "If another Fossilize cast is detected within this many seconds of the previous one, the back-to-back message is shown instead of the first message.",
            min = 1.0,
            max = 12.0,
            step = 0.5,
            decimals = 1,
            getFunc = function()
                local ms = ShoyruFossilizeAlert.savedVariables.backToBackMs or defaults.backToBackMs
                return ms / 1000
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.backToBackMs = math.floor(value * 1000)
            end,
            default = defaults.backToBackMs / 1000,
        },
        {
            type = "slider",
            name = "Cast time (seconds)",
            tooltip = "How long the windup lasts before the stun lands. Default 1.1s matches the observed delay between cast detection and the stun landing.",
            min = 0.1,
            max = 4.0,
            step = 0.1,
            decimals = 1,
            getFunc = function()
                local ms = ShoyruFossilizeAlert.savedVariables.castTimeMs or defaults.castTimeMs
                return ms / 1000
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.castTimeMs = math.floor(value * 1000)
            end,
            default = defaults.castTimeMs / 1000,
        },
        {
            type = "header",
            name = "Colors",
        },
        {
            type = "colorpicker",
            name = "Color (first cast)",
            tooltip = "Color used for the label and bar fill on the first cast.",
            getFunc = function()
                local c = ShoyruFossilizeAlert.savedVariables.colorFirst or defaults.colorFirst
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                ShoyruFossilizeAlert.savedVariables.colorFirst = { r = r, g = g, b = b, a = a or 1 }
                UpdateDisplayedAlert()
            end,
            default = defaults.colorFirst,
        },
        {
            type = "colorpicker",
            name = "Color (back-to-back cast)",
            tooltip = "Color used when a follow-up cast is detected within the back-to-back window.",
            getFunc = function()
                local c = ShoyruFossilizeAlert.savedVariables.colorRepeat or defaults.colorRepeat
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                ShoyruFossilizeAlert.savedVariables.colorRepeat = { r = r, g = g, b = b, a = a or 1 }
                UpdateDisplayedAlert()
            end,
            default = defaults.colorRepeat,
        },
        {
            type = "header",
            name = "Border",
        },
        {
            type = "colorpicker",
            name = "Border color",
            tooltip = "Dark UI style edge around the icon and the timer bar.",
            getFunc = function()
                local c = ShoyruFossilizeAlert.savedVariables.borderColor or defaults.borderColor
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                ShoyruFossilizeAlert.savedVariables.borderColor = { r = r, g = g, b = b, a = a or 1 }
                ApplyBorderStyle()
            end,
            default = defaults.borderColor,
        },
        {
            type = "dropdown",
            name = "Border thickness",
            tooltip = "How thick the border is drawn.",
            choices = { "Thin", "Medium", "Thick" },
            choicesValues = { 2, 4, 8 },
            getFunc = function()
                return ShoyruFossilizeAlert.savedVariables.borderThickness or defaults.borderThickness
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.borderThickness = value
                ApplyBorderStyle()
            end,
            default = defaults.borderThickness,
        },
        {
            type = "slider",
            name = "Border opacity",
            tooltip = "0% is fully transparent, 100% is solid.",
            min = 0,
            max = 100,
            step = 5,
            getFunc = function()
                local c = ShoyruFossilizeAlert.savedVariables.borderColor or defaults.borderColor
                return math.floor(((c.a or 1)) * 100 + 0.5)
            end,
            setFunc = function(value)
                local c = ShoyruFossilizeAlert.savedVariables.borderColor or defaults.borderColor
                ShoyruFossilizeAlert.savedVariables.borderColor = {
                    r = c.r, g = c.g, b = c.b, a = value / 100,
                }
                ApplyBorderStyle()
            end,
            default = math.floor(((defaults.borderColor.a or 1)) * 100 + 0.5),
        },
        {
            type = "header",
            name = "Sound",
        },
        {
            type = "checkbox",
            name = "Play sound on cast",
            tooltip = "Play a sound the moment Fossilize is detected.",
            getFunc = function() return ShoyruFossilizeAlert.savedVariables.soundAlert end,
            setFunc = function(value) ShoyruFossilizeAlert.savedVariables.soundAlert = value end,
            default = defaults.soundAlert,
        },
        {
            type = "dropdown",
            name = "Alert sound",
            tooltip = "Which built-in ESO sound to play. The sound is previewed when you pick it. Custom mp3 files are not supported by the game.",
            choices = SOUND_DISPLAY_NAMES,
            choicesValues = SOUND_KEYS,
            getFunc = function()
                return ShoyruFossilizeAlert.savedVariables.soundName or defaults.soundName
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.soundName = value
                PlaySoundAtVolume(value)
            end,
            default = defaults.soundName,
        },
        {
            type = "slider",
            name = "Alert loudness",
            tooltip = "1 is the sound's normal volume; higher values layer the sound to make it louder. The sound previews when you adjust it. ESO can't play sounds quieter than normal — to reduce volume below 1, lower Audio > Interface Sounds in the game settings or pick a softer sound.",
            min = 1,
            max = 5,
            step = 1,
            getFunc = function()
                return ShoyruFossilizeAlert.savedVariables.soundVolume or defaults.soundVolume
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.soundVolume = value
                local sv = ShoyruFossilizeAlert.savedVariables
                PlaySoundAtVolume((sv and sv.soundName) or defaults.soundName)
            end,
            default = defaults.soundVolume,
        },
        {
            type = "button",
            name = "Test sound",
            tooltip = "Play the currently selected alert sound at the configured loudness.",
            func = function()
                local sv = ShoyruFossilizeAlert.savedVariables
                PlaySoundAtVolume((sv and sv.soundName) or defaults.soundName)
            end,
        },
        {
            type = "header",
            name = "Layout",
        },
        {
            type = "checkbox",
            name = "Unlock alert (test mode)",
            tooltip = "Drives the preview. While enabled you can drag the alert to move it and drag the bottom-right corner to resize it. Disable when finished.",
            getFunc = function()
                return ShoyruFossilizeAlert.savedVariables.showTestAlert
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.showTestAlert = value
                SetWindowInteractive(value)
                if value then StartTestMode() else StopTestMode() end
            end,
            default = defaults.showTestAlert,
        },
        {
            type = "dropdown",
            name = "Preview mode",
            tooltip = "\"Cycle\" alternates between first-cast and back-to-back states. \"Back-to-back only\" parks on the follow-up state so you can tune that color/message in isolation.",
            choices = { "Cycle (first <-> back-to-back)", "Back-to-back only" },
            choicesValues = { "cycle", "repeatOnly" },
            getFunc = function()
                return ShoyruFossilizeAlert.savedVariables.testMode or defaults.testMode
            end,
            setFunc = function(value)
                ShoyruFossilizeAlert.savedVariables.testMode = value
                if ShoyruFossilizeAlert.savedVariables.showTestAlert then
                    StartTestMode()
                end
            end,
            default = defaults.testMode,
        },
        {
            type = "button",
            name = "Reset layout",
            tooltip = "Restore default position, size, messages, colors, and border.",
            func = function()
                local sv = ShoyruFossilizeAlert.savedVariables
                sv.offsetX = defaults.offsetX
                sv.offsetY = defaults.offsetY
                sv.width = defaults.width
                sv.height = defaults.height
                sv.scale = defaults.scale
                sv.showTestAlert = defaults.showTestAlert
                sv.firstMessage = defaults.firstMessage
                sv.repeatMessage = defaults.repeatMessage
                sv.castTimeMs = defaults.castTimeMs
                sv.backToBackMs = defaults.backToBackMs
                sv.colorFirst = {
                    r = defaults.colorFirst.r, g = defaults.colorFirst.g,
                    b = defaults.colorFirst.b, a = defaults.colorFirst.a,
                }
                sv.colorRepeat = {
                    r = defaults.colorRepeat.r, g = defaults.colorRepeat.g,
                    b = defaults.colorRepeat.b, a = defaults.colorRepeat.a,
                }
                sv.borderColor = {
                    r = defaults.borderColor.r, g = defaults.borderColor.g,
                    b = defaults.borderColor.b, a = defaults.borderColor.a,
                }
                sv.borderThickness = defaults.borderThickness
                sv.soundName = defaults.soundName
                sv.soundVolume = defaults.soundVolume
                sv.testMode = defaults.testMode

                StopTestMode()
                ApplyAlertLayout()
                ApplyBorderStyle()
                SetWindowInteractive(false)
                UpdateDisplayedAlert()
            end,
            warning = "This will reset every layout, message, color, and border setting.",
        },
    }

    LAM:RegisterOptionControls("ShoyruFossilizeAlertOptions", optionsTable)
end

local function RegisterEvents()
    EVENT_MANAGER:RegisterForEvent(COMBAT_EVENT_NAME, EVENT_COMBAT_EVENT, OnCombatEvent)
    EVENT_MANAGER:AddFilterForEvent(
        COMBAT_EVENT_NAME,
        EVENT_COMBAT_EVENT,
        REGISTER_FILTER_TARGET_COMBAT_UNIT_TYPE,
        COMBAT_UNIT_TYPE_PLAYER
    )

    -- Filter on unitTag = "player" so we only see effects affecting us.
    EVENT_MANAGER:RegisterForEvent(EFFECT_EVENT_NAME, EVENT_EFFECT_CHANGED, OnEffectChanged)
    EVENT_MANAGER:AddFilterForEvent(
        EFFECT_EVENT_NAME,
        EVENT_EFFECT_CHANGED,
        REGISTER_FILTER_UNIT_TAG,
        "player"
    )

    SLASH_COMMANDS["/sfadebug"] = function()
        debugEnabled = not debugEnabled
        d("[SFA] debug logging " .. (debugEnabled and "ON" or "OFF"))
    end
end

local function OnAddonLoaded(event, addonName)
    if addonName ~= ADDON_NAME then return end

    EVENT_MANAGER:UnregisterForEvent(LOAD_EVENT_NAME, EVENT_ADD_ON_LOADED)

    ShoyruFossilizeAlert.savedVariables = ZO_SavedVars:NewAccountWide(
        "ShoyruFossilizeAlertSavedVariables",
        1,
        nil,
        defaults
    )

    CreateUI()
    ApplyAlertLayout()
    ShoyruFossilizeAlert:CreateSettings()
    RegisterEvents()

    SetWindowInteractive(ShoyruFossilizeAlert.savedVariables.showTestAlert)
    if ShoyruFossilizeAlert.savedVariables.showTestAlert then
        StartTestMode()
    else
        UpdateDisplayedAlert()
    end
end

EVENT_MANAGER:RegisterForEvent(LOAD_EVENT_NAME, EVENT_ADD_ON_LOADED, OnAddonLoaded)
