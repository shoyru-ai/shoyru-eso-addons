KjalnarBoneTracker = {}
KjalnarBoneTracker.name = "ShoyruKjalnarBoneTracker"
KjalnarBoneTracker.version = "2.1"

local ADDON_NAME = KjalnarBoneTracker.name
local EFFECT_EVENT_NAME = ADDON_NAME .. "_Effect"
local TIMER_NAME = ADDON_NAME .. "_Timer"
local TEST_TIMER_NAME = ADDON_NAME .. "_TestTimer"
local LOAD_EVENT_NAME = ADDON_NAME .. "_Loaded"

local BONE_ABILITY_ID = 133505

-- Default debuff duration when the system doesn't report one.
local DEFAULT_STACK_DURATION_MS = 5000

-- Curated list of built-in ESO sounds that are loud enough to function as
-- alerts. Display name -> SOUNDS key.
local SOUND_DISPLAY_NAMES = {
    "Duel Invite",
    "Duel Start",
    "New Notification",
    "Major Buff",
    "Ultimate Ready",
    "Group Invite",
    "Alert Error",
    "Quest Accepted",
    "Objective Complete",
    "Medal Earned",
    "Champion Points",
    "Death Recap",
}
local SOUND_KEYS = {
    "DUEL_INVITE_RECEIVED",
    "DUEL_START",
    "NEW_NOTIFICATION",
    "ABILITY_MAJOR_BUFF",
    "ABILITY_ULTIMATE_READY",
    "GROUP_INVITE",
    "GENERAL_ALERT_ERROR",
    "QUEST_ACCEPTED",
    "OBJECTIVE_COMPLETED",
    "BATTLEGROUND_MEDAL_EARNED",
    "CHAMPION_POINTS_COMMITTED",
    "DEATH_RECAP_KILLING_BLOW_SHOWN",
}

local defaults = {
    enabled = true,
    soundAlert = true,
    soundName = "DUEL_INVITE_RECEIVED",
    soundVolume = 1, -- 1 = normal; higher stacks the sound for extra loudness
    stackLabel = "BONE",
    stunMessage = "STUN NOW!",

    -- Per-stack colors. Stacks 1-3 use the build color. At 4 stacks the color
    -- progresses through stun -> warn -> urgent as the debuff expires.
    colorBuild      = { r = 0.95, g = 0.83, b = 0.49, a = 1 }, -- ESO gold (1-3)
    colorStun       = { r = 0.91, g = 0.32, b = 0.32, a = 1 }, -- red    (4 stacks, fresh)
    colorStunWarn   = { r = 1.00, g = 0.60, b = 0.20, a = 1 }, -- amber  (under warn threshold)
    colorStunUrgent = { r = 1.00, g = 0.15, b = 0.15, a = 1 }, -- vivid  (under urgent threshold)

    -- Seconds remaining at which the stack-4 color switches.
    stunWarnAt   = 2.0,
    stunUrgentAt = 1.0,

    -- Border (Dark UI style) drawn around the icon and the status bar.
    borderColor = { r = 0, g = 0, b = 0, a = 1 },
    borderThickness = 2, -- must be a power of two: 2, 4, or 8.

    -- "cycle" walks through stacks 1->4. "stunOnly" parks on stack 4 so the
    -- threshold color transitions can be observed end-to-end.
    testMode = "cycle",

    -- Layout
    offsetX = 0,
    offsetY = -260,
    width = 220,
    height = 56,
    scale = 1.0,

    -- Test display
    showTestAlert = false,
}

-- ESO's PlaySound has no volume parameter; playing the same sound multiple
-- times in one frame sums amplitude, so soundVolume > 1 means louder.
local function PlaySoundAtVolume(key)
    local sound = SOUNDS and SOUNDS[key]
    if not sound then return end
    local sv = KjalnarBoneTracker.savedVariables
    local volume = math.max(1, math.floor((sv and sv.soundVolume) or defaults.soundVolume))
    for _ = 1, volume do
        PlaySound(sound)
    end
end

local function PlayAlertSound()
    local sv = KjalnarBoneTracker.savedVariables
    if not sv or not sv.soundAlert then
        return
    end
    PlaySoundAtVolume(sv.soundName or defaults.soundName)
end

local alertWindow = nil
local alertLabel = nil
local timerLabel = nil
local iconTexture = nil
local iconBorder = nil
local stackCountLabel = nil
local barBg = nil
local barFill = nil

-- Per-target stack tracking. key = targetUnitId, value = {stacks, endTime, duration}
local stacksByTarget = {}
local activeTargetId = nil
local activeStackCount = 0
local activeEndTimeMs = 0
local activeDurationMs = 0

-- Test mode state
local testStack = 1
local testLastTickMs = 0

local function GetNowMs()
    return GetFrameTimeMilliseconds()
end

local ApplyLabelStyle -- forward declaration; defined later, after labels exist.

local function ApplyAlertLayout()
    if not alertWindow or not KjalnarBoneTracker.savedVariables then
        return
    end

    local sv = KjalnarBoneTracker.savedVariables

    alertWindow:ClearAnchors()
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, sv.offsetX or 0, sv.offsetY or -260)
    alertWindow:SetDimensions(sv.width or 220, sv.height or 56)
    alertWindow:SetScale(sv.scale or 1.0)

    if ApplyLabelStyle then ApplyLabelStyle() end
end

local function GetColorForState(stacks, remainingMs)
    local sv = KjalnarBoneTracker.savedVariables
    local c
    if stacks and stacks >= 4 then
        local remainSec = (remainingMs or 0) / 1000
        local urgentAt = (sv and sv.stunUrgentAt) or defaults.stunUrgentAt
        local warnAt   = (sv and sv.stunWarnAt)   or defaults.stunWarnAt
        if remainSec <= urgentAt then
            c = (sv and sv.colorStunUrgent) or defaults.colorStunUrgent
        elseif remainSec <= warnAt then
            c = (sv and sv.colorStunWarn) or defaults.colorStunWarn
        else
            c = (sv and sv.colorStun) or defaults.colorStun
        end
    else
        c = (sv and sv.colorBuild) or defaults.colorBuild
    end
    return { c.r, c.g, c.b, c.a or 1 }
end

local function GetDisplayForStacks(stacks, remainingMs)
    local sv = KjalnarBoneTracker.savedVariables
    if not stacks or stacks <= 0 then
        return nil, nil
    end

    local color = GetColorForState(stacks, remainingMs)
    if stacks >= 4 then
        local msg = (sv and sv.stunMessage) or defaults.stunMessage
        return msg, color
    end

    local label = (sv and sv.stackLabel) or defaults.stackLabel
    return label, color
end

local function RenderDisplay(stacks, remainingMs, durationMs)
    if not alertLabel or not alertWindow or not barBg or not barFill then
        return
    end

    local text, color = GetDisplayForStacks(stacks, remainingMs)
    if not text or not stacks or stacks <= 0 then
        alertWindow:SetHidden(true)
        return
    end

    alertLabel:SetText(text)
    if color then
        alertLabel:SetColor(color[1], color[2], color[3], color[4])
        barFill:SetColor(color[1], color[2], color[3], 0.95)
    end

    if stackCountLabel then
        stackCountLabel:SetText(tostring(stacks))
        stackCountLabel:SetHidden(false)
    end

    -- Drive the status bar fill width from progress.
    local total = (durationMs and durationMs > 0) and durationMs or DEFAULT_STACK_DURATION_MS
    local progress = (remainingMs and remainingMs > 0) and (remainingMs / total) or 0
    if progress > 1 then progress = 1 end
    local barWidth = math.max(2, barBg:GetWidth() - 2)
    barFill:SetWidth(barWidth * progress)
    barFill:SetHidden(progress <= 0)

    if remainingMs and remainingMs > 0 then
        timerLabel:SetText(string.format("%.1fs", remainingMs / 1000))
        timerLabel:SetHidden(false)
    else
        timerLabel:SetText("")
        timerLabel:SetHidden(true)
    end

    alertWindow:SetHidden(false)
end

local function UpdateDisplayedAlert()
    if not alertLabel or not alertWindow then
        return
    end

    local sv = KjalnarBoneTracker.savedVariables

    -- Test mode takes priority
    if sv and sv.showTestAlert then
        local elapsed = GetNowMs() - testLastTickMs
        local remaining = math.max(0, DEFAULT_STACK_DURATION_MS - elapsed)
        RenderDisplay(testStack, remaining, DEFAULT_STACK_DURATION_MS)
        return
    end

    local now = GetNowMs()
    if activeStackCount <= 0 or now >= activeEndTimeMs then
        alertWindow:SetHidden(true)
        return
    end

    RenderDisplay(activeStackCount, activeEndTimeMs - now, activeDurationMs)
end

local function ChooseActiveTarget()
    -- Pick the most recently applied non-expired target.
    local now = GetNowMs()
    local bestId, bestEntry = nil, nil

    for id, entry in pairs(stacksByTarget) do
        if entry.endTime <= now then
            stacksByTarget[id] = nil
        else
            if not bestEntry or entry.endTime > bestEntry.endTime then
                bestId = id
                bestEntry = entry
            end
        end
    end

    if bestEntry then
        activeTargetId = bestId
        activeStackCount = bestEntry.stacks
        activeEndTimeMs = bestEntry.endTime
        activeDurationMs = bestEntry.duration or DEFAULT_STACK_DURATION_MS
    else
        activeTargetId = nil
        activeStackCount = 0
        activeEndTimeMs = 0
        activeDurationMs = 0
    end
end

local function StopUpdateLoopIfIdle()
    if activeStackCount <= 0 and not (KjalnarBoneTracker.savedVariables and KjalnarBoneTracker.savedVariables.showTestAlert) then
        EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    end
end

local function TickUpdate()
    ChooseActiveTarget()
    UpdateDisplayedAlert()
    StopUpdateLoopIfIdle()
end

local function EnsureUpdateLoop()
    EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    EVENT_MANAGER:RegisterForUpdate(TIMER_NAME, 100, TickUpdate)
end

local function TestTick()
    local now = GetNowMs()
    if now - testLastTickMs >= DEFAULT_STACK_DURATION_MS then
        testLastTickMs = now
        local sv = KjalnarBoneTracker.savedVariables
        local mode = (sv and sv.testMode) or defaults.testMode
        if mode == "stunOnly" then
            testStack = 4
        else
            testStack = testStack + 1
            if testStack > 4 then testStack = 1 end
        end
    end
    UpdateDisplayedAlert()
end

local function StartTestMode()
    local sv = KjalnarBoneTracker.savedVariables
    local mode = (sv and sv.testMode) or defaults.testMode
    testStack = (mode == "stunOnly") and 4 or 1
    testLastTickMs = GetNowMs()
    EVENT_MANAGER:UnregisterForUpdate(TEST_TIMER_NAME)
    EVENT_MANAGER:RegisterForUpdate(TEST_TIMER_NAME, 100, TestTick)
    UpdateDisplayedAlert()
end

local function StopTestMode()
    EVENT_MANAGER:UnregisterForUpdate(TEST_TIMER_NAME)
    UpdateDisplayedAlert()
end

local function RecordStackForTarget(targetUnitId, stackOverride, durationMs)
    local key = targetUnitId or 0
    local now = GetNowMs()
    local entry = stacksByTarget[key]

    local newStacks
    if stackOverride and stackOverride > 0 then
        newStacks = stackOverride
    elseif entry and now < entry.endTime then
        newStacks = (entry.stacks or 0) + 1
    else
        newStacks = 1
    end

    if newStacks > 4 then
        newStacks = 4
    end

    local lifetime = (durationMs and durationMs > 0) and durationMs or DEFAULT_STACK_DURATION_MS

    stacksByTarget[key] = {
        stacks = newStacks,
        endTime = now + lifetime,
        duration = lifetime,
    }
    activeTargetId = key
    activeStackCount = newStacks
    activeEndTimeMs = now + lifetime
    activeDurationMs = lifetime

    EnsureUpdateLoop()
    UpdateDisplayedAlert()

    -- Fire the alert when the enemy first reaches 4 stacks (the stun cue),
    -- not on every refresh while already at 4.
    local previousStacks = entry and entry.stacks or 0
    if newStacks == 4 and previousStacks < 4 then
        PlayAlertSound()
    end
end

local function ClearTarget(targetUnitId)
    local key = targetUnitId or 0
    stacksByTarget[key] = nil
    if activeTargetId == key then
        ChooseActiveTarget()
        UpdateDisplayedAlert()
        StopUpdateLoopIfIdle()
    end
end

local function ClearAll()
    stacksByTarget = {}
    activeTargetId = nil
    activeStackCount = 0
    activeEndTimeMs = 0
    activeDurationMs = 0
    EVENT_MANAGER:UnregisterForUpdate(TIMER_NAME)
    if alertWindow and not (KjalnarBoneTracker.savedVariables and KjalnarBoneTracker.savedVariables.showTestAlert) then
        alertWindow:SetHidden(true)
    end
end

local function SaveWindowPosition()
    if not alertWindow or not KjalnarBoneTracker.savedVariables then
        return
    end
    local sv = KjalnarBoneTracker.savedVariables
    local cx, cy = alertWindow:GetCenter()
    local gw, gh = GuiRoot:GetWidth(), GuiRoot:GetHeight()
    sv.offsetX = cx - gw / 2
    sv.offsetY = cy - gh / 2
end

function ApplyLabelStyle()
    if not alertWindow or not iconTexture or not alertLabel or not timerLabel or not barBg then
        return
    end
    local w = alertWindow:GetWidth()
    local h = alertWindow:GetHeight()

    -- Icon is a square the full height of the window, anchored to the left.
    local iconSize = h
    iconTexture:ClearAnchors()
    iconTexture:SetAnchor(LEFT, alertWindow, LEFT, 0, 0)
    iconTexture:SetDimensions(iconSize, iconSize)

    -- Stack count overlay in the bottom-right corner of the icon, ESO style.
    local stackFontSize = math.max(8, math.floor(iconSize * 0.34))
    stackCountLabel:SetFont(string.format("$(BOLD_FONT)|%d|outline", stackFontSize))
    stackCountLabel:ClearAnchors()
    stackCountLabel:SetAnchor(BOTTOMRIGHT, iconTexture, BOTTOMRIGHT, -2, -1)

    -- The right-hand region (next to the icon) holds the name and time bar.
    local gap = math.max(2, math.floor(h * 0.06))
    local rightX = iconSize + gap
    local rightWidth = math.max(20, w - rightX)

    -- Name label (top half of the right area).
    local mainSize = math.max(8, math.floor(math.min(h * 0.42, rightWidth * 0.18)))
    alertLabel:SetFont(string.format("$(BOLD_FONT)|%d|soft-shadow-thick", mainSize))
    alertLabel:ClearAnchors()
    alertLabel:SetAnchor(TOPLEFT, alertWindow, TOPLEFT, rightX + 2, math.floor(h * 0.05))
    alertLabel:SetAnchor(BOTTOMRIGHT, alertWindow, TOPRIGHT, -2, math.floor(h * 0.5))
    alertLabel:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
    alertLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)

    -- Status bar (bottom half of the right area).
    local barInset = math.max(1, math.floor(h * 0.06))
    barBg:ClearAnchors()
    barBg:SetAnchor(TOPLEFT, alertWindow, LEFT, rightX, math.floor(h * 0.1))
    barBg:SetAnchor(BOTTOMRIGHT, alertWindow, BOTTOMRIGHT, -barInset, -barInset)

    -- Fill is anchored on the left only; its width is driven by progress.
    barFill:ClearAnchors()
    barFill:SetAnchor(TOPLEFT, barBg, TOPLEFT, 1, 1)
    barFill:SetAnchor(BOTTOMLEFT, barBg, BOTTOMLEFT, 1, -1)

    -- Time remaining text, right-justified inside the bar.
    local timerSize = math.max(7, math.floor(math.min(h * 0.26, rightWidth * 0.10)))
    timerLabel:SetFont(string.format("$(MEDIUM_FONT)|%d|outline", timerSize))
    timerLabel:ClearAnchors()
    timerLabel:SetAnchor(RIGHT, barBg, RIGHT, -3, 0)
    timerLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    timerLabel:SetVerticalAlignment(TEXT_ALIGN_CENTER)
end

local function ApplyBorderStyle()
    if not iconBorder or not barBg then return end
    local sv = KjalnarBoneTracker.savedVariables
    local c = (sv and sv.borderColor) or defaults.borderColor

    -- Must be a power of two; clamp to one of the supported values.
    local t = (sv and sv.borderThickness) or defaults.borderThickness
    if     t >= 8 then t = 8
    elseif t >= 4 then t = 4
    else                t = 2
    end

    -- nil = engine's default solid 1px edge texture, which tints cleanly with
    -- SetEdgeColor (unlike named DDS textures that have their own hue).
    iconBorder:SetEdgeTexture(nil, t, t, t, 0)
    iconBorder:SetEdgeColor(c.r, c.g, c.b, c.a or 1)
    barBg:SetEdgeTexture(nil, t, t, t, 0)
    barBg:SetEdgeColor(c.r, c.g, c.b, c.a or 1)
end

local function SaveWindowDimensions()
    if not alertWindow or not KjalnarBoneTracker.savedVariables then
        return
    end
    local sv = KjalnarBoneTracker.savedVariables
    sv.width = alertWindow:GetWidth()
    sv.height = alertWindow:GetHeight()
    ApplyLabelStyle()
end

local function SetWindowInteractive(interactive)
    if not alertWindow then return end
    alertWindow:SetMovable(interactive)
    alertWindow:SetMouseEnabled(interactive)
    alertWindow:SetResizeHandleSize(interactive and 12 or 0)
end

local function CreateUI()
    alertWindow = WINDOW_MANAGER:CreateTopLevelWindow("KjalnarBoneTrackerWindow")
    alertWindow:SetDimensions(220, 56)
    alertWindow:SetAnchor(CENTER, GuiRoot, CENTER, 0, -260)
    alertWindow:SetMovable(false)
    alertWindow:SetMouseEnabled(false)
    alertWindow:SetClampedToScreen(true)
    alertWindow:SetDimensionConstraints(60, 20, 1200, 400)
    alertWindow:SetHidden(true)
    alertWindow:SetDrawTier(DT_HIGH)
    alertWindow:SetDrawLayer(DL_OVERLAY)

    alertWindow:SetHandler("OnMoveStop", SaveWindowPosition)
    alertWindow:SetHandler("OnResizeStop", function()
        SaveWindowDimensions()
        SaveWindowPosition()
    end)

    -- Square ability icon on the left, just like the game's native debuff tray.
    iconTexture = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_TEXTURE)
    local iconPath = GetAbilityIcon and GetAbilityIcon(BONE_ABILITY_ID)
    if iconPath and iconPath ~= "" then
        iconTexture:SetTexture(iconPath)
    end

    -- Dark UI style frame around the icon. Parented to the alert window
    -- (not the texture) so the edge renders reliably, and anchored to the
    -- icon's bounds so it tracks resizes.
    iconBorder = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_BACKDROP)
    iconBorder:SetAnchor(TOPLEFT, iconTexture, TOPLEFT, 0, 0)
    iconBorder:SetAnchor(BOTTOMRIGHT, iconTexture, BOTTOMRIGHT, 0, 0)
    iconBorder:SetCenterColor(0, 0, 0, 0)

    -- Stack count number overlaid on the icon's bottom-right corner.
    stackCountLabel = WINDOW_MANAGER:CreateControl(nil, iconTexture, CT_LABEL)
    stackCountLabel:SetColor(1, 1, 1, 1)
    stackCountLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    stackCountLabel:SetVerticalAlignment(TEXT_ALIGN_BOTTOM)
    stackCountLabel:SetText("")

    -- Status bar background sits to the right of the icon. Edge styled via
    -- ApplyBorderStyle() so the user's border color picker applies here too.
    barBg = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_BACKDROP)
    barBg:SetCenterColor(0, 0, 0, 0.75)

    -- Status bar fill. Width is set dynamically based on remaining time.
    barFill = WINDOW_MANAGER:CreateControl(nil, barBg, CT_TEXTURE)
    barFill:SetColor(0.85, 0.85, 0.85, 0.95)

    -- Name label above the bar (e.g. "BONE" or "STUN NOW!").
    alertLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    alertLabel:SetColor(1, 1, 1, 1)
    alertLabel:SetText("BONE")

    -- Time remaining text overlaid on the right edge of the bar.
    timerLabel = WINDOW_MANAGER:CreateControl(nil, alertWindow, CT_LABEL)
    timerLabel:SetColor(1, 1, 1, 1)
    timerLabel:SetText("")
    timerLabel:SetHidden(true)

    ApplyLabelStyle()
    ApplyBorderStyle()
end

local function OnEffectChanged(
    eventCode,
    changeType,
    effectSlot,
    effectName,
    unitTag,
    beginTime,
    endTime,
    stackCount,
    iconName,
    buffType,
    effectType,
    abilityType,
    statusEffectType,
    unitName,
    unitId,
    abilityId,
    sourceType
)
    if not KjalnarBoneTracker.savedVariables or not KjalnarBoneTracker.savedVariables.enabled then
        return
    end

    if abilityId ~= BONE_ABILITY_ID then
        return
    end

    if sourceType ~= COMBAT_UNIT_TYPE_PLAYER then
        return
    end

    local key = unitId
    if not key or key == 0 then
        key = 0
    end

    if changeType == EFFECT_RESULT_FADED then
        ClearTarget(key)
        return
    end

    -- GAINED or UPDATED: trust the system's stack count and reported duration.
    local durationMs = nil
    if beginTime and endTime and endTime > beginTime then
        durationMs = (endTime - beginTime) * 1000
    end

    if stackCount and stackCount > 0 then
        RecordStackForTarget(key, stackCount, durationMs)
    else
        RecordStackForTarget(key, nil, durationMs)
    end
end

function KjalnarBoneTracker:CreateSettings()
    local LAM = LibAddonMenu2
    if not LAM then
        return
    end

    local panelData = {
        type = "panel",
        name = "Shoyru's Kjalnar Bone Tracker",
        displayName = "Shoyru's Kjalnar Bone Tracker",
        author = "Shoyru",
        version = KjalnarBoneTracker.version,
        registerForRefresh = true,
        registerForDefaults = true,
    }

    LAM:RegisterAddonPanel("KjalnarBoneTrackerOptions", panelData)

    local optionsTable = {
        {
            type = "description",
            text = "Tracks the Bone Shattering Trauma debuff (Kjalnar's Nightmare set) applied by your own light attacks. Each light attack adds a stack; at 5 stacks the set procs damage on a stunned target — so the goal is to reach 4 stacks, stun the enemy, then land the 5th light attack while they're CC'd.\n\nThe alert shows the Bone debuff icon, the current stack count, and a depleting bar with seconds remaining. The label color follows the stack-4 color stages (fresh -> warn -> urgent) as the debuff expires so you can react before the window closes. Customize messages, colors, thresholds, border, and sound below.\n\nUnlock the alert in the Layout section to drag/resize it. Custom mp3 sounds are not supported by ESO; only built-in game sounds.",
            width = "full",
        },
        {
            type = "checkbox",
            name = "Activate Addon",
            tooltip = "Enable or disable bone stack tracking.",
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.enabled
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.enabled = value
                if not value then
                    ClearAll()
                end
            end,
            default = defaults.enabled,
        },
        {
            type = "colorpicker",
            name = "Color (stacks 1-3)",
            tooltip = "Color used for the name text and status bar fill while the enemy has 1-3 bone stacks.",
            getFunc = function()
                local c = KjalnarBoneTracker.savedVariables.colorBuild or defaults.colorBuild
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                KjalnarBoneTracker.savedVariables.colorBuild = { r = r, g = g, b = b, a = a or 1 }
                UpdateDisplayedAlert()
            end,
            default = defaults.colorBuild,
        },
        {
            type = "colorpicker",
            name = "Color (stack 4 — fresh)",
            tooltip = "Color used the moment the enemy reaches 4 stacks, before the warn threshold.",
            getFunc = function()
                local c = KjalnarBoneTracker.savedVariables.colorStun or defaults.colorStun
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                KjalnarBoneTracker.savedVariables.colorStun = { r = r, g = g, b = b, a = a or 1 }
                UpdateDisplayedAlert()
            end,
            default = defaults.colorStun,
        },
        {
            type = "colorpicker",
            name = "Color (stack 4 — warn)",
            tooltip = "Color used at stack 4 once the remaining time drops below the warn threshold.",
            getFunc = function()
                local c = KjalnarBoneTracker.savedVariables.colorStunWarn or defaults.colorStunWarn
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                KjalnarBoneTracker.savedVariables.colorStunWarn = { r = r, g = g, b = b, a = a or 1 }
                UpdateDisplayedAlert()
            end,
            default = defaults.colorStunWarn,
        },
        {
            type = "colorpicker",
            name = "Color (stack 4 — urgent)",
            tooltip = "Color used at stack 4 once the remaining time drops below the urgent threshold.",
            getFunc = function()
                local c = KjalnarBoneTracker.savedVariables.colorStunUrgent or defaults.colorStunUrgent
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                KjalnarBoneTracker.savedVariables.colorStunUrgent = { r = r, g = g, b = b, a = a or 1 }
                UpdateDisplayedAlert()
            end,
            default = defaults.colorStunUrgent,
        },
        {
            type = "slider",
            name = "Warn threshold (seconds)",
            tooltip = "Switch to the warn color when this many seconds remain on the stack-4 debuff.",
            min = 0.1,
            max = 4.0,
            step = 0.1,
            decimals = 1,
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.stunWarnAt or defaults.stunWarnAt
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.stunWarnAt = value
                UpdateDisplayedAlert()
            end,
            default = defaults.stunWarnAt,
        },
        {
            type = "slider",
            name = "Urgent threshold (seconds)",
            tooltip = "Switch to the urgent color when this many seconds remain on the stack-4 debuff.",
            min = 0.1,
            max = 4.0,
            step = 0.1,
            decimals = 1,
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.stunUrgentAt or defaults.stunUrgentAt
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.stunUrgentAt = value
                UpdateDisplayedAlert()
            end,
            default = defaults.stunUrgentAt,
        },
        {
            type = "colorpicker",
            name = "Border color (icon + bar)",
            tooltip = "Dark UI style edge around the ability icon and the timer bar. Alpha works too if you want a softer frame.",
            getFunc = function()
                local c = KjalnarBoneTracker.savedVariables.borderColor or defaults.borderColor
                return c.r, c.g, c.b, c.a or 1
            end,
            setFunc = function(r, g, b, a)
                KjalnarBoneTracker.savedVariables.borderColor = { r = r, g = g, b = b, a = a or 1 }
                ApplyBorderStyle()
            end,
            default = defaults.borderColor,
        },
        {
            type = "dropdown",
            name = "Border thickness",
            tooltip = "How thick the border is drawn around the icon and the timer bar.",
            choices = { "Thin", "Medium", "Thick" },
            choicesValues = { 2, 4, 8 },
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.borderThickness or defaults.borderThickness
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.borderThickness = value
                ApplyBorderStyle()
            end,
            default = defaults.borderThickness,
        },
        {
            type = "slider",
            name = "Border opacity",
            tooltip = "How opaque the border is. 0% is fully transparent (invisible), 100% is solid.",
            min = 0,
            max = 100,
            step = 5,
            getFunc = function()
                local c = KjalnarBoneTracker.savedVariables.borderColor or defaults.borderColor
                return math.floor(((c.a or 1)) * 100 + 0.5)
            end,
            setFunc = function(value)
                local c = KjalnarBoneTracker.savedVariables.borderColor or defaults.borderColor
                KjalnarBoneTracker.savedVariables.borderColor = {
                    r = c.r, g = c.g, b = c.b, a = value / 100,
                }
                ApplyBorderStyle()
            end,
            default = math.floor(((defaults.borderColor.a or 1)) * 100 + 0.5),
        },
        {
            type = "checkbox",
            name = "Play sound at 4 stacks",
            tooltip = "Play a sound when the enemy reaches 4 bone stacks (the stun cue).",
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.soundAlert
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.soundAlert = value
            end,
            default = defaults.soundAlert,
        },
        {
            type = "dropdown",
            name = "Alert sound",
            tooltip = "Which built-in ESO sound to play at 4 stacks. The sound is previewed when you pick it. Custom mp3 files are not supported by the game.",
            choices = SOUND_DISPLAY_NAMES,
            choicesValues = SOUND_KEYS,
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.soundName or defaults.soundName
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.soundName = value
                PlaySoundAtVolume(value)
            end,
            default = defaults.soundName,
        },
        {
            type = "slider",
            name = "Alert loudness",
            tooltip = "1 is the sound's normal volume; higher values layer the sound to make it louder. The sound previews when you adjust it. ESO can't play sounds quieter than normal — lower Audio > Interface Sounds for that.",
            min = 1,
            max = 5,
            step = 1,
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.soundVolume or defaults.soundVolume
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.soundVolume = value
                local sv = KjalnarBoneTracker.savedVariables
                PlaySoundAtVolume((sv and sv.soundName) or defaults.soundName)
            end,
            default = defaults.soundVolume,
        },
        {
            type = "button",
            name = "Test sound",
            tooltip = "Play the currently selected alert sound at the configured loudness.",
            func = function()
                local sv = KjalnarBoneTracker.savedVariables
                PlaySoundAtVolume((sv and sv.soundName) or defaults.soundName)
            end,
        },
        {
            type = "header",
            name = "Messages",
        },
        {
            type = "editbox",
            name = "Stack label (stacks 1-3)",
            tooltip = "Word shown before the stack count for stacks 1-3 (e.g. \"BONE x2\"). Customize to whatever you want, like \"Test\".",
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.stackLabel
            end,
            setFunc = function(value)
                if value == nil or value == "" then
                    value = defaults.stackLabel
                end
                KjalnarBoneTracker.savedVariables.stackLabel = value
                UpdateDisplayedAlert()
            end,
            default = defaults.stackLabel,
            isMultiline = false,
        },
        {
            type = "editbox",
            name = "4-stack message",
            tooltip = "Text shown when the enemy has 4 bone stacks. This is your cue to stun before the 5th light attack.",
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.stunMessage
            end,
            setFunc = function(value)
                if value == nil or value == "" then
                    value = defaults.stunMessage
                end
                KjalnarBoneTracker.savedVariables.stunMessage = value
                UpdateDisplayedAlert()
            end,
            default = defaults.stunMessage,
            isMultiline = false,
        },
        {
            type = "header",
            name = "Layout",
        },
        {
            type = "checkbox",
            name = "Unlock alert (test mode)",
            tooltip = "Drives the preview. While enabled you can drag the alert to move it and drag the bottom-right corner to resize it. Disable when finished.",
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.showTestAlert
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.showTestAlert = value
                SetWindowInteractive(value)
                if value then
                    StartTestMode()
                else
                    StopTestMode()
                end
            end,
            default = defaults.showTestAlert,
        },
        {
            type = "dropdown",
            name = "Preview mode",
            tooltip = "What the test alert displays. \"Cycle 1-4\" walks through every stack; \"Stack 4 only\" parks on the 4-stack debuff so you can watch the color transition through warn/urgent thresholds.",
            choices = { "Cycle 1-4", "Stack 4 only" },
            choicesValues = { "cycle", "stunOnly" },
            getFunc = function()
                return KjalnarBoneTracker.savedVariables.testMode or defaults.testMode
            end,
            setFunc = function(value)
                KjalnarBoneTracker.savedVariables.testMode = value
                if KjalnarBoneTracker.savedVariables.showTestAlert then
                    StartTestMode()
                end
            end,
            default = defaults.testMode,
        },
        {
            type = "button",
            name = "Reset layout",
            tooltip = "Restore default alert position, size, and messages.",
            func = function()
                local sv = KjalnarBoneTracker.savedVariables
                sv.offsetX = defaults.offsetX
                sv.offsetY = defaults.offsetY
                sv.width = defaults.width
                sv.height = defaults.height
                sv.scale = defaults.scale
                sv.showTestAlert = defaults.showTestAlert
                sv.stackLabel = defaults.stackLabel
                sv.stunMessage = defaults.stunMessage
                sv.soundName = defaults.soundName
                sv.soundVolume = defaults.soundVolume
                sv.colorBuild = {
                    r = defaults.colorBuild.r,
                    g = defaults.colorBuild.g,
                    b = defaults.colorBuild.b,
                    a = defaults.colorBuild.a,
                }
                sv.colorStun = {
                    r = defaults.colorStun.r,
                    g = defaults.colorStun.g,
                    b = defaults.colorStun.b,
                    a = defaults.colorStun.a,
                }
                sv.colorStunWarn = {
                    r = defaults.colorStunWarn.r,
                    g = defaults.colorStunWarn.g,
                    b = defaults.colorStunWarn.b,
                    a = defaults.colorStunWarn.a,
                }
                sv.colorStunUrgent = {
                    r = defaults.colorStunUrgent.r,
                    g = defaults.colorStunUrgent.g,
                    b = defaults.colorStunUrgent.b,
                    a = defaults.colorStunUrgent.a,
                }
                sv.stunWarnAt = defaults.stunWarnAt
                sv.stunUrgentAt = defaults.stunUrgentAt
                sv.borderColor = {
                    r = defaults.borderColor.r,
                    g = defaults.borderColor.g,
                    b = defaults.borderColor.b,
                    a = defaults.borderColor.a,
                }
                sv.borderThickness = defaults.borderThickness
                sv.testMode = defaults.testMode
                ApplyBorderStyle()

                StopTestMode()
                ApplyAlertLayout()
                SetWindowInteractive(false)
                UpdateDisplayedAlert()
            end,
            warning = "This will reset alert layout and messages.",
        },
    }

    LAM:RegisterOptionControls("KjalnarBoneTrackerOptions", optionsTable)
end

local function RegisterEvents()
    -- Primary: EVENT_EFFECT_CHANGED gives us the system stack count directly.
    EVENT_MANAGER:RegisterForEvent(EFFECT_EVENT_NAME, EVENT_EFFECT_CHANGED, OnEffectChanged)
    EVENT_MANAGER:AddFilterForEvent(
        EFFECT_EVENT_NAME,
        EVENT_EFFECT_CHANGED,
        REGISTER_FILTER_ABILITY_ID,
        BONE_ABILITY_ID
    )
    EVENT_MANAGER:AddFilterForEvent(
        EFFECT_EVENT_NAME,
        EVENT_EFFECT_CHANGED,
        REGISTER_FILTER_SOURCE_COMBAT_UNIT_TYPE,
        COMBAT_UNIT_TYPE_PLAYER
    )

end

local function OnAddonLoaded(event, addonName)
    if addonName ~= ADDON_NAME then
        return
    end

    EVENT_MANAGER:UnregisterForEvent(LOAD_EVENT_NAME, EVENT_ADD_ON_LOADED)

    KjalnarBoneTracker.savedVariables = ZO_SavedVars:NewAccountWide(
        "KjalnarBoneTrackerSavedVariables",
        1,
        nil,
        defaults
    )

    CreateUI()
    ApplyAlertLayout()
    KjalnarBoneTracker:CreateSettings()
    RegisterEvents()

    SetWindowInteractive(KjalnarBoneTracker.savedVariables.showTestAlert)

    if KjalnarBoneTracker.savedVariables.showTestAlert then
        StartTestMode()
    else
        UpdateDisplayedAlert()
    end
end

EVENT_MANAGER:RegisterForEvent(LOAD_EVENT_NAME, EVENT_ADD_ON_LOADED, OnAddonLoaded)
