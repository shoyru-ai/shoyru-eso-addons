-- ShoyrUI :: Core/DuelHUD.lua
-- ===========================================================================
-- Live in-duel HUD -- "Duel Vitals".
-- A clean, movable, scalable card that shows your live OUT (DPS) / HEAL (HPS) /
-- IN (incoming DPS) / TIME while a duel is in progress, plus a diverging "tempo"
-- bar (the live damage-war: are you winning the exchange right now?). Refreshes
-- at ~10 Hz off DM.LiveSnapshot(), flashes on a new biggest hit, and freezes the
-- final numbers ("FINAL") for a few seconds when the duel ends.
--
-- Self-contained on purpose: its own palette / font / formatter so it never leans
-- on DuelMetricsUI's file-locals (that file is at the 200-local cap). Registers on
-- the shared ShoyrUI global as ShoyrUI.DuelHUD; reads live data through the
-- ShoyrUI.DuelMetrics seam only.
-- ===========================================================================

ShoyrUI = ShoyrUI or {}
local HUD = {}
ShoyrUI.DuelHUD = HUD

local WM = WINDOW_MANAGER
local EM = EVENT_MANAGER
local DM                       -- resolved to ShoyrUI.DuelMetrics at Init

-- Palette mirrors the analyzer's C so the HUD feels like part of the same suite.
local C = {
    bg     = { 0.055, 0.062, 0.078, 0.96 },  -- card background
    edge   = { 0.200, 0.220, 0.270, 1 },     -- card border
    track  = { 0.140, 0.150, 0.185, 1 },     -- tempo track
    hi     = { 0.930, 0.940, 0.960, 1 },     -- bright (flash / big numbers)
    mid    = { 0.560, 0.590, 0.660, 1 },     -- muted labels
    out    = { 0.910, 0.720, 0.360, 1 },     -- OUT  -- gold
    heal   = { 0.420, 0.820, 0.580, 1 },     -- HEAL -- green
    inc    = { 0.960, 0.540, 0.500, 1 },     -- IN   -- red
    time   = { 0.660, 0.700, 0.780, 1 },     -- TIME -- neutral
    accent = { 0.910, 0.720, 0.360, 1 },     -- live pulse / FINAL tag
}

-- Base geometry at scale 1.0. sv.scale multiplies every dimension + font into REAL pixels (see _Layout),
-- and the window's actual width = W * scale -- no SetScale (unreliable on a top-level window).
local W, PAD = 372, 12
local H_HEAD, H_CELLS, H_TEMPO = 20, 54, 24
local SCALE_MIN, SCALE_MAX = 0.6, 2.0
local FLASH_MS, HOLD_MS = 420, 6000

local function Font(size, weight)
    size = math.max(1, math.floor(size or 14))
    return string.format("%s|%d|soft", (weight == "bold") and "$(BOLD_FONT)" or "$(MEDIUM_FONT)", size)
end

local function Abbrev(n)
    n = n or 0
    if n >= 1e6 then return string.format("%.2fM", n / 1e6)
    elseif n >= 1e5 then return string.format("%.0fK", n / 1e3)
    elseif n >= 1e3 then return string.format("%.1fK", n / 1e3)
    else return tostring(math.floor(n + 0.5)) end
end
local function FmtTime(sec)
    sec = math.floor(sec or 0)
    return string.format("%d:%02d", math.floor(sec / 60), sec % 60)
end

-- A representative snapshot for the unlocked "place me" preview (no duel needed).
local PREVIEW = { out = 18400, hps = 6100, inc = 11200, dur = 42, maxHit = 0, active = true }
local ZERO = { out = 0, hps = 0, inc = 0, dur = 0, maxHit = 0, active = true }

-- ---- state ---------------------------------------------------------------
local sv                       -- sv.hud subtable (see HUD_DEFAULTS)
local win                      -- top-level window (nil until Build)
local ui = {}                  -- control refs: head, live, bg, cells{}, tempo{}
local state = { mode = "idle", last = nil, frozen = nil, flashUntil = 0, lastMax = 0, holdUntil = 0 }
local ticking = false

local HUD_DEFAULTS = {
    -- Defaults for a FRESH install (existing users keep their saved values). Ships UNLOCKED so a new
    -- user can immediately drag it into place (they'd otherwise have to find the settings toggle first),
    -- and smaller (0.75) so it's unobtrusive out of the box -- lock + resize to taste from there.
    enabled = true, x = nil, y = nil, scale = 0.75, opacity = 0.92, locked = false,
    show = { out = true, heal = true, inc = true, time = true, tempo = true },
    endStay = false,           -- false = hold then settle to idle; true = keep final numbers until next duel
}

-- The four metric cells, in display order. `key` indexes sv.hud.show.
local CELLS = {
    { key = "out",  label = "OUT",  col = C.out },
    { key = "heal", label = "HEAL", col = C.heal },
    { key = "inc",  label = "IN",   col = C.inc },
    { key = "time", label = "TIME", col = C.time },
}

-- ---- build ---------------------------------------------------------------
local function MakeCell(spec)
    local cell = WM:CreateControl(nil, win, CT_CONTROL)
    local lab = WM:CreateControl(nil, cell, CT_LABEL)
    lab:SetFont(Font(11, "bold")); lab:SetColor(unpack(C.mid))
    lab:SetHorizontalAlignment(TEXT_ALIGN_CENTER); lab:SetText(spec.label)
    lab:SetAnchor(TOP, cell, TOP, 0, 0)
    local val = WM:CreateControl(nil, cell, CT_LABEL)
    val:SetFont(Font(27, "bold")); val:SetColor(unpack(spec.col))
    val:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    val:SetAnchor(TOP, cell, TOP, 0, 15)
    return { cell = cell, lab = lab, val = val, spec = spec }
end

local function Build()
    if win then return end
    win = WM:CreateTopLevelWindow("ShoyruPvPMetricsHUD")
    win:SetClampedToScreen(true)
    win:SetHidden(true)
    win:SetDimensions(W, H_HEAD + H_CELLS + H_TEMPO)

    local bg = WM:CreateControl(nil, win, CT_TEXTURE)
    bg:SetAnchorFill(win)
    bg:SetColor(unpack(C.bg))
    ui.bg = bg

    -- top accent line (pulses while live, solid on FINAL)
    local acc = WM:CreateControl(nil, win, CT_TEXTURE)
    acc:SetColor(unpack(C.accent))
    acc:SetAnchor(TOPLEFT, win, TOPLEFT, 1, 1)
    acc:SetAnchor(TOPRIGHT, win, TOPRIGHT, -1, 1)
    acc:SetHeight(2)
    ui.acc = acc

    -- header: left tag + right LIVE/FINAL indicator
    local head = WM:CreateControl(nil, win, CT_LABEL)
    head:SetFont(Font(12, "bold")); head:SetColor(unpack(C.accent)); head:SetText("SMX")
    head:SetAnchor(TOPLEFT, win, TOPLEFT, PAD, 5)
    ui.head = head
    local live = WM:CreateControl(nil, win, CT_LABEL)
    live:SetFont(Font(11, "bold")); live:SetColor(unpack(C.accent))
    live:SetHorizontalAlignment(TEXT_ALIGN_RIGHT); live:SetText("LIVE")
    live:SetAnchor(TOPRIGHT, win, TOPRIGHT, -PAD, 6)
    ui.live = live

    ui.cells = {}
    for i = 1, #CELLS do ui.cells[i] = MakeCell(CELLS[i]) end

    -- tempo bar: track + diverging fill from centre + net-rate label
    local tempo = {}
    local track = WM:CreateControl(nil, win, CT_TEXTURE)
    track:SetColor(unpack(C.track))
    tempo.track = track
    local fill = WM:CreateControl(nil, win, CT_TEXTURE)
    fill:SetColor(unpack(C.out))
    tempo.fill = fill
    local ctr = WM:CreateControl(nil, win, CT_TEXTURE)
    ctr:SetColor(unpack(C.hi))
    tempo.ctr = ctr
    local net = WM:CreateControl(nil, win, CT_LABEL)
    net:SetFont(Font(11, "bold")); net:SetColor(unpack(C.mid))
    net:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    tempo.net = net
    ui.tempo = tempo

    -- resize grabber (bottom-right): a visual cue that the card is resizable while unlocked. The actual
    -- resize is NATIVE ESO edge/corner dragging (SetResizeHandleSize in Apply) -- reliable, unlike the
    -- old SetScale approach, which rendered unpredictably on a top-level window.
    local grip = WM:CreateControl(nil, win, CT_TEXTURE)
    grip:SetTexture("EsoUI/Art/ChatWindow/chat_size_grabber.dds")
    grip:SetDimensions(16, 16)
    grip:SetAnchor(BOTTOMRIGHT, win, BOTTOMRIGHT, -2, -2)
    grip:SetAlpha(0.6)
    grip:SetHidden(true)
    grip:SetMouseEnabled(false)   -- the native resize handle owns this corner
    ui.grip = grip

    win:SetHandler("OnMoveStop", function()
        if sv then sv.x, sv.y = win:GetLeft(), win:GetTop() end
    end)
    -- Native resize: while dragging, reflow the contents to the current width every frame (height locked
    -- to the card's aspect); on release, snap to the exact scaled size and persist it.
    win:SetHandler("OnResizeStart", function()
        EM:RegisterForUpdate("ShoyruPvPMetricsHUD_Rz", 16, function()
            if not win then return end
            local k = math.min(SCALE_MAX, math.max(SCALE_MIN, win:GetWidth() / W))
            HUD._Layout(k)
            win:SetHeight(HUD._TotalH(k))
        end)
    end)
    win:SetHandler("OnResizeStop", function()
        EM:UnregisterForUpdate("ShoyruPvPMetricsHUD_Rz")
        if sv then sv.scale = math.min(SCALE_MAX, math.max(SCALE_MIN, win:GetWidth() / W)) end
        HUD.Apply()
    end)
    -- Mouse wheel over the card (while unlocked) is a convenience resize.
    win:SetHandler("OnMouseWheel", function(_, delta)
        if not sv or sv.locked then return end
        sv.scale = math.min(SCALE_MAX, math.max(SCALE_MIN, (sv.scale or 1) + (delta > 0 and 0.1 or -0.1)))
        HUD.Apply()
    end)

    HUD.Apply()
end

-- Total card height at scale k (depends on whether the tempo bar is shown).
function HUD._TotalH(k)
    local show = (sv and sv.show) or HUD_DEFAULTS.show
    local h = (H_HEAD + H_CELLS) * k
    if show.tempo ~= false then h = h + H_TEMPO * k end
    return h
end

-- Lay out every child for scale k: fonts, the evenly-spread visible cells, and the tempo bar. Sizes are
-- REAL pixels (k x base), not SetScale. Does NOT set the window WIDTH -- Apply() and the live resize drag
-- own that; this just fits the contents to whatever width k implies.
function HUD._Layout(k)
    if not win then return end
    local pad, wpx, headH = PAD * k, W * k, H_HEAD * k
    local show = (sv and sv.show) or HUD_DEFAULTS.show
    ui.head:SetFont(Font(12 * k, "bold")); ui.head:ClearAnchors(); ui.head:SetAnchor(TOPLEFT, win, TOPLEFT, pad, 5 * k)
    ui.live:SetFont(Font(11 * k, "bold")); ui.live:ClearAnchors(); ui.live:SetAnchor(TOPRIGHT, win, TOPRIGHT, -pad, 6 * k)
    ui.acc:SetHeight(math.max(1, math.floor(2 * k)))
    local vis = {}
    for i = 1, #ui.cells do if show[ui.cells[i].spec.key] ~= false then vis[#vis + 1] = ui.cells[i] end end
    local n = math.max(#vis, 1)
    local cw = (wpx - 2 * pad) / n
    for i = 1, #ui.cells do ui.cells[i].cell:SetHidden(true) end
    for i = 1, #vis do
        local c = vis[i]
        c.cell:SetHidden(false); c.cell:ClearAnchors()
        c.cell:SetDimensions(cw, (H_CELLS - 6) * k)
        c.cell:SetAnchor(TOPLEFT, win, TOPLEFT, pad + (i - 1) * cw, headH)
        c.lab:SetFont(Font(11 * k, "bold")); c.lab:ClearAnchors(); c.lab:SetAnchor(TOP, c.cell, TOP, 0, 0)
        c.val:SetFont(Font(27 * k, "bold")); c.val:ClearAnchors(); c.val:SetAnchor(TOP, c.cell, TOP, 0, 15 * k)
    end
    local tempoOn = show.tempo ~= false
    local t = ui.tempo
    t.track:SetHidden(not tempoOn); t.fill:SetHidden(not tempoOn); t.ctr:SetHidden(not tempoOn); t.net:SetHidden(not tempoOn)
    if tempoOn then
        t.track:ClearAnchors(); t.track:SetAnchor(TOPLEFT, win, TOPLEFT, pad, headH + (H_CELLS - 2) * k)
        t.track:SetDimensions(wpx - 2 * pad, 6 * k)
        t.ctr:ClearAnchors(); t.ctr:SetDimensions(math.max(1, math.floor(2 * k)), 10 * k); t.ctr:SetAnchor(CENTER, t.track, CENTER, 0, 0)
        t.net:SetFont(Font(11 * k, "bold")); t.net:ClearAnchors(); t.net:SetAnchor(TOP, t.track, BOTTOM, 0, 2 * k); t.net:SetWidth(wpx - 2 * pad)
    end
end

-- Apply all config from sv using REAL scaled dimensions (no SetScale -- that renders unreliably on a
-- top-level window and was behind the "won't resize / sometimes doesn't show" reports): size, opacity,
-- lock state, native resize handles, on-screen position.
function HUD.Apply()
    if not win or not sv then return end
    local k = math.min(SCALE_MAX, math.max(SCALE_MIN, sv.scale or 1.0))
    win:SetAlpha(math.min(1, math.max(0.15, sv.opacity or 0.92)))
    win:SetMovable(not sv.locked)
    win:SetMouseEnabled(not sv.locked)
    win:SetResizeHandleSize(sv.locked and 0 or 10)   -- native edge/corner resize only while unlocked
    win:SetDimensionConstraints(W * SCALE_MIN, 1, W * SCALE_MAX, 4000)
    if ui.grip then ui.grip:SetHidden(sv.locked) end
    win:SetDimensions(W * k, HUD._TotalH(k))
    HUD._Layout(k)
    if not sv.x or not sv.y then
        local gw = (GuiRoot and GuiRoot:GetWidth()) or 1920
        sv.x, sv.y = math.floor(gw / 2 - (W * k) / 2), 220
    end
    win:ClearAnchors()
    win:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, sv.x, sv.y)
end

-- ---- render --------------------------------------------------------------
local function CellValue(key, s)
    if key == "out" then return Abbrev(s.out)
    elseif key == "heal" then return Abbrev(s.hps)
    elseif key == "inc" then return Abbrev(s.inc)
    else return FmtTime(s.dur) end
end

-- phase: "live" (pulsing, climbing), "final" (frozen result), "idle" (resting between duels)
local function Render(s, now, phase)
    if not win or not s then return end
    for i = 1, #ui.cells do
        local c = ui.cells[i]
        if not c.cell:IsHidden() then c.val:SetText(CellValue(c.spec.key, s)) end
    end
    -- flash the OUT value white briefly on a new biggest hit (live only)
    local flashing = phase == "live" and now < state.flashUntil
    local outCell = ui.cells[1]
    if outCell then outCell.val:SetColor(unpack(flashing and C.hi or C.out)) end

    -- tempo = the DAMAGE LEAD: total dealt vs total taken this fight. The bar leans toward whoever has
    -- dealt more overall (steady, not a jittery per-second figure), and the label shows the lead in
    -- damage. This is the at-a-glance "am I winning the trade" read.
    local t = ui.tempo
    if not t.track:IsHidden() then
        local dealt, taken = s.dealt or 0, s.taken or 0
        local sum = dealt + taken
        local lead = dealt - taken
        local frac = (sum > 0) and (lead / sum) or 0
        local half = t.track:GetWidth() / 2          -- scaled track width (real px), not the base constant
        t.fill:ClearAnchors()
        t.fill:SetHeight(t.track:GetHeight())        -- match the (scaled) track height
        if frac >= 0 then
            t.fill:SetColor(unpack(C.out))
            t.fill:SetAnchor(LEFT, t.ctr, CENTER, 0, 0); t.fill:SetWidth(math.max(0, frac * half))
        else
            t.fill:SetColor(unpack(C.inc))
            t.fill:SetAnchor(RIGHT, t.ctr, CENTER, 0, 0); t.fill:SetWidth(math.max(0, -frac * half))
        end
        if phase == "idle" or sum <= 0 then
            t.net:SetText("");
        elseif math.abs(lead) < sum * 0.02 then
            t.net:SetText("even trade"); t.net:SetColor(unpack(C.mid))
        elseif lead > 0 then
            t.net:SetText("you lead by " .. Abbrev(lead)); t.net:SetColor(unpack(C.out))
        else
            t.net:SetText("behind by " .. Abbrev(-lead)); t.net:SetColor(unpack(C.inc))
        end
    end

    -- indicator + accent by phase
    if phase == "live" then
        ui.live:SetText("LIVE"); ui.live:SetColor(unpack(C.accent))
        ui.acc:SetAlpha(0.45 + 0.55 * math.abs(math.sin(now / 420)))   -- gentle pulse
    elseif phase == "final" then
        ui.live:SetText("FINAL"); ui.live:SetColor(unpack(C.hi))
        ui.acc:SetAlpha(1)
    else   -- idle: resting, no pulse, dim accent
        ui.live:SetText("READY"); ui.live:SetColor(unpack(C.mid))
        ui.acc:SetAlpha(0.28)
    end
end

-- ---- tick ----------------------------------------------------------------
local function StartTick()
    if ticking then return end
    ticking = true
    EM:RegisterForUpdate("ShoyruPvPMetricsHUD_Tick", 100, HUD.Tick)
end
local function StopTick()
    if not ticking then return end
    ticking = false
    EM:UnregisterForUpdate("ShoyruPvPMetricsHUD_Tick")
end

function HUD.Tick()
    if not win then return end
    local now = GetGameTimeMilliseconds()
    if state.mode == "live" then
        local s = DM and DM.LiveSnapshot()
        if not s then return end
        state.last = s
        if s.maxHit and s.maxHit > state.lastMax then
            if state.lastMax > 0 then state.flashUntil = now + FLASH_MS end
            state.lastMax = s.maxHit
        end
        Render(s, now, "live")
    elseif state.mode == "preview" then
        Render(PREVIEW, now, "live")
    elseif state.mode == "frozen" then
        Render(state.frozen, now, "final")
        -- Hold the final numbers, then (unless "keep up" is set) settle back to the resting idle
        -- card -- the HUD stays on screen, it just stops showing this duel's result.
        if not (sv and sv.endStay) and now >= state.holdUntil then HUD.ShowIdle() end
    end
end

-- ---- lifecycle -----------------------------------------------------------
-- The HUD is PERSISTENT: whenever it's enabled it stays on screen in a resting "idle" card, goes
-- "live" during a duel, holds the "final" numbers briefly after, then settles back to idle. It only
-- leaves the screen when disabled in settings (HUD.Off).

-- Resting card: visible, static zeros, no animation (so no tick needed while idle).
function HUD.ShowIdle()
    if not sv or not sv.enabled then return end
    Build()
    state.mode = "idle"; state.frozen = nil
    StopTick()
    HUD.Apply()
    win:SetHidden(false)
    Render(ZERO, GetGameTimeMilliseconds(), "idle")
end

function HUD.OnDuelStart()
    if not sv or not sv.enabled then return end
    Build()
    state.mode = "live"; state.frozen = nil; state.last = nil
    state.flashUntil = 0; state.lastMax = 0
    HUD.Apply()
    win:SetHidden(false)
    Render((DM and DM.LiveSnapshot()) or ZERO, GetGameTimeMilliseconds(), "live")   -- zeros if cur isn't up yet
    StartTick()
end

function HUD.OnDuelFinish()
    if not win or state.mode ~= "live" then return end
    state.frozen = (DM and DM.LiveSnapshot()) or state.last
    if not state.frozen then HUD.ShowIdle(); return end   -- no data captured -> straight back to resting
    state.mode = "frozen"
    state.holdUntil = GetGameTimeMilliseconds() + HOLD_MS
    Render(state.frozen, GetGameTimeMilliseconds(), "final")
    StartTick()   -- keep ticking so the hold expires and we settle to idle
end

-- Fully leave the screen -- only when the user disables the HUD.
function HUD.Off()
    StopTick()
    state.mode = "off"
    if win then win:SetHidden(true) end
end

-- ---- config API (settings panel + slash) ---------------------------------
function HUD.SetScale(v)
    if not sv then return end
    sv.scale = math.min(SCALE_MAX, math.max(SCALE_MIN, v))
    HUD.Apply()
end
function HUD.SetLocked(v)
    if not sv then return end
    sv.locked = v and true or false
    if not win then Build() end
    HUD.Apply()
    -- While unlocked (and not in a duel), show representative PREVIEW numbers so the card can be
    -- placed/sized meaningfully; re-lock settles it back to the resting idle card.
    if not sv.locked and state.mode ~= "live" and state.mode ~= "frozen" then
        state.mode = "preview"; win:SetHidden(false); StartTick()
    elseif sv.locked and state.mode == "preview" then
        HUD.ShowIdle()
    end
end
function HUD.ResetPos()
    if not sv then return end
    sv.x, sv.y = nil, nil
    HUD.Apply()
end
function HUD.Refresh()               -- called on any settings change (metric toggles, opacity, enable)
    if not sv then return end
    if not sv.enabled then HUD.Off(); return end
    if not win then Build() end
    if state.mode == "off" then state.mode = "idle" end
    win:SetHidden(false)
    HUD.Apply()
    -- Repaint the current frame AFTER layout so a cell just toggled ON populates immediately. Idle and
    -- preview aren't on the update tick, so without this the re-shown cell stayed blank (the "0 doesn't
    -- display" bug when flipping HPS etc. in settings).
    local now = GetGameTimeMilliseconds()
    if state.mode == "preview" then Render(PREVIEW, now, "live")
    elseif state.mode == "live" then Render((DM and DM.LiveSnapshot()) or ZERO, now, "live")
    elseif state.mode == "frozen" then Render(state.frozen or ZERO, now, "final")
    else Render(ZERO, now, "idle") end
end
function HUD.Toggle()                -- /smxhud: flip lock for quick placement
    if not sv then return end
    HUD.SetLocked(not sv.locked)
    return sv.locked
end
function HUD.ToggleEnabled()        -- keybind: show/hide the live HUD (mirrors the settings "Enable HUD" box)
    if not sv then return false end
    sv.enabled = not sv.enabled
    HUD.Refresh()                   -- enabled -> build+show+render idle; disabled -> Off()/hide
    return sv.enabled and true or false
end

function HUD.Cfg() return sv end   -- settings panel reads/writes the live config table

function HUD.Init(dmSv)
    DM = ShoyrUI.DuelMetrics
    dmSv.hud = dmSv.hud or {}
    sv = dmSv.hud
    for k, v in pairs(HUD_DEFAULTS) do
        if sv[k] == nil then
            if type(v) == "table" then sv[k] = {} ; for kk, vv in pairs(v) do sv[k][kk] = vv end
            else sv[k] = v end
        end
    end
    sv.show = sv.show or {}
    for k, v in pairs(HUD_DEFAULTS.show) do if sv.show[k] == nil then sv.show[k] = v end end

    EM:RegisterForEvent("ShoyruPvPMetricsHUD_Start", EVENT_DUEL_STARTED, HUD.OnDuelStart)
    EM:RegisterForEvent("ShoyruPvPMetricsHUD_Finish", EVENT_DUEL_FINISHED, HUD.OnDuelFinish)

    -- Persistent: if enabled, the resting card is on screen from login. Disable it in settings to hide.
    -- Move/resize is via the settings "Unlock" toggle (no slash command -- release ships /smx + /smxbuild).
    if sv.enabled then HUD.ShowIdle() end
end
