-- ShoyrUI :: Core/DuelMetrics.lua
-- "Shoyru's Duel Metrics" (/SMX) — a DUEL-ONLY combat tracker. Duels are 1v1 and combat-isolated
-- (Battle Spirit, no third party), so we can capture a clean, complete picture with LibCombat as
-- the data engine (the same engine Combat Metrics / ImpressiveStats use) while keeping OUR UI
-- simple and duel-focused. LibCombat is OPTIONAL: if it's missing we degrade to a basic record.
--
-- Capture (LibCombat streams, registered only during a duel):
--   FIGHTSUMMARY  -> totals + build/gear/CP snapshot (one per duel; force-bounded by LibCombat's
--                    own EVENT_DUEL_* handling, so duel == one fight)
--   DAMAGE_OUT/IN -> per-ability damage dealt (to opponent) / taken (from opponent side)
--   HEAL_IN/SELF  -> per-ability healing received
--   EFFECTS_IN/OUT-> buff/debuff GAINED->FADED intervals -> uptime %
--   PLAYERSTATS   -> stat min/avg/max (spell/weapon dmg, penetration, crit, resistances, ...)
--   RESOURCES     -> magicka/stamina/ultimate gains/drains
--   SKILL_TIMINGS -> light-attack weaving (skillDelay) for the Optimizations tab
--   + a light per-second timeline (dmgOut/dmgIn/mag/stam/ult) for Ebb & Flow.
-- Commit uses ImpressiveStats' two-key barrier: persist only once BOTH EVENT_DUEL_FINISHED and the
-- LibCombat summary have arrived (the summary lands up to ~800ms after the duel ends).
--
-- Duel API: EVENT_DUEL_STARTED (no args -> GetDuelInfo()), EVENT_DUEL_FINISHED(result,wasLocal,
-- oppName,oppHandle,alliance,gender,classId,raceId); results DUEL_RESULT_WON / _FORFEIT only.

ShoyrUI = ShoyrUI or {}
local DM = {}
ShoyrUI.DuelMetrics = DM

local EM = EVENT_MANAGER
local LC = nil            -- LibCombat, resolved in Init

DM.DEFAULTS = { opponents = {}, autoOpen = false, version = 2 }
-- Dev-tools flag. /smx (the live view) and /smxbuild (shared-build viewer) are always registered; the
-- demo/reset/debug commands (/smxdemo, /smxclear, /smxwipe, /smxauto, /smxrank, /smxlinkdebug) are gated
-- behind this. Set to false for a release build so users only get the live view.
DM.DEV = false   -- RELEASE: only /smx, /smxbuild (+ /smxhud) ship; demo/reset/debug commands are off.

local sv = nil
local cur = nil           -- in-progress duel accumulators (nil when not dueling)
local NAME = "ShoyrUI_DuelMetrics"

-- Result-code classification (for per-ability crit split from the raw streams).
local CRIT = {
    [ACTION_RESULT_CRITICAL_DAMAGE] = true, [ACTION_RESULT_DOT_TICK_CRITICAL] = true,
    [ACTION_RESULT_CRITICAL_HEAL] = true, [ACTION_RESULT_HOT_TICK_CRITICAL] = true,
}
-- DoT ticks vs direct hits: a DoT/debuff is CLEANSABLE (purge), a direct hit is not (block/dodge). We
-- read this off the result the stream already hands us, so the Report Card can give the right advice.
local DOT = {
    [ACTION_RESULT_DOT_TICK] = true, [ACTION_RESULT_DOT_TICK_CRITICAL] = true,
}

local function Norm(name) return zo_strformat("<<1>>", name or "") end
local function Comma(n) return (ZO_CommaDelimitNumber and ZO_CommaDelimitNumber(math.floor(n or 0))) or tostring(math.floor(n or 0)) end
local function ClassName(classId)
    if not classId or classId == 0 then return "?" end
    local ok, name = pcall(function() return zo_strformat("<<1>>", GetClassName(GENDER_MALE, classId)) end)
    return (ok and name ~= "" and name) or ("class" .. classId)
end

-- ===========================================================================
-- Live accumulators
-- ===========================================================================

local function NewAccumulators()
    return {
        duelStart = GetGameTimeMilliseconds(),
        dealt = {}, taken = {}, healIn = {},        -- [abilityId] = { total, hits, crit, name }
        buffsMe = {}, debuffsMe = {}, debuffsOpp = {}, -- [abilityId] = { open, uptime, count, name, intervals }
        statusIds = {},                             -- [abilityId] = true (learned from raw EVENT_EFFECT_CHANGED)
        effectIcons = {},                           -- [abilityId] = iconPath (the exact icon the game shows)
        effectDur = {},                             -- [abilityId] = nominal duration (s) from the effect event
        stats = {},                                 -- [statId]    = { min, max, sum, count }
        resources = {},                             -- [powerType] = { gains, drains }
        weave = { delaySum = 0, delayCount = 0, weaves = 0, casts = 0, events = {} },
        timeline = {},                              -- [second]    = { dmgOut, dmgIn, mag, stam, ult, ultCast }
        cc = { onMe = {}, onOpp = {} },             -- crowd control counts by kind, per direction
        ccSeen = {},                                -- dedup: key -> last ms (game double-fires CC results)
        ccKindSeen = {},                            -- hard-CC dedup by (dir+kind): one stun/fear = one count
        clutch = { onMe = {}, onOpp = {} },         -- active mitigation per ability: onMe = you blocked/dodged/shielded THEIR
        clutchSeen = {},                            --   attack (defensive); onOpp = they blocked/dodged YOUR attack (wasted offense)
        log = {},                                   -- chronological event stream: { {t,id,val,crit,dir}, ... }
        spendLog = {},                              -- resource DRAINS: { {t,id,pt,val}, ... } (mag/stam spend by source)
        maxDealt = 0, maxTaken = 0,
        -- O(1) running grand-totals for the LIVE HUD (DM.LiveSnapshot). Kept as scalars so the 10 Hz
        -- HUD tick never has to re-sum the per-ability tables. The per-ability tables stay authoritative
        -- for the committed record; these are a fast mirror of their sums, updated on each event.
        sumDealt = 0, sumTaken = 0, sumHeal = 0,
        -- Damage your hits dealt that the OPPONENT's damage shield absorbed. The game reports this as a
        -- separate DAMAGE_SHIELDED event (keyed on the WARD, e.g. Hardened Ward) -- NOT a normal damage
        -- event -- so it's missing from the per-ability damage sum. It IS damage you dealt (CMX counts
        -- it), so it's folded back into dmgDealt/DPS. Can't be attributed per-attack (event names the ward).
        -- Fires for ANY damage shield (Hardened Ward is just one example -- Harness Magicka / Annulment /
        -- Bone Shield / Conjured Ward / set procs all report DAMAGE_SHIELDED); we key off the RESULT.
        sumDealtShield = 0,
        sumTakenShield = 0,   -- the mirror: enemy damage YOUR ward absorbed -> folded into dmgTaken/dpsIn.
    }
end
local LOG_CAP = 5000   -- bound the stored event log (keeps SavedVars sane on long, drawn-out duels).
-- Raised 1000->5000: at 1000 the pinned-scrubber "damage by source" and the combat-log tab silently
-- truncated on long/busy duels (missing later sources). 5000 covers multi-minute duels; the per-ability
-- totals are separate uncapped accumulators, so headline numbers were never affected by the cap.
-- t = RELATIVE MILLISECONDS from duel start, so the combat log can show ms precision (e.g. two
-- abilities landing in the same global cooldown).
local function LogEvent(timems, id, val, crit, dir, dmgType)
    if not cur or not cur.log then return end
    if #cur.log >= LOG_CAP then return end
    cur.log[#cur.log + 1] = { t = math.max(0, (timems or 0) - (cur.duelStart or timems or 0)), id = id, val = val, crit = crit, dir = dir, dtype = dmgType }
end
-- YOUR ult cast (any type): fires on the ult-pool drop; names it from your currently-slotted ultimate
-- (slot 8) so even a no-damage ult like Corrosive Armor is captured.
local function LogUlt(timems)
    if not cur or not cur.log then return end
    if #cur.log >= LOG_CAP then return end
    local id = (GetSlotBoundId and GetSlotBoundId(8)) or 0
    local nm = (id > 0 and GetAbilityName and GetAbilityName(id)) or ""
    nm = (nm ~= "" and zo_strformat("<<1>>", nm)) or "Ultimate"
    cur.log[#cur.log + 1] = { t = math.max(0, (timems or 0) - (cur.duelStart or timems or 0)), id = id, name = nm, dir = "ult", actor = "you" }
end
-- Is this ability an ULTIMATE? Generic (no hardcoded id list): ultimates cost the ULTIMATE mechanic.
-- Catches opponent DAMAGE/DEBUFF ults from the events they land on us (self-buff ults stay invisible).
local function IsUlt(id)
    if not id or id == 0 or type(GetAbilityCost) ~= "function" then return false end
    local ok, _, mech = pcall(GetAbilityCost, id)
    return ok and mech == COMBAT_MECHANIC_FLAGS_ULTIMATE
end
-- OPPONENT ult cast, detected from an ult ability landing on us. Deduped per id within 4s (an ult
-- ticks/hits many times per cast; ults have long cooldowns so a later hit = a new cast).
local function LogOppUlt(timems, id)
    if not cur or not cur.log or #cur.log >= LOG_CAP then return end
    cur.ultSeen = cur.ultSeen or {}
    if cur.ultSeen[id] and (timems - cur.ultSeen[id]) < 4000 then return end
    cur.ultSeen[id] = timems
    local nm = (GetAbilityName and GetAbilityName(id)) or ""
    nm = (nm ~= "" and zo_strformat("<<1>>", nm)) or "Ultimate"
    cur.log[#cur.log + 1] = { t = math.max(0, (timems or 0) - (cur.duelStart or timems or 0)), id = id, name = nm, dir = "ult", actor = "opp" }
end

local function Second(timems) return math.max(0, math.floor((timems - (cur.duelStart or timems)) / 1000)) end
local function Bucket(sec)
    local b = cur.timeline[sec]
    if not b then b = { dmgOut = 0, dmgIn = 0, heal = 0, mag = 0, stam = 0, ult = 0, ultCast = 0 }; cur.timeline[sec] = b end
    return b
end
local function AddAbility(tbl, abilityId, val, isCrit, over, dot, dmgType)
    local a = tbl[abilityId]
    -- Store the icon at capture time (like CMX) so display never has to guess it from the id later.
    if not a then a = { total = 0, hits = 0, crit = 0, dotHits = 0, name = GetAbilityName(abilityId) or "", icon = GetAbilityIcon(abilityId) or "", max = val, min = val, over = 0, dtypes = {} }; tbl[abilityId] = a end
    a.total = a.total + val; a.hits = a.hits + 1
    if isCrit then a.crit = a.crit + 1 end
    if dot then a.dotHits = (a.dotHits or 0) + 1 end   -- ticks that came in as a DoT (cleansable)
    if val > a.max then a.max = val end
    if val < a.min then a.min = val end
    if over and over > 0 then a.over = a.over + over end   -- overhealing (LibCombat overflow)
    -- Damage by type (drives damage-type-mix + opponent weapon/role inference). Attributed by value so
    -- the dominant type per ability is the one that actually dealt the damage, not the most frequent tick.
    if dmgType and dmgType ~= 0 then a.dtypes[dmgType] = (a.dtypes[dmgType] or 0) + val end
end

-- ---- LibCombat stream callbacks (only registered during a duel) ----

local function OnDamage(ct, timems, result, sourceUnitId, targetUnitId, abilityId, hitValue, damageType, overflow)
    if not cur or (hitValue or 0) <= 0 then return end
    local crit = CRIT[result] or false
    local dot = DOT[result] or false
    -- Bracket ACTIVE combat by the first/last damage event (either direction). Live DPS/HPS divide by
    -- this span, NOT by wall-clock-since-duel-start -- EVENT_DUEL_STARTED fires at the countdown, several
    -- seconds before the first hit, so wall-clock inflates the denominator and under-reports DPS. Damage
    -- (not heals) defines the window: regen/HoTs can tick during the pre-fight countdown.
    cur.combatStart = cur.combatStart or timems
    cur.combatLast = timems
    if ct == LIBCOMBAT_EVENT_DAMAGE_OUT then
        AddAbility(cur.dealt, abilityId, hitValue, crit, nil, dot, damageType)
        cur.sumDealt = cur.sumDealt + hitValue                              -- live HUD running total
        if hitValue > cur.maxDealt then cur.maxDealt, cur.maxDealtAbility = hitValue, abilityId end
        Bucket(Second(timems)).dmgOut = Bucket(Second(timems)).dmgOut + hitValue
        LogEvent(timems, abilityId, hitValue, crit, "out", damageType)
    else -- DAMAGE_IN
        AddAbility(cur.taken, abilityId, hitValue, crit, nil, dot, damageType)
        cur.sumTaken = cur.sumTaken + hitValue                              -- live HUD running total
        if hitValue > cur.maxTaken then cur.maxTaken, cur.maxTakenAbility = hitValue, abilityId end
        Bucket(Second(timems)).dmgIn = Bucket(Second(timems)).dmgIn + hitValue
        LogEvent(timems, abilityId, hitValue, crit, "in", damageType)
        if IsUlt(abilityId) then LogOppUlt(timems, abilityId) end   -- their damage ult landing on us
    end
end

local function OnHeal(ct, timems, result, sourceUnitId, targetUnitId, abilityId, hitValue, overflow)
    if not cur or (hitValue or 0) <= 0 then return end
    -- Skip source-less heals (no ability id). ESO reports the odd heal with abilityId 0 (untracked ticks /
    -- passive regen) and LibCombat leaves those OUT of its fight healing total, so counting them made the
    -- per-ability healing list overshoot the headline and show a meaningless "#0" row. No source -> not shown.
    if not abilityId or abilityId <= 0 then return end
    AddAbility(cur.healIn, abilityId, hitValue, CRIT[result] or false, overflow or 0)   -- healing received / self (+ overheal)
    cur.sumHeal = cur.sumHeal + hitValue                                    -- live HUD running total
    Bucket(Second(timems)).heal = Bucket(Second(timems)).heal + hitValue   -- per-second healing for the Ebb & Flow HPS line
    LogEvent(timems, abilityId, hitValue, CRIT[result] or false, "heal")
end

-- Route effects into three buckets: buffs on ME (EFFECTS_IN + buff), debuffs on ME
-- (EFFECTS_IN + debuff), and debuffs I put on the OPPONENT (EFFECTS_OUT).
local function OnEffect(ct, timems, unitId, abilityId, changeType, effectType, stacks, sourceType, effectSlot)
    if not cur then return end
    local tbl
    if ct == LIBCOMBAT_EVENT_EFFECTS_OUT then
        tbl = cur.debuffsOpp
    elseif effectType == BUFF_EFFECT_TYPE_DEBUFF then
        tbl = cur.debuffsMe
    else
        tbl = cur.buffsMe
    end
    local b = tbl[abilityId]
    if not b then b = { open = nil, uptime = 0, count = 0, name = GetAbilityName(abilityId) or "", intervals = {} }; tbl[abilityId] = b end
    if changeType == EFFECT_RESULT_GAINED or changeType == EFFECT_RESULT_UPDATED then
        if not b.open then b.open = timems; b.count = b.count + 1 end
    elseif changeType == EFFECT_RESULT_FADED then
        if b.open then
            b.uptime = b.uptime + (timems - b.open)
            -- Record the gained->faded window (relative to duel start) for recast-efficiency, purge
            -- detection and critical-window analysis (Buffs & Debuffs deepening #4/#6).
            b.intervals[#b.intervals + 1] = { s = b.open - cur.duelStart, e = timems - cur.duelStart }
            b.open = nil
        end
    end
end

-- The eight elemental/damage STATUS EFFECTS have fixed, well-known ability ids (game constants, identical
-- in every client language). We identify them by ID -- NOT by statusEffectType and NOT by name. A
-- statusEffectType whitelist is WRONG: ordinary abilities' effect events carry damage-flavoured types
-- (Rending Slashes / Blood Craze / werewolf bleeds all report BLEED; Dazing Smash reports one too), so
-- it mislabels those DoTs/abilities as "status effects" -- the reported bug (fake statuses, bad uptimes).
-- This id set is the single source of truth. (Verified against captured real-duel data.)
local STATUS_IDS = {
    [18084]  = true,   -- Burning      (flame)
    [21929]  = true,   -- Poisoned     (poison)
    [95134]  = true,   -- Concussion   (shock)
    [95136]  = true,   -- Chill        (frost)
    [148801] = true,   -- Hemorrhaging (bleed)
    [178118] = true,   -- Overcharged  (magic)
    [178123] = true,   -- Sundered     (physical)
    [178127] = true,   -- Diseased     (disease)
}
DM.STATUS_IDS = STATUS_IDS   -- shared with DuelMetricsUI for display-side classification

-- LibCombat's EFFECTS stream forwards neither statusEffectType NOR the icon, so we watch the raw
-- EVENT_EFFECT_CHANGED during a duel to (a) learn which abilityIds are status effects — classification
-- from the game itself, no hand-maintained id list — and (b) grab the EXACT icon the game shows for
-- each effect (CMX-style), so the UI never has to guess it from the id later, and (c) grab the NOMINAL
-- duration at GAINED (endTime-beginTime) so purge detection can flag intervals that faded early.
local function OnRawEffect(_, changeType, _, _, unitTag, beginTime, endTime, _, iconName, _, _, _, statusEffectType, _, _, abilityId)
    if not cur or not abilityId then return end
    if STATUS_IDS[abilityId] then cur.statusIds[abilityId] = true end   -- genuine status effect (by id)
    if iconName and iconName ~= "" then cur.effectIcons[abilityId] = iconName end
    if changeType == EFFECT_RESULT_GAINED and beginTime and endTime and endTime > beginTime then
        local d = endTime - beginTime                       -- seconds; keep the longest seen (full duration)
        if d > (cur.effectDur[abilityId] or 0) then cur.effectDur[abilityId] = d end
    end
end

-- Crowd-control ledger. LibCombat has no CC stream, so we read the CC ACTION_RESULT_* codes off
-- EVENT_COMBAT_EVENT (registered per-result, so only CC events reach us). Direction from unit type:
-- target = the player -> CC on me; source = the player -> CC I landed on the opponent.
local CC_RESULT = {
    [ACTION_RESULT_STUNNED]     = "Stun",
    [ACTION_RESULT_FEARED]      = "Fear",
    [ACTION_RESULT_DISORIENTED] = "Disorient",
    [ACTION_RESULT_SILENCED]    = "Silence",
    [ACTION_RESULT_ROOTED]      = "Immobilize",
    [ACTION_RESULT_SNARED]      = "Snare",
    [ACTION_RESULT_STAGGERED]   = "Stagger",
    [ACTION_RESULT_INTERRUPT]   = "Interrupt",
}
-- Actions that are NEVER a CC source but get tagged with a CC result while you're CC'd (the game attaches
-- the active CC result to whatever you were doing). Break Free / Weapon Swap are the common culprits.
local CC_DENY = { [16565] = true, [28541] = true }   -- Break Free, Weapon Swap
local CC_HARD = { Stun = true, Fear = true, Disorient = true, Immobilize = true }
-- Name-based version of the deny (for the retroactive ledger cleanup: OLD records were captured before the
-- source==target self-event drop, so they carry these player actions tagged with the CC you were under).
-- Break Free / Weapon Swap / light + heavy attacks are NEVER an enemy CC landed on you.
local function IsSelfActionName(name)
    if type(name) ~= "string" or name == "" then return false end
    if name == "Break Free" or name == "Weapon Swap" or name == "Swap Weapons" then return true end
    return name:find("^Light Attack") ~= nil or name:find("^Heavy Attack") ~= nil
end
-- Record CC PER ABILITY (kind + name + count). The abilityId on a CC combat event is UNRELIABLE: a single
-- stun/fear fires many concurrent events, each carrying whatever ability was happening at that instant
-- (your heals, light attacks, DoT ticks). We defend against that: (1) a self-event (source==target==you) is
-- your own action tagged with the CC you're under, not an enemy CC -> skip; (2) drop Break Free / Weapon
-- Swap / light+heavy attacks; (3) HARD CC is deduped by (direction+kind) within a CC-length window so one
-- stun counts ONCE instead of once per concurrent action.
local function OnCombatCC(_, result, _, abilityName, _, _, _, sourceType, _, targetType, _, _, _, _, _, targetUnitId, abilityId)
    if not cur then return end
    local kind = CC_RESULT[result]
    if not kind then return end
    local meT = (targetType == COMBAT_UNIT_TYPE_PLAYER)
    local meS = (sourceType == COMBAT_UNIT_TYPE_PLAYER)
    local dir
    if meT and not meS then dir = cur.cc.onMe          -- opponent CC'd me
    elseif meS and not meT then dir = cur.cc.onOpp      -- I CC'd the opponent
    else return end                                    -- self-event (or ambiguous) -> not a real CC
    if CC_DENY[abilityId] then return end
    local nm = Norm(abilityName)
    if nm:find("Light Attack") or nm:find("Heavy Attack") then return end
    local now = GetGameTimeMilliseconds()
    if CC_HARD[kind] then
        -- one stun/fear = one count: ignore repeats of the same kind+direction within a CC-length window.
        local kkey = (dir == cur.cc.onMe and "me_" or "op_") .. kind
        if cur.ccKindSeen[kkey] and (now - cur.ccKindSeen[kkey]) < 3000 then return end
        cur.ccKindSeen[kkey] = now
    else
        local key = result .. "_" .. (targetUnitId or 0) .. "_" .. (abilityId or 0)   -- soft CC: per-ability dedup
        if cur.ccSeen[key] and (now - cur.ccSeen[key]) < 500 then return end
        cur.ccSeen[key] = now
    end
    local r = dir[abilityId]
    if not r then r = { kind = kind, name = nm, count = 0, times = {} }; dir[abilityId] = r end
    r.count = r.count + 1
    -- Timestamp (relative ms) every CC so the analyzer can correlate a stun with the burst that follows
    -- it, measure break-free latency, and detect CC thrown into immunity.
    r.times[#r.times + 1] = math.max(0, now - (cur.duelStart or now))
end

-- Active-defense ledger (the "clutch play" layer LibCombat/CC don't surface). Same EVENT_COMBAT_EVENT
-- trick as CC: one filtered registration per result code, so only block/dodge/shield events reach us.
-- BLOCKED + BLOCKED_DAMAGE both mean "blocked"; DAMAGE_SHIELDED carries the amount the ward absorbed.
-- Direction: target = player => YOUR defensive play against their attack; source = player => THEY
-- blocked/dodged/shielded YOUR attack (wasted offense). Per-ability so we know WHAT you blocked.
-- VERIFIED vs real duel data (2026-07-07, 22-duel SV audit): block/dodge events name the ATTACK as
-- assumed, but DAMAGE_SHIELDED names the WARD that absorbed (Concentrated Barrier / Tri Focus / etc.),
-- never the attack -- so shield rows are ward-attributed, shield-only rows in this ledger. hitValue is
-- the absorbed amount, direction as assumed (your side shows YOUR ward, theirs shows THEIRS).
local CLUTCH_RESULT = {
    [ACTION_RESULT_BLOCKED]         = "block",
    [ACTION_RESULT_BLOCKED_DAMAGE]  = "block",
    [ACTION_RESULT_DODGED]          = "dodge",
    [ACTION_RESULT_DAMAGE_SHIELDED] = "shield",
}
local function OnCombatClutch(_, result, _, abilityName, _, _, _, sourceType, _, targetType, hitValue, _, _, _, _, targetUnitId, abilityId)
    if not cur then return end
    local kind = CLUTCH_RESULT[result]
    if not kind then return end
    local dir = (targetType == COMBAT_UNIT_TYPE_PLAYER) and cur.clutch.onMe
        or (sourceType == COMBAT_UNIT_TYPE_PLAYER) and cur.clutch.onOpp or nil
    if not dir then return end
    local now = GetGameTimeMilliseconds()
    local key = result .. "_" .. (targetUnitId or 0) .. "_" .. (abilityId or 0)   -- dedup double-fires
    if cur.clutchSeen[key] and (now - cur.clutchSeen[key]) < 300 then return end
    cur.clutchSeen[key] = now
    local r = dir[abilityId]
    if not r then r = { name = Norm(abilityName), block = 0, dodge = 0, shield = 0, absorbed = 0, times = {} }; dir[abilityId] = r end
    r[kind] = r[kind] + 1
    if kind == "shield" then
        r.absorbed = r.absorbed + (hitValue or 0)   -- damage a ward ate
        -- OUTGOING shield (your attack, absorbed by the ENEMY's ward) is still damage you dealt -- fold it
        -- into your DPS total (it lands in DAMAGE_SHIELDED, not the damage stream, so the per-ability sum
        -- misses it: DPS on a warded target read far too low, e.g. 2.4k vs the real 7.6k).
        if dir == cur.clutch.onOpp then cur.sumDealtShield = cur.sumDealtShield + (hitValue or 0)
        elseif dir == cur.clutch.onMe then cur.sumTakenShield = cur.sumTakenShield + (hitValue or 0) end   -- enemy dmg your ward ate
    end
    -- Timestamp (relative ms) every active-defense event so the analyzer can tell proactive defense from
    -- reactive (blocks that land AFTER the first hit) and read an opponent who blocks on your tells.
    r.times[#r.times + 1] = math.max(0, now - (cur.duelStart or now))
end

local function OnStat(ct, timems, statchange, newvalue, statId)
    if not cur or not statId then return end
    local s = cur.stats[statId]
    if not s then s = { min = newvalue, max = newvalue, sum = 0, count = 0 }; cur.stats[statId] = s end
    if newvalue < s.min then s.min = newvalue end
    if newvalue > s.max then s.max = newvalue end
    s.sum = s.sum + newvalue; s.count = s.count + 1
end

local function OnResource(ct, timems, abilityId, powerChange, powerType, powerValue)
    if not cur then return end
    local r = cur.resources[powerType]
    if not r then r = { gains = 0, drains = 0 }; cur.resources[powerType] = r end
    if (powerChange or 0) >= 0 then r.gains = r.gains + powerChange else r.drains = r.drains - powerChange end
    -- Resource SPEND by source (magicka/stamina drains attributed to the ability that caused them).
    if (powerChange or 0) < 0 and (powerType == COMBAT_MECHANIC_FLAGS_MAGICKA or powerType == COMBAT_MECHANIC_FLAGS_STAMINA) and #cur.spendLog < LOG_CAP then
        cur.spendLog[#cur.spendLog + 1] = { t = math.max(0, (timems or 0) - (cur.duelStart or timems or 0)), id = abilityId or 0, pt = powerType, val = -powerChange }
    end
    -- Timeline: current pool level for hp/mag/stam/ult. (hp powers the Defense recovery-speed read --
    -- how fast you climb back to 80% after dropping under 50%; nil on old records = graceful fallback.)
    local b = Bucket(Second(timems))
    if powerType == COMBAT_MECHANIC_FLAGS_HEALTH then b.hp = powerValue
    elseif powerType == COMBAT_MECHANIC_FLAGS_MAGICKA then b.mag = powerValue
    elseif powerType == COMBAT_MECHANIC_FLAGS_STAMINA then b.stam = powerValue
    elseif powerType == COMBAT_MECHANIC_FLAGS_ULTIMATE then
        -- An ult cast shows up as the pool dropping by a big chunk (ults cost >= ~75). A big
        -- NEGATIVE powerChange is the cast; mark that second so the Ebb & Flow ult markers fire
        -- in real duels (previously ultCast was only ever set by the demo).
        b.ult = powerValue
        if (powerChange or 0) <= -75 then b.ultCast = b.ultCast + 1; LogUlt(timems) end
    end
end

local function OnSkill(ct, timems, reducedslot, abilityId, skillStatus, skillDelay, skillDuration)
    if not cur then return end
    -- LibCombat fires SEVERAL status events per cast. Count ONE cast per GCD window (>=700ms) and
    -- credit its weave once (any status in the window carrying a delay). Verified vs real data
    -- 2026-07-07: raw events ran ~4-5x real casts, which flattened every coverage ratio to ~33%
    -- regardless of how the player actually wove. (_wv* transients live on cur, not cur.weave, so
    -- they never persist into the committed record.)
    local t = timems or 0
    if not cur._wvLast or (t - cur._wvLast) >= 700 then
        cur.weave.casts = cur.weave.casts + 1
        cur._wvLast, cur._wvWeaved = t, false
    end
    if skillDelay and skillDelay > 0 and not cur._wvWeaved then
        cur._wvWeaved = true
        cur.weave.delaySum = cur.weave.delaySum + skillDelay
        cur.weave.delayCount = cur.weave.delayCount + 1
    end
    -- Per-cast event (relative ms + the weave delay this cast) so the analyzer can tell weaving under
    -- pressure from weaving free, spot clipping (casts jammed together), and find downtime gaps. Capped.
    if #cur.weave.events < 250 then
        cur.weave.events[#cur.weave.events + 1] = { t = math.max(0, (timems or 0) - (cur.duelStart or timems or 0)), d = skillDelay or 0 }
    end
end

-- Stream types we register on duel start (unregistered on capture).
local STREAMS
local function StreamHandlers()
    STREAMS = STREAMS or {
        [LIBCOMBAT_EVENT_DAMAGE_OUT] = OnDamage, [LIBCOMBAT_EVENT_DAMAGE_IN] = OnDamage,
        [LIBCOMBAT_EVENT_HEAL_IN] = OnHeal, [LIBCOMBAT_EVENT_HEAL_SELF] = OnHeal,
        [LIBCOMBAT_EVENT_EFFECTS_IN] = OnEffect, [LIBCOMBAT_EVENT_EFFECTS_OUT] = OnEffect,
        [LIBCOMBAT_EVENT_PLAYERSTATS] = OnStat, [LIBCOMBAT_EVENT_RESOURCES] = OnResource,
        [LIBCOMBAT_EVENT_SKILL_TIMINGS] = OnSkill,
    }
    return STREAMS
end

local function RegisterStreams()
    if not LC then return end
    LC:RegisterForCombatEvent(NAME, LIBCOMBAT_EVENT_FIGHTSUMMARY, function(ct, fight) DM.OnFightSummary(fight) end)
    for ct, cb in pairs(StreamHandlers()) do LC:RegisterForCombatEvent(NAME, ct, cb) end
end
local function UnregisterStreams()
    if not LC then return end
    LC:UnregisterForCombatEvent(NAME, LIBCOMBAT_EVENT_FIGHTSUMMARY)
    for ct in pairs(StreamHandlers()) do LC:UnregisterForCombatEvent(NAME, ct) end
end

-- Snapshot the DEFENSIVE advanced stats the character-sheet "Advanced Stats" panel exposes
-- (ESO has no per-element resist API — these are the additional defensive values it DOES provide).
-- GetAdvancedStatValue(type) -> (valueText, flatValue, percentValue); guarded so it degrades if a
-- constant/API is absent. Build stats, so a duel-start snapshot is representative.
local function SnapshotAdvanced()
    if type(GetAdvancedStatValue) ~= "function" then return nil end
    local function get(typeConst, which)
        if typeConst == nil then return nil end
        local ok, _, flat, pct = pcall(GetAdvancedStatValue, typeConst)
        if not ok then return nil end
        return (which == "pct") and pct or flat
    end
    return {
        blockMit  = get(ADVANCED_STAT_DISPLAY_TYPE_BLOCK_MITIGATION, "pct"),
        blockCost = get(ADVANCED_STAT_DISPLAY_TYPE_BLOCK_COST,       "flat"),
        dodgeCost = get(ADVANCED_STAT_DISPLAY_TYPE_DODGE_COST,       "flat"),
        ccBreak   = get(ADVANCED_STAT_DISPLAY_TYPE_CC_BREAK_COST,    "flat"),
    }
end

-- Build-defining player buffs, identified by ability id (same tables LibDataPacker/SuperStar use).
local BOON_IDS = {      -- the 13 mundus stones ("Boon: The X"); two possible with Twice-Born Star
    [13940]=true,[13943]=true,[13974]=true,[13975]=true,[13976]=true,[13977]=true,[13978]=true,
    [13979]=true,[13980]=true,[13981]=true,[13982]=true,[13984]=true,[13985]=true,
}
local WWVAMP_IDS = {    -- value = vampirism stage; 0 = lycanthropy
    [135397]=1,[135399]=2,[135400]=3,[135402]=4,[35658]=0,
}
-- Duel-start snapshot of the build bits LibCombat does NOT capture: mundus boon(s), the
-- vamp-stage/werewolf buff, food (heuristic: a long TIMED buff, >=10 min duration — food/drink/XP
-- scrolls; permanent buffs like Battle Spirit/ESO Plus/toggles report no duration and are skipped),
-- and the 12 champion slottables (+points spent). None of these can change mid-combat.
local function ScanBuildExtras()
    local n = GetNumBuffs and GetNumBuffs("player")
    if type(n) ~= "number" or not GetUnitBuffInfo then return nil end
    local s = { boons = {}, food = {} }
    for i = 1, n do
        local _, startT, endT, _, _, _, _, _, _, _, abilityId = GetUnitBuffInfo("player", i)
        if BOON_IDS[abilityId] then s.boons[#s.boons+1] = abilityId
        elseif WWVAMP_IDS[abilityId] then s.wwVamp = abilityId
        elseif endT and startT and endT > startT and (endT - startT) >= 600 and #s.food < 4 then
            s.food[#s.food+1] = abilityId
        end
    end
    table.sort(s.boons)
    if GetSlotBoundId and HOTBAR_CATEGORY_CHAMPION then
        s.cp = {}
        for i = 1, 12 do
            local ok, id = pcall(GetSlotBoundId, i, HOTBAR_CATEGORY_CHAMPION)
            if ok and id and id > 0 then
                local pok, pts = pcall(GetNumPointsSpentOnChampionSkill, id)
                s.cp[i] = { id = id, pts = (pok and pts) or 0 }
            end
        end
    end
    return s
end

-- Purchased CLASS MASTERY abilities (the subclassing mastery line) — same walk LibDataPacker's
-- build codec uses: class skill lines flagged isClassMastery, collect purchased ability ids.
local function ScanClassMastery()
    local out = {}
    pcall(function()
        for li = GetNumSkillLines(SKILL_TYPE_CLASS), 1, -1 do
            local _, _, _, _, _, _, isClassMastery = GetSkillLineDynamicInfo(SKILL_TYPE_CLASS, li)
            if isClassMastery then
                for si = 1, GetNumSkillAbilities(SKILL_TYPE_CLASS, li) do
                    local _, _, _, _, _, purchased = GetSkillAbilityInfo(SKILL_TYPE_CLASS, li, si)
                    if purchased then out[#out+1] = GetSkillAbilityId(SKILL_TYPE_CLASS, li, si) end
                end
            end
        end
    end)
    return out[1] and out or nil
end

-- ===========================================================================
-- Duel lifecycle
-- ===========================================================================

local function OnDuelStarted()
    if cur and cur.result then DM.Commit() end     -- flush a stray finished-but-uncommitted duel
    cur = NewAccumulators()
    local _, oppName, oppHandle = GetDuelInfo()
    cur.oppName = Norm(oppName)
    cur.oppHandle = (oppHandle and oppHandle ~= "" and oppHandle) or cur.oppName
    cur.myName = Norm(GetRawUnitName and GetRawUnitName("player") or GetUnitName("player"))
    cur.myHandle = (GetDisplayName and GetDisplayName()) or ""
    cur.myClassId = GetUnitClassId("player")
    cur.myRaceId = (GetUnitRaceId and GetUnitRaceId("player")) or 0
    cur.myCP = (GetPlayerChampionPointsEarned and GetPlayerChampionPointsEarned()) or (GetUnitChampionPoints and GetUnitChampionPoints("player")) or 0
    cur.adv = SnapshotAdvanced()
    cur.scan = ScanBuildExtras()
    if Norm(GetRawUnitName("reticleover")) == cur.oppName then
        cur.oppClassId = GetUnitClassId("reticleover")
        cur.oppRaceId = (GetUnitRaceId and GetUnitRaceId("reticleover")) or nil
        cur.oppCP = (GetUnitChampionPoints and GetUnitChampionPoints("reticleover")) or nil
    end
    if LC then RegisterStreams() else cur.noEngine = true end
end

-- Called when LibCombat hands us the duel's fight summary (totals + build snapshot).
function DM.OnFightSummary(fight)
    if not cur or cur.fightAdded then return end
    -- Validate this is the duel's fight (combatstart ≈ duelStart within 6s) — ImpressiveStats pattern.
    if fight and fight.combatstart and math.abs(fight.combatstart - cur.duelStart) > 6000 then return end
    UnregisterStreams()
    cur.fightAdded = true
    cur.combattime = fight and fight.combattime or ((GetGameTimeMilliseconds() - cur.duelStart) / 1000)
    cur.totalDealt = (fight and fight.damageOutTotal) or 0
    cur.totalTaken = (fight and fight.damageInTotal) or 0
    cur.totalHeal = (fight and fight.healingInTotal) or 0
    cur.dpsOut = (fight and fight.DPSOut) or 0
    cur.dpsIn = (fight and fight.DPSIn) or 0
    cur.hps = (fight and fight.HPSIn) or 0
    if fight and fight.charData then
        local cd = fight.charData
        -- Keep the rest of LibCombat's snapshot too: both action bars (skillBars[bar][slot]=abilityId,
        -- slots 3-7 + ultimate in 8; a bar is only present if it was active during the fight),
        -- the attribute-point split, and vampire/werewolf curse (0=none, 1=vampire, 2=werewolf).
        -- CP: use the scalar total we captured (cur.myCP); LibCombat's fight.CP is a table on some
        -- records, not the champion-point number the Build tab wants.
        cur.build = { equip = cd.equip, CP = (type(fight.CP) == "number" and fight.CP) or cur.myCP or 0, classId = cd.classId,
            bars = cd.skillBars, curse = cd.Curse,
            attr = { hp = cd.APHealth, mag = cd.APMagicka, stam = cd.APStam } }
        -- Scribed skills: LibCombat keys them by the slotted ability id -> {script1,script2,script3}.
        -- Also recover the craftedAbilityId (needed to SHARE the build) by reverse lookup — valid
        -- here because this runs at duel end, while the character still has these scripts active.
        if cd.scribedSkills and next(cd.scribedSkills) then
            local scribed = {}
            for id, scripts in pairs(cd.scribedSkills) do
                local craftedId
                if GetAbilityIdForCraftedAbilityId then
                    for c = 1, 30 do
                        local ok, aid = pcall(GetAbilityIdForCraftedAbilityId, c)
                        if ok and aid == id then craftedId = c break end
                    end
                end
                scribed[id] = { crafted = craftedId, s = { scripts[1], scripts[2], scripts[3] } }
            end
            cur.build.scribed = scribed
        end
        -- Active class skill lines (subclassing) — LibCombat captures the 3 line ids.
        if cd.SkillLines and cd.SkillLines[1] then cur.build.lines = { cd.SkillLines[1], cd.SkillLines[2], cd.SkillLines[3] } end
        -- Purchased class-mastery abilities (own scan; can't change mid-duel).
        cur.build.mastery = ScanClassMastery()
        -- Fold in the duel-start scan (mundus/food/vamp-stage/champion slottables).
        local sc = cur.scan
        if sc then
            cur.build.boons = (#sc.boons > 0) and sc.boons or nil
            cur.build.food = (#sc.food > 0) and sc.food or nil
            cur.build.wwVamp = sc.wwVamp
            cur.build.cpSlots = (sc.cp and next(sc.cp)) and sc.cp or nil
        end
    end
    DM.TryCommit()
end

local function OnDuelFinished(_, result, wasLocal, oppName, oppHandle, _, _, oppClassId, oppRaceId)
    if not cur then return end
    cur.oppClassId = oppClassId or cur.oppClassId
    cur.oppRaceId = oppRaceId or cur.oppRaceId
    if oppName and oppName ~= "" then cur.oppName = Norm(oppName) end
    if oppHandle and oppHandle ~= "" then cur.oppHandle = oppHandle end
    -- WON = someone died: win if it was the opponent, loss if it was me. FORFEIT =
    -- someone left/forfeited the duel (no kill) → count it as a DRAW.
    if result == DUEL_RESULT_WON then
        cur.result = wasLocal and "win" or "loss"
    else
        cur.result = "draw"
    end
    cur.resultAdded = true
    if cur.noEngine then                              -- no LibCombat → nothing else is coming, commit now
        cur.combattime = (GetGameTimeMilliseconds() - cur.duelStart) / 1000
        DM.Commit()
    else
        DM.TryCommit()
        -- Safety: if the summary never arrives (edge), commit what we have shortly after.
        zo_callLater(function() if cur and cur.resultAdded and not cur.committed then UnregisterStreams(); DM.Commit() end end, 1500)
    end
end

-- Two-key barrier: only persist once BOTH the result and the fight summary have arrived.
function DM.TryCommit()
    if cur and cur.resultAdded and (cur.fightAdded or cur.noEngine) and not cur.committed then DM.Commit() end
end

-- ===========================================================================
-- Finalize + store
-- ===========================================================================

-- Full sorted ability list (highest damage first). n = optional cap; nil = keep ALL
-- (a duel only ever has a few dozen distinct abilities, so we store them all and let
-- the UI show the complete table).
local function TopAbilities(tbl, n)
    local arr = {}
    for id, a in pairs(tbl) do
        -- Dominant damage type = the type that dealt the most of this ability's damage (by value).
        local dtype, dbest = nil, 0
        if a.dtypes then for t, v in pairs(a.dtypes) do if v > dbest then dbest, dtype = v, t end end end
        arr[#arr + 1] = { id = id, total = a.total, hits = a.hits, crit = a.crit, name = a.name, icon = a.icon, max = a.max, min = a.min, over = a.over,
            dot = (a.hits or 0) > 0 and (a.dotHits or 0) / a.hits >= 0.5 or false, dtype = dtype }   -- mostly DoT ticks => cleansable
    end
    table.sort(arr, function(x, y) return x.total > y.total end)
    if n then while #arr > n do arr[#arr] = nil end end
    return arr
end
local function SumTotal(tbl) local s = 0; for _, a in pairs(tbl) do s = s + a.total end; return s end
local function SumOver(tbl) local s = 0; for _, a in pairs(tbl) do s = s + (a.over or 0) end; return s end

function DM.Commit()
    if not sv or not cur or not cur.result or cur.committed then return end
    cur.committed = true
    local c = cur
    cur = nil

    local handle = c.oppHandle or c.oppName or "?"
    -- Real duels ALWAYS go to the real store, even while the demo is being viewed (sv.realOpponents holds
    -- the real store during a demo view, so a duel finished mid-demo isn't dropped into the demo data).
    local store = sv.realOpponents or sv.opponents
    local o = store[handle]
    if not o then o = { name = c.oppName, handle = handle, classId = c.oppClassId, wins = 0, losses = 0, draws = 0, duels = {} }; store[handle] = o end
    o.name = c.oppName or o.name
    o.classId = c.oppClassId or o.classId
    o.draws = o.draws or 0
    if c.result == "win" then o.wins = o.wins + 1
    elseif c.result == "draw" then o.draws = o.draws + 1
    else o.losses = o.losses + 1 end

    -- Close any effects still active at duel end, then flatten each bucket to a sorted list.
    local endms = GetGameTimeMilliseconds()
    local function EffectList(tbl)
        local arr = {}
        for id, b in pairs(tbl) do
            if b.open then
                b.uptime = b.uptime + (endms - b.open)
                b.intervals[#b.intervals + 1] = { s = b.open - c.duelStart, e = endms - c.duelStart }
                b.open = nil
            end
            arr[#arr + 1] = { id = id, name = b.name, uptime = b.uptime, count = b.count,
                icon = (c.effectIcons and c.effectIcons[id]) or GetAbilityIcon(id) or "",
                dur = c.effectDur and c.effectDur[id],   -- nominal duration (s) for purge detection
                intervals = b.intervals, isStatus = (c.statusIds and c.statusIds[id]) or nil }
        end
        table.sort(arr, function(x, y) return (x.uptime or 0) > (y.uptime or 0) end)
        return arr
    end
    -- Finalize stat averages.
    local stats = {}
    for id, s in pairs(c.stats) do stats[id] = { min = s.min, max = s.max, avg = (s.count > 0 and s.sum / s.count) or s.max } end

    -- Duration = ACTIVE combat span (first -> last DAMAGE event) -- the same tight window the live HUD
    -- uses and the basis the per-ability sums are honest against. Falls back to LibCombat's combattime,
    -- then wall-clock, when no damage was captured.
    local span = (c.combatStart and c.combatLast and c.combatLast > c.combatStart)
        and (c.combatLast - c.combatStart) / 1000 or nil
    local dur = span or (c.combattime and c.combattime > 0 and c.combattime) or math.max(0.1, (endms - c.duelStart) / 1000)
    -- Totals come from OUR per-ability capture (== the ability rows == the live HUD), NOT LibCombat's
    -- fight totals: for a duel, damageOutTotal can include stray AoE/DoT damage to the opponent's
    -- pets/summons, inflating "your DPS" (seen as up to +30% over the real player-vs-player damage).
    -- dpsOut/dpsIn/hps are DERIVED from these totals and the span, so every metric agrees.
    local shieldedOut, shieldedIn = c.sumDealtShield or 0, c.sumTakenShield or 0
    local dealtTot, takenTot, healTot = SumTotal(c.dealt) + shieldedOut, SumTotal(c.taken) + shieldedIn, SumTotal(c.healIn)
    local rec = {
        date = GetTimeStamp(), result = c.result,
        myClassId = c.myClassId, oppClassId = c.oppClassId,
        myName = c.myName, myHandle = c.myHandle,
        myRaceId = c.myRaceId, oppRaceId = c.oppRaceId, myCP = c.myCP, oppCP = c.oppCP,
        durationS = dur,
        -- Damage
        dmgDealt = dealtTot, dmgTaken = takenTot,
        dmgShieldedOut = shieldedOut,   -- of dmgDealt, this much was absorbed by the enemy's ward (not in dealtTop)
        dmgShieldedIn = shieldedIn,     -- of dmgTaken, this much was absorbed by YOUR ward (not in takenTop)
        dpsOut = dur > 0 and dealtTot / dur or 0, dpsIn = dur > 0 and takenTot / dur or 0,
        dealtTop = TopAbilities(c.dealt), takenTop = TopAbilities(c.taken),
        maxDealt = c.maxDealt, maxDealtAbility = c.maxDealtAbility,
        maxTaken = c.maxTaken, maxTakenAbility = c.maxTakenAbility,
        -- Healing
        healReceived = healTot, hps = dur > 0 and healTot / dur or 0,
        healTop = TopAbilities(c.healIn), overHeal = SumOver(c.healIn),
        -- Effects (uptime ms; UI divides by duration). 3 buckets.
        buffsMe = EffectList(c.buffsMe), debuffsMe = EffectList(c.debuffsMe), debuffsOpp = EffectList(c.debuffsOpp),
        -- Raw stats (min/avg/max by statId)
        stats = stats,
        resources = c.resources,
        weave = c.weave,
        timeline = c.timeline,
        cc = c.cc,
        clutch = c.clutch,
        build = c.build,
        adv = c.adv,
        log = c.log,
        spendLog = c.spendLog,
    }
    rec.id = sv.nextDuelId or 1     -- stable unique id for cross-referencing this exact duel
    sv.nextDuelId = rec.id + 1
    DM.SanitizeDuel(rec)            -- drop source-less buckets + mis-tagged CC before it's stored
    o.duels[#o.duels + 1] = rec

    d(string.format("|cFFD700[Duel Metrics]|r %s vs %s \226\128\148 %s (dealt %s, taken %s). /SMX for the log.",
        ClassName(c.myClassId), c.oppName or "?", c.result:upper(), Comma(rec.dmgDealt), Comma(rec.dmgTaken)))

    -- Don't auto-open during calibration -- the Report Card is locked until 10 duels, so it would just
    -- pop up a useless "n/10" lock screen after each fight. Also skip while viewing the demo (real duel
    -- lives in the stashed real store, not the on-screen demo).
    local totalDuels = 0
    for _, o2 in pairs(store) do totalDuels = totalDuels + (o2.duels and #o2.duels or 0) end
    if not sv.realOpponents and sv.autoOpen and totalDuels >= 10 and ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.OpenDuel then
        -- Delay the auto-open past the duel-end scene handling. Showing our cursor-grabbing scene the
        -- instant the duel commits makes the game reassert its own scene and immediately hide ours (the
        -- "flashes open then closes" bug). A short defer lets the transition settle so the window sticks.
        local h, idx = handle, #o.duels
        if zo_callLater then
            zo_callLater(function()
                if sv.autoOpen and ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.OpenDuel then ShoyrUI.DuelMetricsUI.OpenDuel(h, idx) end
            end, 1200)
        else
            ShoyrUI.DuelMetricsUI.OpenDuel(h, idx)
        end
    end
end

-- ===========================================================================
-- /SMX chat report (until the window is built)
-- ===========================================================================

local RESULT_COLOR = { win = "|c66DD66", loss = "|cDD6666", draw = "|cAAB0BF" }
local function ResultStr(r) return (RESULT_COLOR[r] or "|cFFFFFF") .. (r or "?"):upper() .. "|r" end

local function ListOpponents()
    local arr = {}
    for _, o in pairs(sv.opponents) do arr[#arr + 1] = o end
    table.sort(arr, function(a, b) return #a.duels > #b.duels end)
    d("|cFFD700[Shoyru's Duel Metrics]|r \226\128\148 " .. #arr .. " opponent(s). /SMX <name> to search:")
    for _, o in ipairs(arr) do
        d(string.format("  %s (%s) [%s] \226\128\148 %dW / %dL / %dD over %d duel(s)",
            o.name or "?", o.handle or "?", ClassName(o.classId), o.wins or 0, o.losses or 0, o.draws or 0, #o.duels))
    end
    if #arr == 0 then d("  no duels recorded yet \226\128\148 go duel someone!") end
end

local function SearchOpponent(term)
    local low, found = term:lower(), 0
    for h, o in pairs(sv.opponents) do
        if ((o.name or ""):lower():find(low, 1, true)) or (h:lower():find(low, 1, true)) then
            found = found + 1
            d(string.format("|cFFD700%s|r (%s) [%s] \226\128\148 %dW / %dL / %dD, %d duels",
                o.name or "?", h, ClassName(o.classId), o.wins or 0, o.losses or 0, o.draws or 0, #o.duels))
            for i = #o.duels, math.max(1, #o.duels - 5), -1 do
                local du = o.duels[i]
                d(string.format("   %s: %s vs %s | dealt %s, taken %s, healed %s (%.0fs)",
                    ResultStr(du.result), ClassName(du.myClassId), ClassName(du.oppClassId),
                    Comma(du.dmgDealt), Comma(du.dmgTaken), Comma(du.healReceived or 0), du.durationS or 0))
            end
        end
    end
    if found == 0 then d("|cFFD700[Duel Metrics]|r no opponent matching \"" .. term .. "\".") end
end

local function OnSlash(arg)
    arg = (arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.Toggle then ShoyrUI.DuelMetricsUI.Toggle(arg); return end
    if arg == "" then ListOpponents() else SearchOpponent(arg) end
end

-- ===========================================================================
-- /smxdemo — inject synthetic duels so the SMX window can be exercised WITHOUT a
-- partner (you can't duel solo). Repeatable: reseeds on each call. /smxclear wipes
-- it. Demo opponents use "@Demo*" handles + a demo=true flag on records so they're
-- trivially identifiable and removable. DEBUG helper — gate/remove before shipping.
-- ===========================================================================
local DEMO_PREFIX = "@Demo"

local function DemoAbil(id, fallback, total, hits, crit)
    local nm = GetAbilityName(id)
    if not nm or nm == "" then nm = fallback end
    local avg = (hits > 0) and (total / hits) or total
    return { id = id, name = nm, icon = GetAbilityIcon(id) or "", total = total, hits = hits, crit = crit or 0, max = math.floor(avg * 1.8), min = math.floor(avg * 0.45),
        over = math.floor(total * math.random(0, 45) / 100),   -- 0-45% overheal (only meaningful for heals)
        dot = (math.random(100) <= 35) }   -- ~35% DoTs so the cleanse-vs-block advice branch is exercised
end
local function MkTop(spec)
    local t = {}
    for _, s in ipairs(spec) do t[#t + 1] = DemoAbil(s[1], s[2], s[3], s[4], s[5]) end
    return t
end
-- Large pools (~30 each) so a demo duel can surface 20+ distinct effects per panel and
-- the three buff/debuff sections actually scroll. Best-effort real abilityIds (drive the
-- icon; a miss just shows no icon) — the NAME string is what labels the row regardless.
local DEMO_BUFFS = {
    {61687,"Major Sorcery"}, {61685,"Minor Sorcery"}, {61665,"Major Brutality"}, {61662,"Minor Brutality"},
    {61689,"Major Prophecy"}, {61691,"Minor Prophecy"}, {61667,"Major Savagery"}, {61666,"Minor Savagery"},
    {61694,"Major Resolve"}, {61693,"Minor Resolve"}, {61696,"Major Ward"}, {61695,"Minor Ward"},
    {61745,"Major Berserk"}, {61744,"Minor Berserk"}, {61747,"Major Force"}, {61746,"Minor Force"},
    {61736,"Major Expedition"}, {61735,"Minor Expedition"}, {61709,"Major Heroism"}, {61708,"Minor Heroism"},
    {61705,"Major Endurance"}, {61704,"Minor Endurance"}, {61707,"Major Intellect"}, {61706,"Minor Intellect"},
    {61713,"Major Vitality"}, {61549,"Minor Vitality"}, {61711,"Major Mending"}, {61710,"Minor Mending"},
    {61722,"Major Protection"}, {61721,"Minor Protection"}, {88490,"Minor Toughness"}, {61716,"Major Evasion"},
}
local DEMO_DEBUFFS = {
    {61743,"Major Breach"}, {61742,"Minor Breach"}, {61725,"Major Maim"}, {61723,"Minor Maim"},
    {61727,"Major Defile"}, {61726,"Minor Defile"}, {106754,"Major Vulnerability"}, {79717,"Minor Vulnerability"},
    {147643,"Major Cowardice"}, {79867,"Minor Cowardice"}, {145977,"Major Brittle"}, {145975,"Minor Brittle"},
    {88401,"Minor Magickasteal"}, {45902,"Off Balance"}, {79895,"Minor Uncertainty"}, {140699,"Minor Timidity"},
    {79907,"Minor Enervation"}, {86304,"Minor Lifesteal"}, {18084,"Burning"}, {95136,"Chilled"},
    {95134,"Concussion"}, {21929,"Poisoned"}, {178118,"Overcharged"}, {178123,"Sundered"},
    {148801,"Hemorrhaging"}, {178127,"Diseased"}, {36968,"Marked"}, {88245,"Trauma"},
    {40457,"Degeneration"}, {86310,"Stagger"},
}
-- Which demo debuff names are STATUS EFFECTS (so the Status Effects view populates under /smxdemo;
-- real duels learn this from the game via OnRawEffect).
local DEMO_STATUS = {
    ["Burning"] = true, ["Chilled"] = true, ["Concussion"] = true, ["Poisoned"] = true,
    ["Overcharged"] = true, ["Sundered"] = true, ["Hemorrhaging"] = true, ["Diseased"] = true,
}
local function DemoEffects(pool, n, dur)
    local idx = {}; for i = 1, #pool do idx[i] = i end
    local durMs = math.max(1000, (dur or 20) * 1000)
    local out = {}
    for i = 1, math.min(n, #pool) do
        local j = math.random(i, #pool); idx[i], idx[j] = idx[j], idx[i]
        local a = pool[idx[i]]
        -- Build application intervals across the duel; ~30% fade EARLY (a purge/cleanse), the rest run
        -- their nominal duration. uptime + count are derived so the Purged column has real data.
        local nominal = math.random(5, 20)                        -- nominal duration (s)
        local nomMs, apps = nominal * 1000, math.random(1, 8)
        local step, intervals, uptime = durMs / apps, {}, 0
        for k = 1, apps do
            local s = math.floor((k - 1) * step + math.random(0, math.floor(step * 0.4)))
            if s < durMs then
                local purged = (math.random(100) <= 30)
                local len = purged and math.floor(nomMs * math.random(15, 50) / 100) or nomMs
                local e = math.min(durMs, s + len)
                intervals[#intervals + 1] = { s = s, e = e }
                uptime = uptime + (e - s)
            end
        end
        out[#out + 1] = { id = a[1], name = a[2], icon = GetAbilityIcon(a[1]) or "", isStatus = DEMO_STATUS[a[2]] or nil,
            dur = nominal, intervals = intervals, uptime = math.min(uptime, durMs), count = #intervals }
    end
    table.sort(out, function(x, y) return x.uptime > y.uptime end)
    return out
end
-- Synthetic min/avg/max stat samples (keyed by LibCombat statId) so the Stats/Grade
-- tabs have data in the demo. Crit ids (3/13) are stored as RATING (UI converts to %).
local function DemoStats()
    local function mk(base, spread)
        local avg = base * (0.92 + math.random() * 0.16)
        return { min = math.floor(avg * (1 - spread)), avg = avg, max = math.floor(avg * (1 + spread)) }
    end
    return {
        [2]  = mk(math.random(2900, 4200), 0.12),   -- spell dmg
        [12] = mk(math.random(2900, 4200), 0.12),   -- weapon dmg
        [3]  = mk(math.random(11000, 16000), 0.05), -- spell crit (rating)
        [13] = mk(math.random(11000, 16000), 0.05), -- weapon crit (rating)
        [4]  = mk(math.random(50, 82), 0.02),       -- spell crit dmg
        [14] = mk(math.random(50, 82), 0.02),       -- weapon crit dmg
        [5]  = mk(math.random(9000, 21000), 0.08),  -- spell pen (sometimes over cap)
        [15] = mk(math.random(9000, 21000), 0.08),  -- weapon pen
        [25] = mk(math.random(8, 32), 0.05),        -- status chance (already a %, not a rating)
        [21] = mk(math.random(24000, 34000), 0.04), -- max health
        [22] = mk(math.random(12000, 26000), 0.06), -- phys resist
        [23] = mk(math.random(12000, 26000), 0.06), -- spell resist
        [24] = mk(math.random(900, 2400), 0.05),    -- crit resist
        [1]  = mk(math.random(24000, 40000), 0.05), -- max magicka
        [11] = mk(math.random(20000, 34000), 0.05), -- max stamina
    }
end
-- Demo defensive advanced stats (see SnapshotAdvanced): block mitigation %, and block/dodge/CC-break costs.
local function DemoAdv()
    return {
        blockMit  = math.random(50, 62),
        blockCost = math.random(1600, 2600),
        dodgeCost = math.random(2800, 4200),
        ccBreak   = math.random(2700, 4300),
    }
end
-- Synthetic chronological event log for the combat-log view (samples the demo ability pools).
local function DemoLog(dealtTop, takenTop, healTop, dur)
    local log = {}
    local pools = { { dealtTop, "out" }, { takenTop, "in" }, { healTop, "heal" } }
    local n = math.min(LOG_CAP, math.max(24, dur * 4))
    for _ = 1, n do
        local p = pools[math.random(#pools)]
        local list = p[1]
        if list and #list > 0 then
            local a = list[math.random(#list)]
            local avg = (a.hits and a.hits > 0) and (a.total / a.hits) or (a.total or 5000)
            log[#log + 1] = { t = math.random(0, math.max(0, dur * 1000 - 1)), id = a.id, val = math.max(1, math.floor(avg * (0.6 + math.random() * 0.8))), crit = (math.random(100) <= 20), dir = p[2], dtype = a.dtype }
        end
    end
    -- a few of YOUR ult casts (Phase 1 = your side only)
    local DEMO_ULTS = { "Flawless Dawnbreaker", "Corrosive Armor", "Shifting Standard", "Soul Assault", "Permafrost", "Ravenous Goliath" }
    for _ = 1, math.random(1, math.max(1, math.min(8, math.floor(dur / 6)))) do
        log[#log + 1] = { t = math.random(0, math.max(0, dur * 1000 - 1)), id = 0, name = DEMO_ULTS[math.random(#DEMO_ULTS)], dir = "ult", actor = (math.random(100) <= 55) and "you" or "opp" }
    end
    table.sort(log, function(x, y) return x.t < y.t end)
    return log
end
-- Synthetic resource-spend log (magicka/stamina drains by ability) for the Sustain spend-by-source view.
local function DemoSpendLog(dealtTop, dur)
    local out, pts = {}, { COMBAT_MECHANIC_FLAGS_MAGICKA, COMBAT_MECHANIC_FLAGS_STAMINA }
    for _ = 1, math.min(LOG_CAP, math.max(12, dur)) do
        local a = (dealtTop and #dealtTop > 0) and dealtTop[math.random(#dealtTop)] or nil
        out[#out + 1] = { t = math.random(0, math.max(0, dur * 1000 - 1)), id = a and a.id or 0, pt = pts[math.random(2)], val = math.random(1500, 4200) }
    end
    return out
end
local function DemoResources()
    return {
        [COMBAT_MECHANIC_FLAGS_MAGICKA]  = { gains = math.random(40000, 160000), drains = math.random(50000, 180000) },
        [COMBAT_MECHANIC_FLAGS_STAMINA]  = { gains = math.random(40000, 160000), drains = math.random(50000, 180000) },
        [COMBAT_MECHANIC_FLAGS_ULTIMATE] = { gains = math.random(200, 900), drains = math.random(200, 900) },
    }
end
local function DemoWeave(dur)
    local casts = math.max(1, math.floor(dur * (0.9 + math.random() * 0.6)))
    -- Vary the weave RATIO so the report card sees both clean and sloppy games: ~35% sloppy (half to
    -- two-thirds of casts weaved -> the weave-discipline insight fires), the rest tight (80-97%).
    local ratio = (math.random(100) <= 35) and (0.50 + math.random() * 0.18) or (0.80 + math.random() * 0.17)
    local dc = math.max(1, math.floor(casts * ratio))
    -- Per-cast events spread across the duel; the first `dc` carry a weave delay (d>0 = wove a light
    -- attack), the rest d=0 (skipped). Shuffled so weaved/skipped casts interleave over time.
    local events = {}
    local durMs = math.max(1000, (dur or 20) * 1000)
    for i = 1, casts do events[i] = { t = math.floor((i - 0.5) / casts * durMs), d = (i <= dc) and math.random(100, 300) or 0 } end
    for i = #events, 2, -1 do local j = math.random(i); local td = events[i].d; events[i].d = events[j].d; events[j].d = td end
    return { casts = casts, weaves = dc, delayCount = dc, delaySum = dc * math.random(100, 300), events = events }
end
local function DemoTimeline(dur)
    -- ~30% of demo duels feature a genuine resource CRASH (a pool dumped to near-empty for a stretch)
    -- so the Report Card's resource-death-spiral insight has real data to find; the rest float normally.
    local crash = (math.random(100) <= 30)
    local crashAt = crash and math.random(2, math.max(3, dur - 3)) or -1
    local crashPool = (math.random(2) == 1) and "mag" or "stam"
    -- ~40% of demo duels take a deep HP dip (under 50%) then climb back at a variable pace, so the
    -- Defense recovery-speed read has both fast and slow recoveries to grade.
    local dip = (math.random(100) <= 40)
    local dipAt = dip and math.random(2, math.max(3, dur - 6)) or -1
    local dipLen = dip and math.random(2, 8) or 0
    local tl, mag, stam, ult, hp = {}, 1.0, 1.0, 0, 1.0
    for s = 0, math.max(0, dur - 1) do
        mag = math.max(0.15, math.min(1, mag + (math.random() - 0.55) * 0.25))
        stam = math.max(0.15, math.min(1, stam + (math.random() - 0.55) * 0.25))
        if dip and s >= dipAt and s < dipAt + dipLen then hp = 0.30 + math.random() * 0.15
        else hp = math.max(0.55, math.min(1, hp + (math.random() - 0.35) * 0.20)) end
        local mFrac, sFrac = mag, stam
        -- Around the crash second, dump the chosen pool to ~2-9% for a few seconds (a blown rotation).
        if crash and s >= crashAt and s <= crashAt + math.random(2, 4) then
            local low = 0.02 + math.random() * 0.07
            if crashPool == "mag" then mFrac = low else sFrac = low end
        end
        ult = ult + math.random(8, 28)
        local ultCast = 0
        if ult >= 500 then ult = ult - math.random(250, 500); ultCast = 1 end
        tl[s] = {
            dmgOut = math.random(0, 22000), dmgIn = math.random(0, 22000),
            heal = math.random(0, 9000),
            hp = math.floor(hp * 32000),
            mag = math.floor(mFrac * 40000), stam = math.floor(sFrac * 34000),
            ult = math.min(500, ult), ultCast = ultCast,
        }
    end
    return tl
end
-- Demo action bars: read the player's LIVE hotbars when the game API is available (the demo runs
-- in-game), else fall back to canned PvP ability ids so the Build tab still renders offline/in tests.
local function DemoBars()
    if GetSlotBoundId and HOTBAR_CATEGORY_PRIMARY and HOTBAR_CATEGORY_BACKUP then
        local bars = {}
        for b, cat in ipairs({ HOTBAR_CATEGORY_PRIMARY, HOTBAR_CATEGORY_BACKUP }) do
            local t, any = {}, false
            for i = 3, 8 do
                local id = GetSlotBoundId(i, cat)
                if id and id > 0 then t[i] = id; any = true end
            end
            if any then bars[b] = t end
        end
        if bars[1] or bars[2] then return bars end
    end
    return { { [3] = 38814, [4] = 20805, [5] = 32685, [6] = 46348, [7] = 63044, [8] = 40161 },
             { [3] = 38689, [4] = 28607, [5] = 85999, [6] = 29037, [7] = 26879, [8] = 27413 } }
end
local function DemoBuild()
    local equip = {}
    if GetItemLink and BAG_WORN and EQUIP_SLOT_ITERATION_BEGIN then
        for i = EQUIP_SLOT_ITERATION_BEGIN, EQUIP_SLOT_ITERATION_END do
            local link = GetItemLink(BAG_WORN, i, LINK_STYLE_DEFAULT)
            if link and link ~= "" then equip[i] = link end
        end
    end
    local attrs = { { hp = 0, mag = 64, stam = 0 }, { hp = 0, mag = 0, stam = 64 }, { hp = 20, mag = 0, stam = 44 } }
    -- Live duel-start-style scan when in-game (mundus/food/vamp/champion come out real); canned offline.
    local sc = ScanBuildExtras()
    -- Curse comes from the LIVE character in-game (the demo carries YOUR identity — a random
    -- curse claimed Shoyru was a werewolf); random only offline where the API is absent.
    local liveCurse; pcall(function() liveCurse = GetPlayerCurseType() end)
    local b = { equip = equip, CP = (GetPlayerChampionPointsEarned and GetPlayerChampionPointsEarned()) or math.random(1600, 3600),
        classId = (GetUnitClassId and GetUnitClassId("player")) or 3,
        bars = DemoBars(), curse = (type(liveCurse) == "number") and liveCurse or math.random(0, 2), attr = attrs[math.random(#attrs)] }
    if sc and (sc.boons[1] or sc.food[1] or sc.wwVamp or (sc.cp and next(sc.cp))) then
        b.boons = sc.boons[1] and sc.boons or nil
        b.food = sc.food[1] and sc.food or nil
        b.wwVamp = sc.wwVamp
        b.cpSlots = (sc.cp and next(sc.cp)) and sc.cp or nil
    else
        b.boons = { 13975, 13984 }                       -- Thief + Shadow (Twice-Born Star demo)
        b.food = { 84720 }                               -- Bewitched Sugar Skulls
        if b.curse == 1 then b.wwVamp = 135399 end       -- vamp stage 2 when the curse rolled vampire
        b.cpSlots = {}
        local demoStars = { 264, 260, 259, 263, 88, 89, 84, 82, 133, 134, 136, 160 }
        for i = 1, 12 do b.cpSlots[i] = { id = demoStars[i], pts = 50 } end
    end
    -- Class skill lines: live when available (subclassing-aware), canned offline.
    local ok, lines = pcall(function()
        local out, list = {}, SKILLS_DATA_MANAGER and SKILLS_DATA_MANAGER.activeClassSkillLineDataList
        for i = 1, 3 do if list and list[i] then out[i] = list[i].id end end
        return out[1] and out or nil
    end)
    b.lines = (ok and lines) or { 35, 38, 43 }           -- Ardent Flame / Assassination / Storm Calling
    -- Class masteries: live scan in-game; canned pair offline so the row renders in tests.
    b.mastery = ScanClassMastery() or { 63044, 61919 }
    -- Canned scribed entry keyed to a canned-bar ability (38689, back bar) so the script
    -- sub-row renders offline; harmlessly unmatched when live bars are in play.
    b.scribed = { [38689] = { crafted = 2, s = { 1, 22, 43 } } }
    return b
end
local DEMO_CC = {
    { 32685, "Fossilize", "Immobilize" }, { 29037, "Petrify", "Immobilize" }, { 26879, "Blazing Spear", "Immobilize" },
    { 38814, "Dizzying Swing", "Stun" }, { 20805, "Molten Whip", "Stun" }, { 63044, "Radiant Glory", "Stun" },
    { 46348, "Crushing Shock", "Snare" }, { 38689, "Endless Hail", "Snare" }, { 28607, "Flurry", "Snare" }, { 85999, "Cutting Dive", "Snare" },
}
local function DemoCC(dur)
    local durMs = (dur or 20) * 1000
    local function side()
        local order = {}; for i = 1, #DEMO_CC do order[i] = i end
        local t, pick = {}, math.random(1, 4)
        for i = 1, math.min(pick, #DEMO_CC) do
            local j = math.random(i, #DEMO_CC); order[i], order[j] = order[j], order[i]
            local c = DEMO_CC[order[i]]
            local soft = (c[3] == "Snare" or c[3] == "Immobilize" or c[3] == "Silence")
            -- Uptime for soft/root CC is capped at ~18s so long (5-12 min) demo duels don't report
            -- absurd cumulative root time; counts kept low (1-3) so hard-CC reads like a real fight.
            local cnt = math.random(1, 3)
            local times = {}; for k = 1, cnt do times[k] = math.random(0, math.max(1, durMs - 1)) end
            t[c[1]] = { kind = c[3], name = c[2], count = cnt, times = times,
                uptime = soft and math.min(18000, math.floor(durMs * math.random(10, 50) / 100)) or nil }
        end
        return t
    end
    return { onMe = side(), onOpp = side() }
end

-- Scary blockable/dodgeable burst abilities, so the clutch ledger names real threats in /smxdemo.
local DEMO_BURST = {
    { 62599, "Dawnbreaker of Smiting" }, { 46331, "Crystal Fragments" }, { 113105, "Incapacitating Strike" },
    { 133027, "Onslaught" }, { 126724, "Soul Assault" }, { 38547, "Reverse Slice" }, { 38596, "Executioner" },
}
-- Wards for demo shield rows. Real DAMAGE_SHIELDED events name the WARD that absorbed, not the attack
-- (verified vs live data 2026-07-07), so demo shields live on their own shield-only ward rows too.
local DEMO_WARDS = {
    { 61506, "Concentrated Barrier" }, { 29224, "Hardened Ward" }, { 30962, "Tri Focus" },
}
-- Synthetic active-defense ledger (see cur.clutch): what you blocked/dodged of THEIR attacks (defensive)
-- and what THEY blocked/dodged of yours (wasted offense), plus ward rows -- ~45% of defensive sides
-- (~30% offensive) get one so the shield-as-sustain path populates with real-shaped data.
-- COHERENT with the rest of the record (Shoyru's demo-defense audit: every demo duel graded D/F on
-- Defense because clutch ids never matched the ability tables and times never hit the burst window):
-- defensive rows reference THEIR real takenTop abilities (non-DoT), offensive rows reference YOUR
-- dealtTop; ~65% of defensive sides land some saves inside the timeline's incoming-peak 3s window.
local function DemoClutch(dur, dealtTop, takenTop, tl)
    -- their hardest incoming 3s window (mirrors RC.PeakIn) so demo saves can be placed inside it
    local peakAt, peakVal = 0, -1
    if type(tl) == "table" then
        for s = 0, math.floor(dur) do
            local sum = 0
            for k = 0, 2 do local b = tl[s + k]; if b then sum = sum + (b.dmgIn or 0) end end
            if sum > peakVal then peakVal, peakAt = sum, s end
        end
    end
    local function side(defensive)
        local t = {}
        -- pull attack rows from the matching ability table (non-DoT only -- you can't block a tick);
        -- fall back to the generic burst pool when the table is thin.
        local pool = {}
        for _, a in ipairs((defensive and takenTop or dealtTop) or {}) do
            if a.id and a.name and not a.dot and not a.name:find("^Light Attack") and not a.name:find("^Heavy Attack") then
                pool[#pool + 1] = { a.id, a.name }
            end
        end
        if #pool == 0 then pool = DEMO_BURST end
        local answered = defensive and (math.random(100) <= 65)
        for i = 1, math.min(math.random(1, 3), #pool) do
            local j = math.random(i, #pool); pool[i], pool[j] = pool[j], pool[i]
            local a = pool[i]
            local blk, dg = math.random(0, 3), math.random(0, 2)
            if blk + dg > 0 then
                local times = {}
                for k = 1, (blk + dg) do
                    if answered and i == 1 and k <= 2 then
                        times[k] = peakAt * 1000 + math.random(0, 2900)   -- a save INSIDE their burst window
                    else
                        times[k] = math.random(0, math.max(1, dur * 1000 - 1))
                    end
                end
                t[a[1]] = { name = a[2], block = blk, dodge = dg, shield = 0, absorbed = 0, times = times }
            end
        end
        if math.random(100) <= (defensive and 45 or 30) then
            local w = DEMO_WARDS[math.random(#DEMO_WARDS)]
            local sh = math.random(1, 4)
            local times = {}; for k = 1, sh do times[k] = math.random(0, math.max(1, dur * 1000 - 1)) end
            t[w[1]] = { name = w[2], block = 0, dodge = 0, shield = sh, absorbed = math.random(8000, 45000), times = times }
        end
        return t
    end
    return { onMe = side(true), onOpp = side(false) }
end

-- Damage-type pools for demo synthesis. Referenced BY NAME so they match whatever the analyzer uses:
-- real ESO ints in-game, stable auto-stub ints under the test env (so magic-vs-physical stays coherent).
local DTYPE_MAGIC = { DAMAGE_TYPE_FIRE, DAMAGE_TYPE_SHOCK, DAMAGE_TYPE_COLD, DAMAGE_TYPE_MAGIC }
local DTYPE_PHYS  = { DAMAGE_TYPE_PHYSICAL, DAMAGE_TYPE_BLEED, DAMAGE_TYPE_POISON, DAMAGE_TYPE_DISEASE }
-- Paint a coherent damage-type profile onto an ability list: a "ranged" fighter's damage is mostly
-- magic/staff types, a melee fighter's is physical. ~30% roll monoculture (one type) so the
-- damage-type-mix + kiter/brawler insights have varied material to fire on.
local function DemoPaintTypes(list, ranged, mono)
    local pool = ranged and DTYPE_MAGIC or DTYPE_PHYS
    if mono then pool = { pool[math.random(#pool)] } end
    for i, a in ipairs(list) do a.dtype = pool[((i - 1) % #pool) + 1] end
end
local function DemoDuel(hoursAgo, result, oppClassId, dur, dealtTop, takenTop, healTop)
    local function sum(t) local s = 0; for _, a in ipairs(t) do s = s + a.total end; return s end
    local dealt, taken, heal = sum(dealtTop), sum(takenTop), sum(healTop)
    local overheal = 0; for _, a in ipairs(healTop) do overheal = overheal + (a.over or 0) end
    -- Damage-type profiles (assigned before the log is built so log entries can inherit the type):
    -- YOUR damage drives the monoculture read; the OPPONENT's damage on you drives their weapon/role read.
    DemoPaintTypes(dealtTop, (math.random(100) <= 50), math.random(100) <= 30)
    DemoPaintTypes(takenTop, (math.random(100) <= 50), math.random(100) <= 30)
    -- Timeline first: the clutch ledger aligns its saves to the incoming-damage peak inside it.
    local tl = DemoTimeline(dur)
    return {
        date = GetTimeStamp() - hoursAgo * 3600,
        result = result,
        myClassId = (GetUnitClassId and GetUnitClassId("player")) or 3,
        myName = Norm(GetRawUnitName and GetRawUnitName("player") or GetUnitName and GetUnitName("player")),
        myHandle = (GetDisplayName and GetDisplayName()) or "@you",
        myRaceId = (GetUnitRaceId and GetUnitRaceId("player")) or math.random(1, 10),
        oppRaceId = math.random(1, 10),
        myCP = (GetPlayerChampionPointsEarned and GetPlayerChampionPointsEarned()) or math.random(1600, 3600),
        oppCP = math.random(1600, 3600),
        oppClassId = oppClassId,
        durationS = dur,
        dmgDealt = dealt, dmgTaken = taken,
        dpsOut = math.floor(dealt / dur), dpsIn = math.floor(taken / dur),
        dealtTop = dealtTop, takenTop = takenTop,
        maxDealt = dealtTop[1] and math.floor(dealtTop[1].total / math.max(1, dealtTop[1].hits) * 2.0) or 0,
        maxDealtAbility = dealtTop[1] and dealtTop[1].id or nil,
        maxTaken = takenTop[1] and math.floor(takenTop[1].total / math.max(1, takenTop[1].hits) * 2.0) or 0,
        maxTakenAbility = takenTop[1] and takenTop[1].id or nil,
        healReceived = heal, hps = math.floor(heal / dur), healTop = healTop, overHeal = overheal,
        -- High counts (pools hold ~30) so every panel overflows past 15 rows and scrolls.
        buffsMe = DemoEffects(DEMO_BUFFS, math.random(16, 28), dur),
        debuffsMe = DemoEffects(DEMO_DEBUFFS, math.random(12, 22), dur),
        debuffsOpp = DemoEffects(DEMO_DEBUFFS, math.random(14, 24), dur),
        stats = DemoStats(), resources = DemoResources(), weave = DemoWeave(dur),
        timeline = tl, build = DemoBuild(), cc = DemoCC(dur),
        clutch = DemoClutch(dur, dealtTop, takenTop, tl),
        adv = DemoAdv(),
        log = DemoLog(dealtTop, takenTop, healTop, dur),
        spendLog = DemoSpendLog(dealtTop, dur),
        demo = true,
    }
end

-- Guarantee a KILLING BLOW on a decisive demo duel: append a final burst cluster on the
-- winner's side, ending just before the duel does (well over the Bursts view's 2x-average
-- threshold), and fold it into the record's totals/per-ability/timeline so every tab stays
-- self-consistent. ~45% also open with an ult cast so the ULT tag shows on some of them.
local function InjectKB(du)
    if du.result ~= "win" and du.result ~= "loss" then return end
    local out = du.result == "win"
    local side = out and du.dealtTop or du.takenTop
    if not (side and side[1] and du.log) then return end
    local durMs = du.durationS * 1000
    -- Sized so the cluster clears the Bursts threshold EVEN AFTER it inflates the fight's own
    -- average (X >= 2 * 3s * (T+X)/dur  ==>  X >= 6T/(dur-6); 8T gives ~1.3x margin). T must be
    -- the EVENT-LOG sum for this side — the detector averages over the log, and the demo log's
    -- total diverges from the ability-table totals.
    local baseTotal = 0
    local dirKey = out and "out" or "in"
    for _, e in ipairs(du.log) do if e.dir == dirKey and (e.val or 0) > 0 then baseTotal = baseTotal + e.val end end
    local target = math.max(24000, math.ceil(8 * baseTotal / math.max(3, du.durationS - 6)))
    local nHits = math.random(2, 4)
    local tEnd = durMs - math.random(300, 900)
    local t = math.max(0, tEnd - math.random(1200, 2200))
    if math.random(100) <= 45 then
        du.log[#du.log+1] = { t = math.max(0, t - math.random(200, 800)), id = 0,
            name = out and "Dawnbreaker of Smiting" or "Onslaught", dir = "ult", actor = out and "you" or "opp" }
    end
    local left = target
    for h = 1, nHits do
        local a = side[math.random(#side)]
        local val = (h == nHits) and left or math.min(left, math.floor(target / nHits * (70 + math.random(60)) / 100))
        val = math.max(1000, val); left = math.max(0, left - val)
        local ht = math.min(tEnd, t)
        du.log[#du.log+1] = { t = ht, id = a.id, val = val, crit = math.random(100) <= 40, dir = out and "out" or "in" }
        a.total = a.total + val; a.hits = (a.hits or 0) + 1
        local sec = math.floor(ht / 1000)
        local tl = du.timeline and du.timeline[sec]
        if tl then if out then tl.dmgOut = (tl.dmgOut or 0) + val else tl.dmgIn = (tl.dmgIn or 0) + val end end
        if out then du.dmgDealt = du.dmgDealt + val else du.dmgTaken = du.dmgTaken + val end
        t = t + math.floor((tEnd - t) / math.max(1, nHits - h)) + math.random(0, 150)
    end
    du.dpsOut = math.floor(du.dmgDealt / math.max(1, du.durationS))
    du.dpsIn = math.floor(du.dmgTaken / math.max(1, du.durationS))
    -- burst detection + the Log view assume the event stream is chronological (real capture
    -- appends in order); re-sort since the cluster was appended after earlier-timed events
    table.sort(du.log, function(x, y) return (x.t or 0) < (y.t or 0) end)
end

local function WipeDemo()
    local removed = 0
    if sv and sv.opponents then
        for h in pairs(sv.opponents) do
            if type(h) == "string" and h:find("^" .. DEMO_PREFIX) then sv.opponents[h] = nil; removed = removed + 1 end
        end
    end
    return removed
end

function DM.Demo(count)
    count = tonumber(count) or 20
    if not sv then d("|cFFD700[Duel Metrics]|r not ready yet.") return end
    -- Enter an ISOLATED demo view: stash the real store aside (once) and seed the demo into a fresh store,
    -- so demo duels never mix with your real rank/calibration/list. /smxclear (or a reload) restores real.
    if not sv.realOpponents then sv.realOpponents = sv.opponents end
    sv.opponents = {}
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.ResetAnalytics then ShoyrUI.DuelMetricsUI.ResetAnalytics() end

    local function opp(handle, name, classId)
        local o = { name = name, handle = handle, classId = classId, wins = 0, losses = 0, draws = 0, duels = {} }
        sv.opponents[handle] = o
        return o
    end
    local function add(o, du)
        o.duels[#o.duels + 1] = du
        if du.result == "win" then o.wins = o.wins + 1
        elseif du.result == "draw" then o.draws = o.draws + 1
        else o.losses = o.losses + 1 end
    end

    -- Default 20 duels (Shoyru's review size); /smxdemo <n> seeds more (e.g. 100 for the
    -- scale/scroll pressure test). Every duel is DECISIVE with an injected killing-blow
    -- cluster so the Bursts view's KILLING BLOW (and often ULT) tags are always on display.
    math.randomseed(((GetTimeStamp and GetTimeStamp()) or 0) + ((GetGameTimeMilliseconds and GetGameTimeMilliseconds()) or 0))
    -- 3rd value = YOUR win probability vs that person, so the overall rank + its rival/peer/
    -- nemesis breakdown are actually exercised (a lone nemesis @15% + a peer @50% + strong
    -- results everywhere else ~= a realistic A/S profile, worst matchup blocks S+).
    local ROSTER = {
        { "Zaudrus", 3, 0.90 }, { "Iceheart", 2, 0.85 }, { "Bleakrock", 6, 1.00 }, { "Shadowmere", 3, 0.78 },
        { "Molag", 1, 0.15 },   -- nemesis: he's better than you
        { "Kynareth", 4, 0.50 },-- peer: dead-even matchup
        { "Vulkhel", 5, 0.95 }, { "Sancre", 117, 0.82 },
        { "Deshaan", 6, 0.88 }, { "Rimmen", 2, 0.70 }, { "Skywatch", 4, 0.62 }, { "Bangkorai", 1, 1.00 },
    }
    -- Large pools so a duel can surface ~20 distinct damage sources (pressure test).
    local DEALT = {
        {46348,"Crushing Shock"}, {103623,"Crushing Weapon"}, {16499,"Light Attack"}, {39011,"Elemental Blockade"},
        {38807,"Wrecking Blow"}, {46356,"Force Pulse"}, {38268,"Deep Slash"}, {28306,"Puncture"}, {38823,"Reverse Slice"},
        {38814,"Dizzying Swing"}, {103571,"Elemental Weapon"}, {38819,"Executioner"}, {26188,"Puncturing Sweeps"},
        {38689,"Endless Hail"}, {203447,"Bound Armaments"}, {40457,"Degeneration"}, {20805,"Molten Whip"},
        {26879,"Blazing Spear"}, {32685,"Fossilize"}, {21230,"Venomous Claw"}, {38906,"Deadly Cloak"}, {85999,"Cutting Dive"},
    }
    local TAKEN = {
        {61919,"Merciless Resolve"}, {38660,"Poison Injection"}, {25260,"Surprise Attack"}, {46324,"Crystal Fragments"},
        {26188,"Puncturing Sweeps"}, {18718,"Mages' Fury"}, {46340,"Force Shock"}, {28591,"Whirlwind"}, {34851,"Impale"},
        {21732,"Reflective Light"}, {28607,"Flurry"}, {17897,"Frozen Weapon"}, {103623,"Crushing Weapon"},
        {88803,"Cliff Racer"}, {185805,"Fatecarver"}, {87663,"Screaming Cliff Racer"}, {23236,"Streak"}, {38970,"Frost Reach"},
        {26114,"Puncturing Strikes"}, {29037,"Petrify"}, {46356,"Force Pulse"}, {63044,"Radiant Glory"},
    }
    local HEAL  = { {40076,"Rapid Regeneration"}, {61507,"Resolving Vigor"}, {61503,"Vigor"}, {40079,"Radiating Regeneration"}, {22253,"Honor the Dead"}, {22262,"Extended Ritual"} }

    local function pickAbilities(pool, count)
        local idx = {}; for i = 1, #pool do idx[i] = i end
        local out = {}
        local n = math.min(count, #pool)
        -- Heavy-tailed like a real fight: a lead ability (or two) carries a big share, the rest chip
        -- in with a decaying tail. ~40% of the time the lead spikes hard enough to read as a
        -- one-dimensional build (so the Report Card's damage-concentration insight has something to
        -- catch). Sorted desc so [1] is genuinely the biggest (matches real TopAbilities + maxDealt).
        local spike = (math.random(100) <= 40) and math.random(230, 340) / 100 or math.random(120, 180) / 100
        for i = 1, n do
            local j = math.random(i, #pool); idx[i], idx[j] = idx[j], idx[i]
            local a = pool[idx[i]]
            -- The spike drives DAMAGE (bigger hits), not hit COUNT -- so the lead ability reads like a
            -- hard-hitting spammable, not thousands of ticks. Hit count decays gently down the tail.
            local decay = (i == 1) and 1.3 or 1 / (1 + (i - 1) * 0.4)
            local hits = math.max(2, math.floor(math.random(6, 40) * math.max(0.3, decay)))
            local total = math.floor(hits * math.random(2500, 9500) * ((i == 1) and spike or 1))
            out[#out+1] = DemoAbil(a[1], a[2], total, hits, math.random(0, hits))
        end
        table.sort(out, function(x, y) return x.total > y.total end)
        return out
    end

    local opps, winProb = {}, {}
    for _, nc in ipairs(ROSTER) do
        local o = opp(DEMO_PREFIX .. nc[1], nc[1], nc[2])
        opps[#opps+1] = o; winProb[o] = nc[3] or 0.5
    end

    -- Fill opponents up to the rating threshold (3 decisive duels) IN ORDER before scattering
    -- the rest at random, so ~count/3 opponents are always rated -> the overall rank actually
    -- shows in /smxdemo (20 duels -> ~6 rated rivals, past the 5-rival gate) instead of every
    -- matchup being too thin to count.
    local RATE_MIN = 3
    local order = {}
    for oi = 1, #opps do for _ = 1, RATE_MIN do order[#order+1] = oi end end

    for i = 1, count do
        local o = order[i] and opps[order[i]] or opps[math.random(#opps)]
        -- ~20% are long, drawn-out duels (5-12 min) so the Ebb & Flow graph can be seen at length.
        local dur = (math.random(100) <= 20) and math.random(300, 720) or math.random(9, 55)
        -- Result drawn from YOUR win probability vs this specific opponent (see ROSTER).
        local result = (math.random() <= winProb[o]) and "win" or "loss"
        -- RANDOM date (not i*3): the opponent order runs strong->weak, so sequential dates put all the
        -- wins in the newest slots and made the trend read "Improving" forever. Random breaks that.
        local du = DemoDuel(math.random(1, count * 3), result, o.classId, dur,
            pickAbilities(DEALT, math.random(6, 20)),
            pickAbilities(TAKEN, math.random(5, 20)),
            pickAbilities(HEAL, math.random(2, 5)))
        InjectKB(du)
        add(o, du)
    end

    DM.EnsureDuelIds()   -- demo duels are referenceable too (header shows "Duel #N")
    local n = 0; for _ in pairs(sv.opponents) do n = n + 1 end
    d(string.format("|cFFD700[Duel Metrics]|r seeded %d demo duels (all with killing blows) across %d opponents. |c9a9aa2/smxdemo <n>|r for more, |c9a9aa2/smxclear|r wipes.", count, n))
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.ShowLog then ShoyrUI.DuelMetricsUI.ShowLog() end
end

function DM.DemoClear()
    if sv and sv.realOpponents then
        -- Leave the demo view: restore the real store and drop the demo.
        sv.opponents = sv.realOpponents; sv.realOpponents = nil
        if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.ResetAnalytics then ShoyrUI.DuelMetricsUI.ResetAnalytics() end
        d("|cFFD700[Duel Metrics]|r left the demo \226\128\148 showing your real duels again.")
    else
        local removed = WipeDemo()   -- legacy: clean any stray @Demo* left in the real store
        d("|cFFD700[Duel Metrics]|r removed " .. removed .. " demo opponent(s).")
    end
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.RefreshIfOpen then ShoyrUI.DuelMetricsUI.RefreshIfOpen() end
end

-- FULL reset -- wipe EVERY duel record (real + demo) for a clean, first-install state. Marks the
-- migration done (sv.migrated) so nothing re-imports on the next load, and clears the legacy Shoyru's UI
-- duel store (the migration source) if it's present, so a true fresh start actually stays fresh.
function DM.Wipe()
    if not sv then d("|cFFD700[Duel Metrics]|r not ready yet.") return end
    if sv.realOpponents then sv.opponents = sv.realOpponents; sv.realOpponents = nil end   -- wipe REAL, not the demo view
    local opps, duels = 0, 0
    for _, o in pairs(sv.opponents or {}) do opps = opps + 1; duels = duels + (o.duels and #o.duels or 0) end
    sv.opponents = {}
    sv.migrated = true
    sv.autoOpen = false   -- reset the preference to the fresh-install default too
    if type(ShoyrUISavedVariables) == "table" and type(ShoyrUISavedVariables.duels) == "table" and type(ShoyrUISavedVariables.duels.opponents) == "table" then
        ShoyrUISavedVariables.duels.opponents = {}   -- clear the migration source too (legacy leftover)
    end
    d(string.format("|cFFD700[Duel Metrics]|r WIPED %d opponent(s) / %d duel(s). Clean slate \226\128\148 the Report Card recalibrates from 0 (unlocks after 10 duels).", opps, duels))
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.RefreshIfOpen then ShoyrUI.DuelMetricsUI.RefreshIfOpen() end
end

-- /smxrank <tier> — DEBUG: seed demo rivals whose win rates land your OVERALL RANK exactly on
-- a chosen tier, so the hero chip's colours, S-band burst/shimmer, progression bar and the
-- "how ranks work" modal highlight can all be verified without grinding real duels. Args:
--   S+ S S- A+ A A- B+ B B- C+ C C- D+ D D- F  -> that exact tier
--   prov (or -)  -> the pre-placement "3/5 rivals, duel 2 more" state
--   sblock       -> 95%+ average but a lone nemesis, so you're HELD at S (exercises the S+ gate)
--   list         -> print the options
-- Because each rival is seeded with the SAME number of decisive duels (D), the mean of the
-- per-rival win rates equals totalWins/totalDuels EXACTLY, so we hit the target band on the nose.
-- Cutoffs MIRROR RANK.grades in DuelMetricsUI.lua — keep the two in sync if you retune them.
function DM.RankDemo(arg)
    if not sv then d("|cFFD700[Duel Metrics]|r not ready yet.") return end
    sv.opponents = sv.opponents or {}
    local key = tostring(arg or ""):gsub("%s+", ""):upper()

    -- {tier, floor%} top-down, identical to RANK.grades. The rung above's floor is this band's ceiling.
    local GRADES = {
        {"S+",95},{"S",90},{"S-",85},{"A+",81},{"A",77},{"A-",72},
        {"B+",68},{"B",64},{"B-",60},{"C+",56},{"C",52},{"C-",48},
        {"D+",44},{"D",40},{"D-",35},{"F",0},
    }
    if key == "" or key == "LIST" or key == "HELP" or key == "?" then
        d("|cFFD700[Duel Metrics]|r /smxrank <tier> \226\128\148 force your overall rank for visual testing.")
        d("  tiers: |c9a9aa2S+ S S- A+ A A- B+ B B- C+ C C- D+ D D- F|r")
        d("  also: |c9a9aa2prov|r (pre-placement) \194\183 |c9a9aa2sblock|r (held at S by one nemesis) \194\183 |c9a9aa2list|r")
        return
    end

    -- Isolated demo view (same as /smxdemo): stash real aside, seed rivals into a fresh store.
    if not sv.realOpponents then sv.realOpponents = sv.opponents end
    sv.opponents = {}
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.ResetAnalytics then ShoyrUI.DuelMetricsUI.ResetAnalytics() end
    math.randomseed(((GetTimeStamp and GetTimeStamp()) or 0) + ((GetGameTimeMilliseconds and GetGameTimeMilliseconds()) or 0))

    -- valid class ids so seeded rivals show real class colours/icons (1-6 + 117 Arcanist).
    local CLS = { 1, 2, 3, 4, 5, 6, 117 }
    -- small ability pools so a seeded rival's duel still opens with populated tabs if clicked.
    local DEALT = { {46356,"Force Pulse"}, {38807,"Wrecking Blow"}, {26188,"Puncturing Sweeps"}, {38819,"Executioner"} }
    local TAKEN = { {61919,"Merciless Resolve"}, {46324,"Crystal Fragments"}, {34851,"Impale"}, {28607,"Flurry"} }
    local HEAL  = { {61507,"Resolving Vigor"}, {40076,"Rapid Regeneration"} }
    local function abils(pool, n)
        local out = {}
        for i = 1, math.min(n, #pool) do
            local a = pool[i]
            local hits = math.random(4, 40)
            out[#out+1] = DemoAbil(a[1], a[2], hits * math.random(2500, 9000), hits, math.random(0, hits))
        end
        return out
    end
    local hour = 0
    local function seedRival(idx, wins, losses)
        local classId = CLS[((idx - 1) % #CLS) + 1]
        local o = { name = "Rank " .. idx, handle = DEMO_PREFIX .. "Rank" .. idx, classId = classId,
            wins = 0, losses = 0, draws = 0, duels = {} }
        sv.opponents[o.handle] = o
        local function one(res)
            hour = hour + 1
            local du = DemoDuel(hour, res, classId, math.random(12, 45), abils(DEALT, 4), abils(TAKEN, 4), abils(HEAL, 2))
            InjectKB(du)
            o.duels[#o.duels + 1] = du
            if res == "win" then o.wins = o.wins + 1 else o.losses = o.losses + 1 end
        end
        for _ = 1, wins do one("win") end
        for _ = 1, losses do one("loss") end
    end

    -- PROVISIONAL: 3 rated rivals, under the 5-rival gate -> chip shows "3/5, duel 2 more".
    if key == "PROV" or key == "PROVISIONAL" or key == "-" then
        for i = 1, 3 do seedRival(i, 7, 3) end
        d("|cFFD700[Duel Metrics]|r seeded a PROVISIONAL profile (3/5 rivals). Open |c9a9aa2/smx|r.")
        if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.RefreshIfOpen then ShoyrUI.DuelMetricsUI.RefreshIfOpen() end
        return
    end

    -- SBLOCK: many near-perfect rivals + one nemesis, so the mean clears 95% (Compute yields S+)
    -- but the sub-65% worst matchup demotes it to S — the exact state the S+ gate is built to catch,
    -- and the one that flips the progression caption to "beat every rival >= 65%".
    if key == "SBLOCK" or key == "S+BLOCK" or key == "SB" then
        for i = 1, 20 do seedRival(i, 3, 0) end    -- 20 rivals at 100% -> mean clears 95% (Compute yields S+)
        seedRival(21, 1, 3)                         -- one nemesis at 25% -> worst < 65 demotes it to S
        d("|cFFD700[Duel Metrics]|r seeded S (held): 95%+ avg but a 25%% nemesis blocks S+. Open |c9a9aa2/smx|r.")
        if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.RefreshIfOpen then ShoyrUI.DuelMetricsUI.RefreshIfOpen() end
        return
    end

    -- Named tier: aim for a mean 60% of the way up its band (comfortably clear of both edges),
    -- then split the wins evenly across the rivals so the average lands on that mean exactly.
    local lo, hi
    for i, g in ipairs(GRADES) do
        if g[1] == key then lo = g[2]; hi = (i == 1) and 100 or GRADES[i - 1][2]; break end
    end
    if not lo then
        d("|cFFD700[Duel Metrics]|r unknown tier '" .. key .. "'. Try |c9a9aa2/smxrank list|r.")
        return
    end
    local R, D = 6, 10                       -- 6 rivals (past the 5-rival gate), 10 decisive duels each
    local mean = lo + (hi - lo) * 0.6
    local totalWins = math.max(0, math.min(R * D, math.floor(mean / 100 * R * D + 0.5)))
    local base, extra = math.floor(totalWins / R), totalWins % R
    for i = 1, R do
        local w = base + ((i <= extra) and 1 or 0)
        seedRival(i, w, D - w)
    end
    d(string.format("|cFFD700[Duel Metrics]|r seeded a %s profile (%d rivals, avg %d%% win). Open |c9a9aa2/smx|r.",
        key, R, math.floor(totalWins / (R * D) * 100 + 0.5)))
    if ShoyrUI.DuelMetricsUI and ShoyrUI.DuelMetricsUI.RefreshIfOpen then ShoyrUI.DuelMetricsUI.RefreshIfOpen() end
end

-- ===========================================================================
-- Init
-- ===========================================================================

function DM.HasEngine() return LC ~= nil end

-- ---- Live snapshot for the in-duel HUD ------------------------------------
-- Derive current rates from the running accumulators. Live DPS/HPS use WALL-CLOCK duel time
-- (now - duelStart), the same basis as the HUD's duration readout -- so the numbers stay coherent
-- with the clock the user is watching. (The committed record uses LibCombat's combattime, which
-- excludes any out-of-combat gap; in a duel the two are ~identical.) Split into a pure helper so the
-- rate math is unit-testable without a live `cur`.
--   active == true  -> a duel is in progress (numbers still climbing)
--   active == false -> duel finished, awaiting commit (HUD freezes on the DUEL_FINISHED event anyway)
function DM._LiveFrom(c, now)
    if not c then return nil end
    -- Denominator = ACTIVE combat span (first damage -> last damage), matching how the committed record's
    -- DPS is derived. While the duel is live the window runs first-hit -> now; once finished it freezes at
    -- the last hit. Before the first hit there's no combat yet -> span 0 -> rates read 0.
    local cs = c.combatStart
    local endMs = (c.result ~= nil) and (c.combatLast or cs or now) or now
    local dur = cs and math.max(0, ((endMs or now) - cs) / 1000) or 0
    local d = (dur > 0.05) and dur or 0.05                    -- guard the first tick (div-by-zero)
    local dealt = (c.sumDealt or 0) + (c.sumDealtShield or 0)   -- + damage the enemy's ward absorbed
    local taken = (c.sumTaken or 0) + (c.sumTakenShield or 0)   -- + enemy damage your ward absorbed
    return {
        out = dealt / d, hps = (c.sumHeal or 0) / d, inc = taken / d,
        dur = dur, dealt = dealt, taken = taken, heal = c.sumHeal or 0,
        maxHit = c.maxDealt or 0, active = (c.result == nil),
    }
end
function DM.LiveSnapshot() return DM._LiveFrom(cur, GetGameTimeMilliseconds()) end

-- Stable, unique, monotonically-increasing per-duel id (shown as "Duel #N" in the UI) so a specific duel
-- can be referenced across sessions and machines. Backfills any record missing one (existing saves + freshly
-- migrated duels) ONCE, in global date order, then hands out sv.nextDuelId to new duels at commit. Never reused.
function DM.EnsureDuelIds()
    if not sv then return end
    local maxId, missing = 0, {}
    for _, o in pairs(sv.opponents or {}) do
        for _, du in pairs((type(o) == "table" and o.duels) or {}) do
            if type(du) == "table" then
                if type(du.id) == "number" then
                    if du.id > maxId then maxId = du.id end
                else
                    missing[#missing + 1] = du
                end
            end
        end
    end
    table.sort(missing, function(a, b) return (a.date or 0) < (b.date or 0) end)
    local nextId = math.max(maxId + 1, sv.nextDuelId or 1)
    for _, du in ipairs(missing) do du.id = nextId; nextId = nextId + 1 end
    sv.nextDuelId = nextId
end

-- One-time, per-duel data hygiene applied on load (covers records saved before these fixes) and on every
-- fresh commit. Two corrections, both "remove what provably should not be there", never invent data:
--   1. Source-less ability buckets (id <= 0) are dropped from the damage/heal top lists -- the game reports
--      the odd hit/heal with no ability, LibCombat excludes them from its totals, and they render as "#0".
--   2. CC ledger cleanup: ESO attaches the active CC result to whatever the unit was doing, so old records
--      logged your OWN actions as incoming CC. Correct it by ownership: an INCOMING CC should be the
--      ENEMY's ability, so drop any entry that is one of YOUR abilities -- it appears in what YOU did
--      (damage / healing / self-buffs / debuffs you applied). Matched by NAME as well as id, because the
--      CC event is tagged with an ability's CAST id while your damage/heal list holds its TICK id (a pure
--      id match misses Vigor/Cauterize/Heart of Flame etc.). The OUTGOING side is the mirror: an outgoing
--      CC should be YOUR ability, so drop anything that is one of THEIRS (their damage to you / their
--      debuffs on you). Universal self-actions (Break Free / weapon swap / light+heavy attacks) go on both.
function DM.SanitizeDuel(du)
    if type(du) ~= "table" then return end
    local function dropSourceless(list)
        if type(list) ~= "table" then return end
        for i = #list, 1, -1 do
            local a = list[i]
            if type(a) ~= "table" or not a.id or a.id <= 0 then table.remove(list, i) end
        end
    end
    dropSourceless(du.dealtTop); dropSourceless(du.takenTop); dropSourceless(du.healTop)
    -- Reconcile the headline totals + rates to the (uncapped) per-ability rows -- the honest player-vs-
    -- player numbers. Old records stored LibCombat's damageOutTotal, which over-counted outgoing damage
    -- (stray AoE/DoT on the opponent's pets) by up to ~30%, so the DPS tiles disagreed with both the
    -- ability list and the live HUD. Recompute from the rows so all three agree. durationS is left as
    -- saved (old records predate the combat-span capture); new commits already store the tight span.
    local function rowsum(list) local s = 0; for _, a in ipairs(list or {}) do s = s + (a.total or 0) end; return s end
    local d = (du.durationS and du.durationS > 0) and du.durationS or nil
    -- Add back damage the enemy's ward absorbed (kept separately, not in dealtTop, since the event names
    -- the ward not the attack) so the headline DPS on a shielded target isn't under-reported.
    if type(du.dealtTop) == "table" then du.dmgDealt = rowsum(du.dealtTop) + (du.dmgShieldedOut or 0); if d then du.dpsOut = du.dmgDealt / d end end
    if type(du.takenTop) == "table" then du.dmgTaken = rowsum(du.takenTop) + (du.dmgShieldedIn or 0); if d then du.dpsIn = du.dmgTaken / d end end
    if type(du.healTop) == "table" then du.healReceived = rowsum(du.healTop); if d then du.hps = du.healReceived / d end end
    if type(du.cc) == "table" then
        -- Build a set of ability names + ids from several sources (the player's or the opponent's).
        local function collect(sets)
            local names, ids = {}, {}
            for _, list in ipairs(sets) do
                for _, a in ipairs(list or {}) do
                    if a.id then ids[a.id] = true end
                    if type(a.name) == "string" and a.name ~= "" then names[a.name:lower()] = true end
                end
            end
            return names, ids
        end
        -- What YOU did vs what THEY did (used to decide ownership of a mis-tagged CC).
        local myN, myId = collect({ du.dealtTop, du.healTop, du.buffsMe, du.debuffsOpp })
        local opN, opId = collect({ du.takenTop, du.debuffsMe })
        local function cleanCC(side, names, ids)
            if type(side) ~= "table" then return end
            for id, r in pairs(side) do
                if type(r) == "table" then
                    local nm = type(r.name) == "string" and r.name:lower() or nil
                    if IsSelfActionName(r.name) or ids[id] or (nm and names[nm]) then side[id] = nil end
                end
            end
        end
        cleanCC(du.cc.onMe, myN, myId)     -- incoming CC that is YOUR ability = a mis-tag
        cleanCC(du.cc.onOpp, opN, opId)    -- outgoing CC that is THEIR action = a mis-tag
    end
end

function DM.Init(dmSv)
    sv = dmSv
    sv.opponents = sv.opponents or {}
    -- If a demo view was open when we last logged out, restore the real store and discard the demo, so a
    -- reload always comes back to your real duels (demo is ephemeral).
    if sv.realOpponents then sv.opponents = sv.realOpponents; sv.realOpponents = nil end
    -- Self-healing invariant: the real store must never contain @Demo* opponents. Purge any left behind by
    -- pre-isolation /smxdemo runs (this is why an old save showed a combined real+demo record).
    for h in pairs(sv.opponents) do if type(h) == "string" and h:find("^" .. DEMO_PREFIX) then sv.opponents[h] = nil end end
    if sv.autoOpen == nil then sv.autoOpen = false end
    LC = LibCombat   -- optional; nil = degrade to a basic record (result + duration only)

    EM:RegisterForEvent("ShoyrUI_DM_Start", EVENT_DUEL_STARTED, OnDuelStarted)
    EM:RegisterForEvent("ShoyrUI_DM_Finish", EVENT_DUEL_FINISHED, OnDuelFinished)
    EM:RegisterForEvent("ShoyrUI_DM_RawEffect", EVENT_EFFECT_CHANGED, OnRawEffect)   -- status-effect classification
    -- Crowd control: one registration per CC result code, each filtered so only that result reaches us.
    for result in pairs(CC_RESULT) do
        local rn = "ShoyrUI_DM_CC_" .. result
        EM:RegisterForEvent(rn, EVENT_COMBAT_EVENT, OnCombatCC)
        EM:AddFilterForEvent(rn, EVENT_COMBAT_EVENT, REGISTER_FILTER_COMBAT_RESULT, result)
    end
    -- Active defense (block/dodge/shield): same per-result filtered registration.
    for result in pairs(CLUTCH_RESULT) do
        local rn = "ShoyrUI_DM_CL_" .. result
        EM:RegisterForEvent(rn, EVENT_COMBAT_EVENT, OnCombatClutch)
        EM:AddFilterForEvent(rn, EVENT_COMBAT_EVENT, REGISTER_FILTER_COMBAT_RESULT, result)
    end
    SLASH_COMMANDS["/smx"] = OnSlash          -- THE live view (always available)
    SLASH_COMMANDS["/SMX"] = OnSlash
    if DM.DEV then                            -- dev/testing tools -- gated so a release build ships /smx only
        SLASH_COMMANDS["/smxdemo"] = function(arg) DM.Demo(arg) end
        SLASH_COMMANDS["/smxclear"] = function() DM.DemoClear() end
        SLASH_COMMANDS["/smxwipe"] = function(arg)
            if tostring(arg or ""):lower():find("yes") then DM.Wipe()
            else d("|cFFD700[Duel Metrics]|r |cFF6666/smxwipe ERASES ALL recorded duels (real + demo) for a first-install clean slate.|r Type |cFFD700/smxwipe yes|r to confirm.") end
        end
        SLASH_COMMANDS["/smxauto"] = function()
            sv.autoOpen = not sv.autoOpen
            d("|cFFD700[Duel Metrics]|r auto-open after a duel is now " .. (sv.autoOpen and "|c66DD66ON|r (opens ~1s after the duel ends)" or "|cDD6666OFF|r (review on demand with /smx)") .. ".")
        end
        SLASH_COMMANDS["/smxrank"] = function(arg) DM.RankDemo(arg) end
    end
    if not LC then
        d("|cFFD700[Shoyru's Duel Metrics]|r LibCombat not found \226\128\148 duel logging works but detailed stats are disabled. Install LibCombat for the full breakdown.")
    end
    DM.EnsureDuelIds()   -- backfill stable per-duel ids (existing + migrated records) so duels are referenceable
    for _, o in pairs(sv.opponents or {}) do
        for _, du in pairs((type(o) == "table" and o.duels) or {}) do DM.SanitizeDuel(du) end
    end
end
