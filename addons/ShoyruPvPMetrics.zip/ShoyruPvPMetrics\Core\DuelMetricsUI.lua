-- ShoyrUI :: Core/DuelMetricsUI.lua
-- "Shoyru's Duel Metrics" window (/SMX). A small stats app for your duels:
--
--   HOME (the /SMX landing) = a character hero panel (name, class, overall W-L-D +
--   win rate + a provisional avg-rank chip) and three top-level tabs:
--     • Recent    — every duel, newest first
--     • Opponents — one row per person + your record vs them  -> drills into that
--                   person's full duel history
--     • Classes   — one row per class + matchup win-rate %     -> drills into every
--                   duel vs that class
--   Any list row that is a DUEL drills into the per-duel DETAIL (the 6-tab
--   Damage / Buffs / Healing / Raw Stats / Grade / Timeline breakdown). A back
--   button walks the nav stack: Home -> (Opponent|Class) -> Duel.
--
-- Driven through a SCENE_MANAGER scene so it grabs the cursor and ESC closes it.
-- Resizable by dragging any edge/corner; size persists to sv.win. All Lua, no XML.
-- Data source = ShoyrUI.DuelMetrics SavedVars (see Core/DuelMetrics.lua for schema).

ShoyrUI = ShoyrUI or {}
local UI = {}
ShoyrUI.DuelMetricsUI = UI

local WM = WINDOW_MANAGER

local sv = nil
local win, content
local heroPane, heroIcon, heroName, heroClass, heroRecord, heroRecordSub, heroRankLetter
local navPane, searchEdit
local navButtons = {}
local sortPane, footer
local sortChips = {}
local CR = {}   -- fight-card crumb controls (Pane, Title, Sub, Right, IconMe, MeName, Vs, IconOpp, OppName, Prev, Next)
local listScroll, listChild, listEmpty, listRows = nil, nil, nil, {}
local duelScroll, duelChild, detailTabBar, detailLines = nil, nil, nil, {}
local dmgPane, dmgTilesArea, dmgSplit, dealtScroll, dealtChild, takenScroll, takenChild, dealtTitle, takenTitle
local dmgTilesPool, dealtLines, takenLines = {}, {}, {}
local buffPane, buffTabBar
local buffScroll, buffChild, buffLines = nil, nil, {}   -- single panel (segmented sub-tabs)
local buffSubChips, buffSubTab = {}, "buffs"
local fitPending = false   -- true = the next render should auto-fit the window height to content
-- Timeline (Ebb & Flow) pane — a custom canvas (mirrored damage histogram + resource
-- sparkline), so it lives outside the line renderer like the damage/buff panes.
local F = {}   -- Ebb & Flow timeline controls (Pane, TilesArea, PlotTitle, Plot, Baseline, ResTitle, ResBand, Legend, T0, Tend, Empty, ...)
F.TilesPool, F.DmgBars, F.ResDots, F.Marks = {}, {}, {}, {}
F.SubChips, F.BreakLines = {}, {}   -- Ebb & Flow view chips + source-breakdown line pool
local detailTabButtons = {}
local smxScene

local nav, homeTab, filterText = {}, "recent", ""
local currentDuel, currentTab = nil, "optim"   -- default landing tab = Report Card
-- Duel-detail find-in-tabs search (SEPARATE from the home duel-list search).
local DS = {}   -- duel-detail find-in-tabs search controls + state (Bar, Edit, Bg, PH, Count, Prev, Next, Term, Matches, Idx)
DS.Term, DS.Matches, DS.Idx = "", {}, 0
local lastW, lastH = 0, 0
local built = false

local W, H = 1120, 680           -- default: wide landscape (CMX-style); >= MINW so the tab labels fit
local MINW, MINH = 1120, 520   -- floor where the 7-tab bar + fight-card crumb + tables stay in bounds
local MAXW, MAXH = 1800, 1300
local PAD = 18
local TOP = 46                   -- content region starts below the title
local ROW_H = 66   -- fits the two-line row text (bumped with the larger font so it can't touch the border)
local LINE_H = 30

local contentW = W - PAD * 2 - 24
local tabBarW = W - PAD * 2

-- ---------------------------------------------------------------------------
-- Design system — cleaner font (medium weight, thin shadow) + a refined dark
-- palette with a single gold accent. Result colors are muted, not neon.
-- ---------------------------------------------------------------------------
local FONT_BUMP = 2   -- nudge everything slightly bigger across the board
local function Font(size, weight)
    size = math.max(1, math.floor(size or 14) + FONT_BUMP)
    local face = (weight == "bold") and "$(BOLD_FONT)" or "$(MEDIUM_FONT)"
    return string.format("%s|%d|soft-shadow-thin", face, size)
end

local C = {
    win0  = { 0.055, 0.062, 0.078, 0.975 },
    card  = { 0.100, 0.110, 0.135, 1 },
    row   = { 0.115, 0.125, 0.150, 0.92 },
    rowH  = { 0.165, 0.180, 0.220, 0.96 },
    chip  = { 0.140, 0.150, 0.185, 1 },
    line  = { 0.200, 0.220, 0.270, 1 },
    hi    = { 0.930, 0.940, 0.960, 1 },
    mid   = { 0.640, 0.670, 0.740, 1 },
    lo    = { 0.430, 0.460, 0.530, 1 },
    accent= { 0.910, 0.720, 0.360, 1 },
    win   = { 0.420, 0.820, 0.580, 1 },
    loss  = { 0.960, 0.540, 0.500, 1 },   -- brightened so its luminance matches win/draw
    draw  = { 0.660, 0.700, 0.780, 1 },
    warn  = { 0.950, 0.820, 0.360, 1 },   -- amber: the "yellow" tier for threshold-coloured uptimes
    magic = { 0.46, 0.66, 0.99, 1 },      -- spell / magical stats (magicka-blue, per ESO + LibCombat)
    phys  = { 0.56, 0.86, 0.47, 1 },      -- weapon / physical stats (stamina-green)
    health= { 0.95, 0.55, 0.45, 1 },      -- health stats (ESO health-bar red/amber)
    dim   = { 0.34, 0.36, 0.42, 1 },      -- dim/inactive text (e.g. disabled crumb arrows)
}
local RCLR = { win = C.win, loss = C.loss, draw = C.draw }
local RTAG = { win = "WIN", loss = "LOSS", draw = "DRAW" }
-- Threshold colouring for UPTIME %% (buff/debuff/status maintenance): green high, amber mid, red low.
-- Tunable — these are the "you define these" cutoffs.
local UPTIME_GREEN, UPTIME_AMBER = 70, 40
local function UptimeColor(pct)
    if pct >= UPTIME_GREEN then return C.win elseif pct >= UPTIME_AMBER then return C.warn else return C.loss end
end

local function Hex(c) return string.format("%02X%02X%02X", math.floor(c[1]*255+0.5), math.floor(c[2]*255+0.5), math.floor(c[3]*255+0.5)) end
local function Comma(n) return (ZO_CommaDelimitNumber and ZO_CommaDelimitNumber(math.floor((n or 0)+0.5))) or tostring(math.floor((n or 0)+0.5)) end
-- Compact number for tiles/table cells so big values fit (1.12M, 640K, 940).
local function Abbrev(n)
    n = n or 0
    if n >= 1e6 then return string.format("%.2fM", n / 1e6)
    elseif n >= 1e5 then return string.format("%.0fK", n / 1e3)
    elseif n >= 1e3 then return string.format("%.1fK", n / 1e3)
    else return tostring(math.floor(n + 0.5)) end
end
-- Overall report-card grade for one duel -> (letter, score, colour). Forward-declared here so the
-- recent-duels list (built above the scoring code) can show a per-duel grade; assigned near RC below.
local DuelGrade
-- Duration as m:ss once it reaches a minute (45 -> "45s", 95 -> "1:35", 300 -> "5:00").
local function FmtDur(s)
    s = math.floor((s or 0) + 0.5)
    if s < 60 then return s .. "s" end
    return string.format("%d:%02d", math.floor(s / 60), s % 60)
end
-- ALWAYS m:ss (36 -> "0:36", 80 -> "1:20") for effect/CC uptimes, which the user wants read as clock
-- time even under a minute. Hung off UI, not a new file-scope local -- this chunk is at the 200-local cap.
function UI._FmtMS(s)
    s = math.floor((s or 0) + 0.5)
    return string.format("%d:%02d", math.floor(s / 60), s % 60)
end

local function Border(bg, c, t)
    t = t or 1
    bg:SetEdgeTexture(nil, t, t, t, 0)
    bg:SetEdgeColor(c[1], c[2], c[3], c[4] or 1)
end
local function backdrop(parent, center, border, t)
    local bg = WM:CreateControl(nil, parent, CT_BACKDROP)
    bg:SetAnchorFill(parent)
    if center then bg:SetCenterColor(unpack(center)) end
    if border then Border(bg, border, t) end
    return bg
end
local function label(parent, size, color, align, weight)
    local l = WM:CreateControl(nil, parent, CT_LABEL)
    l:SetFont(Font(size, weight))
    if color then l:SetColor(unpack(color)) end
    if align then l:SetHorizontalAlignment(align) end
    return l
end

-- Brief click "flash" on press — a white overlay shown on OnMouseDown and auto-hidden
-- shortly after, so a click reads as a physical button press. Uses only OnMouseDown so
-- it never clobbers a button's existing OnMouseUp (click) handler.
local function AddPress(btn)
    if not btn then return end
    local ov = WM:CreateControl(nil, btn, CT_BACKDROP)
    ov:SetAnchorFill(btn)
    ov:SetCenterColor(1, 1, 1, 0.16)
    ov:SetEdgeColor(0, 0, 0, 0)
    ov:SetDrawLevel(20)
    ov:SetHidden(true)
    btn:SetHandler("OnMouseDown", function()
        ov:SetHidden(false)
        zo_callLater(function() ov:SetHidden(true) end, 150)
    end)
end

local function ClassName(id)
    if not id or id == 0 then return "?" end
    local ok, name = pcall(function() return zo_strformat("<<1>>", GetClassName(GENDER_MALE, id)) end)
    return (ok and name ~= "" and name) or ("Class " .. id)
end
local function ClassIcon(id)
    if not id or id == 0 then return nil end
    local ok, icon = pcall(GetClassIcon, id)
    return (ok and icon) or nil
end
local function RaceName(id)
    if not id or id == 0 then return "" end
    local ok, name = pcall(function() return zo_strformat("<<1>>", GetRaceName(GENDER_MALE, id)) end)
    return (ok and name ~= "" and name) or ""
end
-- Real game icon for an ability, or nil — never the "?" placeholder. If the game has
-- no icon for the id (e.g. a synthetic/unknown id), we show no icon rather than a "?".
local function AbilityIcon(id)
    if not id or id == 0 then return nil end
    local ok, ic = pcall(GetAbilityIcon, id)
    if not ok or not ic or ic == "" or ic:find("icon_missing") or ic:find("_missing") then return nil end
    return ic
end
-- Prefer the icon captured WITH the record (CMX-style — the exact icon the game showed, always valid);
-- fall back to a live lookup by id for older records that predate icon capture.
local function IconFor(rec)
    local ic = rec and rec.icon
    if ic and ic ~= "" and not ic:find("_missing") then return ic end
    return AbilityIcon(rec and rec.id)
end
local function PlayerName()
    local n = (GetRawUnitName and GetRawUnitName("player")) or (GetUnitName and GetUnitName("player"))
    return zo_strformat("<<1>>", n or "?")
end
local function Ago(ts)
    local now = (GetTimeStamp and GetTimeStamp()) or 0
    local diff = math.max(0, now - (ts or now))
    if diff < 60 then return "just now"
    elseif diff < 3600 then return math.floor(diff/60) .. "m ago"
    elseif diff < 86400 then return math.floor(diff/3600) .. "h ago"
    else return math.floor(diff/86400) .. "d ago" end
end
local function DateStr(ts, withTime)
    ts = ts or (GetTimeStamp and GetTimeStamp()) or 0
    local ok, s = pcall(function() return os.date(withTime and "%b %d, %Y  %H:%M" or "%b %d, %Y", ts) end)
    return (ok and s) or ""
end

-- Win rate ignores draws (wins / decisive). Returns rate%, total duels.
local function WinRate(w, l, dr)
    local dec = (w or 0) + (l or 0)
    local total = dec + (dr or 0)
    return (dec > 0 and math.floor((w or 0)/dec*100 + 0.5) or 0), total
end
-- Overall player rank for the hero chip. Two ideas do all the work: (1) each OPPONENT
-- counts once regardless of how many times you dueled them (equal weight) so grinding one
-- person can't pad your rank and a nemesis genuinely drags your average down; (2) S+ is a
-- special "you dominate literally everyone" gate. A rated opponent = >=MINDUELS decisive
-- duels (draws/forfeits excluded); you need MINRIVALS rated opponents before any rank shows.
-- Every rung (+/base/-) is a mean-win-rate cutoff; all knobs live here (RANK.* is one local
-- to stay under DuelMetricsUI's 200 main-chunk local cap). These are the "you define these".
local RANK = {
    MINDUELS = 2, MINRIVALS = 5,       -- >=2 decisive duels to rate a matchup; >=5 rivals to rank
    NEMESIS = 45, PEER_HI = 55,        -- <45% vs someone = they're better than you; 45-55% = a peer
    SPLUS_WORST = 65,                  -- S+ ALSO needs your worst matchup >= this (nobody close)
    -- first mean-win% cutoff met, top-down = your grade. 16 rungs for fine-grained placement.
    grades = {
        { "S+", 95 }, { "S", 90 }, { "S-", 85 },
        { "A+", 81 }, { "A", 77 }, { "A-", 72 },
        { "B+", 68 }, { "B", 64 }, { "B-", 60 },
        { "C+", 56 }, { "C", 52 }, { "C-", 48 },
        { "D+", 44 }, { "D", 40 }, { "D-", 35 },
        { "F", 0 },
    },
    -- One colour per letter band (the +/- share it). Keyed by the tier's first character so
    -- S+/S/S- all read as one family. Distinct hues so a glance = a tier (Shoyru's spec).
    colors = {
        S = { 0.35, 0.74, 1.00, 1 },   -- lightning blue
        A = { 0.40, 0.83, 0.46, 1 },   -- green
        B = { 0.98, 0.84, 0.32, 1 },   -- yellow
        C = { 0.98, 0.60, 0.26, 1 },   -- orange
        D = { 0.95, 0.40, 0.38, 1 },   -- red
        F = { 0.72, 0.50, 0.96, 1 },   -- purple
    },
}
function RANK.Compute()
    local rates, worst, nemeses, peers = {}, 100, 0, 0
    if sv and sv.opponents then
        for _, o in pairs(sv.opponents) do
            local dec = (o.wins or 0) + (o.losses or 0)
            if dec >= RANK.MINDUELS then
                local wr = (o.wins or 0) / dec * 100
                rates[#rates + 1] = wr
                if wr < worst then worst = wr end
                if wr < RANK.NEMESIS then nemeses = nemeses + 1
                elseif wr <= RANK.PEER_HI then peers = peers + 1 end
            end
        end
    end
    local rivals = #rates
    if rivals < RANK.MINRIVALS then
        -- "Almost rated" opponents (1..MINDUELS-1 decisive duels) + how many MORE decisive duels each needs,
        -- so the chip/tooltip can tell you exactly who to re-duel to get placed. Closest first.
        local partial = {}
        if sv and sv.opponents then
            for _, o in pairs(sv.opponents) do
                local dec = (o.wins or 0) + (o.losses or 0)
                if dec >= 1 and dec < RANK.MINDUELS then
                    partial[#partial + 1] = { name = o.name or o.handle or "?", have = dec, need = RANK.MINDUELS - dec }
                end
            end
            table.sort(partial, function(a, b) return a.have > b.have end)
        end
        return { provisional = true, rivals = rivals, need = RANK.MINRIVALS, minduels = RANK.MINDUELS, partial = partial }
    end
    local sum = 0; for _, wr in ipairs(rates) do sum = sum + wr end
    local mean = sum / rivals
    local tier = "F"
    for _, g in ipairs(RANK.grades) do if mean >= g[2] then tier = g[1]; break end end
    -- S+ demands you also beat your WORST rival comfortably; a peer/nemesis blocks it -> S.
    if tier == "S+" and worst < RANK.SPLUS_WORST then tier = "S" end
    return { tier = tier, mean = mean, worst = worst, rivals = rivals, nemeses = nemeses, peers = peers }
end
function RANK.Color(tier)
    return RANK.colors[tier:sub(1, 1)] or C.hi
end
-- Paint a rank badge as the FULL tier string (e.g. "A+") in one label, so the +/- reads inline at
-- the letter's size/baseline -- consistent with the report card. suffixLbl (a legacy split label)
-- is just cleared if present.
function RANK.PaintBadge(letterLbl, suffixLbl, tier, color)
    local col = color or RANK.Color(tier)
    letterLbl:SetText(tier)
    letterLbl:SetColor(unpack(col))
    if suffixLbl then suffixLbl:SetText("") end
end
-- Progress from the current rung toward the next one up, by mean win rate. Returns
-- nextTier, fraction 0..1, and the win% the next rung needs (nil once you're at S+).
function RANK.Progress(rk)
    for i, g in ipairs(RANK.grades) do
        if g[1] == rk.tier then
            if i == 1 then return nil end               -- already S+
            local lo, hi = g[2], RANK.grades[i - 1][2]  -- this rung's floor, next rung's floor
            local frac = hi > lo and math.max(0, math.min(1, (rk.mean - lo) / (hi - lo))) or 1
            return RANK.grades[i - 1][1], frac, hi
        end
    end
end
-- Top-rank (S+) tagline. Easter egg: nobody outranks you... except Shoyru. The legend himself (the one
-- account that could see this and be confused about being above himself) gets the straight version. A
-- proper name, so it stays "Shoyru" in every language once the rest of the UI is localised.
function RANK.TopRankLabel(handle)
    if handle == "@Shoyru" then return "Top rank \226\128\148 nobody's above you. You're Shoyru." end
    return "Top rank \226\128\148 nobody's above you except Shoyru"
end
-- The "how ranks work" overlay: a dim scrim + a card listing every rung and its win-rate cutoff,
-- built once and toggled by the (i) button. Rows are stored per-tier so RenderHero can highlight
-- the player's current rung. Referenced ESO globals (DL_*, TEXT_*) resolve in-game only; the test
-- harness never calls this (it exercises data builders, not UI construction).
function RANK.BuildModal(win)
    local m = WM:CreateControl(nil, win, CT_CONTROL)
    m:SetAnchorFill(win)
    m:SetDrawTier(DT_HIGH)   -- lift above the window's controls. NOT SetDrawLayer(DL_OVERLAY):
    m:SetMouseEnabled(true)  -- that renders on top but silently drops mouse input (the close bug).
    m:SetHidden(true)
    local dim = WM:CreateControl(nil, m, CT_TEXTURE)
    dim:SetAnchorFill(m); dim:SetColor(0, 0, 0, 0.75); dim:SetMouseEnabled(true)
    dim:SetHandler("OnMouseUp", function() m:SetHidden(true) end)      -- click outside the card closes
    local W, H = 860, 620
    local panel = WM:CreateControl(nil, m, CT_CONTROL)
    panel:SetDimensions(W, H); panel:SetAnchor(CENTER, m, CENTER, 0, 0)
    backdrop(panel, C.card, C.line, 2); panel:SetMouseEnabled(true)   -- eat clicks on the card itself
    local t = label(panel, 30, C.accent, nil, "bold")
    t:SetAnchor(TOPLEFT, panel, TOPLEFT, 34, 26); t:SetText("Dueling Tier Progression")
    local x = WM:CreateControlFromVirtual(nil, panel, "ZO_CloseButton")
    x:SetAnchor(TOPRIGHT, panel, TOPRIGHT, -14, 18)
    x:SetHandler("OnClicked", function() m:SetHidden(true) end)
    x:SetHandler("OnMouseUp", function(_, _, inside) if inside then m:SetHidden(true) end end)
    local blurb = label(panel, 16, C.mid)
    blurb:SetAnchor(TOPLEFT, panel, TOPLEFT, 34, 72)
    blurb:SetAnchor(TOPRIGHT, panel, TOPRIGHT, -34, 72)
    blurb:SetText("Your tier reflects your average win rate across every rival you have faced. Each rival is weighted equally, regardless of how many times you have dueled them, so no single matchup dominates your placement. You are rated once you have faced at least five rivals across two or more decisive duels each.")
    -- two spacious columns of 8 rungs each. desc is LEFT+RIGHT anchored (bounded) so a long line
    -- can NEVER bleed into the next column (the old S+ row overflowed onto B-).
    RANK.rungRows = {}
    local COLW, X0, Y0, STEP = 372, 36, 156, 48
    for i, g in ipairs(RANK.grades) do
        local col, rowIn = (i <= 8) and 0 or 1, (i - 1) % 8
        local row = WM:CreateControl(nil, panel, CT_CONTROL)
        row:SetDimensions(COLW, 40)
        row:SetAnchor(TOPLEFT, panel, TOPLEFT, X0 + col * (COLW + 40), Y0 + rowIn * STEP)
        local hl = WM:CreateControl(nil, row, CT_TEXTURE)
        hl:SetAnchorFill(row); hl:SetColor(unpack(RANK.Color(g[1]))); hl:SetAlpha(0.14); hl:SetHidden(true)
        local rule = WM:CreateControl(nil, row, CT_TEXTURE)   -- faint separator = chart feel
        rule:SetHeight(1); rule:SetColor(unpack(C.line))
        rule:SetAnchor(BOTTOMLEFT, row, BOTTOMLEFT, 0, 6); rule:SetAnchor(BOTTOMRIGHT, row, BOTTOMRIGHT, 0, 6)
        -- Bordered badge chip, tinted by the tier colour. The base letter is centered in the chip and
        -- the +/- modifier hangs off its right edge, so every base letter lines up down the column.
        local box = WM:CreateControl(nil, row, CT_BACKDROP)
        box:SetDimensions(48, 34); box:SetAnchor(LEFT, row, LEFT, 8, 0)
        box:SetCenterColor(unpack(C.chip)); Border(box, RANK.Color(g[1]), 2)
        -- Full tier as ONE centred string (e.g. "A+"), so the +/- reads inline at the same size/baseline
        -- as the letter -- matching the report card (was a smaller raised superscript).
        local letter = label(box, 22, RANK.Color(g[1]), TEXT_ALIGN_CENTER, "bold")
        letter:SetDimensions(44, 34); letter:SetAnchor(CENTER, box, CENTER, 0, 0)
        letter:SetVerticalAlignment(TEXT_ALIGN_CENTER); letter:SetText(g[1])
        -- PREMIUM: the S-band rungs (S+/S/S-) show a spinning ray-burst behind the badge, so players
        -- see what they're chasing (Overwatch-style). OnUpdate only ticks while the modal is open.
        if g[1]:sub(1, 1) == "S" then
            local sz = (g[1] == "S+" and 54) or (g[1] == "S" and 48) or 44
            local bz = WM:CreateControl(nil, box, CT_TEXTURE)
            bz:SetTexture("EsoUI/Art/Crafting/white_burst.dds")
            bz:SetDimensions(sz, sz); bz:SetAnchor(CENTER, box, CENTER, 0, 0)
            local bc = RANK.Color(g[1]); bz:SetColor(bc[1], bc[2], bc[3], 0.38); bz:SetDrawLevel(0)  -- dim glow so the letter stays legible
            pcall(function() bz:SetBlendMode(TEX_BLEND_MODE_ADD) end)
            bz:SetHandler("OnUpdate", function(self)
                self:SetTextureRotation(((GetGameTimeMilliseconds() % 9000) / 9000) * (2 * math.pi), 0.5, 0.5)
            end)
            letter:SetDrawLevel(2)   -- keep the glyph above the burst
        end
        local desc = label(row, 16, C.hi)
        desc:SetAnchor(LEFT, row, LEFT, 66, 0); desc:SetAnchor(RIGHT, row, RIGHT, -8, 0)
        desc:SetText((g[1] == "S+" and "95%+ avg, no matchup under 65%")
            or (g[2] > 0 and string.format("\226\137\165 %d%% average", g[2])) or "under 35% average")
        RANK.rungRows[g[1]] = hl
    end
    local foot = label(panel, 13, C.lo)
    foot:SetAnchor(BOTTOMLEFT, panel, BOTTOMLEFT, 28, -20)
    foot:SetAnchor(BOTTOMRIGHT, panel, BOTTOMRIGHT, -28, -20)
    foot:SetText("Your tier updates automatically as your results change.")
    RANK.modal = m
end
function RANK.ToggleModal()
    if RANK.modal then RANK.modal:SetHidden(not RANK.modal:IsHidden()) end
end
-- Pre-colored "w-l-d" string for right-aligned record cells.
local function WLD(w, l, dr)
    return string.format("|c%s%d|r |c565b66-|r |c%s%d|r |c565b66-|r |c%s%d|r",
        Hex(C.win), w or 0, Hex(C.loss), l or 0, Hex(C.draw), dr or 0)
end

-- ---------------------------------------------------------------------------
-- Data aggregation
-- ---------------------------------------------------------------------------
local function AllDuels()
    local arr = {}
    if sv and sv.opponents then
        for h, o in pairs(sv.opponents) do
            for i, du in ipairs(o.duels or {}) do arr[#arr+1] = { handle = h, idx = i, o = o, du = du } end
        end
    end
    table.sort(arr, function(a, b) return (a.du.date or 0) > (b.du.date or 0) end)
    return arr
end
local function OverallStats()
    local w, l, dr = 0, 0, 0
    if sv and sv.opponents then
        for _, o in pairs(sv.opponents) do
            w = w + (o.wins or 0); l = l + (o.losses or 0); dr = dr + (o.draws or 0)
        end
    end
    return w, l, dr
end
local function OpponentArray()
    local arr = {}
    if sv and sv.opponents then for _, o in pairs(sv.opponents) do arr[#arr+1] = o end end
    table.sort(arr, function(a, b) return (a.duels and #a.duels or 0) > (b.duels and #b.duels or 0) end)
    return arr
end
local function ClassArray()
    local map = {}
    if sv and sv.opponents then
        for _, o in pairs(sv.opponents) do
            for _, du in ipairs(o.duels or {}) do
                local cid = du.oppClassId or o.classId or 0
                local m = map[cid]
                if not m then m = { classId = cid, w = 0, l = 0, dr = 0, n = 0 }; map[cid] = m end
                m.n = m.n + 1
                if du.result == "win" then m.w = m.w + 1
                elseif du.result == "draw" then m.dr = m.dr + 1
                else m.l = m.l + 1 end
            end
        end
    end
    local arr = {}; for _, m in pairs(map) do arr[#arr+1] = m end
    table.sort(arr, function(a, b) return a.n > b.n end)
    return arr
end
local function DuelsVsOpponent(handle)
    local arr, o = {}, sv and sv.opponents and sv.opponents[handle]
    if o then for i, du in ipairs(o.duels or {}) do arr[#arr+1] = { handle = handle, idx = i, o = o, du = du } end end
    table.sort(arr, function(a, b) return (a.du.date or 0) > (b.du.date or 0) end)
    return arr
end
local function DuelsVsClass(classId)
    local arr = {}
    if sv and sv.opponents then
        for h, o in pairs(sv.opponents) do
            for i, du in ipairs(o.duels or {}) do
                if (du.oppClassId or o.classId) == classId then arr[#arr+1] = { handle = h, idx = i, o = o, du = du } end
            end
        end
    end
    table.sort(arr, function(a, b) return (a.du.date or 0) > (b.du.date or 0) end)
    return arr
end

-- ---------------------------------------------------------------------------
-- Nav stack (forward-declared Render is assigned far below)
-- ---------------------------------------------------------------------------
local Render
local function Push(v) nav[#nav+1] = v; fitPending = true; Render() end
local function Back() if #nav > 1 then nav[#nav] = nil end; fitPending = true; Render() end

-- ---- list item builders (each returns a row descriptor for RenderList) ----
local function DuelItem(e, avg)
    local du, o = e.du, e.o
    local rc = RCLR[du.result] or C.mid
    local tag = RTAG[du.result] or "?"
    -- per-duel report-card grade badge (colour = the grade) beside the W/L tag. Guarded so a thin
    -- record can never break the list. `avg` is the caller's shared MyAverages() (keeps the list O(n)).
    local gl, gcol
    local ok, a, _, c = pcall(DuelGrade, du, avg)
    if ok and a then gl, gcol = a, c end
    return {
        stripe = rc, icon = ClassIcon(du.oppClassId),
        -- @account handle primary (persistent identity); character name + matchup + time as the secondary.
        primary = (o.handle and o.handle ~= "" and o.handle) or o.name or "?",
        secondary = string.format("|c%s%s|r   \226\128\162  %s vs %s   \226\128\162  %s", Hex(C.lo), o.name or "", ClassName(du.myClassId), ClassName(du.oppClassId), Ago(du.date)),
        rp = tag, rpColor = rc,
        grade = gl, gradeColor = gcol,   -- fixed-column badge (see GetRow) so grades align down the list
        rs = string.format("%s dealt  \226\128\162  %s taken  \226\128\162  %s", Comma(du.dmgDealt), Comma(du.dmgTaken), FmtDur(du.durationS)),
        search = (o.handle or "") .. " " .. (o.name or "") .. " " .. ClassName(du.oppClassId),
        onClick = function() currentTab = "optim"; Push({ kind = "duel", handle = e.handle, idx = e.idx }) end,   -- open on the Report Card; Prev/Next keep your tab
    }
end
local function OppItem(o)
    local rate, total = WinRate(o.wins, o.losses, o.draws)
    local sc = (total == 0) and C.mid or (rate >= 55 and C.win or (rate < 45 and C.loss or C.draw))
    return {
        stripe = sc, icon = ClassIcon(o.classId),
        -- @account handle is the identity that persists (character names can change); show it primary,
        -- with the character name + class as the secondary line.
        primary = (o.handle and o.handle ~= "" and o.handle) or o.name or "?",
        secondary = string.format("|c%s%s|r   \226\128\162  %s", Hex(C.lo), o.name or "", ClassName(o.classId)),
        rp = WLD(o.wins, o.losses, o.draws), rpRaw = true,
        rs = string.format("%d%% win rate  \226\128\162  %d duels", rate, total),
        search = (o.name or "") .. " " .. (o.handle or "") .. " " .. ClassName(o.classId),
        onClick = function() Push({ kind = "opponent", handle = o.handle }) end,
    }
end
local function ClassItem(m)
    local rate = WinRate(m.w, m.l, m.dr)
    return {
        stripe = C.accent, icon = ClassIcon(m.classId),
        primary = ClassName(m.classId),
        secondary = string.format("%d duel%s", m.n, m.n == 1 and "" or "s"),
        rp = WLD(m.w, m.l, m.dr), rpRaw = true,
        rs = string.format("%d%% win rate", rate),
        search = ClassName(m.classId),
        onClick = function() Push({ kind = "class", classId = m.classId }) end,
    }
end

-- Per-tab sort. dir: -1 desc, 1 asc. Options drive the sort-chip bar on home.
local sortState = {
    recent    = { key = "date",  dir = -1 },
    opponents = { key = "duels", dir = -1 },
    classes   = { key = "duels", dir = -1 },
}
local SORTS = {
    recent    = { { key = "date", label = "Date" }, { key = "dealt", label = "Dmg dealt" }, { key = "taken", label = "Dmg taken" }, { key = "dur", label = "Duration" } },
    opponents = { { key = "duels", label = "Duels" }, { key = "wr", label = "Win %" }, { key = "wins", label = "Wins" }, { key = "losses", label = "Losses" }, { key = "name", label = "Name" } },
    classes   = { { key = "duels", label = "Duels" }, { key = "wr", label = "Win %" }, { key = "wins", label = "Wins" }, { key = "losses", label = "Losses" } },
}
local function cmpNum(dir, a, b)
    if a == b then return false end
    if dir < 0 then return a > b else return a < b end
end

local function HomeItems(tab)
    local items, st = {}, sortState[tab]
    if tab == "recent" then
        local arr, key, dir = AllDuels(), st.key, st.dir
        table.sort(arr, function(a, b)
            local function v(e) local du = e.du
                if key == "dealt" then return du.dmgDealt or 0 elseif key == "taken" then return du.dmgTaken or 0
                elseif key == "dur" then return du.durationS or 0 else return du.date or 0 end end
            return cmpNum(dir, v(a), v(b))
        end)
        for _, e in ipairs(arr) do items[#items+1] = DuelItem(e) end
    elseif tab == "opponents" then
        local arr, key, dir = OpponentArray(), st.key, st.dir
        table.sort(arr, function(a, b)
            if key == "name" then
                local an, bn = (a.name or ""):lower(), (b.name or ""):lower()
                if an == bn then return false end
                if dir < 0 then return an > bn else return an < bn end
            end
            local function v(o)
                if key == "wins" then return o.wins or 0 elseif key == "losses" then return o.losses or 0
                elseif key == "wr" then return (WinRate(o.wins, o.losses, o.draws)) else return o.duels and #o.duels or 0 end end
            return cmpNum(dir, v(a), v(b))
        end)
        for _, o in ipairs(arr) do items[#items+1] = OppItem(o) end
    else
        local arr, key, dir = ClassArray(), st.key, st.dir
        table.sort(arr, function(a, b)
            local function v(m)
                if key == "wins" then return m.w elseif key == "losses" then return m.l
                elseif key == "wr" then return (WinRate(m.w, m.l, m.dr)) else return m.n end end
            return cmpNum(dir, v(a), v(b))
        end)
        for _, m in ipairs(arr) do items[#items+1] = ClassItem(m) end
    end
    return items
end
local function FilterItems(items)
    if filterText == "" then return items end
    local out, term = {}, filterText:lower()
    for _, it in ipairs(items) do
        if (it.search or ""):lower():find(term, 1, true) then out[#out+1] = it end
    end
    return out
end

-- ---------------------------------------------------------------------------
-- Generic list rows (one pool serves duels, opponents and classes)
-- ---------------------------------------------------------------------------
local function GetRow(i)
    local r = listRows[i]
    if r then return r end
    r = WM:CreateControl(nil, listChild, CT_CONTROL)
    r:SetMouseEnabled(true)
    r.bg = backdrop(r, C.row, C.line, 1)
    r.stripe = WM:CreateControl(nil, r, CT_BACKDROP)
    r.stripe:SetDimensions(4, ROW_H - 12)
    r.stripe:SetAnchor(LEFT, r, LEFT, 0, 0)
    r.stripe:SetEdgeColor(0, 0, 0, 0)
    r.icon = WM:CreateControl(nil, r, CT_TEXTURE)
    r.icon:SetDimensions(34, 34)
    r.icon:SetAnchor(LEFT, r, LEFT, 16, 0)
    r.primary = label(r, 19, C.hi, nil, "bold")
    r.secondary = label(r, 14, C.mid)
    r.secondary:SetAnchor(TOPLEFT, r.primary, BOTTOMLEFT, 0, 3)
    -- per-duel grade badge = the RIGHTMOST column, LEFT-aligned so the BASE letter sits at a fixed x
    -- and the +/- hangs off its right -> letters line up down the list (B under the C of C+, not the +).
    r.grade = label(r, 22, C.hi, TEXT_ALIGN_LEFT, "bold")
    r.grade:SetDimensions(46, ROW_H)
    r.grade:SetAnchor(RIGHT, r, RIGHT, -26, 0)
    r.grade:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    r.rp = label(r, 16, C.hi, TEXT_ALIGN_RIGHT, "bold")
    r.rp:SetAnchor(TOPRIGHT, r, TOPRIGHT, -98, 9)   -- clears the grade column with breathing room
    r.rs = label(r, 13, C.lo, TEXT_ALIGN_RIGHT)
    r.rs:SetAnchor(TOPRIGHT, r.rp, BOTTOMRIGHT, 0, 4)
    r:SetHandler("OnMouseEnter", function() r.bg:SetCenterColor(unpack(C.rowH)) end)
    r:SetHandler("OnMouseExit", function() r.bg:SetCenterColor(unpack(C.row)) end)
    AddPress(r)
    listRows[i] = r
    return r
end

local function RenderList(items, emptyMsg)
    if not listChild then return end
    local y = 0
    for i, it in ipairs(items) do
        local r = GetRow(i)
        r:ClearAnchors()
        r:SetDimensions(contentW, ROW_H)
        r:SetAnchor(TOPLEFT, listChild, TOPLEFT, 0, y)
        r:SetHidden(false)
        r.bg:SetCenterColor(unpack(C.row))
        local sc = it.stripe or C.mid
        r.stripe:SetCenterColor(sc[1], sc[2], sc[3], 1)
        if it.icon then r.icon:SetHidden(false); r.icon:SetTexture(it.icon) else r.icon:SetHidden(true) end
        -- Anchor the primary+secondary block from the row TOP with a fixed margin (not icon-relative),
        -- so the two lines centre against the row/icon and can't spill onto the bottom border.
        r.primary:ClearAnchors()
        r.primary:SetAnchor(TOPLEFT, r, TOPLEFT, it.icon and 62 or 16, 9)
        r.primary:SetText(it.primary or "")
        r.secondary:SetText(it.secondary or "")
        if it.rpRaw then r.rp:SetText(it.rp or ""); r.rp:SetColor(unpack(C.hi))
        else r.rp:SetText(it.rp or ""); r.rp:SetColor(unpack(it.rpColor or C.hi)) end
        r.rs:SetText(it.rs or "")
        if it.grade then r.grade:SetHidden(false); r.grade:SetText(it.grade); r.grade:SetColor(unpack(it.gradeColor or C.hi))
        else r.grade:SetHidden(true) end
        local fn = it.onClick
        r:SetHandler("OnMouseUp", function(_, _, inside) if inside and fn then fn() end end)
        y = y + ROW_H + 6
    end
    for i = #items + 1, #listRows do listRows[i]:SetHidden(true) end
    if listEmpty then
        listEmpty:SetHidden(#items > 0)
        if #items == 0 then listEmpty:SetText(emptyMsg or "Nothing here yet.") end
    end
    listChild:SetHeight(math.max(1, y))
    pcall(ZO_Scroll_ResetToTop, listScroll)
    pcall(ZO_Scroll_UpdateScrollBar, listScroll)
end

-- ---------------------------------------------------------------------------
-- Duel DETAIL (pooled "lines" = optional icon + left label + right label)
-- ---------------------------------------------------------------------------
-- Ability table columns. Laid out left-to-right starting right after a fixed-width
-- NAME column (so numbers sit near the name, not pinned to the far edge), evenly
-- dividing the remaining width — recomputed each render so it fits the page.
local COLTITLE = { "DPS %", "DPS", "DMG", "CRIT/HITS", "CRIT %", "MIN", "AVG", "MAX" }
local NCOL = 8
local MAXCOL = 10   -- pool of column labels per line (sections may use up to this many)

local function GetLine(child, pool, i)
    local ln = pool[i]
    if ln then return ln end
    ln = WM:CreateControl(nil, child, CT_CONTROL)
    -- Search highlight: a soft accent fill+border drawn BEHIND the row content (created
    -- first so icon/labels render on top). Toggled by the find-in-tabs search. Uses the
    -- Border helper's edge-texture trick so it never leaves a white-box artifact.
    ln.hl = backdrop(ln, { C.accent[1], C.accent[2], C.accent[3], 0.16 }, { C.accent[1], C.accent[2], C.accent[3], 0.85 }, 1)
    ln.hl:SetHidden(true)
    ln.icon = WM:CreateControl(nil, ln, CT_TEXTURE)
    ln.icon:SetDimensions(26, 26)
    ln.icon:SetAnchor(LEFT, ln, LEFT, 0, 0)
    ln.left = label(ln, 16, C.hi)
    ln.left:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    -- Separate bullet glyph so wrapped body text can hang-indent under the first word (not the bullet).
    ln.bullet = label(ln, 16, C.hi)
    ln.bullet:SetVerticalAlignment(TEXT_ALIGN_TOP)
    ln.bullet:SetHidden(true)
    ln.right = label(ln, 16, C.mid, TEXT_ALIGN_RIGHT)
    ln.right:SetAnchor(RIGHT, ln, RIGHT, 0, 0)
    ln.col = {}
    for k = 1, MAXCOL do
        local c = label(ln, 15, C.mid, TEXT_ALIGN_RIGHT)
        c:SetHeight(LINE_H)
        c:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        ln.col[k] = c
    end
    ln.rule = WM:CreateControl(nil, ln, CT_BACKDROP)  -- faint bottom border (table rows)
    ln.rule:SetHeight(1)
    ln.rule:SetAnchor(BOTTOMLEFT, ln, BOTTOMLEFT, 0, 0)
    ln.rule:SetAnchor(BOTTOMRIGHT, ln, BOTTOMRIGHT, 0, 0)
    ln.rule:SetEdgeColor(0, 0, 0, 0)
    ln.rule:SetHidden(true)
    -- interactive hit-target sized to JUST the icon + name text, so hover tooltips / right-click fire
    -- only over the item itself, not anywhere in the (wide, mostly-empty) row.
    ln.hit = WM:CreateControl(nil, ln, CT_CONTROL)
    ln.hit:SetMouseEnabled(false); ln.hit:SetHidden(true)
    pool[i] = ln
    return ln
end

-- Column geometry for the current width: name column width + per-column width.
local function ColGeom(ncol)
    ncol = ncol or NCOL
    local nameW = math.floor(math.max(150, math.min(300, contentW * 0.26)))
    local vx0 = nameW + 10
    local cw = math.max(42, (contentW - vx0) / ncol)
    return nameW, vx0, cw
end

-- Lazily build N "stat tiles" on a line (label stacked over a big value). Reused
-- across renders. Returns the tile pool.
local function EnsureTiles(ln, n)
    ln.tiles = ln.tiles or {}
    for k = 1, n do
        if not ln.tiles[k] then
            local t = {}
            t.frame = WM:CreateControl(nil, ln, CT_CONTROL)
            t.bg = backdrop(t.frame, C.card, C.line, 1)
            -- Label pinned to a top band, value fills the rest and centers — both use
            -- LEFT+RIGHT anchors so width tracks the frame and text can't escape the box.
            t.lab = label(t.frame, 12, C.hi, TEXT_ALIGN_CENTER, "bold")
            t.lab:SetAnchor(TOPLEFT, t.frame, TOPLEFT, 3, 9)
            t.lab:SetAnchor(TOPRIGHT, t.frame, TOPRIGHT, -3, 9)
            t.lab:SetHeight(14)
            t.val = label(t.frame, 22, C.hi, TEXT_ALIGN_CENTER, "bold")
            t.val:SetAnchor(TOPLEFT, t.frame, TOPLEFT, 3, 25)
            t.val:SetAnchor(BOTTOMRIGHT, t.frame, BOTTOMRIGHT, -3, -6)
            t.val:SetVerticalAlignment(TEXT_ALIGN_CENTER)
            ln.tiles[k] = t
        end
    end
    return ln.tiles
end

local function RenderLinesInto(scroll, child, pool, items)
    if not child then return end
    local y = 0
    for i, it in ipairs(items) do
        local ln = GetLine(child, pool, i)
        local gap = (it.header and i > 1) and 12 or 0
        local useCols = (it.cols ~= nil) or it.colHeader
        local rowH = it.h or LINE_H
        local advanceH = rowH
        ln:ClearAnchors()
        ln:SetAnchor(TOPLEFT, child, TOPLEFT, 0, y + gap)
        ln:SetHidden(false)
        if ln.hl then ln.hl:SetHidden(true) end   -- reset search highlight; re-applied after render
        if ln.bullet then ln.bullet:SetHidden(true) end   -- reset hanging-indent bullet (shown only when set)

        if it.separator then
            -- A thin full-width divider between grouped blocks (e.g. Report Card strengths).
            ln:SetMouseEnabled(false); ln:SetHandler("OnMouseEnter", nil); ln:SetHandler("OnMouseExit", nil); ln:SetHandler("OnMouseUp", nil)
            ln.icon:SetHidden(true); ln.left:SetText(""); ln.right:SetText("")
            for _, c in ipairs(ln.col) do c:SetHidden(true) end
            if ln.tiles then for _, t in ipairs(ln.tiles) do t.frame:SetHidden(true) end end
            advanceH = it.h or 13
            ln:SetDimensions(contentW, advanceH)
            ln.rule:SetHidden(false); ln.rule:SetCenterColor(0.22, 0.24, 0.30, 0.9)
        elseif it.tiles then
            -- Stat-tile strip, wrapped to fit narrow windows (never squeeze a tile
            -- below ~130px — otherwise labels/values spill out of their boxes).
            -- (clear any row-level interactivity a recycled row carried — tiles manage their own)
            ln:SetMouseEnabled(false); ln:SetHandler("OnMouseEnter", nil); ln:SetHandler("OnMouseExit", nil); ln:SetHandler("OnMouseUp", nil)
            ln.icon:SetHidden(true); ln.left:SetText(""); ln.right:SetText("")
            for _, c in ipairs(ln.col) do c:SetHidden(true) end
            if ln.rule then ln.rule:SetHidden(true) end
            local n = math.max(1, #it.tiles)
            local gaps, tileH = 8, 60
            local perRow = math.max(1, math.min(n, math.floor((contentW + gaps) / (130 + gaps))))
            local rows = math.ceil(n / perRow)
            local tileW = math.floor((contentW - gaps * (perRow - 1)) / perRow)
            advanceH = rows * tileH + (rows - 1) * gaps
            ln:SetDimensions(contentW, advanceH)
            local tiles = EnsureTiles(ln, n)
            for k = 1, #tiles do
                local t = tiles[k]
                if k <= n then
                    local col, row = (k - 1) % perRow, math.floor((k - 1) / perRow)
                    t.frame:SetHidden(false)
                    t.frame:ClearAnchors()
                    t.frame:SetDimensions(tileW, tileH)
                    t.frame:SetAnchor(TOPLEFT, ln, TOPLEFT, col * (tileW + gaps), row * (tileH + gaps))
                    t.lab:SetText(it.tiles[k].l or "")
                    t.val:SetText(it.tiles[k].v or "")
                    t.val:SetColor(unpack(it.tiles[k].c or C.hi))
                    -- Right-click a tile with a `post` message -> "Post to chat" (pre-fills the chat
                    -- box). A `click` function makes plain LEFT-click act directly (e.g. SHARE BUILD).
                    local post, click = it.tiles[k].post, it.tiles[k].click
                    local tip = it.tiles[k].tip or (post and "Right-click to post to chat")
                    t.frame:SetMouseEnabled((post or click) ~= nil)
                    t.frame:SetHandler("OnMouseUp", (post or click) and function(_, btn, inside)
                        if not inside then return end
                        if click and btn == MOUSE_BUTTON_INDEX_LEFT then click() return end
                        if post and btn == MOUSE_BUTTON_INDEX_RIGHT then
                            ClearMenu(); AddCustomMenuItem("Post to chat", function() if StartChatInput then StartChatInput("SMX: " .. post:sub(1, 1):upper() .. post:sub(2)) end end); ShowMenu(t.frame)
                        end
                    end or nil)
                    -- Tooltip anchored to the CURSOR (not the wide tile) so the hint sits by the pointer.
                    -- relativePoint explicit — omitted, SetOwner mirrors it and the tip clamps to the screen edge.
                    t.frame:SetHandler("OnMouseEnter", tip and function()
                        InitializeTooltip(InformationTooltip, t.frame, BOTTOM, 0, 4, TOP)   -- centred just below the tile, consistently
                        SetTooltipText(InformationTooltip, tip)
                    end or nil)
                    t.frame:SetHandler("OnMouseExit", tip and function() ClearTooltip(InformationTooltip) end or nil)
                else
                    t.frame:SetHidden(true)
                end
            end
        else
            ln:SetDimensions(contentW, rowH)
            if ln.tiles then for _, t in ipairs(ln.tiles) do t.frame:SetHidden(true) end end
            -- icon + name
            if it.icon then
                ln.icon:SetHidden(false); ln.icon:SetTexture(it.icon)
                ln.icon:ClearAnchors(); ln.left:ClearAnchors()
                if it.wrap then
                    -- multi-line row (e.g. a gear piece with the enchant on line 2): pin the icon to
                    -- the TOP so it lines up with the item NAME, not the row's vertical centre (enchant).
                    ln.icon:SetAnchor(TOPLEFT, ln, TOPLEFT, 0, 2)
                    ln.left:SetAnchor(TOPLEFT, ln.icon, TOPRIGHT, 8, 3)
                    ln.left:SetVerticalAlignment(TEXT_ALIGN_TOP)
                else
                    ln.icon:SetAnchor(LEFT, ln, LEFT, 0, 0)
                    ln.left:SetAnchor(LEFT, ln.icon, RIGHT, 8, 0)
                    ln.left:SetVerticalAlignment(TEXT_ALIGN_CENTER)
                end
            else
                ln.icon:SetHidden(true)
                ln.left:ClearAnchors()
                if it.bullet then
                    -- Hanging indent: bullet sits in the left margin, text is indented so a wrapped line
                    -- aligns under the FIRST WORD instead of under the bullet.
                    ln.bullet:SetHidden(false); ln.bullet:SetText(it.bullet); ln.bullet:SetFont(Font(16))
                    ln.bullet:SetHeight(LINE_H); ln.bullet:ClearAnchors(); ln.bullet:SetAnchor(TOPLEFT, ln, TOPLEFT, 0, 0)
                    ln.left:SetAnchor(TOPLEFT, ln, TOPLEFT, 16, 0)
                    ln.left:SetVerticalAlignment(TEXT_ALIGN_TOP)
                else
                    ln.left:SetAnchor(LEFT, ln, LEFT, 0, 0)
                    ln.left:SetVerticalAlignment(it.wrap and TEXT_ALIGN_TOP or TEXT_ALIGN_CENTER)
                end
            end
            ln.left:SetHeight(LINE_H)
            ln.left:SetFont(Font(it.header and 17 or (it.colHeader and 13 or 16), (it.header or it.colHeader) and "bold" or nil))
            ln.left:SetText(it.colHeader and (it.srcLabel or "Damage Source") or (it.left or ""))
            ln.left:SetColor(unpack(it.colHeader and C.hi or it.color or (it.header and C.accent) or C.hi))
            -- right value vs. table columns
            if useCols then
                local vals = it.colHeader and (it.colTitles or COLTITLE) or it.cols
                local ncol = #vals
                local nameW, vx0, cw = ColGeom(ncol)
                ln.left:SetWidth(math.max(60, nameW - (it.icon and 34 or 0)))
                ln.right:SetText("")
                for k = 1, #ln.col do
                    local c = ln.col[k]
                    if k <= ncol then
                        c:SetHidden(false)
                        c:ClearAnchors()
                        c:SetAnchor(TOPLEFT, ln, TOPLEFT, math.floor(vx0 + (k - 1) * cw), 0)
                        c:SetWidth(math.floor(cw) - 8)
                        -- All value cells are bold + white for legibility (was: only the boldCol,
                        -- rest grey). The 100%-crit gold cue is kept as the one accent override.
                        c:SetFont(Font(it.colHeader and 12 or 15, "bold"))
                        c:SetText(vals[k] or "")
                        c:SetHorizontalAlignment((it.colAlign and it.colAlign[k]) or TEXT_ALIGN_RIGHT)   -- per-column override (grades left-align)
                        if (not it.colHeader) and it.critAll and it.critCols and it.critCols[k] then c:SetColor(unpack(C.accent))
                        elseif (not it.colHeader) and it.colColors and it.colColors[k] then c:SetColor(unpack(it.colColors[k]))
                        elseif (not it.colHeader) and it.valColor then c:SetColor(unpack(it.valColor))   -- whole-row value tint (stats)
                        else c:SetColor(unpack(C.hi)) end
                    else
                        c:SetHidden(true)
                    end
                end
                ln.rule:SetHidden(it.noRule == true)
                ln.rule:SetCenterColor(unpack(it.colHeader and C.line or { 0.15, 0.16, 0.20, 0.9 }))
            else
                for _, c in ipairs(ln.col) do c:SetHidden(true) end
                ln.rule:SetHidden(true)
                ln.right:ClearAnchors()
                if it.field then
                    -- Table-like: value right-aligned in a fixed column that lines up with the stat
                    -- tables' first value column, so Racial/Survivability read as the same grid.
                    local nameW, vx0, cw = ColGeom(3)
                    ln.left:SetWidth(math.max(60, vx0 - 6))
                    ln.right:SetWidth(math.floor(cw))
                    ln.right:SetAnchor(RIGHT, ln, LEFT, math.floor(vx0 + cw - 8), 0)
                    ln.right:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
                else
                    -- Right-side reserve sized to reality: it.rw override > 110 when a right tag
                    -- exists > 6 when none (a fixed 130 was truncating names in narrow columns).
                    local reserve = it.rw or (it.right and 110 or 6)
                    ln.left:SetWidth(math.max(60, contentW - reserve - (it.icon and 34 or 0) - (it.bullet and 16 or 0)))
                    ln.right:SetWidth(math.floor(contentW * 0.6))
                    ln.right:SetAnchor(RIGHT, ln, RIGHT, 0, 0)
                    ln.right:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
                    if it.wrap then
                        -- informational text: wrap to as many lines as it needs instead of clipping
                        ln.left:SetHeight(LINE_H * 4)
                        local th = math.max(20, math.floor((ln.left.GetTextHeight and ln.left:GetTextHeight()) or 0) + 4)
                        advanceH = math.max(it.h or 24, th)
                        ln.left:SetHeight(advanceH)
                        ln:SetDimensions(contentW, advanceH)
                    end
                end
                ln.right:SetText(it.right or "")
                ln.right:SetColor(unpack(it.rcolor or C.mid))
            end
            -- Generic row interactions: hover -> the game's real ABILITY TOOLTIP (tipId = ability
            -- id; tipCp = champion star id, resolved live via GetChampionAbilityId), and
            -- right-click -> "Link in chat" (postLink = an item link). Pooled rows: handlers are
            -- CLEARED when a reused row has none (the F.Lolli lesson — no stale interactivity).
            local tipId, tipCp, postLink = it.tipId, it.tipCp, it.postLink
            ln:SetMouseEnabled(false)   -- the ROW itself is inert; interactivity lives on ln.hit (icon+name)
            if (tipId or tipCp or postLink) and not it.tiles then
                -- size the hit-target to just the icon + name TEXT, so the tooltip / right-click fire only
                -- over the item, not the empty part of the row. Anchored under the name (fixed, not cursor).
                local nameLeft = it.icon and 34 or 0
                local tw = (ln.left.GetTextWidth and math.floor(ln.left:GetTextWidth())) or 0
                local regionW = (ln.left.GetWidth and ln.left:GetWidth()) or 300
                ln.hit:SetHidden(false); ln.hit:SetMouseEnabled(true)
                ln.hit:ClearAnchors(); ln.hit:SetAnchor(TOPLEFT, ln, TOPLEFT, 0, 0)
                ln.hit:SetDimensions(math.max(24, nameLeft + math.min(tw + 6, regionW)), advanceH)
                ln.hit:SetHandler("OnMouseEnter", function()
                    local aid = tipId
                    if not aid and tipCp then
                        local ok, v = pcall(GetChampionAbilityId, tipCp)
                        aid = (ok and type(v) == "number" and v > 0) and v or nil
                    end
                    if aid then
                        local ok = pcall(function()
                            InitializeTooltip(AbilityTooltip, ln.hit, BOTTOMLEFT, 0, 3, TOPLEFT)
                            AbilityTooltip:SetAbilityId(aid)
                        end)
                        if not ok then pcall(ClearTooltip, AbilityTooltip) end
                    elseif postLink and tostring(postLink):find("|H", 1, true) then
                        local ok = pcall(function()   -- gear / set item link -> the game's ITEM tooltip
                            InitializeTooltip(ItemTooltip, ln.hit, BOTTOMLEFT, 0, 3, TOPLEFT)
                            ItemTooltip:SetLink(postLink)
                        end)
                        if not ok then pcall(ClearTooltip, ItemTooltip) end
                    end
                end)
                ln.hit:SetHandler("OnMouseExit", function() pcall(ClearTooltip, AbilityTooltip); pcall(ClearTooltip, ItemTooltip) end)
                ln.hit:SetHandler("OnMouseUp", postLink and function(_, btn, upInside)
                    if upInside and btn == MOUSE_BUTTON_INDEX_RIGHT then
                        ClearMenu()
                        AddCustomMenuItem("Link in chat", function()
                            if ZO_LinkHandler_InsertLink then ZO_LinkHandler_InsertLink(postLink)
                            elseif StartChatInput then StartChatInput(postLink) end
                        end)
                        ShowMenu(ln.hit)
                    end
                end or nil)
            elseif ln.hit then
                ln.hit:SetHidden(true); ln.hit:SetMouseEnabled(false)
                ln.hit:SetHandler("OnMouseEnter", nil); ln.hit:SetHandler("OnMouseExit", nil); ln.hit:SetHandler("OnMouseUp", nil)
            end
        end
        y = y + advanceH + gap + (it.tiles and 8 or 4)
    end
    for i = #items + 1, #pool do pool[i]:SetHidden(true) end
    child:SetHeight(math.max(1, y))
    if scroll then
        pcall(ZO_Scroll_ResetToTop, scroll)
        pcall(ZO_Scroll_UpdateScrollBar, scroll)
    end
end
local function RenderLines(items) RenderLinesInto(duelScroll, duelChild, detailLines, items) end

-- A titled ability table: a column-header row then one row per ability (ALL of them),
-- with damage, % of section, hit count, and a crits/hits ratio (gold when 100% crit).
local function AbilityRows(items, list, dur, opts)
    list = list or {}
    if #list == 0 then return end
    opts = opts or {}
    dur = (dur and dur > 0) and dur or 1
    -- Always show highest damage first (demo data isn't pre-sorted); copy so we never
    -- reorder the stored record.
    local sorted = {}
    for _, a in ipairs(list) do sorted[#sorted+1] = a end
    table.sort(sorted, function(x, y) return (x.total or 0) > (y.total or 0) end)
    list = sorted
    -- Highlight the crit columns (gold on 100% crit) by their position in this section's
    -- titles, so it stays correct when the healing table adds an OVER % column.
    local titles = opts.titles or COLTITLE
    local critCols = {}
    for i, t in ipairs(titles) do if t == "CRIT/HITS" or t == "CRIT %" then critCols[i] = true end end
    -- Drop any source-less bucket (id <= 0): the game occasionally reports a heal/hit with no ability id,
    -- and LibCombat excludes those from its fight totals too -- so a nameless "#0" row made the per-ability
    -- list overshoot the headline. New captures skip these; this also covers records saved before the fix.
    local rows = {}
    for _, a in ipairs(list) do if a.id and a.id > 0 then rows[#rows + 1] = a end end
    local sum = 0; for _, a in ipairs(rows) do sum = sum + (a.total or 0) end
    items[#items+1] = { colHeader = true, srcLabel = opts.srcLabel, colTitles = titles }
    for _, a in ipairs(rows) do
        local hits, total = a.hits or 0, a.total or 0
        local pct = (sum > 0) and math.floor(total/sum*100 + 0.5) or 0
        local avg = (hits > 0) and total / hits or 0
        local critpct = (hits > 0) and math.floor((a.crit or 0)/hits*100 + 0.5) or 0
        local critHits = string.format("%d/%d", a.crit or 0, hits)
        local cols
        if opts.heal then
            local over = a.over or 0
            local overpct = ((over + total) > 0) and math.floor(over / (over + total) * 100 + 0.5) or 0
            -- HEAL %, HPS, HEAL, OVER %, CRIT/HITS, CRIT %, MIN, AVG, MAX
            cols = { pct .. "%", Abbrev(total / dur), Abbrev(total), overpct .. "%", critHits, critpct .. "%", Abbrev(a.min or 0), Abbrev(avg), Abbrev(a.max or 0) }
        else
            -- DPS %, DPS, DMG, CRIT/HITS, CRIT %, MIN, AVG, MAX
            cols = { pct .. "%", Abbrev(total / dur), Abbrev(total), critHits, critpct .. "%", Abbrev(a.min or 0), Abbrev(avg), Abbrev(a.max or 0) }
        end
        items[#items+1] = {
            icon = IconFor(a),
            left = (a.name and a.name ~= "") and a.name or ("#" .. tostring(a.id)),
            cols = cols, critAll = (hits > 0 and (a.crit or 0) >= hits), critCols = critCols,
        }
    end
end
local function DamageItems(du)
    local items = {}
    local hasDetail = (du.dealtTop and #du.dealtTop > 0) or (du.takenTop and #du.takenTop > 0)
    -- Headline numbers as a stat-tile strip (no left-to-right scanning).
    items[#items+1] = { tiles = {
        { l = "TIME",     v = FmtDur(du.durationS), c = C.hi },
        { l = "OUT DPS",  v = Abbrev(du.dpsOut),   c = C.win },
        { l = "IN DPS",   v = Abbrev(du.dpsIn),    c = C.loss },
        { l = "HPS",      v = Abbrev(du.hps or 0), c = C.hi },
        { l = "DEALT",    v = Abbrev(du.dmgDealt), c = C.win },
        { l = "TAKEN",    v = Abbrev(du.dmgTaken), c = C.loss },
    } }
    items[#items+1] = { header = true, left = "Damage Dealt", right = "Total " .. Abbrev(du.dmgDealt), rcolor = C.lo }
    AbilityRows(items, du.dealtTop, du.durationS)
    -- Damage the enemy's ward absorbed is in the total/DPS but can't be split per-attack (the game names
    -- the WARD, not your ability), so the rows above sum to less than the headline by this amount.
    if (du.dmgShieldedOut or 0) > 0 then
        items[#items+1] = { left = string.format("|c777777\226\128\162 %s of your damage was absorbed by the opponent's damage shields (counted in your DPS; the game doesn't tag which of your abilities it was).|r", Abbrev(du.dmgShieldedOut)), wrap = true }
    end
    items[#items+1] = { header = true, left = "Damage Taken", right = "Total " .. Abbrev(du.dmgTaken), rcolor = C.lo }
    AbilityRows(items, du.takenTop, du.durationS)
    if (du.dmgShieldedIn or 0) > 0 then
        items[#items+1] = { left = string.format("|c777777\226\128\162 %s of the incoming damage was absorbed by your own damage shields (counted in the total; the game doesn't tag which enemy ability it was).|r", Abbrev(du.dmgShieldedIn)), wrap = true }
    end
    if not hasDetail then
        items[#items+1] = { left = "|c999999No per-ability breakdown for this duel \226\128\148 LibCombat wasn't active.|r" }
    end
    return items
end
-- Headline stat-tile strip for the Damage tab (rendered above the two scroll panels).
-- The head-to-head tiles are colored green when I did better than my opponent in that
-- department and red when they did, with an up/down arrow showing which side did more.
local ARR_UP = "  |t18:18:/esoui/art/miscellaneous/list_sortup.dds|t"
local ARR_DN = "  |t18:18:/esoui/art/miscellaneous/list_sortdown.dds|t"
-- Green = this side did MORE in that department (the higher value), red = less; the
-- arrow points up on the bigger one. So whoever's number is higher shows green.
local function CmpTile(lbl, mine, other)
    mine, other = mine or 0, other or 0
    if mine == other then return { l = lbl, v = Abbrev(mine), c = C.hi } end
    local higher = mine > other
    return { l = lbl, v = Abbrev(mine) .. (higher and ARR_UP or ARR_DN), c = higher and C.win or C.loss }
end
local function DamageTiles(du)
    local dOut, dIn = du.dpsOut or 0, du.dpsIn or 0
    local dealt, taken = du.dmgDealt or 0, du.dmgTaken or 0
    local opp = (currentDuel and currentDuel.o and (currentDuel.o.handle or currentDuel.o.name)) or "my opponent"
    local t = {
        { l = "TIME", v = FmtDur(du.durationS), c = C.hi,
          post = string.format("this duel vs %s lasted %s.", opp, FmtDur(du.durationS)) },
        CmpTile("OUT DPS", dOut, dIn),
        CmpTile("IN DPS", dIn, dOut),
        CmpTile("DEALT", dealt, taken),
        CmpTile("TAKEN", taken, dealt),
    }
    t[2].post = string.format("I did an average of %s DPS to %s during this duel.", Comma(dOut), opp)
    t[3].post = string.format("%s did an average of %s DPS to me during this duel.", opp, Comma(dIn))
    t[4].post = string.format("I did a total of %s damage to %s during this duel.", Comma(dealt), opp)
    t[5].post = string.format("%s did a total of %s damage to me during this duel.", opp, Comma(taken))
    return { tiles = t }
end

-- Tab icons (approximate ESO built-ins — easy to swap paths later).
local TAB_ICON = {
    damage  = "/esoui/art/lfg/lfg_dps_up.dds",
    healing = "/esoui/art/lfg/lfg_healer_up.dds",
    buffs   = "/esoui/art/icons/ability_buff_minor_vitality.dds",
    stats   = "/esoui/art/lfg/lfg_tank_up.dds",
    flow    = "/esoui/art/icons/ability_debuff_stagger.dds",
    optim   = "/esoui/art/icons/ability_debuff_reveal.dds",
    build   = "/esoui/art/icons/ability_debuff_knockback.dds",
}
local TABS = {
    { key = "optim",   label = "Report Card" },   -- summary first: the landing tab when a duel opens
    { key = "damage",  label = "Damage" },
    { key = "healing", label = "Healing" },
    { key = "buffs",   label = "Buffs" },   -- short: the sub-tabs read Buffs/Debuffs/Status/Control
    { key = "stats",   label = "Stats" },
    { key = "flow",    label = "Timeline" },
    { key = "build",   label = "Build" },
}
-- Sub-tabs inside the Buffs & Debuffs view (segmented; one spacious panel each).
local BUFF_SUBTABS = {
    { key = "buffs",   label = "Buffs" },
    { key = "debuffs", label = "Debuffs" },
    { key = "status",  label = "Status Effects" },
    { key = "control", label = "Crowd Control" },
}
-- ===========================================================================
-- TAB GUIDE — a per-tab "what's on this tab" breakdown, opened by the (i) button
-- in the duel-detail header. ONE context-sensitive overlay (not 7 cramped glyphs):
-- the header button is present on every tab and always describes the tab you're on.
-- Everything hangs off the existing UI module table (UI.guide.*) so it adds NO new main-chunk
-- local (the file sits at the 200-local cap); the modal reuses the shared line renderer
-- (RenderLinesInto) via header + wrap rows.
-- ===========================================================================
UI.guide = {}
UI.guide.content = {
    optim = {
        title = "Report Card",
        blurb = "Your performance in this duel \226\128\148 graded first against THIS opponent (did you win the exchanges), then against your own recent form. Locked until you've logged 10 duels so your baseline is meaningful.",
        sections = {
            { h = "Strengths radar",
              b = "Six strengths \226\128\148 Offense, Defense, Sustain, Burst, Pressure and Weaving \226\128\148 are each scored 0\226\128\147100 and plotted on the hexagon. The further a point reaches toward the edge, the stronger you were in that area this duel. A bigger overall shape is a better-rounded duel." },
            { h = "The scale",
              b = "Letters run F up to A+ with +/\226\136\146 shading inside each band (A+ 92, A 85, A\226\136\146 80, B+ 74 ... C is anchored at 50). Read C as \"an even fight on that front\", B as \"you clearly had the edge\", and A as \"you dominated it\". The overall grade blends the six strengths with the outcome, so a scrappy win and a clean win don't read the same. (S-tier lives on the main screen's Dueling Tier \226\128\148 that's your rank across opponents; this card grades one duel's performance.)" },
            { h = "How grading works",
              b = "Each strength is judged the way a coach would, without drowning you in formulas: Offense is mostly the damage war (out-damaging THIS opponent matters more than your raw number). Burst is whether you create real kill windows for YOUR build's style \226\128\148 DoT pressure and one-shot builds are held to different spikes. Sustain and Pressure are absolute: what you survived, and how relentlessly your key debuffs stayed on them. Weaving is how often a light attack rides each cast \226\128\148 and whether you out-wove them. Defense asks whether you answered their burst, defended their real threats, kept your mitigation buffs (Resolve) up, and recovered fast when hurt (back to 80% after a deep dip) \226\128\148 then damage taken vs your norm. Where your history matters, it's the MEDIAN of your last 50 duels \226\128\148 robust, and not gameable by padding easy fights." },
            { h = "The four tiles",
              b = "THIS DUEL is your overall grade for the fight. OUTCOME is the win / loss / draw. YOUR NORM is your baseline grade. TREND compares your last 10 duels to that norm \226\128\148 \226\134\145 improving, \226\134\147 falling off, \226\134\146 steady." },
            { h = "What this duel tells you",
              b = "Personalized reads of THIS duel \226\128\148 not generic tips. Every win includes WHAT WON IT and every loss includes HOW YOU DIED (the killing blow, the window that closed it, and whether a CC opened it). The rest name your actual abilities, timestamps and numbers: what hurt you most, where a resource bottomed out, the light-attack war, how the opponent fought, and how you performed against your own average. They shift every duel and only surface what's most crucial." },
            { h = "Matchup notes",
              b = "A class read for your opponent \226\128\148 VERIFIED against this duel when possible. We know each class's signature lineup (a Sorc's Curse\226\134\146Streak\226\134\146Frags, a DK's Fossilize burst), so instead of repeating the stereotype, this checks whether THIS player actually ran it, whether it landed on you, and whether you answered it \226\128\148 or flags them as off-script and names their real threat. Falls back to a rotating curated tip for classes without a signature yet." },
            { h = "Calibration lock",
              b = "Until you've logged 10 duels the card stays locked and shows an n/10 progress counter. Grades need a personal baseline before they mean anything, so the first ten duels just build it." },
        },
    },
    damage = {
        title = "Damage",
        blurb = "Everything you dealt and everything you took this duel, side by side.",
        sections = {
            { h = "Head-to-head tiles",
              b = "TIME, OUT DPS, IN DPS, DEALT and TAKEN. Each head-to-head tile turns green when you out-did your opponent in that column and red when they out-did you; the arrow points to the bigger side." },
            { h = "Damage Dealt / Damage Taken",
              b = "Two independently-scrolling tables. Each ability row shows total damage, its share of the section, hit count, and a crits/hits ratio (gold at 100% crit). Both sides scroll on their own so a 20-ability spread never buries the other." },
            { h = "Post to chat",
              b = "Right-click any headline tile to drop its summary line straight into chat \226\128\148 handy for sharing a clean DPS number after a fight." },
        },
    },
    healing = {
        title = "Healing",
        blurb = "How much you healed, how efficiently, and exactly where it came from.",
        sections = {
            { h = "Headline tiles",
              b = "TIME, HPS, TOTAL HEALED, OVERHEAL % (healing wasted over full health), and SUSTAIN (the share of the damage you took that you out-healed). Sustain is the quick read on whether you were winning the attrition race." },
            { h = "Healing Received table",
              b = "Every heal source with HEAL %, HPS, raw HEAL, OVER %, crits/hits, crit %, and the min / avg / max single heal \226\128\148 so you can see which heal was actually carrying you." },
            { h = "Nothing showing?",
              b = "If the table is empty, LibCombat wasn't active for that duel or you simply took no heals. Install/enable LibCombat to capture detailed healing." },
        },
    },
    buffs = {
        title = "Buffs & Debuffs",
        blurb = "Uptime on every buff, debuff, status effect and crowd-control effect in the duel.",
        sections = {
            { h = "Four sub-tabs",
              b = "Buffs (on you), Debuffs (on either fighter), Status Effects (burning, poisoned, concussed and friends), and Crowd Control. Pick a sub-tab to swap the panel." },
            { h = "Uptime columns",
              b = "Each effect shows UPTIME %, ACTIVE seconds, and COUNT (times applied). Uptime is threshold-coloured, so weak coverage on something you should keep rolling jumps out immediately." },
            { h = "Applied to whom",
              b = "Debuffs and status effects split into 'On <opponent>' \226\128\148 your pressure \226\128\148 and 'On You' \226\128\148 theirs \226\128\148 so you can read both directions at a glance." },
            { h = "Uptime & count",
              b = "UPTIME %% is how much of the duel the effect was active; ACTIVE is that time as m:ss; COUNT is how many times it was applied. (No cleanse/purge column \226\128\148 the game never tells us when a debuff was purged, so any such number would be a guess.)" },
            { h = "Crowd Control",
              b = "Aggregates HARD crowd control only \226\128\148 stuns, knockdowns, fears, silences \226\128\148 so it reflects real control, not snares and minor slows." },
        },
    },
    stats = {
        title = "Raw Stats",
        blurb = "Your character stats through the duel \226\128\148 the min, average and max of each while you actually fought.",
        sections = {
            { h = "Offense",
              b = "Spell & Weapon Damage, Spell & Weapon Crit chance and crit damage, Spell & Weapon Penetration, and Status chance." },
            { h = "Defense",
              b = "Max Health, Physical & Spell Resistance (with the mitigation % each buys), and Crit Resistance (shown as crit-damage reduced)." },
            { h = "Resources",
              b = "Max Magicka and Max Stamina, plus how your resources flowed over the course of the duel." },
            { h = "Racial resistances",
              b = "Element-specific racial resists \226\128\148 Dunmer flame, Nord frost, Argonian/Bosmer poison & disease \226\128\148 folded in on top of your base resists, since the game doesn't roll them into the generic resist stat." },
            { h = "Why min / avg / max?",
              b = "Buffs, procs and Major/Minor effects push these up and down mid-fight. The spread shows what you actually ran under pressure, not a static character-sheet snapshot." },
        },
    },
    flow = {
        title = "Timeline (Ebb & Flow)",
        blurb = "The whole duel as a timeline \226\128\148 see exactly when the momentum swung.",
        sections = {
            { h = "The graph",
              b = "A line chart across the duel's duration. Toggle the You / Opponent lines on and off; the source breakdown listed below the graph follows your toggles." },
            { h = "Five lenses",
              b = "Damage, Healing, Sustain, Bursts and Log sub-tabs each redraw the graph for that view, so you can isolate one story at a time." },
            { h = "Scrubber & pin",
              b = "Drag across the graph to read any single moment. Pin a time to freeze the breakdown list at that instant while you study the swing around it." },
            { h = "Bursts",
              b = "Detected burst windows are plotted as a lollipop chart; step through them to see what made up each spike \226\128\148 the exact abilities that stacked in your biggest moments." },
            { h = "Combat Log",
              b = "The raw event stream with filters, so you can replay precisely what landed and when \226\128\148 the ground truth behind every other tab." },
        },
    },
    build = {
        title = "Build",
        blurb = "The full build both fighters ran this duel, captured at the opening bell.",
        sections = {
            { h = "Left column \226\128\148 character & gear",
              b = "Race, class lines, attributes, mundus, food/drink, vampire/werewolf and curse, plus every gear piece with its set, trait and exact enchant. Sets are tallied so 5-piece bonuses read at a glance." },
            { h = "Right column \226\128\148 bars & Champion",
              b = "Both action bars (including scribed-skill scripts) and your 12 slotted Champion stars, laid out so the whole loadout reads without scrolling." },
            { h = "Hover for tooltips",
              b = "Hover any ability, Champion star or gear piece for the game's real tooltip; right-click a gear piece to link it in chat." },
            { h = "Share it",
              b = "The SETS tile is postable \226\128\148 right-click it to drop a clean build summary into chat." },
        },
    },
}
-- Build the header/body item list for RenderLinesInto: an intro blurb (muted) then,
-- per section, a bold accent sub-header + a wrapped body paragraph.
function UI.guide.Items(key)
    local g = UI.guide.content[key] or UI.guide.content.optim
    local items = {}
    if g.blurb then items[#items+1] = { wrap = true, left = g.blurb, color = C.mid, h = 26 } end
    for _, s in ipairs(g.sections) do
        items[#items+1] = { header = true, left = s.h }
        items[#items+1] = { wrap = true, left = s.b, color = C.hi, h = 24 }
    end
    return items
end
-- The overlay itself (built once in BuildWindow); referenced ESO globals resolve in-game only.
function UI.guide.BuildModal(win)
    local m = WM:CreateControl(nil, win, CT_CONTROL)
    m:SetAnchorFill(win)
    m:SetDrawTier(DT_HIGH)      -- lift above the window's controls (same pattern as the rank modal)
    m:SetMouseEnabled(true)
    m:SetHidden(true)
    local dim = WM:CreateControl(nil, m, CT_TEXTURE)
    dim:SetAnchorFill(m); dim:SetColor(0, 0, 0, 0.75); dim:SetMouseEnabled(true)
    dim:SetHandler("OnMouseUp", function() m:SetHidden(true) end)   -- click the scrim to close
    local W2, H2 = 800, 600
    local panel = WM:CreateControl(nil, m, CT_CONTROL)
    panel:SetDimensions(W2, H2); panel:SetAnchor(CENTER, m, CENTER, 0, 0)
    backdrop(panel, C.card, C.line, 2); panel:SetMouseEnabled(true)   -- eat clicks on the card itself
    UI.guide.Icon = WM:CreateControl(nil, panel, CT_TEXTURE)
    UI.guide.Icon:SetDimensions(30, 30); UI.guide.Icon:SetAnchor(TOPLEFT, panel, TOPLEFT, 30, 26)
    UI.guide.Title = label(panel, 27, C.accent, nil, "bold")
    UI.guide.Title:SetAnchor(LEFT, UI.guide.Icon, RIGHT, 12, 0)
    local x = WM:CreateControlFromVirtual(nil, panel, "ZO_CloseButton")
    x:SetAnchor(TOPRIGHT, panel, TOPRIGHT, -12, 16)
    x:SetHandler("OnClicked", function() m:SetHidden(true) end)
    x:SetHandler("OnMouseUp", function(_, _, inside) if inside then m:SetHidden(true) end end)
    local rule = WM:CreateControl(nil, panel, CT_BACKDROP)
    rule:SetHeight(1)
    rule:SetAnchor(TOPLEFT, panel, TOPLEFT, 28, 74); rule:SetAnchor(TOPRIGHT, panel, TOPRIGHT, -28, 74)
    rule:SetCenterColor(unpack(C.line)); rule:SetEdgeColor(0, 0, 0, 0)
    UI.guide.Scroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_GuideScroll", panel, "ZO_ScrollContainer")
    UI.guide.Scroll:SetAnchor(TOPLEFT, panel, TOPLEFT, 30, 88)
    UI.guide.Scroll:SetAnchor(BOTTOMRIGHT, panel, BOTTOMRIGHT, -18, -44)
    UI.guide.Child = UI.guide.Scroll:GetNamedChild("ScrollChild")
    if UI.guide.Child then UI.guide.Child:SetResizeToFitDescendents(false) end
    UI.guide.Lines = {}
    local foot = label(panel, 13, C.lo)
    foot:SetAnchor(BOTTOMLEFT, panel, BOTTOMLEFT, 30, -16)
    foot:SetAnchor(BOTTOMRIGHT, panel, BOTTOMRIGHT, -30, -16)
    foot:SetText("This guide always describes the tab you're viewing \226\128\148 switch tabs and reopen it for another.")
    UI.guide.modal = m
end
-- Populate for `key` and show. Temporarily borrows the module `contentW` so the shared
-- renderer sizes rows to the modal body width, then restores it (same trick the Build columns use).
function UI.guide.Show(key)
    if not UI.guide.modal then return end
    local g = UI.guide.content[key] or UI.guide.content.optim
    UI.guide.Title:SetText(g.title)
    if UI.guide.Icon then
        if TAB_ICON[key] then UI.guide.Icon:SetHidden(false); UI.guide.Icon:SetTexture(TAB_ICON[key]) else UI.guide.Icon:SetHidden(true) end
    end
    local saved = contentW
    local bw = (UI.guide.Child and UI.guide.Child.GetWidth and UI.guide.Child:GetWidth()) or 0
    if bw < 100 then bw = 740 end   -- first open before layout settles
    contentW = bw - 6
    RenderLinesInto(UI.guide.Scroll, UI.guide.Child, UI.guide.Lines, UI.guide.Items(key))
    contentW = saved
    UI.guide.modal:SetHidden(false)
end
function UI.guide.Toggle(key)
    if not UI.guide.modal then return end
    if UI.guide.modal:IsHidden() then UI.guide.Show(key) else UI.guide.modal:SetHidden(true) end
end
local HEAL_COLS = { "HEAL %", "HPS", "HEAL", "OVER %", "CRIT/HITS", "CRIT %", "MIN", "AVG", "MAX" }
local function HealingItems(du)
    local items = {}
    local taken, healed, over = du.dmgTaken or 0, du.healReceived or 0, du.overHeal or 0
    local sustain = (taken > 0) and (math.floor(healed / taken * 100 + 0.5) .. "%") or "\226\128\148"
    local overpct = ((over + healed) > 0) and (math.floor(over / (over + healed) * 100 + 0.5) .. "%") or "0%"
    local opp = (currentDuel and currentDuel.o and (currentDuel.o.handle or currentDuel.o.name)) or "my opponent"
    items[#items+1] = { tiles = {
        { l = "TIME",         v = FmtDur(du.durationS), c = C.hi },
        { l = "HPS",          v = Abbrev(du.hps or 0),          c = C.win,
          post = string.format("I averaged %s HPS during this duel vs %s.", Comma(du.hps or 0), opp) },
        { l = "TOTAL HEALED", v = Abbrev(healed),               c = C.win,
          post = string.format("I did a total of %s healing during this duel vs %s.", Comma(healed), opp) },
        { l = "OVERHEAL",     v = overpct,                      c = C.hi,
          post = string.format("I overhealed %s of my healing during this duel vs %s.", overpct, opp) },
        { l = "SUSTAIN",      v = sustain,                      c = C.hi,
          post = string.format("I out-healed %s of the damage I took during this duel vs %s.", sustain, opp) },
    } }
    items[#items+1] = { header = true, left = "Healing Received", right = "Total " .. Abbrev(healed), rcolor = C.lo }
    AbilityRows(items, du.healTop, du.durationS, { srcLabel = "Heal Source", titles = HEAL_COLS, heal = true })
    if not (du.healTop and #du.healTop > 0) then
        items[#items+1] = { left = "|c999999No healing recorded for this duel \226\128\148 LibCombat wasn't active, or you took no heals.|r" }
    end
    return items
end

-- Effect table (buffs / debuffs) — uptime-focused. list is already sorted by uptime.
local EFFECT_COLS = { "UPTIME %", "ACTIVE", "COUNT" }
local function EffectRows(items, list, dur)
    list = list or {}
    dur = (dur and dur > 0) and dur or 1
    items[#items+1] = { colHeader = true, srcLabel = "Effect", colTitles = EFFECT_COLS, boldCol = 1 }
    if #list == 0 then
        items[#items+1] = { left = "|c777777None recorded.|r" }
        return
    end
    for _, e in ipairs(list) do
        local up = (e.uptime or 0) / 1000
        local pct = math.min(100, math.floor(up / dur * 100 + 0.5))
        items[#items+1] = {
            icon = IconFor(e),
            left = (e.name and e.name ~= "") and e.name or ("#" .. tostring(e.id)),
            cols = { pct .. "%", UI._FmtMS(up), tostring(e.count or 0) },
            colColors = { UptimeColor(pct) },   -- threshold-colour the uptime %
            boldCol = 1,
        }
    end
end
-- Split a captured effect list into status effects vs plain debuffs, classified purely by the STATUS
-- EFFECT ABILITY ID (the eight elemental/damage statuses have fixed game-constant ids). We do NOT trust
-- the stored isStatus flag: older records baked in false positives (Rending Slashes / Blood Craze /
-- werewolf bleeds / Dazing Smash were flagged as statuses because their effect events carry a
-- damage-flavoured statusEffectType) -- classifying by id here fixes those retroactively, and is
-- language-independent. On UI to avoid a new file-scope local (this file is at the 200-active-local cap).
UI._STATUS_IDS = {
    [18084] = true, [21929] = true, [95134] = true, [95136] = true,    -- Burning, Poisoned, Concussion, Chill
    [148801] = true, [178118] = true, [178123] = true, [178127] = true, -- Hemorrhaging, Overcharged, Sundered, Diseased
}
local function NonStatus(list) local o = {}; for _, e in ipairs(list or {}) do if not UI._STATUS_IDS[e.id] then o[#o+1] = e end end; return o end
local function StatusOnly(list) local o = {}; for _, e in ipairs(list or {}) do if UI._STATUS_IDS[e.id] then o[#o+1] = e end end; return o end

-- Purge/cleanse detection: how many of an effect's application windows faded EARLY (well under its
-- nominal duration) AND ended before the duel did — i.e. removed by a purge, not expired or cut off by
-- the duel ending. On "Applied to <Opp>" that's them cleansing your pressure; on "Applied to Me", you
-- cleansing theirs. Needs the captured intervals + nominal duration (older records / no data -> 0).
local DIR_EFFECT_COLS = { "UPTIME %", "ACTIVE", "COUNT" }
local function PurgeCount(e, durS)
    if not e.intervals or #e.intervals == 0 then return 0 end
    local nomMs = (e.dur or 0) * 1000
    if nomMs < 1000 then return 0 end
    local endMs = (durS or 0) * 1000
    local ivs = e.intervals   -- appended in FADED order, so chronological
    local n = 0
    for i = 1, #ivs do
        local iv = ivs[i]
        local len = (iv.e or 0) - (iv.s or 0)
        if len < nomMs * 0.6 and (iv.e or 0) < endMs - 1500 then
            -- A REFRESH/reapplication splits one effect into back-to-back windows (real Major Breach:
            -- 0->12.8, 12.8->17.5) — the early end is a re-cast, not a cleanse. Only count a purge when a
            -- real GAP follows (effect stayed gone > ~500ms = an enemy cleanse) or it's the final window.
            local nxt = ivs[i + 1]
            if (not nxt) or ((nxt.s or 0) - (iv.e or 0) > 500) then n = n + 1 end
        end
    end
    return n
end

-- Break an "on target" (out) and an "on you" (in) effect stream into TWO labelled groups, each its own
-- uptime-sorted table under a coloured header: "On <opponent> — your pressure" (green) then "On You —
-- incoming" (red). Powers the Debuffs and Status (and later Control) sub-views. Clearer than inline
-- tags and scales to long lists, so it's used for all the two-way views.
local function DirEffectRows(items, outList, inList, dur, srcLabel, oppName, oppIcon, myIcon)
    dur = (dur and dur > 0) and dur or 1
    -- NOTE: no PURGED/cleanse column. We never observe the opponent casting a cleanse; a "purge" could
    -- only be INFERRED from a debuff window ending early, and that inference is dominated by re-procs,
    -- refreshes, natural expiry and status-effect cycling (Minor Vuln/Maim/Brittle, mythic procs like
    -- Mark of Hircine) -- plus most builds can't cleanse at all. It produced false positives, so it's out.
    local function group(list, headerText, headerColor, headerIcon)
        items[#items+1] = { header = true, left = headerText, color = headerColor, icon = headerIcon }
        items[#items+1] = { colHeader = true, srcLabel = srcLabel or "Effect", colTitles = DIR_EFFECT_COLS, boldCol = 1 }
        if not list or #list == 0 then items[#items+1] = { left = "|c777777None.|r" }; return end
        local sorted = {}
        for _, e in ipairs(list) do sorted[#sorted+1] = e end
        table.sort(sorted, function(x, y) return (x.uptime or 0) > (y.uptime or 0) end)
        for _, e in ipairs(sorted) do
            local up = (e.uptime or 0) / 1000
            local pct = math.min(100, math.floor(up / dur * 100 + 0.5))
            items[#items+1] = {
                icon = IconFor(e),
                left = (e.name and e.name ~= "") and e.name or ("#" .. tostring(e.id)),
                cols = { pct .. "%", UI._FmtMS(up), tostring(e.count or 0) },
                colColors = { UptimeColor(pct) },   -- threshold-colour the uptime %
                boldCol = 1,
            }
        end
    end
    group(outList, "Applied to " .. (oppName or "Target"), C.win, oppIcon)
    group(inList, "Applied to Me", C.loss, myIcon)
end

-- Crowd-control ledger (the Control sub-view): per-ability, so you see WHAT CC'd you and (for the
-- duration-based kinds) HOW LONG. onMe/onOpp are [abilityId] = { kind, name, count, uptime? }.
-- CC namespace (one file-scope local to conserve the 200-per-chunk local budget).
-- soft = duration-based kinds that show a TIME but do NOT feed the aggregate (snare/root/silence show
-- time; snare+stagger excluded from hard). hard = kinds counted in the "HARD CC" tiles: Stun/Fear/
-- Disorient/Immobilize(root)/Silence -- Fear & Disorient are mechanically stuns, Silence hard-stops casting.
local CC = {
    soft = { Snare = true, Immobilize = true, Silence = true },
    -- HARD CC = loss of character control (Stun/Fear/Disorient). Immobilize (root) and Silence keep you in
    -- control of your character, so they stay in the soft list with a duration and are NOT counted as hard.
    hard = { Stun = true, Fear = true, Disorient = true },
    cols = { "KIND", "COUNT", "TIME" },
}
local function ControlRows(items, du, oppName, oppIcon, myIcon)
    local cc = du.cc or {}
    local onMe, onOpp = cc.onMe or {}, cc.onOpp or {}
    -- Soft-CC time comes from the debuff's uptime we already captured (their debuff on the relevant unit).
    local function upMap(list) local m = {}; for _, e in ipairs(list or {}) do m[e.id] = e.uptime end; return m end
    local meUp, oppUp = upMap(du.debuffsMe), upMap(du.debuffsOpp)
    -- Aggregate = HARD CC only (stun/fear/disorient/root); snares & other soft CC are shown in the
    -- list but don't inflate the headline. (type guard: pre-v1.22 records stored cc as kind->number.)
    local function total(t) local s = 0; for _, r in pairs(t) do if type(r) == "table" and CC.hard[r.kind] then s = s + (r.count or 0) end end; return s end
    items[#items+1] = { tiles = {
        { l = "HARD CC ON THEM", v = tostring(total(onOpp)), c = C.win },
        { l = "HARD CC ON YOU", v = tostring(total(onMe)), c = C.loss },
    } }
    local function group(tbl, upm, headerText, headerColor, headerIcon)
        items[#items+1] = { header = true, left = headerText, color = headerColor, icon = headerIcon }
        items[#items+1] = { colHeader = true, srcLabel = "Ability", colTitles = CC.cols, boldCol = 2 }
        local arr = {}
        for id, r in pairs(tbl) do if type(r) == "table" then arr[#arr+1] = { id = id, r = r } end end
        if #arr == 0 then items[#items+1] = { left = "|c777777None.|r" }; return end
        table.sort(arr, function(a, b) return (a.r.count or 0) > (b.r.count or 0) end)
        for _, x in ipairs(arr) do
            local r = x.r
            local upMs = r.uptime or upm[x.id] or 0
            local timeStr = (CC.soft[r.kind] and upMs > 0) and UI._FmtMS(upMs / 1000) or "\226\128\148"
            -- Soft CC (not in the aggregate) is dimmed so hard CC reads as the meaningful stuff.
            local hard = CC.hard[r.kind]
            items[#items+1] = {
                icon = AbilityIcon(x.id),
                left = (r.name and r.name ~= "") and r.name or ("#" .. tostring(x.id)),
                color = hard and C.hi or C.lo,
                cols = { r.kind or "", tostring(r.count or 0), timeStr },
                boldCol = 2,
            }
        end
    end
    group(onOpp, oppUp, "Applied to " .. (oppName or "Target"), C.win, oppIcon)
    group(onMe, meUp, "Applied to Me", C.loss, myIcon)
end
-- ===========================================================================
-- STATS tab (raw stats: min / avg / max per LibCombat stat, grouped)
-- ===========================================================================
-- Numeric LibCombat stat ids (stable constants; hardcoded so this file loads even
-- when LibCombat is absent — see LibCombat.lua LIBCOMBAT_STAT_*). kind drives display.
local STAT_DEF = {
    offense = {
        { id = 2,  label = "Spell Damage",        kind = "num",  tint = "magic" },
        { id = 12, label = "Weapon Damage",       kind = "num",  tint = "phys"  },
        { id = 3,  label = "Spell Crit Chance",   kind = "crit", tint = "magic" },
        { id = 13, label = "Weapon Crit Chance",  kind = "crit", tint = "phys"  },
        { id = 4,  label = "Spell Crit Damage",   kind = "pct",  tint = "magic" },
        { id = 14, label = "Weapon Crit Damage",  kind = "pct",  tint = "phys"  },
        { id = 5,  label = "Spell Penetration",   kind = "num",  tint = "magic" },
        { id = 15, label = "Weapon Penetration",  kind = "num",  tint = "phys"  },
        { id = 25, label = "Status Chance",       kind = "pct"  },
    },
    defense = {
        { id = 21, label = "Max Health",      kind = "num",    tint = "health" },
        { id = 22, label = "Physical Resist", kind = "resist", tint = "phys"  },
        { id = 23, label = "Spell Resist",    kind = "resist", tint = "magic" },
        { id = 24, label = "Crit Resist",     kind = "critresist" },
    },
    resource = {
        { id = 1,  label = "Max Magicka",     kind = "num", tint = "magic" },
        { id = 11, label = "Max Stamina",     kind = "num", tint = "phys"  },
    },
}
local function FmtStat(kind, v)
    v = v or 0
    if kind == "crit" then
        local ok, pct = pcall(GetCriticalStrikeChance, math.floor(v))
        return (ok and pct) and string.format("%.1f%%", pct) or Comma(v)
    elseif kind == "pct" then
        -- Already a full percentage (LibCombat CRITBONUS = 50 base + mundus/CP/backstabber/etc.,
        -- and status chance). Show as-is, e.g. 72.5%.
        return string.format("%.1f%%", v)
    else
        -- num / resist / critresist: PLAIN number in the MIN/AVG/MAX columns so the actual values
        -- line up with every other row; the mitigation % (resist/critresist) rides on the label
        -- instead (see MitStat) so it never shoves the numbers out of alignment.
        return Comma(v)
    end
end
-- Mitigation the resistance buys, shown beside the LABEL (not inside the numeric columns).
local function MitStat(kind, avg)
    avg = avg or 0
    if kind == "resist" then return string.format("   |c565b66\226\128\162 %.0f%% mitigation|r", math.min(50, avg / 660))
    elseif kind == "critresist" then return string.format("   |c565b66\226\128\162 %.1f%% crit-dmg reduced|r", avg / 68)
    else return "" end
end
local STAT_COLS = { "MIN", "AVG", "MAX" }
-- Map LibCombat resource powerType flags to display names for the resource-flow table.
local POWER_NAME = {
    [COMBAT_MECHANIC_FLAGS_MAGICKA]  = "Magicka",
    [COMBAT_MECHANIC_FLAGS_STAMINA]  = "Stamina",
    [COMBAT_MECHANIC_FLAGS_ULTIMATE] = "Ultimate",
    [COMBAT_MECHANIC_FLAGS_HEALTH]   = "Health",
}
-- Element-SPECIFIC racial resistances. Racial Weapon/Spell Damage is already baked into the captured
-- SD/WD stats, and general resist passives (Breton spell, Nord Rugged) already land in the Spell/Physical
-- Resistance stat -- but element-specific racials (Dunmer flame, Nord frost, Bosmer/Argonian poison &
-- disease) are NOT in that generic stat, so we add them to show the TRUE elemental resistance.
-- school = base resist it stacks on (spell covers flame/frost/shock/magic; phys the rest).
-- Values = the standard "Resist X" passive (2310); edit here if a patch rebalances them.
-- One RACE namespace (kept as a single file-scope local to conserve the 200-per-chunk local budget).
local RACE = {
    -- resist[raceId] = element-specific racial resistances, exact max-rank values (UESP/Dottz).
    -- Single-element resists (Dunmer Resist Flame, Nord Resist Frost) are 4620; the dual
    -- Poison & Disease ones (Argonian Resistance, Bosmer Resist Affliction) are 2310 each.
    resist = {
        [4] = { { el = "Flame",  school = "spell", bonus = 4620 } },                                                    -- Dark Elf: Resist Flame
        [5] = { { el = "Frost",  school = "spell", bonus = 4620 } },                                                    -- Nord: Resist Frost
        [6] = { { el = "Poison", school = "phys", bonus = 2310 }, { el = "Disease", school = "phys", bonus = 2310 } },  -- Argonian: Argonian Resistance
        [8] = { { el = "Poison", school = "phys", bonus = 2310 }, { el = "Disease", school = "phys", bonus = 2310 } },  -- Wood Elf: Resist Affliction
    },
    -- resistNote[raceId] = explanation for races whose racial resist is GENERAL (already in the base
    -- Spell/Physical Resist above) rather than element-specific. Races with no entry and no resist[] get
    -- a generic "No racial resistance passive." line so the section is never confusingly empty.
    resistNote = {
        [1] = "Spell Attunement (+2310 Spell Resistance) is general \226\128\148 already included in Spell Resist above.",
        [5] = "Rugged (+2600 Physical & Spell Resistance) is general \226\128\148 already included in the resists above.",
    },
    -- passives[raceId] = one-line duel-relevant passive summary (Build tab, informational).
    passives = {
        [1]  = "Spell Resistance (+Spell Resist) \226\128\162 Gift of Magnus (+Max Magicka) \226\128\162 Magicka cost reduction",
        [2]  = "Adrenaline Rush + Conditioning (Stamina sustain, +Max Stamina) \226\128\162 Martial Training (weapon cost)",
        [3]  = "Unflinching (+Max Health, +Healing Taken) \226\128\162 Swift Warrior (+Weapon/Spell Damage) \226\128\162 Brawny (+Max Stamina)",
        [4]  = "Resist Flame (+Flame Resistance) \226\128\162 Dynamic (+Weapon/Spell Damage, +Max Mag/Stam)",
        [5]  = "Resist Frost (+Frost Resistance) \226\128\162 Rugged (+Physical/Spell Resistance) \226\128\162 Stalwart (+Max Stamina, Ultimate)",
        [6]  = "Argonian Resistance (+Poison/Disease Resistance, +Max Health) \226\128\162 Life Mender (+Healing Done)",
        [7]  = "Elemental Talent (+Weapon/Spell Damage) \226\128\162 Syrabane's Boon (+Max Magicka) \226\128\162 Spell Recharge (recovery)",
        [8]  = "Resist Affliction (+Poison/Disease Resistance, +Max Stamina) \226\128\162 Hunter's Eye (+Dodge, +Physical Pen)",
        [9]  = "Feline Ambush (+Weapon/Spell Crit, +Crit Damage) \226\128\162 Carnage (+Crit) \226\128\162 Lunar Blessings (recovery)",
        [10] = "Tough (+Max Health) \226\128\162 Imperial Mettle (+Max Stamina) \226\128\162 Red Diamond (resource return)",
    },
}
local function StatsItems(du)
    local st = du.stats
    local has = false
    if st then for _ in pairs(st) do has = true break end end
    if not has then
        return { { header = true, left = "Raw Stats" },
                 { left = "|c999999No stat samples for this duel \226\128\148 LibCombat wasn't active.|r" } }
    end
    local items = {}
    local function pick(id) local s = st[id]; return s and (s.avg or s.max) end
    -- Category tint -> colour (magical blue / physical green / health red; nil = neutral white).
    local function tintCol(t) return t == "magic" and C.magic or t == "phys" and C.phys or t == "health" and C.health or nil end
    -- headline avg tiles
    local spell, weap = pick(2) or 0, pick(12) or 0
    local critOk, critPct = pcall(GetCriticalStrikeChance, math.floor(math.max(pick(3) or 0, pick(13) or 0)))
    local pen = math.max(pick(5) or 0, pick(15) or 0)   -- effective pen = higher of spell / physical
    -- Header makes the tiles unambiguous: these are AVERAGES over the duel, not a build snapshot.
    items[#items+1] = { header = true, left = "Average Stats (this duel)" }
    local opp = (currentDuel and currentDuel.o and (currentDuel.o.handle or currentDuel.o.name)) or "my opponent"
    local critTxt = (critOk and critPct) and string.format("%.0f%%", critPct) or "\226\128\148"
    items[#items+1] = { tiles = {
        { l = "SPELL DMG",   v = Comma(spell), c = C.magic, post = string.format("my average Spell Damage during this duel vs %s was %s.", opp, Comma(spell)) },
        { l = "WEAPON DMG",  v = Comma(weap),  c = C.phys,  post = string.format("my average Weapon Damage during this duel vs %s was %s.", opp, Comma(weap)) },
        { l = "CRIT CHANCE", v = critTxt,      c = C.accent, post = string.format("my average Critical Chance during this duel vs %s was %s.", opp, critTxt) },
        { l = "PENETRATION", v = Comma(pen),   c = C.hi,    post = string.format("my average Penetration during this duel vs %s was %s.", opp, Comma(pen)) },
    } }
    local function group(title, defs)
        local any = false
        for _, d in ipairs(defs) do if st[d.id] then any = true break end end
        if not any then return end
        items[#items+1] = { header = true, left = title }
        items[#items+1] = { colHeader = true, srcLabel = "Stat", colTitles = STAT_COLS, boldCol = 2 }
        for _, d in ipairs(defs) do
            local s = st[d.id]
            if s then
                -- Colour the stat name AND its values by category (blue/green/health-red; neutral=white).
                local tcol = tintCol(d.tint)
                items[#items+1] = { left = d.label .. MitStat(d.kind, s.avg or s.max), color = tcol, valColor = tcol, boldCol = 2,
                    cols = { FmtStat(d.kind, s.min), FmtStat(d.kind, s.avg), FmtStat(d.kind, s.max) } }
            end
        end
    end
    group("Offense", STAT_DEF.offense)
    group("Defense", STAT_DEF.defense)
    -- ESO exposes no per-element resistances (even the char sheet only shows these two); make it
    -- clear which resist governs which damage school so "what's my flame resist?" is answered.
    if st[22] or st[23] then
        items[#items+1] = { left = "|c777f8bSpell Resist covers Flame / Frost / Shock / Magic  \226\128\162  Physical Resist covers Physical / Poison / Disease / Bleed|r" }
    end
    -- Racial Resistances: always shown so it's clear we accounted for the race. Element-specific
    -- racials (Dunmer/Nord/Argonian/Bosmer) add to base Spell/Physical Resist for the TRUE elemental
    -- value; races whose racial is general (Breton) or absent get an explanatory note instead.
    if du.myRaceId and du.myRaceId ~= 0 then
        items[#items+1] = { header = true, left = "Racial Resistances \226\128\148 " .. RaceName(du.myRaceId) }
        local rr = RACE.resist[du.myRaceId]
        if rr then
            -- Show each element resist across the SAME MIN/AVG/MAX as the base resist it stacks on, each
            -- PLUS the racial bonus, so the +bonus is unmistakable and the row lines up with the Spell/
            -- Physical Resist rows above. (It used to show a single AVG+bonus value, which -- because spell
            -- resist swings ~5-6k with Major Resolve -- landed right on top of the MAX spell-resist number,
            -- so it looked like the racial bonus had never been added.)
            items[#items+1] = { colHeader = true, srcLabel = "Element", colTitles = STAT_COLS, boldCol = 2 }
            for _, e in ipairs(rr) do
                local s = st[e.school == "spell" and 23 or 22]
                local ecol = (e.school == "spell") and C.magic or C.phys
                -- Element name only (the section header already says "Racial Resistances" and the column
                -- is "Element") -- "Flame Resistance (+4620)" + the mitigation suffix overflowed the label
                -- and clipped "mitigation"; "Flame (+4620)" leaves room.
                local label = e.el .. "   |c6a6f7b(+" .. e.bonus .. ")|r"
                if s then
                    items[#items+1] = {
                        left = label .. MitStat("resist", (s.avg or s.max or 0) + e.bonus), color = ecol, valColor = ecol, boldCol = 2,
                        cols = { Comma((s.min or 0) + e.bonus), Comma((s.avg or s.max or 0) + e.bonus), Comma((s.max or 0) + e.bonus) },
                    }
                else
                    -- No base-resist sample this duel: show just the flat racial bonus.
                    items[#items+1] = { field = true, left = label, color = ecol, right = "+" .. Comma(e.bonus), rcolor = ecol }
                end
            end
        end
        local note = RACE.resistNote[du.myRaceId] or (not rr and "No racial resistance passive." or nil)
        if note then items[#items+1] = { left = "|c777f8b" .. note .. "|r" } end
    end
    -- Survivability: the extra DEFENSIVE values from the char sheet's Advanced Stats panel.
    local a = du.adv
    if a then
        local srows = {}
        if a.blockMit  then srows[#srows+1] = { field = true, left = "Block Mitigation", right = string.format("%.0f%%", a.blockMit), rcolor = C.hi } end
        if a.blockCost then srows[#srows+1] = { field = true, left = "Block Cost",       right = Comma(a.blockCost),                rcolor = C.hi } end
        if a.dodgeCost then srows[#srows+1] = { field = true, left = "Roll Dodge Cost",  right = Comma(a.dodgeCost),                rcolor = C.hi } end
        if a.ccBreak   then srows[#srows+1] = { field = true, left = "Break Free Cost",  right = Comma(a.ccBreak),                  rcolor = C.hi } end
        if #srows > 0 then
            items[#items+1] = { header = true, left = "Survivability (advanced stats)" }
            for _, r in ipairs(srows) do items[#items+1] = r end
        end
    end
    group("Resource Pools", STAT_DEF.resource)
    -- Resource flow: GAINED vs BURNED per 2 seconds (recovery ticks every 2s -> CMX-style sustain
    -- read), plus NET so you can see at a glance whether you were bleeding a pool or holding steady.
    if du.resources and (du.durationS or 0) > 0 then
        local dur = du.durationS
        local order = { COMBAT_MECHANIC_FLAGS_MAGICKA, COMBAT_MECHANIC_FLAGS_STAMINA, COMBAT_MECHANIC_FLAGS_ULTIMATE }
        local rcol = { [COMBAT_MECHANIC_FLAGS_MAGICKA] = C.magic, [COMBAT_MECHANIC_FLAGS_STAMINA] = C.phys, [COMBAT_MECHANIC_FLAGS_ULTIMATE] = C.accent }
        local rows = {}
        for _, pt in ipairs(order) do
            local r, nm = du.resources[pt], POWER_NAME[pt]
            if r and nm and ((r.gains or 0) > 0 or (r.drains or 0) > 0) then
                local g2, b2 = (r.gains or 0) / dur * 2, (r.drains or 0) / dur * 2
                local net = g2 - b2
                rows[#rows+1] = {
                    left = nm, color = rcol[pt],
                    cols = { "+" .. Abbrev(g2), "-" .. Abbrev(b2), (net >= 0 and "+" or "-") .. Abbrev(math.abs(net)) },
                    colColors = { C.win, C.loss, net >= 0 and C.win or C.loss },
                }
            end
        end
        if #rows > 0 then
            items[#items+1] = { header = true, left = "Resource Flow (per 2s)" }
            items[#items+1] = { colHeader = true, srcLabel = "Resource", colTitles = { "GAINED", "BURNED", "NET" } }
            for _, r in ipairs(rows) do items[#items+1] = r end
            items[#items+1] = { left = "|c777f8bNET = gained \226\136\146 burned per 2s. Negative = you were bleeding that pool over the fight.|r" }
        end
    end
    return items
end

-- ===========================================================================
-- GRADE tab (graded report card vs opponent result + vs your own average)
-- ===========================================================================
local function MyAverages()
    local n, dOut, dIn, dealt, taken, heal = 0, 0, 0, 0, 0, 0
    for _, e in ipairs(AllDuels()) do
        local du = e.du; n = n + 1
        dOut = dOut + (du.dpsOut or 0); dIn = dIn + (du.dpsIn or 0)
        dealt = dealt + (du.dmgDealt or 0); taken = taken + (du.dmgTaken or 0); heal = heal + (du.healReceived or 0)
    end
    if n == 0 then n = 1 end
    return { dpsOut = dOut/n, dpsIn = dIn/n, dmgDealt = dealt/n, dmgTaken = taken/n, healReceived = heal/n }
end
-- 13-step +/neutral/- scale (Shoyru). 50 stays anchored at C = "an even fight on that front".
-- Deliberately capped at A+ -- S-tier belongs to the Dueling Tier RANK (cross-opponent ladder,
-- free to rebrand later), not the per-duel performance GRADE; sharing scales would inflate both.
local function GradeLetter(score)
    if score >= 92 then return "A+" elseif score >= 85 then return "A" elseif score >= 80 then return "A-"
    elseif score >= 74 then return "B+" elseif score >= 68 then return "B" elseif score >= 62 then return "B-"
    elseif score >= 56 then return "C+" elseif score >= 50 then return "C" elseif score >= 44 then return "C-"
    elseif score >= 38 then return "D+" elseif score >= 32 then return "D" elseif score >= 26 then return "D-"
    else return "F" end
end
-- Build-static observations (true every duel you run this build) -- kept OUT of the per-duel insights.
-- Each only fires when the stat is actually off, so different builds surface different notes.
local function BuildFlags(du)
    local out, st = {}, du.stats
    if st then
        local function avg(id) local s = st[id]; return s and (s.avg or s.max) end
        local pen = math.max(avg(5) or 0, avg(15) or 0)
        if pen > 18200 then
            out[#out+1] = string.format("Penetration averages %s \226\128\148 past the ~18.2k cap it's wasted unless your target over-stacks resistances; the excess could be crit or damage instead.", Comma(pen))
        elseif pen > 0 and pen < 9000 then
            out[#out+1] = string.format("Penetration is only %s \226\128\148 well under the ~18.2k a resistance-buffed target carries, so a chunk of every hit is being resisted.", Comma(pen))
        end
        local ok, critPct = pcall(GetCriticalStrikeChance, math.floor(math.max(avg(3) or 0, avg(13) or 0)))
        if ok and critPct > 0 and critPct < 40 then
            out[#out+1] = string.format("Crit chance ~%.0f%% is low \226\128\148 more crit rating raises your sustained damage.", critPct)
        end
        local cd = math.max(avg(4) or 0, avg(14) or 0)   -- already includes the 50% base
        if cd > 0 and cd < 55 then
            out[#out+1] = string.format("Crit damage is only ~%.0f%% (base is 50) \226\128\148 a Shadow mundus, a crit-damage set, or Backstabber/Fighting Finesse CP scales every crit.", cd)
        end
        local hp = avg(21)
        if hp and hp > 0 and hp < 20000 then
            out[#out+1] = string.format("Max health %s is low for PvP \226\128\148 you're one clean combo from dead; more health or Impenetrable helps you survive the opener.", Comma(hp))
        end
        local cr = avg(24)
        if cr and cr > 0 and cr < 1000 then
            out[#out+1] = string.format("Crit resistance %s is low (~%.0f%% crit-damage reduction) \226\128\148 you're eating near-full crits; Impenetrable traits close the gap.", Comma(cr), cr / 68)
        end
        local pr, sr = avg(22), avg(23)
        if pr and pr < 15000 then out[#out+1] = string.format("Physical resistance %s is low \226\128\148 stamina attacks will hit hard.", Comma(pr)) end
        if sr and sr < 15000 then out[#out+1] = string.format("Spell resistance %s is low \226\128\148 magicka attacks will hit hard.", Comma(sr)) end
    end
    local tl = du.timeline
    if tl then
        local high, total = 0, 0
        for _, d in pairs(tl) do total = total + 1; if (d.ult or 0) >= 250 then high = high + 1 end end
        if total > 0 and high / total > 0.5 then
            out[#out+1] = "Ultimate sat capped for over half the duel \226\128\148 you're generating faster than you're spending; use it sooner or slot a cheaper one."
        end
    end
    return out
end
-- Report-card helpers folded into ONE table (RC) to stay under DuelMetricsUI's 200 main-chunk
-- local cap, the same way RANK/F/BD/SB do. Colour per letter grade: A green .. F red.
local RC = {}
-- A monotonic heat gradient so colour directly encodes performance: green (best) -> lime -> yellow
-- -> orange -> red (worst). No blue/other hues -- that's what made B/C look unrelated to strong/weak.
RC.GRADE_COL = {
    A = { 0.40, 0.83, 0.46, 1 }, B = { 0.66, 0.83, 0.38, 1 },
    C = { 0.96, 0.81, 0.35, 1 }, D = { 0.96, 0.58, 0.30, 1 }, F = { 0.94, 0.41, 0.38, 1 },
}
-- ---- UNIVERSAL effect library (game knowledge, NOT build-specific) --------------------------------
-- Keyed by the canonical ESO ability id of the Major/Minor debuff family (source-independent: every
-- skill/set that applies "Major Breach" reports the SAME 61743). role = what it does; w = how much it
-- matters for offensive pressure (majors > minors; a resist/vulnerability shred > a small snare).
-- Ships identical for every user; personalization comes from intersecting this with the effects a
-- player ACTUALLY applied this duel (their debuffsOpp). Status effects are handled via the game's own
-- isStatus flag (captured at runtime) so no id list is needed for them.
RC.EFF = {
    [61743] = { role = "resist",   w = 1.00, short = "Major Breach" },   [61742] = { role = "resist",   w = 0.55, short = "Minor Breach" },
    [106754]= { role = "vuln",     w = 1.00, short = "Major Vulnerability" }, [79717] = { role = "vuln",  w = 0.60, short = "Minor Vulnerability" },
    [145977]= { role = "brittle",  w = 0.85, short = "Major Brittle" },   [145975]= { role = "brittle",  w = 0.50, short = "Minor Brittle" },
    [61725] = { role = "maim",     w = 0.80, short = "Major Maim" },      [61723] = { role = "maim",     w = 0.45, short = "Minor Maim" },
    [61727] = { role = "defile",   w = 0.75, short = "Major Defile" },    [61726] = { role = "defile",   w = 0.45, short = "Minor Defile" },
    [147643]= { role = "cowardice",w = 0.70, short = "Major Cowardice" }, [79867] = { role = "cowardice",w = 0.40, short = "Minor Cowardice" },
    [45902] = { role = "offbal",   w = 0.60, short = "Off Balance" },
}
-- Classify one effect record: returns (role, weight) using the id library first, then the isStatus
-- flag (any game-classified status proc counts as key pressure), else nil for incidental effects.
function RC.EffKind(rec)
    local m = rec and rec.id and RC.EFF[rec.id]
    if m then return m.role, m.w end
    if rec and rec.isStatus then return "status", 0.80 end
    return nil
end
-- ABSOLUTE benchmarks so grades reflect real performance (not just "vs your own average") -- your
-- average grade then genuinely trends up as you improve, and a fall-off shows. dps values where the
-- axis hits ~100. TUNABLE: if grades read high/low for your build, adjust these (report your numbers).
RC.BENCH = { off = 11000, def = 11000, burst = 45000 }   -- 11k dps out ~ A+ offense; 11k dps taken ~ F defense; 45k in 3s ~ A+ burst
function RC.Color(gl) return RC.GRADE_COL[(gl or "F"):sub(1, 1)] or C.hi end
function RC.DeltaStr(v, base)
    v = v or 0; base = base or 0
    if base <= 0 then return Abbrev(v) end
    return string.format("%s (%+d%%)", Abbrev(v), math.floor((v - base) / base * 100 + 0.5))
end
function RC.DeltaColor(v, base)   -- green when v (higher) beats base
    v = v or 0; base = base or 0
    if base <= 0 or v == base then return C.hi end
    return v > base and C.win or C.loss
end
function RC.PctVs(v, base)
    if not base or base <= 0 then return "n/a" end
    return string.format("%+d%%", math.floor((v - base) / base * 100 + 0.5))
end
-- Peak damage in any 3-second window (the "burst" measure), from the per-second timeline.
function RC.RollingPeak(du)
    local tl, dur = du.timeline, du.durationS or 0
    if type(tl) ~= "table" or dur < 1 then return du.maxDealt or 0 end
    local peak = 0
    for s = 0, dur do
        local sum = 0
        for k = 0, 2 do local c = tl[s + k]; if c then sum = sum + (c.dmgOut or 0) end end
        if sum > peak then peak = sum end
    end
    return peak
end
-- Their hardest 3s window (incoming): value + start second. Mirrors RollingPeak on dmgIn.
function RC.PeakIn(du)
    local tl, dur = du.timeline, du.durationS or 0
    if type(tl) ~= "table" or dur < 1 then return 0, 0 end
    local peak, at = 0, 0
    for s = 0, dur do
        local sum = 0
        for k = 0, 2 do local c = tl[s + k]; if c then sum = sum + (c.dmgIn or 0) end end
        if sum > peak then peak, at = sum, s end
    end
    return peak, at
end
-- Recovery speed (Shoyru): when you drop under 50% HP, how many seconds to climb back to 80%?
-- Returns (worstRecoverySecs or nil, hadHPData). nil + true = never dipped below half (full credit);
-- an unrecovered dip (died there / duel ended) reads as a slow one. hp is only on records captured
-- since the b.hp timeline field landed -- old duels return hadHPData=false and the caller stays neutral.
function RC.Recovery(du)
    local tl, dur = du.timeline, math.floor(du.durationS or 0)
    if type(tl) ~= "table" then return nil, false end
    local maxHP = 0
    for _, b in pairs(tl) do if (b.hp or 0) > maxHP then maxHP = b.hp end end
    local st = du.stats and du.stats[21]
    maxHP = math.max(maxHP, (st and (st.max or st.avg)) or 0)
    if maxHP <= 0 then return nil, false end
    local worst, dipAt, sampled = nil, nil, false
    for s = 0, dur do
        local hp = tl[s] and tl[s].hp
        if hp and hp > 0 then
            sampled = true
            if not dipAt and hp < maxHP * 0.5 then dipAt = s
            elseif dipAt and hp >= maxHP * 0.8 then
                local rec = s - dipAt
                if not worst or rec > worst then worst = rec end
                dipAt = nil
            end
        end
    end
    if not sampled then return nil, false end
    if dipAt then worst = math.max(worst or 0, 12) end   -- dipped and never made it back
    return worst, true
end
-- ---- Calibration + personal baseline (a sliding-window MEDIAN over your recent duels) ----
-- Median (not mean) + a window makes it robust: a few flukes or sandbagged duels barely move it,
-- old builds age out, and there's no frozen bar to game. The Report Card stays LOCKED until MINCAL
-- duels so the baseline is meaningful. Baseline drives Offense/Defense/Burst (50 = your median).
RC.MINCAL = 10     -- duels before the Report Card unlocks
RC.WINDOW = 50     -- baseline = median over your last N duels (slides continuously, stays current)
RC.RECENT = 10     -- trend = your last N duels' mean grade vs your baseline-window norm
RC._bl = nil       -- baseline cache, keyed by duel count
function RC.DuelCount()
    local n = 0
    if sv and sv.opponents then for _, o in pairs(sv.opponents) do n = n + (o.duels and #o.duels or 0) end end
    return n
end
function RC.Calibrating() return RC.DuelCount() < RC.MINCAL end
function RC.Baseline()
    local arr = AllDuels()   -- newest-first
    local n = #arr
    if RC._bl and RC._bl.n == n then return RC._bl end
    local function med(t)
        if #t == 0 then return 0 end
        table.sort(t)
        local h = #t / 2
        return (#t % 2 == 1) and t[math.floor(h) + 1] or (t[h] + t[h + 1]) / 2
    end
    local o, i, b = {}, {}, {}
    for idx = 1, math.min(n, RC.WINDOW) do   -- last WINDOW duels only
        local du = arr[idx].du
        o[#o + 1] = du.dpsOut or 0; i[#i + 1] = du.dpsIn or 0; b[#b + 1] = RC.RollingPeak(du)
    end
    RC._bl = { n = n, off = math.max(1, med(o)), def = math.max(1, med(i)), burst = math.max(1, med(b)) }
    return RC._bl
end
-- Mean grade of your last RECENT duels vs your baseline-window norm -> improvement / decline.
function RC.Trend()
    local arr = AllDuels()
    if #arr < RC.MINCAL then return nil end
    local rSum, rN = 0, math.min(RC.RECENT, #arr)
    local wSum, wN = 0, math.min(#arr, RC.WINDOW)
    for idx = 1, wN do
        local s = RC.Overall(arr[idx].du, RC.Dims(arr[idx].du))
        wSum = wSum + s
        if idx <= rN then rSum = rSum + s end
    end
    return rSum / rN, wSum / wN   -- recent-mean grade, window-mean (your norm)
end
-- Hard crowd control (stun/fear/disorient/immobilize) landed from one cc side table -> count + seconds.
-- Soft CC (snare/silence) carries uptime but isn't a caught-flat-footed event, so it's excluded here.
-- HARD CC = loss of character control only (Stun/Fear/Disorient; Fear & Disorient are mechanically stuns).
-- Immobilize (root) and Silence are NOT hard CC -- you keep control of your character -- so they read as
-- soft/other CC with a duration instead of inflating the "hard CC" headline and grade.
RC.HARD_CC = { Stun = true, Fear = true, Disorient = true }
function RC.HardCC(side)
    local n, secs = 0, 0
    if type(side) == "table" then
        for _, c in pairs(side) do
            if RC.HARD_CC[c.kind] then n = n + (c.count or 0); secs = secs + (c.uptime or 0) / 1000 end
        end
    end
    return n, secs
end
-- Lowest point either primary resource reached, as a fraction of its OWN peak this duel (self-
-- normalizing, so it needs no pool size). 1 = never dipped; ~0 = bottomed out. Drives Sustain.
function RC.ResourceFloor(du)
    local tl = du.timeline
    if type(tl) ~= "table" then return 1 end
    local function floorOf(key)
        local mx, mn = 0, nil
        for _, c in pairs(tl) do
            local v = c[key]
            -- 0 = a per-second bucket that was CREATED by a damage/heal event but had no resource sample
            -- that second (mag/stam default to 0), NOT a real "resource hit zero". Counting those zeros
            -- made every duel report "a resource bottomed out at 0:0X, 0% of peak" before the first tick.
            -- Only real samples (v > 0) define the floor.
            if v and v > 0 then if v > mx then mx = v end; if not mn or v < mn then mn = v end end
        end
        if mx <= 0 or not mn then return 1 end
        return mn / mx
    end
    return math.min(floorOf("mag"), floorOf("stam"))
end
-- Weighted debuff pressure: how well you kept your KEY debuffs (Breach/Vuln/Maim/Defile/status, from
-- RC.EFF + the isStatus flag) on the target, plus a bonus for hard CC landed. The "key" set is
-- discovered from what you actually applied this duel -- a player with no meaningful debuffs is scored
-- against the raw average at a penalty. Returns (score, hasKeyDebuffs, hardCCLanded).
function RC.PressureScore(du, dur)
    local keySum, keyW, rawSum, rawN = 0, 0, 0, 0
    for _, e in ipairs(du.debuffsOpp or {}) do
        local up = math.min(100, (e.uptime or 0) / 1000 / dur * 100)
        rawSum = rawSum + up; rawN = rawN + 1
        local _, w = RC.EffKind(e)
        if w then keySum = keySum + up * w; keyW = keyW + w end
    end
    local base
    if keyW > 0 then base = keySum / keyW
    elseif rawN > 0 then base = rawSum / rawN * 0.6
    else base = 0 end
    local ccN = RC.HardCC(du.cc and du.cc.onOpp)
    return math.max(0, math.min(100, base + math.min(12, ccN * 2))), keyW > 0, ccN
end
-- Active-defense tally from the clutch ledger for one side. Returns blocks, dodges, shielded-absorbed
-- damage, and the single ability you most often blocked/dodged (for a named insight).
function RC.Mitigation(side)
    local blk, dg, absorbed, topN, top = 0, 0, 0, 0, nil
    if type(side) == "table" then
        for _, r in pairs(side) do
            blk = blk + (r.block or 0); dg = dg + (r.dodge or 0); absorbed = absorbed + (r.absorbed or 0)
            local n = (r.block or 0) + (r.dodge or 0)
            if n > topN then topN, top = n, r end
        end
    end
    return blk, dg, absorbed, top, topN
end
-- Interrupts landed / taken (already captured as a CC "Interrupt" kind), summed for one cc side.
function RC.Interrupts(side)
    local n = 0
    if type(side) == "table" then for _, c in pairs(side) do if c.kind == "Interrupt" then n = n + (c.count or 0) end end end
    return n
end
-- Per-axis average score across your baseline window = your true "norm" for EACH strength. Median axes
-- already grade vs your median, but absolute axes (Sustain/Pressure/Weaving) need this to say "vs your
-- usual" honestly. Cached by duel count like the baseline.
RC._dn = nil
function RC.DimNorms()
    local arr = AllDuels()
    local n = #arr
    if RC._dn and RC._dn.n == n then return RC._dn.norm end
    local wN = math.min(n, RC.WINDOW)
    local sum, norm = {}, {}
    for idx = 1, wN do
        for _, dm in ipairs(RC.Dims(arr[idx].du)) do sum[dm.key] = (sum[dm.key] or 0) + dm.s end
    end
    for k, v in pairs(sum) do norm[k] = v / math.max(1, wN) end
    RC._dn = { n = n, norm = norm }
    return norm
end
-- The six duel "strengths" scored 0..100 (the radar axes + the report-card rows). Offense/Defense/
-- Burst grade vs YOUR baseline median (so 50 = your typical); Sustain/Pressure/Weaving are absolute.
-- Opponent raw stats are hidden by the ESO API, so everything is derived from observable results.
function RC.Dims(du)
    local bl = RC.Baseline()   -- your sliding-window median; 50 = your typical
    local dur = (du.durationS and du.durationS > 0) and du.durationS or 1
    local dims = {}
    local function clamp(x) return math.max(0, math.min(100, x)) end
    local function add(key, label, score, note) dims[#dims + 1] = { key = key, label = label, s = clamp(score), note = note } end

    -- Offense = the damage war first (out-damaging THIS opponent is trackable and telling -- build +
    -- rotation dominance), blended with your own median, plus the BAR WAR (Shoyru: being on the front
    -- bar the majority of the duel is a huge metric that tells the story of the fight).
    -- Log-scaled so 1:1 = 55, 2:1 = 85, 1:2 = 25; capped at 4:1 so a stomp doesn't hide everything else.
    local dOut, dInW = du.dpsOut or 0, du.dpsIn or 0
    local ratio = dOut / math.max(1, dInW)
    local dom = 55 + 30 * math.log(math.max(0.25, math.min(4, ratio))) / math.log(2)
    local selfN = dOut / bl.off * 50
    local meBars, opBars = RC.BarSplit(du.dealtTop), RC.BarSplit(du.takenTop)
    local offScore, barStr
    if meBars and opBars and meBars.frontShare and opBars.frontShare
        and (meBars.laTotal or 0) >= 10 and (opBars.laTotal or 0) >= 10 then
        local barScore = math.max(0, math.min(100, 50 + (meBars.frontShare - opBars.frontShare) * 100))
        offScore = dom * 0.55 + selfN * 0.35 + barScore * 0.10
        barStr = string.format("; front-bar %d%% vs their %d%%", math.floor(meBars.frontShare * 100 + 0.5), math.floor(opBars.frontShare * 100 + 0.5))
    else
        offScore = dom * 0.6 + selfN * 0.4
        barStr = ""
    end
    add("offense", "Offense", offScore,
        string.format("%s DPS out vs %s in \226\128\148 %.1fx the damage war; %s vs your median%s.",
            Abbrev(dOut), Abbrev(dInW), ratio, RC.PctVs(dOut, bl.off), barStr))

    -- Defense = duel-relative first (Shoyru's call): did you ANSWER their burst, defend their actual
    -- threats, and recover fast when hurt -- then damage taken vs your own norm. A duel where your
    -- offense dominated and you were never threatened isn't punished for low block counts.
    local dInD = du.dpsIn or 0
    local ccMe, ccMeSecs = RC.HardCC(du.cc and du.cc.onMe)
    local blk, dg, absorbed = RC.Mitigation(du.clutch and du.clutch.onMe)
    -- 1) Burst answer: active defense (blocks/dodges/ward soaks) inside their hardest 3s window.
    local peakInVal, peakInAt = RC.PeakIn(du)
    local defInPeak = 0
    if du.clutch and type(du.clutch.onMe) == "table" then
        for _, r in pairs(du.clutch.onMe) do if r.times then for _, t in ipairs(r.times) do
            local ts = t / 1000
            if ts >= peakInAt and ts <= peakInAt + 3 then defInPeak = defInPeak + 1 end
        end end end
    end
    local burstAns = (peakInVal < 12000) and 1 or math.min(1, defInPeak / 2)
    -- 2) Threat answer: blocks/dodges specifically on their TOP-3 DIRECT-damage abilities. DoT rows
    -- are excluded -- a Burning Embers tick can't be blocked or dodged, so judging saves against a
    -- DoT-heavy opponent's raw top-3 unfairly zeroed this term (found via demo grading audit).
    local threatSaves = 0
    do
        local topIds, k = {}, 0
        for _, a in ipairs(du.takenTop or {}) do
            if not a.dot then k = k + 1; topIds[a.id or -1] = true; if k >= 3 then break end end
        end
        if du.clutch and type(du.clutch.onMe) == "table" then
            for id, r in pairs(du.clutch.onMe) do if topIds[id] then threatSaves = threatSaves + (r.block or 0) + (r.dodge or 0) end end
        end
    end
    -- Neutral when they never applied real pressure -- no threats to answer isn't a defensive failure.
    local pressured = (du.dmgTaken or 0) >= 15000 and dInD >= 1500
    local threatCred = pressured and math.min(1, threatSaves / 4) or 0.7
    -- 3) Recovery speed: back to 80% HP within 4s of a sub-50% dip = full; 12s+ (or never) = zero.
    local recSecs, hadHP = RC.Recovery(du)
    local recCred = (not hadHP) and 0.65 or (recSecs == nil and 1) or math.max(0, math.min(1, (12 - recSecs) / 8))
    -- 4) Mitigation-buff discipline (Shoyru): Major Resolve/Ward uptime, with a small Minor bonus.
    -- Player-controlled, coachable, captured retroactively via buff intervals. A build where none of
    -- these ever appear stays neutral -- can't tell "didn't slot it" from "let it drop".
    local mitCred, mitPct
    do
        local maj, minr, seen = 0, 0, false
        for _, e in ipairs(du.buffsMe or {}) do
            if e.id == RC.ID_RESOLVE or e.id == RC.ID_WARD_MAJ then maj = math.max(maj, (e.uptime or 0) / 1000 / dur); seen = true
            elseif e.id == RC.ID_RESOLVE_MIN or e.id == RC.ID_WARD_MIN then minr = math.max(minr, (e.uptime or 0) / 1000 / dur); seen = true end
        end
        if seen then
            mitPct = math.min(1, maj)
            -- 90%+ Major = full credit; Minor counts at half weight (it's ~half the resist).
            mitCred = math.min(1, (mitPct + 0.5 * math.min(1, minr)) / 0.9)
        else
            mitCred = 0.6
        end
    end
    -- 5) Your own norm: damage taken vs your median (secondary, per the grading philosophy).
    local selfCred = (dInD > 0) and math.min(1, bl.def / dInD * 0.5) or 1
    local defScore = 100 * (0.25 * burstAns + 0.15 * threatCred + 0.20 * recCred + 0.15 * mitCred + 0.25 * selfCred) - math.min(18, ccMe * 3)
    add("defense", "Defense", defScore,
        string.format("%s%s; %s DPS taken (%s vs your median)%s%s%s.",
            peakInVal >= 12000 and (defInPeak > 0 and string.format("Answered their hardest 3s with %d defenses", defInPeak) or "Their hardest 3s went unanswered")
                or "Never seriously threatened",
            threatSaves > 0 and string.format("; %d saves on their top threats", threatSaves) or "",
            Abbrev(dInD), RC.PctVs(dInD, bl.def),
            mitPct and string.format("; Major Resolve up %d%%", math.floor(mitPct * 100 + 0.5)) or "",
            hadHP and (recSecs == nil and "; never dropped below half HP" or string.format("; back to 80%% HP in %ds after the deep dip", math.floor(recSecs))) or "",
            ccMe > 0 and (ccMeSecs >= 0.5 and string.format("; hard-CC'd %dx (%.0fs)", ccMe, ccMeSecs) or string.format("; hard-CC'd %dx", ccMe)) or ""))

    -- Sustain = effective survival (50) + heal discipline / low overheal (20) + resource management (30).
    -- Effective survival folds SHIELD absorb into both sides of the ratio, so a ward build that ate the
    -- damage with shields (not heals) isn't under-rated. Running a pool to the floor is a first-class term.
    local taken, healed, over = du.dmgTaken or 0, du.healReceived or 0, du.overHeal or 0
    -- On records captured from v1.0.7 on, dmgTaken ALREADY includes ward-absorbed damage (du.dmgShieldedIn
    -- is present, even if 0), so threat = taken. Older records store health-only dmgTaken, so add absorbed.
    -- absorbed stays in the sEff numerator either way -- surviving via a shield is effective survival.
    local threat = taken + ((du.dmgShieldedIn ~= nil) and 0 or absorbed)
    local sEff = threat > 0 and math.min(1, (healed + absorbed) / threat) or (healed > 0 and 1 or 0.5)
    local overpct = (healed + over) > 0 and over / (healed + over) or 0
    local floor = RC.ResourceFloor(du)                 -- 1 = never dipped, ~0 = bottomed out
    local resHealth = math.min(1, floor / 0.55)        -- need >=55% of your peak for full credit (was 35% -- too easy, it floored Sustain ~74 even on a loss)
    add("sustain", "Sustain", sEff * 50 + (1 - overpct) * 20 + resHealth * 30,
        string.format("Handled %s of %s incoming%s, %d%% overheal; resources floored at %d%%.",
            Abbrev(healed + absorbed), Abbrev(threat), absorbed > 0 and string.format(" (%s shielded)", Abbrev(absorbed)) or "",
            math.floor(overpct * 100 + 0.5), math.floor(floor * 100 + 0.5)))

    -- Burst = your peak 3s window vs your SUSTAINED output, judged against what your build can spike.
    -- A DoT build's kill window is ~1.5x its tick pressure; a direct build should double up. Grading raw
    -- peak vs a global bar punished DoT builds and rewarded camping the whole fight for one ult window
    -- (Shoyru's call). Excess spike is capped -- past 2x your target, more one-shot buys nothing.
    local peak = RC.RollingPeak(du)
    local spike = peak / math.max(1, (du.dpsOut or 0) * 3)
    local dotOutTot, dealtT = 0, 0
    for _, a in ipairs(du.dealtTop or {}) do dealtT = dealtT + (a.total or 0); if a.dot then dotOutTot = dotOutTot + (a.total or 0) end end
    local dotShare = dealtT > 0 and dotOutTot / dealtT or 0
    local target = 2.0 - 0.6 * math.min(1, dotShare)
    -- Rescaled (was `30 + 50*(...)` -- a +30 freebie that floored Burst ~66 and maxed it too easily):
    -- anchored so a spike of 1x (peak == your sustained, i.e. no real burst) = 0, MEETING your build's
    -- target = 50 (an average burst), and 2x your target = an elite 100. Discriminates instead of inflating.
    local bScore = (spike <= target)
        and (50 * (spike - 1) / math.max(0.4, target - 1))
        or  (50 + 50 * (spike - target) / math.max(0.4, target))
    add("burst", "Burst", bScore,
        string.format("Peak %s in 3s = %.1fx your sustained (target %.1fx for a %d%% DoT build).",
            Abbrev(peak), spike, target, math.floor(dotShare * 100 + 0.5)))

    local pres, hasKey, ccOpp = RC.PressureScore(du, dur)
    add("pressure", "Pressure", pres,
        hasKey and string.format("Key debuffs averaged %d%% uptime on your target%s.", math.floor(pres - math.min(12, ccOpp * 2) + 0.5),
                ccOpp > 0 and string.format("; %d hard CC landed", ccOpp) or "")
            or (#(du.debuffsOpp or {}) > 0 and "No key debuffs (Breach/Vuln/Maim/status) on your target \226\128\148 only incidental effects."
            or "No debuffs tracked on your target."))

    -- Weaving = COVERAGE first (are you weaving at all -- a LA slotted into every cast), timing as a
    -- minor bonus, plus the light-attack WAR: more landed LAs than the opponent = more time on target
    -- with a better rotation. "100ms vs 130ms" is trivia next to "130 LAs to their 96" (Shoyru's call).
    local wv = du.weave
    local laOut, laIn = RC.LAHits(du.dealtTop), RC.LAHits(du.takenTop)
    if wv and (wv.delayCount or 0) > 0 then
        -- Prefer TRUE coverage rebuilt from the per-cast event log: records captured before the
        -- GCD-dedupe fix stored ~4-5 status events per real cast, flattening delayCount/casts to
        -- ~33% no matter how the player wove. One cast per >=700ms window; weaved if any of its
        -- status events carried a delay. (Verified vs Shoyru's real 22 duels: true coverage 74-100%.)
        local casts, weavedN, avgDelay
        if type(wv.events) == "table" and #wv.events > 1 then
            local lastT, cw, dSum, dN = nil, false, 0, 0
            casts, weavedN = 0, 0
            for _, e in ipairs(wv.events) do
                if not lastT or ((e.t or 0) - lastT) >= 700 then
                    if lastT and cw then weavedN = weavedN + 1 end
                    casts = casts + 1; lastT = e.t or 0; cw = false
                end
                if (e.d or 0) > 0 then
                    if not cw then dSum = dSum + e.d; dN = dN + 1 end
                    cw = true
                end
            end
            if cw then weavedN = weavedN + 1 end
            avgDelay = dN > 0 and dSum / dN or (wv.delaySum / wv.delayCount)
        else
            casts, weavedN, avgDelay = (wv.casts or wv.delayCount), wv.delayCount, wv.delaySum / wv.delayCount
        end
        local ratioW = (casts > 0) and math.min(1, weavedN / casts) or 1
        local score = ratioW * 70 + (avgDelay <= 120 and 15 or avgDelay <= 200 and 8 or 0)
        if laOut > 0 and laIn > 0 then
            score = score + (laOut >= laIn * 1.2 and 15 or laOut >= laIn and 8 or 0)
        else
            score = score + 8   -- LA war unknowable (no LA rows one side): neutral credit
        end
        add("weaving", "Weaving", score,
            string.format("Wove on %d%% of %d casts (avg %dms)%s.",
                math.floor(ratioW * 100 + 0.5), casts, math.floor(avgDelay),
                (laOut > 0 and laIn > 0) and string.format("; LA war %d\226\128\147%d %s", laOut, laIn,
                    laOut >= laIn and "in your favor" or "against you") or ""))
    else
        add("weaving", "Weaving", 50, "No weave data captured.")
    end
    return dims
end
-- Overall = 30% outcome + 70% the mean of the six strengths (outcome isn't a "strength" axis).
function RC.Overall(du, dims)
    local sum, n = 0, 0
    for _, d in ipairs(dims) do sum = sum + d.s; n = n + 1 end
    -- Outcome weight cut 0.30 -> 0.15: the dimensions ALREADY track the exchange (Offense = damage war,
    -- Defense = damage taken), so a heavy raw-outcome term double-counted winning and made the grade
    -- outcome-driven (a DK who played well but lost still landed ~C). 15% keeps winning meaningful
    -- without letting it dominate a well-played loss. The 6 dimensions are averaged EQUALLY.
    local outcome = (du.result == "win" and 100) or (du.result == "draw" and 55) or 15
    return 0.15 * outcome + 0.85 * (n > 0 and sum / n or 0)
end
-- Assign the forward-declared DuelGrade: one duel's overall report-card grade (letter, score, colour).
function DuelGrade(du)
    if RC.Calibrating() then return nil end   -- no grades until the Report Card unlocks
    local score = RC.Overall(du, RC.Dims(du))
    local gl = GradeLetter(score)
    return gl, score, RC.Color(gl)
end
-- Your NORM grade = mean grade across your baseline window (nil while calibrating).
function RC.AvgGrade()
    if RC.Calibrating() then return nil, RC.DuelCount() end
    local arr = AllDuels()
    local wN = math.min(#arr, RC.WINDOW)
    if wN == 0 then return nil, 0 end
    local sum = 0
    for idx = 1, wN do sum = sum + RC.Overall(arr[idx].du, RC.Dims(arr[idx].du)) end
    return sum / wN, #arr
end
-- A text progress bar (filled block run + a dim remainder), coloured by the row's grade.
function RC.Bar(score, color, width)
    width = width or 12
    local filled = math.max(0, math.min(width, math.floor(score / 100 * width + 0.5)))
    return string.format("|c%s%s|r|c33383f%s|r", Hex(color), string.rep("\226\150\136", filled), string.rep("\226\150\136", width - filled))
end
-- ===================================================================================================
-- RC.Ctx(du) -- the ANALYSIS CONTEXT. One pure pass that derives every metric the rule registry reads:
-- damage composition + type mix, opponent model, fight-arc windows + lead curve, resource cliffs, buff/
-- debuff gaps vs incoming damage, CC->burst timing, active-defense timing, weave/heal/crit, cross-duel.
-- Rules read ONLY from this (no rule touches du directly), so a rule is a pure ctx->severity/text fn and
-- the whole catalog is testable off a single crafted ctx. Degrades gracefully on old records (missing
-- dtype/times => the dependent metric is nil and its rules simply don't fire). NOT cached on du (that is a
-- SavedVariables table -- caching would pollute SV and go stale); RC.Insights builds it once per call.
-- ---------------------------------------------------------------------------------------------------
-- Damage-type classification. Referenced BY NAME so it matches the demo's DemoPaintTypes: real ESO ints
-- in-game, stable auto-stub ints under the test env. magic/phys sets drive the ranged-vs-melee opp read.
RC.DTYPE_NAME = {
    [DAMAGE_TYPE_PHYSICAL] = "Physical", [DAMAGE_TYPE_FIRE] = "Flame", [DAMAGE_TYPE_SHOCK] = "Shock",
    [DAMAGE_TYPE_COLD] = "Frost", [DAMAGE_TYPE_MAGIC] = "Magic", [DAMAGE_TYPE_POISON] = "Poison",
    [DAMAGE_TYPE_DISEASE] = "Disease", [DAMAGE_TYPE_BLEED] = "Bleed", [DAMAGE_TYPE_OBLIVION] = "Oblivion",
}
RC.DTYPE_MAGIC = { [DAMAGE_TYPE_FIRE] = true, [DAMAGE_TYPE_SHOCK] = true, [DAMAGE_TYPE_COLD] = true, [DAMAGE_TYPE_MAGIC] = true }
RC.DTYPE_PHYS  = { [DAMAGE_TYPE_PHYSICAL] = true, [DAMAGE_TYPE_BLEED] = true, [DAMAGE_TYPE_POISON] = true, [DAMAGE_TYPE_DISEASE] = true }
RC.DTYPE_WEAPON = { [DAMAGE_TYPE_SHOCK] = "Lightning Staff", [DAMAGE_TYPE_COLD] = "Ice Staff", [DAMAGE_TYPE_FIRE] = "Inferno Staff" }
-- Common effect ids used by the correlational rules (Major Resolve / Sorcery / Brutality / Defile).
RC.ID_RESOLVE, RC.ID_SORCERY, RC.ID_BRUTALITY = 61694, 61687, 61665
RC.ID_DEFILE_MAJ, RC.ID_DEFILE_MIN = 61727, 61726
RC.ID_RESOLVE_MIN, RC.ID_WARD_MAJ, RC.ID_WARD_MIN = 61693, 61696, 61695
function RC.IsLightAttack(a)
    local n = a and a.name
    return type(n) == "string" and (n:find("Light Attack") ~= nil)
end
function RC.IsHeavyAttack(a)
    local n = a and a.name
    return type(n) == "string" and (n:find("Heavy Attack") ~= nil)
end
-- Light-attack HIT counts for one direction (the rotation war in raw counts). The ability tables are
-- stored uncapped at commit, so this backfills for every already-recorded duel. Dodged LAs leave no
-- damage event (slight undercount); blocked LAs still land damage, so they're in.
function RC.LAHits(rows)
    local n = 0
    for _, a in ipairs(rows or {}) do if RC.IsLightAttack(a) then n = n + (a.hits or 0) end end
    return n
end
-- Front/back-bar inference from LA/HA weapon names (Shoyru's guidelines, 2026-07-07): dual wield,
-- 2H, bow, lightning and inferno staves are front-bar weapons; sword-and-board, ice staff and resto
-- are classic back-bars. We never see bar-swap events for the opponent, but every landed Light/Heavy
-- Attack names its weapon -- so the LA distribution across weapon types is the time-on-bar proxy.
RC.BAR_FRONT = { ["Dual Wield"] = true, ["Two Handed"] = true, ["Bow"] = true,
    ["Lightning"] = true, ["Inferno"] = true, ["Flame"] = true, ["Fire"] = true }
RC.BAR_BACK = { ["One Handed"] = true, ["Ice"] = true, ["Restoration"] = true, ["Frost"] = true }
-- Split one side's ability rows into front/back bars. Returns nil (no weapon attacks seen) or
-- { front = {w,la,ha}, back = {w,la,ha}|nil, frontShare, laTotal }.
function RC.BarSplit(rows)
    local types = {}
    for _, a in ipairs(rows or {}) do
        local w = a.name and (a.name:match("^Light Attack %((.+)%)$") or a.name:match("^Heavy Attack %((.+)%)$"))
        if w then
            local tt = types[w]
            if not tt then tt = { w = w, la = 0, ha = 0 }; types[w] = tt end
            if a.name:find("^Light") then tt.la = tt.la + (a.hits or 0) else tt.ha = tt.ha + (a.hits or 0) end
        end
    end
    local arr = {}
    for _, tt in pairs(types) do arr[#arr + 1] = tt end
    if #arr == 0 then return nil end
    table.sort(arr, function(a, b) return a.la + a.ha > b.la + b.ha end)
    local front, back
    for _, e in ipairs(arr) do
        if RC.BAR_FRONT[e.w] and not front then front = e
        elseif RC.BAR_BACK[e.w] and not back then back = e end
    end
    -- The weapon TABLE decides bar identity; LA share only measures TIME on it. A defensive player
    -- pushed onto their ice backbar still mains DW/2H -- high back-bar LA share means they were
    -- pushed off their kill bar, not that ice is their main hand (Shoyru's correction 2026-07-07).
    -- Only when NO table-front weapon exists at all (S&B + ice double-back, bash builds) does
    -- activity decide: the busier weapon is the practical front bar.
    if not front then front = arr[1] end
    if not back then for _, e in ipairs(arr) do if e ~= front then back = e; break end end end
    local laTot = 0
    for _, e in ipairs(arr) do laTot = laTot + e.la end
    return { front = front, back = back, frontShare = laTot > 0 and front.la / laTot or nil, laTotal = laTot }
end
-- Telegraphed wind-ups: blocking THESE is a read. Blocking anything else in a melee duel is just
-- block-weaving -- foundational habit both players run irrespective of what the other is doing
-- (Shoyru's call; the old raw block-after-cast correlation read 91-100% on pure habit blockers).
RC.WINDUPS = {
    ["Dizzying Swing"] = true, ["Uppercut"] = true, ["Wrecking Blow"] = true,
    ["Snipe"] = true, ["Lethal Arrow"] = true, ["Focused Aim"] = true, ["Dark Flare"] = true,
    ["Soul Assault"] = true, ["Radiant Destruction"] = true, ["Radiant Glory"] = true,
    ["Radiant Oppression"] = true, ["Crystal Weapon"] = false, -- instant; listed to document the decision
}
-- ACTIVE shields the player casts and times (cost + a decision), vs passive procs (Concentrated
-- Barrier while blocking, Calculated Defense on any sorc cast, Tri Focus ice heavies) that fire from
-- natural rotation -- timing coaching only makes sense for the former.
RC.ACTIVE_WARDS = {
    ["Hardened Ward"] = true, ["Empowered Ward"] = true, ["Regenerative Ward"] = true,
    ["Conjured Ward"] = true, ["Harness Magicka"] = true, ["Dampen Magic"] = true, ["Annulment"] = true,
    ["Bone Shield"] = true, ["Spiked Bone Shield"] = true, ["Beckoning Armor"] = true,
    ["Igneous Shield"] = true, ["Fragmented Shield"] = true, ["Obsidian Shield"] = true,
    ["Healing Ward"] = true, ["Ward Ally"] = true, ["Steadfast Ward"] = true,
    ["Barrier"] = true, ["Reviving Barrier"] = true, ["Replenishing Barrier"] = true,
    ["Arctic Blast"] = false, -- heal, not a ward; documents the boundary
}
-- ---- Tier 12: CLASS-MATCHUP KNOWLEDGE (curated, from expert Q&A) --------------------------------
-- Keyed by the real ESO class id so it works headless (GetClassName is mocked in tests). Each pool is a
-- few condensed reads the DATA cannot produce; the card rotates through them for variety. Necro (5) and
-- Arcanist (117) are intentionally absent until their Q&A is filled -- ClassTip returns nil for those.
RC.CLASS_TIPS = {
    [1] = {   -- Dragonknight
        "Keep an eye on the Incinerate + Whip + Fossilize timing \226\128\148 that's their burst, and they may double-cast Fossilize to land the Whip. Rolling the Fossilize gets punished by a Dawnbreaker roll-catch, so often the safer play is to take the stun, break fast, and BLOCK rather than roll.",
        "Don't force offense while their stun is up \226\128\148 Fossilize into Molten Whip is their whole kill. Their opening comes when they're front-bar and off their Hearth heal.",
        "You won't burst a DK through their backbar Hearth reset \226\128\148 take your own reset and re-apply buffs instead of parsing into it.",
    },
    [2] = {   -- Sorcerer
        "Track Haunting Curse \226\128\148 they line up Streak/CC to the curse pop. Break the streak stun and BLOCK; a trailing Dawnbreaker punishes the roll.",
        "Don't get greedy at low health \226\128\148 modern Sorcs turn-and-burn or Streak away. Your kill window is when their Streak goes defensive and you can chase it down.",
        "Bash their Dark Deal after a streak to cut the sustain. Your openings are in the gaps between curse procs, on CC immunity.",
    },
    [3] = {   -- Nightblade
        "Two tells: the Off Balance debuff (melee NBs build their whole combo around it) and Incap (+20% damage taken for ~8s). Don't get medium-weave stunned during Off Balance \226\128\148 block-weave or make space.",
        "Fear is unblockable \226\128\148 break free fast and ROLL it. Your window is right after you take a stun (CC immunity), especially if they misplayed and spent their stun.",
        "Don't force offense while Off Balance is on you or Incap is up \226\128\148 they bait a turn-and-burn that can one-shot.",
    },
    [4] = {   -- Warden
        "The burst is the 2nd shalk (Deep Fissure) \226\128\148 it's directional, so roll to the side or through them. The charm AOE (scribed Contingency/Healing Soul) stuns AND heals them; move out of its range.",
        "If they're playing pure defensive you can deliberately take the charm-stun \226\128\148 often they only cast it to heal, which costs them their own offense window.",
        "Polar Winds and Crystalline Slabs are expensive \226\128\148 baiting them out is a win. Slabs is also a stun; take it if you can afford it, else block.",
    },
    [5] = {   -- Necromancer (light read -- Necro telegraphs little beyond Blastbones)
        "Blastbones is the whole read \226\128\148 track it and don't overreach while it's up, because you can be stunned into the explosion. You can't roll Blastbones, only BLOCK it.",
        "Respect a Necro cycling Blastbones every couple of abilities \226\128\148 the BB threat is constant, even through their defensive rotation, so don't overreach into it.",
        "Your openings come when they drop their sustain \226\128\148 Coil, Spirit Guardian, or Tether. Forcing offense before that just feeds them.",
    },
    [6] = {   -- Templar
        "Purifying Light is their burst (both morphs) \226\128\148 like Curse, a stun (Javelin/Toppling) is timed to the pop. Break free and BLOCK; rolling does little vs Jabs or the execute beam. Stay above execute range.",
        "Respect the Ritual/cleanse reset \226\128\148 parsing into it is pointless. Win the resource war: bait a ~4500-mag cleanse with a free debuff recast.",
        "Commit when they're front-bar and not minding their Ritual. Give yourself space so they can't stack stored damage into Purifying Light.",
    },
}
-- One curated class read for the opponent's class (nil if we have no notes for it). `seed` rotates the
-- pool so consecutive duels vs the same class don't repeat the same line.
function RC.ClassTip(oppClassId, seed)
    local pool = oppClassId and RC.CLASS_TIPS[oppClassId]
    if not pool or #pool == 0 then return nil end
    local i = ((seed or 0) % #pool) + 1
    return pool[i]
end

-- ---- Self-play (mirror-match) lens ---------------------------------------
-- When you duel your OWN class the normal class read is wrong twice over: it tells you tells you
-- already know, and it ignores that every stat is now directly comparable (same kit both sides). So
-- the read FLIPS from descriptive ("their kit") to comparative ("you vs them on the same tools") + a
-- curated principle for what actually decides that mirror. Fires only when myClassId == oppClassId.
-- One curated "what wins the mirror" line per class (the concept, not a gear/skill prescription).
RC.MIRROR_TIPS = {
    [1] = {   -- Dragonknight
        "Same DoTs, same Whip, same Fossilize \226\128\148 the mirror is won on who lands the delayed stun first and who wastes theirs. Break free faster and your Whip lands in their CC-immunity gap, not the reverse.",
        "Two Hearth resets means neither of you bursts the other off a full backbar \226\128\148 the fight is decided front-bar, so whoever holds pressure longer without panicking into the heal takes it.",
    },
    [2] = {   -- Sorcerer
        "You both have Curse and the Streak escape. Whoever times burst to their OWN curse pop \226\128\148 instead of reacting to the other's \226\128\148 dictates the fight; don't chase the Streak, punish the landing.",
        "Mirror Sorc is a sustain race as much as a burst race: bait the Dark Deal / Streak spend, then take the window while their magicka is recovering.",
    },
    [3] = {   -- Nightblade
        "Off Balance decides it \226\128\148 whoever imposes the medium-weave stun first sets the tempo and whoever eats it is on the back foot all fight. The mirror is who commits their stun cleaner, not who has more tricks.",
        "Both of you can cloak and both can turn-and-burn \226\128\148 so nobody gets a free reset. Don't waste your Incap window chasing their cloak; make them respect yours.",
    },
    [4] = {   -- Warden
        "Same shalks, same Polar Winds \226\128\148 the mirror is a patience game. Bait the expensive defensives, read the 2nd-shalk direction, and whoever panics into their sustain first loses the trade.",
        "Neither of you cracks the other's Polar/Slabs by force. Win it on tempo: cheap recasts to drain their expensive buttons, then burst the gap.",
    },
    [5] = {   -- Necromancer
        "You both cycle Blastbones and neither of you can roll it. The mirror is respecting BB windows while forcing THEIRS \226\128\148 whoever overreaches into the other's explosion first hands over the fight.",
        "Mirror Necro rewards patience over their sustain (Coil / Spirit Guardian / Tether): don't spend into it, wait for the drop, then commit.",
    },
    [6] = {   -- Templar
        "Two Purifying Lights, two Rituals \226\128\148 whoever stacks and pops PL cleanly while the other is committed wins. Don't parse into their cleanse; bait it, then land your pop on the recast.",
        "Mirror Templar is a resource war on the cleanse: bait the ~4500-mag Ritual/cleanse with a free recast a couple of times and their sustain cracks before yours.",
    },
}
-- Pick the single most decisive DIRECTLY-COMPARABLE signal (same kit => these deltas are apples-to-
-- apples in a way they never are cross-class): bar war, then damage race, then the light-attack war.
function RC.MirrorVerdict(c)
    local me, op = c.bars and c.bars.me, c.bars and c.bars.opp
    if me and op and me.frontShare and op.frontShare and (me.laTotal or 0) >= 15 and (op.laTotal or 0) >= 15 then
        local d = me.frontShare - op.frontShare
        if d >= 0.20 then return string.format("You owned the pressure bar \226\128\148 %d%% front-bar time to their %d%%.", math.floor(me.frontShare * 100 + 0.5), math.floor(op.frontShare * 100 + 0.5)) end
        if d <= -0.20 then return string.format("They out-camped the kill bar \226\128\148 %d%% front-bar time to your %d%%.", math.floor(op.frontShare * 100 + 0.5), math.floor(me.frontShare * 100 + 0.5)) end
    end
    local dOut, dIn = c.dealtTot or 0, c.takenTot or 0
    if dOut > 0 and dIn > 0 then
        local r = dOut / dIn
        if r >= 1.20 then return string.format("You won the damage race, %s dealt to %s taken.", Abbrev(dOut), Abbrev(dIn)) end
        if r <= 0.83 then return string.format("They won the damage race, %s taken to %s dealt.", Abbrev(dIn), Abbrev(dOut)) end
    end
    if c.la and ((c.la.out or 0) + (c.la.inn or 0)) >= 20 then
        local d = (c.la.out or 0) - (c.la.inn or 0)
        if d >= 6 then return string.format("You out-wove them %d\226\128\147%d light attacks \226\128\148 more time on target with the same tools.", c.la.out, c.la.inn) end
        if d <= -6 then return string.format("They out-wove you %d\226\128\147%d light attacks \226\128\148 more uptime on the same tools.", c.la.inn, c.la.out) end
    end
    return "You traded evenly on the shared tools \226\128\148 this one came down to execution in the moment, not the matchup."
end
-- The mirror card: comparative verdict (data) + the curated mirror principle (concept). Returns a
-- single string for the "Matchup notes" bullet, or nil when it isn't a same-class fight.
function RC.MirrorRead(du)
    local cid = du.myClassId
    if not (cid and cid ~= 0 and du.oppClassId == cid) then return nil end
    local cls = RC.CLASS_NAMES[cid] or "your class"
    local verdict = RC.MirrorVerdict(RC.Ctx(du))
    local pool = RC.MIRROR_TIPS[cid]
    local principle = pool and #pool > 0 and pool[(math.floor(du.date or 0) % #pool) + 1] or nil
    return string.format("Mirror match, %s vs %s. %s%s", cls, cls, verdict, principle and (" " .. principle) or "")
end
-- ---- Data-verified matchup read (Shoyru): don't just SAY what the class likes to do -- check the
-- duel record for whether THIS opponent actually ran the textbook lineup, whether it landed on you,
-- and whether you answered it. Each class carries a LIST of combo ROUTES (a class has more than one
-- way to run its game -- Shoyru): `anchors` start a window (matched in the CC ledger, debuff
-- applications on you, or incoming hits), `payload` is the expected follow-up damage inside `win` ms.
-- The scan runs EVERY route and the verdict is written about the one this player actually plays.
-- Names are matched exactly (morphs listed out).
RC.CLASS_COMBOS = {
    [1] = {   -- Dragonknight
        { combo = "the Fossilize burst", tell = "Fossilize", win = 4000,
            anchors = { ["Fossilize"] = true, ["Petrify"] = true, ["Shattering Rocks"] = true },
            payload = { ["Molten Whip"] = true, ["Flame Lash"] = true, ["Power Lash"] = true, ["Lava Whip"] = true,
                ["Incinerate"] = true, ["Heart of Flame"] = true, ["Ferocious Leap"] = true, ["Dragon Leap"] = true, ["Take Flight"] = true } },
        { combo = "the Leap opener", tell = "Ferocious Leap", win = 3500,
            anchors = { ["Ferocious Leap"] = true, ["Dragon Leap"] = true, ["Take Flight"] = true },
            payload = { ["Molten Whip"] = true, ["Flame Lash"] = true, ["Power Lash"] = true, ["Lava Whip"] = true,
                ["Incinerate"] = true, ["Heart of Flame"] = true, ["Fossilize"] = true, ["Petrify"] = true } },
    },
    [2] = {   -- Sorcerer (lineup per Shoyru 2026-07-07: Curse -> Streak timed to the pop -> Frags /
        -- Bound Armaments dump, Dawnbreaker or Overload closing. Streak = anchor AND payload.)
        { combo = "the Curse-Streak window", tell = "Haunting Curse", win = 7000,
            anchors = { ["Haunting Curse"] = true, ["Daedric Prey"] = true, ["Velocious Curse"] = true,
                ["Daedric Curse"] = true, ["Streak"] = true, ["Rune Cage"] = true, ["Rune Prison"] = true },
            payload = { ["Crystal Fragments"] = true, ["Crystal Weapon"] = true, ["Crystal Shard"] = true,
                ["Mages' Wrath"] = true, ["Endless Fury"] = true, ["Mages' Fury"] = true, ["Streak"] = true,
                ["Bound Armaments"] = true, ["Overload"] = true, ["Energy Overload"] = true, ["Power Overload"] = true } },
    },
    [3] = {   -- Nightblade
        { combo = "the Incap opener", tell = "Incapacitating Strike", win = 4000,
            -- Soul Tether = the off-meta pull-stun (@WannaBuyMyDawg runs it -- Shoyru).
            anchors = { ["Incapacitating Strike"] = true, ["Soul Harvest"] = true, ["Death Stroke"] = true,
                ["Soul Tether"] = true, ["Soul Shred"] = true },
            payload = { ["Surprise Attack"] = true, ["Concealed Weapon"] = true, ["Veiled Strike"] = true, ["Impale"] = true,
                ["Killer's Blade"] = true, ["Spectral Bow"] = true, ["Merciless Resolve"] = true, ["Assassin's Will"] = true } },
        { combo = "the bow-proc stack", tell = "Merciless Resolve", win = 3500,
            anchors = { ["Merciless Resolve"] = true, ["Assassin's Will"] = true, ["Spectral Bow"] = true,
                ["Assassin's Scourge"] = true, ["Relentless Focus"] = true, ["Grim Focus"] = true },
            payload = { ["Surprise Attack"] = true, ["Concealed Weapon"] = true, ["Veiled Strike"] = true, ["Impale"] = true,
                ["Killer's Blade"] = true, ["Ambush"] = true, ["Incapacitating Strike"] = true, ["Soul Harvest"] = true } },
    },
    [4] = {   -- Warden
        { combo = "the shalk detonation", tell = "Deep Fissure", win = 3000,
            anchors = { ["Deep Fissure"] = true, ["Subterranean Assault"] = true, ["Scorch"] = true,
                ["Arctic Blast"] = true },
            payload = { ["Cutting Dive"] = true, ["Screaming Cliff Racer"] = true, ["Dive"] = true,
                ["Whirling Blades"] = true, ["Fetcher Infection"] = true, ["Growing Swarm"] = true, ["Crushing Swipe"] = true } },
    },
    [5] = {   -- Necromancer
        { combo = "the Blastbones lineup", tell = "Blastbones", win = 3500,
            anchors = { ["Blighted Blastbones"] = true, ["Stalking Blast Bones"] = true, ["Stalking Blastbones"] = true,
                ["Blastbones"] = true, ["Grave Lord's Sacrifice"] = true },
            payload = { ["Venom Skull"] = true, ["Ricochet Skull"] = true, ["Flame Skull"] = true,
                ["Glacial Colossus"] = true, ["Pestilent Colossus"] = true, ["Frozen Colossus"] = true } },
    },
    [6] = {   -- Templar
        -- Purifying Light / Power of the Light is the Templar setup (a debuff on you -> caught via
        -- debuffsMe intervals), with the stun timed to the pop -- same shape as Sorc's Curse.
        { combo = "the Purifying Light pop", tell = "Purifying Light", win = 7000,
            anchors = { ["Purifying Light"] = true, ["Power of the Light"] = true, ["Backlash"] = true },
            payload = { ["Puncturing Sweep"] = true, ["Biting Jabs"] = true, ["Puncturing Strikes"] = true,
                ["Radiant Oppression"] = true, ["Radiant Glory"] = true, ["Radiant Destruction"] = true,
                ["Toppling Charge"] = true, ["Aurora Javelin"] = true, ["Binding Javelin"] = true, ["Piercing Javelin"] = true } },
        { combo = "the Javelin-into-burst", tell = "Toppling Charge", win = 4000,
            anchors = { ["Toppling Charge"] = true, ["Aurora Javelin"] = true, ["Binding Javelin"] = true,
                ["Piercing Javelin"] = true, ["Focused Charge"] = true, ["Explosive Charge"] = true },
            payload = { ["Puncturing Sweep"] = true, ["Biting Jabs"] = true, ["Puncturing Strikes"] = true,
                ["Radiant Oppression"] = true, ["Radiant Glory"] = true, ["Radiant Destruction"] = true } },
    },
}
RC.CLASS_NAMES = { [1] = "Dragonknight", [2] = "Sorcerer", [3] = "Nightblade", [4] = "Warden",
    [5] = "Necromancer", [6] = "Templar", [117] = "Arcanist" }
-- Abilities EVERY class can slot (Shoyru) -- counted as combo payload for every class signature
-- rather than duplicated per class. Two groups: the common non-class ults (Onslaught + Dawnbreaker
-- of Smiting above all), and the cross-class spammables (weapon/vampire lines: a Sorc running
-- Rending Slashes or Blood for Blood is common).
RC.COMBO_COMMON = {
    -- universal ults
    ["Dawnbreaker"] = true, ["Dawnbreaker of Smiting"] = true, ["Flawless Dawnbreaker"] = true,
    ["Onslaught"] = true, ["Berserker Strike"] = true, ["Berserker Rage"] = true,
    ["Soul Assault"] = true, ["Soul Strike"] = true, ["Shatter Soul"] = true,
    -- cross-class spammables (all morphs)
    ["Rending Slashes"] = true, ["Blood Craze"] = true, ["Twin Slashes"] = true,
    ["Blood for Blood"] = true, ["Arterial Burst"] = true, ["Eviscerate"] = true,
    ["Wrecking Blow"] = true, ["Dizzying Swing"] = true, ["Uppercut"] = true,
}
-- Universal STUNS (Shoyru: every class combo = 2+ class constants + A FORM OF STUN, and the stun is
-- often the 2H weapon stun, not class CC). These open a combo window for ANY class route -- but a
-- universal stun only counts as an ATTEMPT if the class payload actually followed (or was actively
-- avoided); casting Dizzy all day isn't "attempting the Whip burst" unless the whip comes behind it.
-- Class-specific stuns (Fossilize, Streak, Rune Cage, Soul Tether, Arctic Blast) live in each route's
-- anchors instead and always count -- casting THOSE is commitment.
RC.COMBO_STUNS = {
    ["Dazing Smash"] = true, ["Dizzying Swing"] = true, ["Uppercut"] = true, ["Wrecking Blow"] = true,
}
-- The scan itself, separated from the prose so MULTIPLE rules can build on it (Shoyru's call).
-- Scans EVERY route the class has and returns nil (no signature for the class) or the DOMINANT
-- route's verdict -- the one this player actually plays (most attempts; ties broken by most landed):
-- { cls, combo, tell, attempts, landed, avoided, maxDmg, routes = {per-route stats}, alt = 2nd route }.
-- (On RC, not a chunk local -- the main chunk sits at Lua's 200-active-locals ceiling.)
function RC.ScanRoute(du, sig, nameOf)
    -- 1) Anchor times. Class anchors ("hard": their CC casts, debuff applications on you, or incoming
    -- anchor hits) always count as an attempt -- casting Fossilize/Curse/Blastbones IS commitment.
    -- Universal weapon stuns ("soft", RC.COMBO_STUNS via the CC ledger) open a window for any class,
    -- but only count when the class payload actually followed (or was actively avoided).
    local anchors = {}
    for _, r in pairs((du.cc and du.cc.onMe) or {}) do
        if type(r) == "table" and r.name and r.times and (sig.anchors[r.name] or RC.COMBO_STUNS[r.name]) then
            local hard = sig.anchors[r.name] and true or false
            for _, t in ipairs(r.times) do anchors[#anchors + 1] = { t = t, hard = hard, name = r.name } end
        end
    end
    for _, e in ipairs(du.debuffsMe or {}) do
        if e.name and sig.anchors[e.name] and e.intervals then
            for _, iv in ipairs(e.intervals) do anchors[#anchors + 1] = { t = iv.s or 0, hard = true, name = e.name } end
        end
    end
    for _, e in ipairs(du.log or {}) do
        if e.dir == "in" and (e.val or 0) > 0 and nameOf[e.id] and sig.anchors[nameOf[e.id]] then
            anchors[#anchors + 1] = { t = e.t, hard = true, name = nameOf[e.id] }
        end
    end
    table.sort(anchors, function(a, b) return a.t < b.t or (a.t == b.t and a.hard and not b.hard) end)
    -- Count a combo as ONE combination, not one-per-anchor. All anchors that fall inside a single combo
    -- window (`sig.win`, opened by the first anchor of the burst) belong to the SAME attempt: a Curse, the
    -- Streak timed to its pop, and the Frags behind it are ONE Curse->Streak combo -- and a re-applied
    -- DoT/refresh or a multi-hit ult within that window doesn't inflate the count either. A new window only
    -- opens once the previous one has closed, so genuinely separate bursts (more than `sig.win` apart)
    -- still count independently. Window is anchored to the first anchor (fixed, not sliding) so a
    -- continuous stream of pokes can't merge the whole fight into a single combo.
    local dedup, openUntil = {}, nil
    for _, a in ipairs(anchors) do
        if not openUntil or a.t > openUntil then
            dedup[#dedup + 1] = { t = a.t, hard = a.hard }
            openUntil = a.t + sig.win
        elseif a.hard and dedup[#dedup] then
            dedup[#dedup].hard = true                                -- fold into the open combo window
        end
    end
    -- 2) Classify each attempt: payload damage landed in the window, or answered by your active defense.
    local attempts, landed, avoided, maxDmg, stunLed = 0, 0, 0, 0, 0
    for _, a in ipairs(dedup) do
        local t = a.t
        local dmg, saves = 0, 0
        for _, e in ipairs(du.log or {}) do
            local nm = nameOf[e.id]
            if e.dir == "in" and (e.val or 0) > 0 and e.t > t and e.t <= t + sig.win
                and nm and (sig.payload[nm] or RC.COMBO_COMMON[nm]) then dmg = dmg + e.val end
        end
        for _, r in pairs((du.clutch and du.clutch.onMe) or {}) do
            if r.name and (sig.payload[r.name] or RC.COMBO_COMMON[r.name]) and r.times then
                for _, ct in ipairs(r.times) do if ct > t and ct <= t + sig.win then saves = saves + 1 end end
            end
        end
        if a.hard or dmg >= 6000 or saves > 0 then
            attempts = attempts + 1
            if not a.hard then stunLed = stunLed + 1 end
            if dmg >= 6000 then landed = landed + 1; if dmg > maxDmg then maxDmg = dmg end
            elseif saves > 0 then avoided = avoided + 1 end
        end
    end
    return { combo = sig.combo, tell = sig.tell, attempts = attempts,
        landed = landed, avoided = avoided, maxDmg = maxDmg,
        stunLed = attempts > 0 and stunLed > (attempts - stunLed) or false }
end
function RC.ComboScan(du)
    local sigs = du.oppClassId and RC.CLASS_COMBOS[du.oppClassId]
    if not sigs or #sigs == 0 then return nil end
    local cls = RC.CLASS_NAMES[du.oppClassId] or "opponent"
    -- id -> name from the per-duel tables (log rows carry only ids).
    local nameOf = {}
    for _, a in ipairs(du.takenTop or {}) do if a.id and a.name then nameOf[a.id] = a.name end end
    local routes, best, alt = {}, nil, nil
    for _, sig in ipairs(sigs) do
        local r = RC.ScanRoute(du, sig, nameOf)
        routes[#routes + 1] = r
        local function beats(a, b) return not b or a.attempts > b.attempts or (a.attempts == b.attempts and a.landed > b.landed) end
        if beats(r, best) then alt = best; best = r
        elseif beats(r, alt) then alt = r end
    end
    return { cls = cls, combo = best.combo, tell = best.tell, attempts = best.attempts,
        landed = best.landed, avoided = best.avoided, maxDmg = best.maxDmg, stunLed = best.stunLed,
        routes = routes, alt = (alt and alt.attempts > 0) and alt or nil }
end
function RC.MatchupRead(du)
    local sc = RC.ComboScan(du)
    if not sc then return nil end
    local cls, landed, avoided, maxDmg = sc.cls, sc.landed, sc.avoided, sc.maxDmg
    local sig = { combo = sc.combo, tell = sc.tell }
    local anchors = sc.attempts
    -- A second route they also ran gets a trailing mention -- players mix routes (Shoyru).
    local altStr = sc.alt and string.format(" They also mixed in %s %dx%s.", sc.alt.combo, sc.alt.attempts,
        sc.alt.landed > 0 and string.format(" (landed %d)", sc.alt.landed) or "") or ""
    if anchors == 0 then
        local top = du.takenTop and du.takenTop[1]
        local share = (top and (du.dmgTaken or 0) > 0) and math.floor(top.total / du.dmgTaken * 100 + 0.5) or nil
        return string.format("Off-script %s \226\128\148 not one %s setup (or any lineup we track for the class) all duel, so the textbook read doesn't apply. Their real threat was %s%s. Read this player, not the class stereotype.",
            cls, sig.tell, top and top.name or "spread pressure", share and string.format(" (%d%% of what you took)", share) or "")
    elseif landed > 0 then
        -- When the windows were mostly opened by a WEAPON stun (Dazing Smash etc.), the stun is the
        -- tell -- not the class setup ability (Shoyru's combo model: class constants + a form of stun).
        return string.format("Textbook %s \226\128\148 they ran %s %dx and landed it %dx (up to %s in the follow-up window)%s. The %s IS the tell: your answer wants to fire the moment it lands, not after the burst behind it.%s",
            cls, sig.combo, anchors, landed, Abbrev(maxDmg),
            avoided > 0 and string.format("; you answered %d of them", avoided) or "",
            sc.stunLed and "stun" or sig.tell, altStr)
    elseif avoided > 0 then
        return string.format("They tried %s %dx and you answered every one \226\128\148 active defense inside each window, nothing landed. That's the matchup won; expect them to go off-script next time.%s",
            sig.combo, anchors, altStr)
    else
        return string.format("They set up %s %dx but the follow-up never connected \226\128\148 whiffed or half-committed. Punish the setup itself: the moment %s comes out they're committed, and that's your window, not theirs.%s",
            sig.combo, anchors, sig.tell, altStr)
    end
end
-- Cross-duel lookups for the matchup/meta rules. OppOf finds the opponent record that owns this duel
-- (works whether or not it's the currently-open duel); ClassRecord aggregates your W/L vs a whole class.
function RC.OppOf(du)
    if currentDuel and currentDuel.du == du and currentDuel.o then return currentDuel.o end
    if sv and sv.opponents then
        for _, o in pairs(sv.opponents) do
            for _, d in ipairs(o.duels or {}) do if d == du then return o end end
        end
    end
    return nil
end
function RC.ClassRecord(classId)
    local w, l, n = 0, 0, 0
    if classId and sv and sv.opponents then
        for _, o in pairs(sv.opponents) do
            if o.classId == classId then w = w + (o.wins or 0); l = l + (o.losses or 0); n = n + 1 end
        end
    end
    return w, l, n
end
function RC.Ctx(du)
    local dur = (du.durationS and du.durationS > 0) and du.durationS or 1
    local c = { du = du, dur = dur, result = du.result, win = du.result == "win", loss = du.result == "loss" }
    local log = du.log or {}
    local tl = du.timeline

    -- ---- Damage composition ----
    local dealt, taken = du.dealtTop or {}, du.takenTop or {}
    local dealtTot = du.dmgDealt or 0; if dealtTot <= 0 then for _, a in ipairs(dealt) do dealtTot = dealtTot + (a.total or 0) end end
    local takenTot = du.dmgTaken or 0; if takenTot <= 0 then for _, a in ipairs(taken) do takenTot = takenTot + (a.total or 0) end end
    c.dealtTot, c.takenTot = dealtTot, takenTot
    c.top1, c.top2, c.topIn = dealt[1], dealt[2], taken[1]
    c.top1OutShare = (dealtTot > 0 and dealt[1]) and (dealt[1].total or 0) / dealtTot or 0
    c.top2OutShare = (dealtTot > 0 and dealt[2]) and ((dealt[1].total or 0) + (dealt[2].total or 0)) / dealtTot or c.top1OutShare
    c.top1InShare = (takenTot > 0 and taken[1]) and (taken[1].total or 0) / takenTot or 0
    local dotOut, laOut, heavyOut, dotIn = 0, 0, 0, 0
    for _, a in ipairs(dealt) do
        if a.dot then dotOut = dotOut + (a.total or 0) end
        if RC.IsLightAttack(a) then laOut = laOut + (a.total or 0) end
        if RC.IsHeavyAttack(a) then heavyOut = heavyOut + (a.total or 0) end
    end
    for _, a in ipairs(taken) do if a.dot then dotIn = dotIn + (a.total or 0) end end
    c.dotShareOut = dealtTot > 0 and dotOut / dealtTot or 0
    c.laShareOut  = dealtTot > 0 and laOut / dealtTot or 0
    c.heavyShareOut = dealtTot > 0 and heavyOut / dealtTot or 0
    c.dotShareIn  = takenTot > 0 and dotIn / takenTot or 0
    -- The light-attack war in raw HIT counts (rotation dominance -- who spent more of the fight on
    -- target with a LA in front of each cast). Backfills from the uncapped ability tables.
    c.la = { out = RC.LAHits(dealt), inn = RC.LAHits(taken) }
    -- Front/back-bar split both sides (time-on-bar proxy from weapon-named LAs/HAs).
    c.bars = { me = RC.BarSplit(dealt), opp = RC.BarSplit(taken) }

    -- Damage-type mix (dominant type by value) for both directions.
    local function typeMix(list, total)
        local mix = {}
        for _, a in ipairs(list) do if a.dtype then mix[a.dtype] = (mix[a.dtype] or 0) + (a.total or 0) end end
        local topT, topV = nil, 0
        for t, v in pairs(mix) do if v > topV then topV, topT = v, t end end
        return mix, topT, (total > 0 and topV / total or 0)
    end
    c.typeOut, c.typeOutTop, c.typeOutTopShare = typeMix(dealt, dealtTot)
    c.typeIn,  c.typeInTop,  c.typeInTopShare  = typeMix(taken, takenTot)

    -- Opponent model from the damage THEY dealt to you.
    local magIn, physIn = 0, 0
    for t, v in pairs(c.typeIn) do
        if RC.DTYPE_MAGIC[t] then magIn = magIn + v elseif RC.DTYPE_PHYS[t] then physIn = physIn + v end
    end
    local classified = magIn + physIn
    c.opp = { classId = du.oppClassId, topAbility = taken[1], dotReliant = c.dotShareIn >= 0.5 }
    if classified > 0 then
        c.opp.magicShare, c.opp.physShare = magIn / classified, physIn / classified
        c.opp.kind = (c.opp.magicShare >= 0.6 and "ranged") or (c.opp.physShare >= 0.6 and "melee") or "mixed"
        c.opp.weapon = RC.DTYPE_WEAPON[c.typeInTop]
        c.opp.weaponName = RC.DTYPE_NAME[c.typeInTop]
    end

    -- ---- Fight-arc windows + cumulative lead curve ----
    local eOut, eIn, mOut, mIn, lOut, lIn, totOut, totIn = 0, 0, 0, 0, 0, 0, 0, 0
    local net, netPeak, netTrough = 0, 0, 0
    local t3 = dur / 3
    if type(tl) == "table" then
        for s = 0, math.floor(dur) do
            local b = tl[s]
            if b then
                local o, i = b.dmgOut or 0, b.dmgIn or 0
                totOut, totIn = totOut + o, totIn + i
                net = net + o - i
                if net > netPeak then netPeak = net end
                if net < netTrough then netTrough = net end
                if s < t3 then eOut, eIn = eOut + o, eIn + i
                elseif s < 2 * t3 then mOut, mIn = mOut + o, mIn + i
                else lOut, lIn = lOut + o, lIn + i end
            end
        end
    end
    c.windows = { earlyOut = eOut, earlyIn = eIn, midOut = mOut, midIn = mIn, lateOut = lOut, lateIn = lIn, totOut = totOut, totIn = totIn }
    c.frontLoadOut = totOut > 0 and eOut / totOut or 0
    c.lateOutShare = totOut > 0 and lOut / totOut or 0
    c.slowStart = (totOut + totIn) > 0 and (eOut + eIn) / (totOut + totIn) < 0.12 or false
    c.lead = { peak = netPeak, trough = netTrough, endNet = net,
        collapsed = (netPeak > 8000 and net < netPeak * 0.3),
        comeback = (netTrough < -8000 and c.win) }

    -- ---- Resource floor + offense cliff + ult hold ----
    c.res = { floor = RC.ResourceFloor(du) }
    if type(tl) == "table" then
        local magMx, stamMx, ultRun, ultRunMax, lastUlt = 0, 0, 0, 0, 0
        for _, b in pairs(tl) do magMx = math.max(magMx, b.mag or 0); stamMx = math.max(stamMx, b.stam or 0) end
        local lowT, lowF = nil, 1.0
        for s = 0, math.floor(dur) do
            local b = tl[s]
            if b then
                local mf = magMx > 0 and (b.mag or 0) / magMx or 1
                local sf = stamMx > 0 and (b.stam or 0) / stamMx or 1
                local f = math.min(mf, sf)
                if f < lowF then lowF, lowT = f, s end
                -- ult held near-full with no cast this second => running "hold" streak
                if (b.ult or 0) >= 450 and (b.ultCast or 0) == 0 then ultRun = ultRun + 1; if ultRun > ultRunMax then ultRunMax = ultRun end
                else ultRun = 0 end
                lastUlt = b.ult or lastUlt
            end
        end
        c.res.floorAtSec, c.res.floorFrac = lowT, lowF
        c.res.ultHeldSecs, c.res.endedFullUlt = ultRunMax, (lastUlt >= 450)
        -- offense-after-floor: did output fall after the low point?
        if lowT then
            local beforeOut, afterOut, beforeN, afterN, afterIn, totInTl = 0, 0, 0, 0, 0, 0
            for s = 0, math.floor(dur) do
                local b = tl[s]
                if b then
                    totInTl = totInTl + (b.dmgIn or 0)
                    if s < lowT then beforeOut = beforeOut + (b.dmgOut or 0); beforeN = beforeN + 1
                    else afterOut = afterOut + (b.dmgOut or 0); afterN = afterN + 1; afterIn = afterIn + (b.dmgIn or 0) end
                end
            end
            local beforeRate = beforeN > 0 and beforeOut / beforeN or 0
            local afterRate = afterN > 0 and afterOut / afterN or 0
            c.res.offenseCliff = beforeRate > 0 and afterRate < beforeRate * 0.6
            c.res.dmgAfterFloorShare = totInTl > 0 and afterIn / totInTl or 0
        end
    end

    -- ---- Effect uptime + intervals (buffs/debuffs) ----
    local function effUptime(list, id)
        if type(list) == "table" then for _, e in ipairs(list) do if e.id == id then return math.min(1, (e.uptime or 0) / 1000 / dur) end end end
        return 0
    end
    local function effWindows(list, id)
        if type(list) == "table" then for _, e in ipairs(list) do if e.id == id then return e.intervals end end end
        return nil
    end
    c.resolveUptime = effUptime(du.buffsMe, RC.ID_RESOLVE)
    c.offBuffUptime = math.max(effUptime(du.buffsMe, RC.ID_SORCERY), effUptime(du.buffsMe, RC.ID_BRUTALITY))
    c.defileOnMe    = math.max(effUptime(du.debuffsMe, RC.ID_DEFILE_MAJ), effUptime(du.debuffsMe, RC.ID_DEFILE_MIN))
    do  -- share of incoming damage that landed while Major Resolve was DOWN (needs log + intervals)
        local w = effWindows(du.buffsMe, RC.ID_RESOLVE)
        local inTot, inGap = 0, 0
        for _, e in ipairs(log) do
            if e.dir == "in" then
                inTot = inTot + (e.val or 0)
                local up = false
                if w then for _, iv in ipairs(w) do if e.t >= iv.s and e.t <= iv.e then up = true; break end end end
                if not up then inGap = inGap + (e.val or 0) end
            end
        end
        c.dmgInResolveGap = inTot > 0 and inGap / inTot or 0
        c.hasResolveData = (w ~= nil) and inTot > 0
    end
    do  -- worst-kept KEY debuff you actually ran (Breach/Vuln/Maim/Defile/status)
        local worst, worstUp = nil, 101
        for _, e in ipairs(du.debuffsOpp or {}) do
            local role = RC.EffKind(e)
            if role and role ~= "status" then
                local up = math.min(100, (e.uptime or 0) / 1000 / dur * 100)
                if up < worstUp and up < 55 then worst, worstUp = e, up end
            end
        end
        c.keyDebuffWorst = worst and { e = worst, uptime = worstUp, role = RC.EffKind(worst) } or nil
    end

    -- ---- CC timing (needs the per-event timestamps we now capture) ----
    local function hardTimes(side)
        local out = {}
        if type(side) == "table" then
            for _, r in pairs(side) do
                if RC.HARD_CC[r.kind] and r.times then for _, t in ipairs(r.times) do out[#out + 1] = t end end
            end
        end
        table.sort(out); return out
    end
    local ccMeTimes = hardTimes(du.cc and du.cc.onMe)
    local ccMeN = RC.HardCC(du.cc and du.cc.onMe)
    local ccOppTimes = hardTimes(du.cc and du.cc.onOpp)
    local ccOppN = RC.HardCC(du.cc and du.cc.onOpp)
    c.cc = { meN = ccMeN, oppN = ccOppN, meTimes = ccMeTimes,
        interruptsMe = RC.Interrupts(du.cc and du.cc.onMe), interruptsOpp = RC.Interrupts(du.cc and du.cc.onOpp) }
    do  -- burst that followed each CC on you (within 2s), + share of all incoming in those windows
        local burstSum, burstN, ccWinIn, inTot = 0, 0, 0, 0
        for _, e in ipairs(log) do if e.dir == "in" then inTot = inTot + (e.val or 0) end end
        for _, t in ipairs(ccMeTimes) do
            local s = 0
            for _, e in ipairs(log) do if e.dir == "in" and e.t > t and e.t <= t + 2000 then s = s + (e.val or 0) end end
            burstSum, burstN, ccWinIn = burstSum + s, burstN + 1, ccWinIn + s
        end
        c.cc.burstAfterAvg = burstN > 0 and burstSum / burstN or 0
        c.cc.dmgInCCWindows = ccWinIn
        c.cc.dmgInCCShare = inTot > 0 and ccWinIn / inTot or 0
        c.cc.hasTimes = #ccMeTimes > 0 and inTot > 0
    end
    do  -- break-free latency proxy: time from each CC to your next outgoing event
        local bfSum, bfN = 0, 0
        for _, t in ipairs(ccMeTimes) do
            local nxt
            for _, e in ipairs(log) do if e.dir == "out" and e.t > t and (not nxt or e.t < nxt) then nxt = e.t end end
            if nxt then bfSum, bfN = bfSum + (nxt - t), bfN + 1 end
        end
        c.cc.breakFreeAvg = bfN > 0 and bfSum / bfN or nil
    end
    do  -- your CC thrown into immunity (two hard CCs on them < 7s apart)
        local waste = 0
        for i = 2, #ccOppTimes do if ccOppTimes[i] - ccOppTimes[i - 1] < 7000 then waste = waste + 1 end end
        c.cc.immunityWaste = waste
    end
    do  -- caught by the same setup + one-note CC (distinct hard kinds you landed)
        local topCC, topN, kinds = nil, 0, {}
        if du.cc and type(du.cc.onMe) == "table" then
            for _, r in pairs(du.cc.onMe) do if RC.HARD_CC[r.kind] and (r.count or 0) > topN then topN, topCC = r.count, r end end
        end
        if du.cc and type(du.cc.onOpp) == "table" then
            for _, r in pairs(du.cc.onOpp) do if RC.HARD_CC[r.kind] then kinds[r.kind] = true end end
        end
        local kn = 0; for _ in pairs(kinds) do kn = kn + 1 end
        c.cc.repeatSetup = topCC and { name = topCC.name, n = topN } or nil
        c.cc.oppKinds = kn
    end

    -- ---- Active-defense (clutch) timing ----
    local blkMe, dgMe, absMe, meTop, meTopN = RC.Mitigation(du.clutch and du.clutch.onMe)
    local blkOpp, dgOpp, _, oppTop, oppTopN = RC.Mitigation(du.clutch and du.clutch.onOpp)
    c.clutch = { meBlock = blkMe, meDodge = dgMe, meAbsorbed = absMe, meTop = meTop, meTopN = meTopN, oppBlock = blkOpp, oppDodge = dgOpp, oppTop = oppTop, oppTopN = oppTopN }
    do  -- Block-weave (habit) detection + wind-up reads + ward taxonomy, per side.
        -- Numerous blocks SPREAD across the fight = block-weaving between casts (foundation in melee,
        -- says nothing about reads or timing). Blocks concentrated on wind-up abilities = a read.
        local function pattern(ledger)
            local n, mn, mx, wind, windTop, windTopN, activeWard = 0, nil, nil, 0, nil, 0
            for _, r in pairs(type(ledger) == "table" and ledger or {}) do
                local bd = (r.block or 0) + (r.dodge or 0)
                if bd > 0 and r.times then
                    n = n + bd
                    for _, t in ipairs(r.times) do
                        if not mn or t < mn then mn = t end
                        if not mx or t > mx then mx = t end
                    end
                end
                if r.name and (RC.WINDUPS[r.name] or r.name:find("^Heavy Attack")) and (r.block or 0) > 0 then
                    wind = wind + r.block
                    if r.block > windTopN then windTopN, windTop = r.block, r.name end
                end
                if (r.shield or 0) > 0 and r.name and RC.ACTIVE_WARDS[r.name] then activeWard = true end
            end
            local spread = (mn and mx and dur > 0) and (mx - mn) / (dur * 1000) or 0
            return n >= 8 and spread >= 0.40, wind, windTop, activeWard
        end
        local meHabit, _, _, meAW = pattern(du.clutch and du.clutch.onMe)
        local oppHabit, oppWind, oppWindTop, _ = pattern(du.clutch and du.clutch.onOpp)
        c.clutch.meHabit, c.clutch.meActiveWard = meHabit, meAW
        c.clutch.oppHabit = oppHabit
        c.opp = c.opp or {}
        c.opp.windupBlocked, c.opp.windupTop = oppWind, oppWindTop
    end
    do  -- peak incoming 3s window + how much active defense you had in it
        local peakStart, peakVal = 0, -1
        if type(tl) == "table" then
            for s = 0, math.floor(dur) do
                local sum = 0
                for k = 0, 2 do local b = tl[s + k]; if b then sum = sum + (b.dmgIn or 0) end end
                if sum > peakVal then peakVal, peakStart = sum, s end
            end
        end
        c.peakInStart, c.peakInVal = peakStart, peakVal
        local defWin, reactN, totN = 0, 0, 0
        if du.clutch and type(du.clutch.onMe) == "table" then
            for _, r in pairs(du.clutch.onMe) do if r.times then
                -- Ward rows (shield-only) still count as defense-in-window -- a ward soaking the burst IS
                -- defending it -- but a ward procs exactly when a hit lands, so it would ALWAYS read
                -- "reactive"; only block/dodge rows say anything about your timing.
                local activeRow = ((r.block or 0) + (r.dodge or 0)) > 0
                for _, t in ipairs(r.times) do
                    local ts = t / 1000
                    if ts >= peakStart and ts <= peakStart + 3 then defWin = defWin + 1 end
                    if activeRow then
                        totN = totN + 1
                        for _, e in ipairs(log) do if e.dir == "in" and e.t < t and e.t >= t - 500 then reactN = reactN + 1; break end end
                    end
                end
            end end
        end
        c.clutch.defInPeakWindow = defWin
        c.clutch.reactiveShare = totN > 0 and reactN / totN or nil
    end
    do  -- reactive-blocker read: THEY blocked/dodged right after your outgoing tell
        local rbN, rbTot = 0, 0
        if du.clutch and type(du.clutch.onOpp) == "table" then
            -- Their ward rows (shield-only) fire exactly when YOUR hit lands -- always "right after your
            -- tell" by construction -- so only their block/dodge rows can prove they're reading you.
            for _, r in pairs(du.clutch.onOpp) do if r.times and ((r.block or 0) + (r.dodge or 0)) > 0 then for _, t in ipairs(r.times) do
                rbTot = rbTot + 1
                for _, e in ipairs(log) do if e.dir == "out" and e.t < t and e.t >= t - 600 then rbN = rbN + 1; break end end
            end end end
        end
        c.opp.reactiveBlockShare = rbTot > 0 and rbN / rbTot or nil
        c.opp.reactiveBlockN = rbTot
    end

    -- ---- Weave / heal / crit ----
    local wv = du.weave
    if wv and (wv.delayCount or 0) > 0 then
        c.weaveRatio = math.min(1, wv.delayCount / (wv.casts or wv.delayCount))
        c.weaveDelay = wv.delaySum / wv.delayCount
        c.weaveCasts = wv.casts or wv.delayCount
    end
    c.castRate = (wv and (wv.casts or 0) > 0) and wv.casts / dur or nil
    -- Weave quality PRESSURED (within 3s after a CC on you) vs FREE, from the per-cast events -- lets a
    -- rule catch a rotation that only holds together when unbothered. Plus max idle gap between casts.
    if wv and type(wv.events) == "table" and #wv.events >= 8 then
        local pw, pn, fw, fn = 0, 0, 0, 0
        for _, e in ipairs(wv.events) do
            local pressured = false
            for _, t in ipairs(ccMeTimes) do if e.t >= t and e.t <= t + 3000 then pressured = true; break end end
            if pressured then pn = pn + 1; if (e.d or 0) > 0 then pw = pw + 1 end
            else fn = fn + 1; if (e.d or 0) > 0 then fw = fw + 1 end end
        end
        if pn >= 3 and fn >= 3 then c.weaveFreeRatio, c.weavePressuredRatio = fw / fn, pw / pn end
        -- max idle gap between consecutive casts (ms), for downtime detection
        local sorted = {}; for _, e in ipairs(wv.events) do sorted[#sorted + 1] = e.t end
        table.sort(sorted)
        local maxGap = 0
        for i = 2, #sorted do local g = sorted[i] - sorted[i - 1]; if g > maxGap then maxGap = g end end
        c.maxCastGap = maxGap
    end
    local over, healed = du.overHeal or 0, du.healReceived or 0
    c.overShare, c.healReceived = (healed + over) > 0 and over / (healed + over) or 0, healed
    do
        local hits, crits = 0, 0
        for _, a in ipairs(dealt) do if (a.crit or 0) > 0 then hits, crits = hits + (a.hits or 0), crits + a.crit end end
        if hits >= 10 and du.stats then
            local rating = math.floor(math.max((du.stats[3] and du.stats[3].avg) or 0, (du.stats[13] and du.stats[13].avg) or 0))
            local ok, chance = pcall(GetCriticalStrikeChance, rating)
            if ok and chance and chance > 0 then c.critAch, c.critChance = crits / hits * 100, chance end
        end
    end
    if type(du.spendLog) == "table" then  -- resource-hog ability
        local byId, tot = {}, 0
        for _, s in ipairs(du.spendLog) do byId[s.id] = (byId[s.id] or 0) + (s.val or 0); tot = tot + (s.val or 0) end
        local topId, topV = nil, 0; for id, v in pairs(byId) do if v > topV then topV, topId = v, id end end
        c.spendTopShare, c.spendTopId = tot > 0 and topV / tot or 0, topId
    end

    -- ---- Grades + cross-duel ----
    c.dims = RC.Dims(du)
    c.dimByKey = {}; for _, d in ipairs(c.dims) do c.dimByKey[d.key] = d end
    if currentDuel and currentDuel.du == du and currentDuel.o then
        c.vsOpp = { wins = currentDuel.o.wins or 0, losses = currentDuel.o.losses or 0, name = currentDuel.o.name or currentDuel.o.handle }
    end
    c.oppRec = RC.OppOf(du)
    c.oppClassId = du.oppClassId
    c.combo = RC.ComboScan(du)   -- class-signature combo scan (nil when no signature for the class)
    return c
end
-- ---- Personalized insight engine ------------------------------------------------------------------
-- The rules below are UNIVERSAL (each would fire for any player), but every one reads THIS duel's real
-- abilities, timestamps, shares and deltas-vs-YOUR-baseline and fills the sentence with them -- so no
-- two report cards read alike, and nothing here is advice you could hand a stranger sight-unseen. What
-- makes it personal is the intersection with what YOU actually did: the abilities in your dealt/taken
-- lists, the debuffs you applied (via the universal RC.EFF library), your resource curve, your CC
-- ledger, your build. Build-static facts (pen over cap, low resist) live in BuildFlags, NOT here.
RC.ROLE_CONSEQ = {
    resist    = "your hits were landing into full resistances",
    vuln      = "they weren't taking the bonus damage",
    brittle   = "your crits were hitting for less",
    maim      = "they were dealing full damage back",
    defile    = "their healing wasn't being cut",
    cowardice = "their damage wasn't being reduced",
    offbal    = "you missed the off-balance exploit windows",
}
-- LEGACY ranked insight list (the original 14 rules). Still authoritative; the new ctx-based registry
-- (RC.RULES) runs ALONGSIDE it in RC.Insights. Each entry = { sev, key, text }.
function RC.LegacyInsights(du)
    local dur = (du.durationS and du.durationS > 0) and du.durationS or 1
    local dims = RC.Dims(du)
    local dmByKey = {}; for _, d in ipairs(dims) do dmByKey[d.key] = d end
    local out = {}
    local function push(sev, key, text) out[#out + 1] = { sev = sev, key = key, text = text } end

    -- 1. What hurt you most -- the single biggest source of the damage you took. The fix depends on the
    -- damage TYPE: a DoT is cleansable (purge), a direct hit is not (block/dodge). Never "line of sight" --
    -- kiting behind LoS is against duel etiquette, so we don't coach it.
    local tk = du.takenTop and du.takenTop[1]
    if tk and (du.dmgTaken or 0) > 0 then
        local share = tk.total / du.dmgTaken
        if share >= 0.28 then
            local critStr = (tk.hits and tk.hits > 0 and (tk.crit or 0) > 0) and string.format(", %d%% crit", math.floor(tk.crit / tk.hits * 100 + 0.5)) or ""
            -- Channeled heavies (lightning/resto) tick as DOT_TICK in the combat log (verified vs real
            -- data), but they're channels, not effects on you: blockable ticks, and any hard CC cuts the
            -- channel -- "cleanse it" would be wrong advice.
            local isChannelHeavy = tk.dot and tk.name and tk.name:find("^Heavy Attack") ~= nil
            local fix = isChannelHeavy
                and "It's a channeled heavy attack \226\128\148 the ticks read like a DoT but there's nothing to cleanse; the ticks CAN be blocked, and a stun cuts the channel short."
                or tk.dot
                and "It's a damage-over-time effect \226\128\148 once it's ticking you can't block it off, and most builds can't cleanse, so denying the reapplication with spacing is the answer."
                or "It's direct damage \226\128\148 block the cast or roll-dodge the tell and keep Major Resolve up; it's a reaction, not something you remove."
            push(72 + share * 20, "hurt:" .. (tk.id or 0),
                string.format("%d%% of the damage you took came from %s (%d hits%s). %s",
                    math.floor(share * 100 + 0.5), tk.name or "one ability", tk.hits or 0, critStr, fix))
        end
    end

    -- 2. One-dimensional offense -- too much damage riding on a single ability.
    local dl = du.dealtTop and du.dealtTop[1]
    if dl and (du.dmgDealt or 0) > 0 then
        local share = dl.total / du.dmgDealt
        if share >= 0.45 then
            push(56 + share * 15, "conc:" .. (dl.id or 0),
                string.format("%d%% of your damage was one ability (%s) \226\128\148 the moment they block or dodge it your offense stalls. Develop a second threat they also have to respect.",
                    math.floor(share * 100 + 0.5), dl.name or "one skill"))
        end
    end

    -- 3. Crit luck vs your actual crit chance -- separates variance from a real build problem. Count
    -- ONLY abilities that critted at least once this duel: proc sets, DoTs and other non-critable
    -- damage come through with crit=0 and would otherwise drag your "achieved" crit% down and cry RNG
    -- when the real story is just that a chunk of your damage structurally can't crit.
    local hits, crits = 0, 0
    for _, a in ipairs(du.dealtTop or {}) do
        if (a.crit or 0) > 0 then hits = hits + (a.hits or 0); crits = crits + a.crit end
    end
    if hits >= 10 and du.stats then
        local rating = math.floor(math.max((du.stats[3] and du.stats[3].avg) or 0, (du.stats[13] and du.stats[13].avg) or 0))
        local ok, chance = pcall(GetCriticalStrikeChance, rating)
        if ok and chance and chance > 0 then
            local ach = crits / hits * 100
            if ach - chance <= -15 then
                push(44, "critluck", string.format("You critted %d%% this duel against your %d%% chance \226\128\148 cold RNG, not your build. Don't rebuild off one unlucky duel.", math.floor(ach + 0.5), math.floor(chance + 0.5)))
            elseif ach - chance >= 18 then
                push(30, "critluck", string.format("You critted %d%% against your %d%% chance \226\128\148 hot RNG flattered your damage; your real baseline is a touch lower.", math.floor(ach + 0.5), math.floor(chance + 0.5)))
            end
        end
    end

    -- 4. Resource death-spiral -- a pool bottomed out and damage landed after, nothing left to answer.
    local tl = du.timeline
    if type(tl) == "table" then
        local magMx, stamMx = 0, 0
        for _, c in pairs(tl) do magMx = math.max(magMx, c.mag or 0); stamMx = math.max(stamMx, c.stam or 0) end
        local lowT, lowF = nil, 1.0
        for s, c in pairs(tl) do
            -- A bucket with no resource sample this second has mag/stam == 0 (the default), which is
            -- "unsampled", NOT "empty pool". Treating those zeros as a floor made every duel claim a
            -- resource bottomed out at 0:0X / 0% before the first resource tick. Only positive samples count.
            local mf = (magMx > 0 and (c.mag or 0) > 0) and (c.mag / magMx) or 1
            local sf = (stamMx > 0 and (c.stam or 0) > 0) and (c.stam / stamMx) or 1
            local f = math.min(mf, sf)
            if f < lowF then lowF, lowT = f, s end
        end
        if lowT and lowF < 0.15 then
            -- Share of the incoming damage that landed AFTER the floor, measured against the timeline's
            -- OWN total (self-consistent + always <=100%, even if the record total diverges from it).
            local after, totalIn = 0, 0
            for s, c in pairs(tl) do totalIn = totalIn + (c.dmgIn or 0); if s >= lowT then after = after + (c.dmgIn or 0) end end
            local ap = totalIn > 0 and math.min(100, math.floor(after / totalIn * 100 + 0.5)) or 0
            push(68, "resfloor", string.format("A resource bottomed out around %d:%02d (%d%% of its peak) and %d%% of the damage you took landed after \226\128\148 you were out of dodge/break-free. Slow your rotation or add recovery.",
                math.floor(lowT / 60), lowT % 60, math.floor(lowF * 100 + 0.5), ap))
        end
    end

    -- 5. CC vulnerability -- caught by hard CC repeatedly.
    local ccMe, ccMeSecs = RC.HardCC(du.cc and du.cc.onMe)
    if ccMe >= 3 then
        local ccStr = (ccMeSecs >= 0.5) and string.format(" (%.0fs stunned/rooted)", ccMeSecs) or ""
        push(50 + math.min(20, ccMe * 2), "ccme", string.format("You were hard-CC'd %d times%s. Bank break-free stamina and read the setup \226\128\148 every catch is a free burst window for them.", ccMe, ccStr))
    end

    -- 6. CC not converting -- you land the crowd control but don't cash it into burst.
    local ccOpp = RC.HardCC(du.cc and du.cc.onOpp)
    if ccOpp >= 3 and dmByKey.burst and dmByKey.burst.s < 55 then
        push(42, "ccconv", string.format("You landed %d hard CCs but your burst only graded %s \226\128\148 you're not cashing the openings. Load your full combo into the stun instead of chipping at it.", ccOpp, GradeLetter(dmByKey.burst.s)))
    end

    -- 7. Weave discipline -- light attacks skipped on too many casts (free damage on the floor).
    local wv = du.weave
    if wv and (wv.casts or 0) > 0 and (wv.delayCount or 0) > 0 then
        local ratio = math.min(1, wv.delayCount / wv.casts)
        if ratio < 0.7 then
            push(46, "weaveratio", string.format("You wove a light attack on only %d%% of your casts \226\128\148 the skipped light attacks are roughly %d%% of your potential damage. Force an LA before every skill until it's muscle memory.", math.floor(ratio * 100 + 0.5), math.floor((1 - ratio) * 30 + 0.5)))
        end
    end

    -- 8. Key-debuff gap -- a meaningful debuff you DID run fell off for much of the duel.
    local worst, worstUp = nil, 101
    for _, e in ipairs(du.debuffsOpp or {}) do
        local role = RC.EffKind(e)
        if role and role ~= "status" then
            local up = math.min(100, (e.uptime or 0) / 1000 / dur * 100)
            if up < worstUp and up < 55 then worst, worstUp = e, up end
        end
    end
    if worst then
        local role = RC.EffKind(worst)
        push(54, "keygap:" .. (worst.id or 0), string.format("%s was up only %d%% of the duel \226\128\148 for the rest, %s. Re-apply it before it drops.",
            (RC.EFF[worst.id] and RC.EFF[worst.id].short) or worst.name or "A key debuff", math.floor(worstUp + 0.5), RC.ROLE_CONSEQ[role] or "its effect lapsed"))
    end

    -- 9. Overheal -- healing thrown before you're actually hit.
    local over, healed = du.overHeal or 0, du.healReceived or 0
    if healed + over > 0 then
        local op = over / (healed + over)
        if op >= 0.35 then
            push(34, "overheal", string.format("%d%% of your healing was overheal \226\128\148 you're topping off before you drop. Delay heals to when you actually take the hit; that's resource you needed for offense.", math.floor(op * 100 + 0.5)))
        end
    end

    -- 10. Performance vs YOUR norm -- surface the axis that most beat or trailed your usual and explain
    -- WHY, citing the number that drove the grade. A high grade has to say what went RIGHT (only the
    -- engine knows the reason), not "repeat it"; a low grade names what cost you.
    do
        local norms = RC.DimNorms()
        local best, bestDev = nil, 0
        for _, dm in ipairs(dims) do
            local dev = dm.s - (norms[dm.key] or 50)
            if math.abs(dev) > math.abs(bestDev) then best, bestDev = dm, dev end
        end
        if best and math.abs(bestDev) >= 12 then
            local driver = best.note or ""
            if (best.key == "offense" or best.key == "burst") and du.dealtTop and du.dealtTop[1] and du.dealtTop[1].name then
                driver = driver .. " Mostly " .. du.dealtTop[1].name .. "."
            end
            if bestDev > 0 then
                push(40 + math.min(20, bestDev / 2), "vsnorm:" .. best.key,
                    string.format("Your %s graded %s, well above your norm \226\128\148 %s Lock in whatever drove that.", best.label, GradeLetter(best.s), driver))
            else
                push(50 + math.min(18, -bestDev / 2), "vsnorm:" .. best.key,
                    string.format("Your %s graded %s, below your norm \226\128\148 %s That's what cost you this duel.", best.label, GradeLetter(best.s), driver))
            end
        end
    end

    -- 11. Matchup memory (cross-duel) -- a losing head-to-head you keep repeating.
    if currentDuel and currentDuel.o then
        local o = currentDuel.o
        local w, l = o.wins or 0, o.losses or 0
        if w + l >= 3 and l > w then
            push(38, "matchup", string.format("You're %d-%d against %s and keep losing it the same way \226\128\148 change your opener or swap a bar before the next one.", w, l, o.name or o.handle or "them"))
        end
    end

    -- 12. Wasted offense -- they blocked/dodged a chunk of your key ability. Bait it or add unblockable pressure.
    do
        local _, _, _, oppTop, oppN = RC.Mitigation(du.clutch and du.clutch.onOpp)
        if oppTop and oppN >= 3 then
            push(47, "wasted:" .. (oppTop.name or "?"), string.format("They blocked or dodged %s of your %s \226\128\148 stun them first so they can't block, bash to drain their block, or lean on damage that ignores it (DoTs and status still apply through block).", oppN, oppTop.name or "key ability"))
        end
    end

    -- 13. Interrupted -- your casts got shut down repeatedly. Cast from safety or fake-cast the bait.
    local intMe = RC.Interrupts(du.cc and du.cc.onMe)
    if intMe >= 2 then
        push(40, "interrupted", string.format("You were interrupted %d times \226\128\148 their bash is melee range, so space out and hard-cast from range, or only commit to a channel when they're stunned or occupied.", intMe))
    end

    -- 14. Clutch defense (positive reinforcement) -- you actively defended their burst.
    do
        local blk, dg, _, top, topN = RC.Mitigation(du.clutch and du.clutch.onMe)
        if blk + dg >= 4 then
            push(24, "clutchdef", string.format("Sharp active defense \226\128\148 %d blocks / %d dodges%s. That's the difference between eating a burst and shrugging it off.",
                blk, dg, (top and topN >= 2) and string.format(", incl. %s on %s", topN, top.name or "their burst") or ""))
        end
    end

    table.sort(out, function(a, b) return a.sev > b.sev end)
    return out
end
-- ---- Rule REGISTRY (new ctx-based rules) ----------------------------------------------------------
-- Each rule is a pure fn(ctx) -> (severity, text[, dynamicKey]) or nil to not fire, reading ONLY from
-- RC.Ctx. Runs ALONGSIDE the legacy rules above. Capture-gated rules (damage type, CC/clutch timestamps,
-- effect intervals) simply do not fire on old records that lack that data. cat groups rules for
-- category-diverse card selection (a card set never reads as three variations of one point).
RC.RULES = {}
RC.Rule = function(id, cat, fn) RC.RULES[#RC.RULES + 1] = { id = id, cat = cat, fn = fn } end
RC.LEGACY_CAT = { hurt = "defense", conc = "offense", critluck = "stat", resfloor = "resource",
    ccme = "cc", ccconv = "cc", weaveratio = "weave", keygap = "debuff", overheal = "heal",
    vsnorm = "norm", matchup = "matchup", wasted = "offense", interrupted = "cc", clutchdef = "defense" }
function RC.CatOf(key) return RC.LEGACY_CAT[key:match("^[a-z]+") or ""] or "misc" end

-- T2-01 -- share of incoming damage that landed while Major Resolve was DOWN.
RC.Rule("resolvegap", "defense", function(c)
    if not (c.hasResolveData and c.dmgInResolveGap >= 0.4) then return end
    return 60 + c.dmgInResolveGap * 20,
        string.format("%d%% of the damage you took landed while your Major Resolve was down. It's not that they out-damage you \226\128\148 you drop your mitigation right when you commit to offense. Your defense and your damage are fighting each other.", math.floor(c.dmgInResolveGap * 100 + 0.5))
end)
-- T3-01 -- burst that followed each hard CC on you within 2s.
RC.Rule("ccburst", "cc", function(c)
    if not (c.cc.hasTimes and (c.cc.meN or 0) >= 1 and c.cc.burstAfterAvg >= 6000) then return end
    return 62 + math.min(20, c.cc.burstAfterAvg / 1000),
        string.format("Every hard CC on you was followed by a hit within 2 seconds, averaging %s. The stun is not what hurts you \226\128\148 the burst behind it is, and you eat it every time. Reading the setup and getting out before the follow-up lands is the fight.", Abbrev(math.floor(c.cc.burstAfterAvg + 0.5)))
end)
-- T3-02 -- break-free latency (time from a CC to your next action).
RC.Rule("breakfree", "cc", function(c)
    if not (c.cc.hasTimes and (c.cc.meN or 0) >= 1 and c.cc.breakFreeAvg and c.cc.breakFreeAvg >= 1200) then return end
    return 50 + math.min(15, (c.cc.breakFreeAvg - 1200) / 100),
        string.format("You averaged %.1fs to act after each stun \226\128\148 that is a full burst you absorb before you can respond. Whether it is resource or reaction, closing that gap is where the damage is coming from.", c.cc.breakFreeAvg / 1000)
end)
-- T9-01 / T9-02 -- opponent weapon/role read from the damage types they dealt you.
RC.Rule("oppkind", "opponent", function(c)
    local o = c.opp
    if not (o and o.kind) then return end
    if o.kind == "ranged" then
        -- Deliberately does NOT name a weapon: elemental damage (flame/shock/frost) comes from class
        -- skills, sets, enchants and DoTs just as much as a staff, so inferring "an Inferno Staff" from
        -- fire damage was fabricating gear that wasn't in the fight. Name the problem (range), not the kit.
        return 55 + (o.magicShare or 0) * 15,
            "They fought at range \226\128\148 a kiter. The problem is not your damage, it is that you are playing on their terms; closing the gap cleanly and cutting off their space, without your rotation falling apart while you reposition, is the fight you need to win.",
            "oppkind:ranged"
    elseif o.kind == "melee" then
        return 50 + (o.physShare or 0) * 12,
            "They are a melee brawler who wants to live on top of you \226\128\148 nearly all their damage was physical. Letting them sit in your face plays to their whole game; making them chase, and punishing the moment they close, flips who is uncomfortable.",
            "oppkind:melee"
    end
end)
-- T2-04 -- your active defense is reactive (blocks/dodges land AFTER the first hit). Suppressed for
-- block-weavers: blocking between casts in melee is foundation, not a timing failure -- for a habit
-- blocker the correlation is ~always true by construction and says nothing (Shoyru's call).
RC.Rule("reactivedef", "defense", function(c)
    if c.clutch.meHabit then return end
    local rs = c.clutch.reactiveShare
    if not (rs and (c.clutch.meBlock + c.clutch.meDodge) >= 3 and rs >= 0.6) then return end
    return 48 + rs * 12,
        string.format("%d%% of your blocks and dodges came after the first hit of a combo, not before it \226\128\148 you are defending a beat late. The signs are there to see it coming; you are reacting instead of anticipating.", math.floor(rs * 100 + 0.5))
end)
-- Block-weave discipline (positive) -- numerous blocks spread across the whole fight is the habit
-- working: free mitigation between casts while your damage keeps going out.
RC.Rule("blockweave", "defense", function(c)
    if not (c.clutch.meHabit and c.clutch.meBlock >= 12) then return end
    return 26, string.format("Solid block-weave discipline \226\128\148 %d blocks spread across the whole fight. That's free mitigation between casts without giving up your rotation; keep the habit.", c.clutch.meBlock), "blockweave"
end)
-- T9-04 -- opponent read your WIND-UPS specifically. Raw block-after-your-cast correlation is
-- meaningless in melee (everyone block-weaves; it measured 91-100% on pure habit blockers) -- only
-- blocks concentrated on telegraphed abilities are a read, and reads are baitable.
RC.Rule("oppreactive", "opponent", function(c)
    local w, totB = c.opp.windupBlocked or 0, c.clutch.oppBlock or 0
    if not (w >= 3 and totB > 0 and w / totB >= 0.5) then return end
    return 55, string.format("They blocked your wind-ups specifically \226\128\148 %d blocks on %s. That's a read, and reads are baitable: show them the wind-up, let them commit the block, then land the real hit.", w, c.opp.windupTop or "your telegraphed attacks"), "oppreactive"
end)
-- The light-attack war -- rotation dominance in raw counts, not milliseconds.
RC.Rule("lawar", "weave", function(c)
    local o, i = c.la and c.la.out or 0, c.la and c.la.inn or 0
    if o >= 20 and i >= 8 and o >= i * 1.3 then
        return 30, string.format("You won the light-attack war %d\226\128\147%d \226\128\148 more time on target, more casts carrying a weave. That's rotation dominance, and it compounds.", o, i), "lawar:won"
    elseif i >= 20 and o >= 8 and i >= o * 1.3 then
        return 46, string.format("They out-wove you %d\226\128\147%d \226\128\148 they spent more of the fight on target with a light attack in front of each cast. Close the gap: a weave on every cast, even while repositioning.", i, o), "lawar:lost"
    end
end)
-- The front-bar war (Shoyru): who lives on their pressure bar? Compares front-bar LA share both
-- sides. Only when both sides landed enough weapon attacks for the split to mean something.
RC.Rule("frontbar", "weave", function(c)
    local me, op = c.bars and c.bars.me, c.bars and c.bars.opp
    if not (me and op and me.back and me.frontShare and op.frontShare and (me.laTotal or 0) >= 15 and (op.laTotal or 0) >= 15) then return end
    local ms, os = me.frontShare, op.frontShare
    if ms >= os + 0.25 then
        return 28, string.format("You won the bar war \226\128\148 %d%% of your light attacks came from your %s while they managed only %d%% front-bar time%s. More time on the kill bar is more uptime on offense, and that edge compounds.",
            math.floor(ms * 100 + 0.5), me.front.w,
            math.floor(os * 100 + 0.5),
            op.back and string.format(", spending the rest on their %s backbar under your pressure", op.back.w) or ""), "frontbar:won"
    elseif os >= ms + 0.25 then
        return 44, string.format("They out-camped you on the pressure bar \226\128\148 %d%% of their light attacks were front-bar vs your %d%% (%s). You're living back-barred: buffs up, then get back to the weapon that kills.",
            math.floor(os * 100 + 0.5), math.floor(ms * 100 + 0.5), me.front.w), "frontbar:lost"
    end
end)
-- Combo-scan rules (Shoyru: "we can create multiple rules off of that") -- the same class-signature
-- detection that powers the Matchup note also feeds the main card when the pattern is decisive.
RC.Rule("comboeaten", "defense", function(c)
    local sc = c.combo
    if not (sc and sc.landed >= 2) then return end
    return 64, string.format("You ate %s %d times (up to %s in the follow-up window). It is ANNOUNCED every time \226\128\148 the %s is the tell \226\128\148 and it keeps cashing. Defending at the tell, not the burst, is the whole matchup.",
        sc.combo, sc.landed, Abbrev(sc.maxDmg), sc.tell), "comboeaten"
end)
RC.Rule("combodenied", "defense", function(c)
    local sc = c.combo
    if not (sc and sc.attempts >= 2 and sc.landed == 0 and sc.avoided >= 1) then return end
    return 24, string.format("You blanked %s \226\128\148 %d setups, nothing landed. That's the class's main line of play taken off the table; they have to beat you off-script now.",
        sc.combo, sc.attempts), "combodenied"
end)
-- Outcome cards (Shoyru's call): every WIN says what won it, every LOSS says how you died. High
-- severity + a reserved slot in InsightCards, so the outcome read is always on the card.
RC.Rule("wonon", "arc", function(c)
    if c.du.result ~= "win" then return end
    local ratio = (c.du.dpsOut or 0) / math.max(1, c.du.dpsIn or 0)
    if ratio >= 1.5 then
        return 90, string.format("What won it: the damage war \226\128\148 %.1fx their output (%s out vs %s in). You out-built and out-rotated them; from there the clock did the rest.",
            ratio, Abbrev(c.du.dpsOut or 0), Abbrev(c.du.dpsIn or 0)), "wonon"
    end
    -- Otherwise: the axis furthest above your norm is the decisive edge.
    local norms = RC.DimNorms()
    local topAxis, topDelta
    for _, dm in ipairs(c.dims or {}) do
        local nm = norms and norms[dm.key]
        local delta = nm and (dm.s - nm) or 0
        if not topDelta or delta > topDelta then topDelta, topAxis = delta, dm end
    end
    if topAxis and topDelta >= 10 then
        return 90, string.format("What won it: %s \226\128\148 graded %s, well above your usual. %s",
            topAxis.label, GradeLetter(topAxis.s), topAxis.note or ""), "wonon"
    end
    return 90, string.format("What won it: attrition \226\128\148 you handled everything they had (%s taken) while your own pressure never stopped. Nothing spectacular, everything sufficient \226\128\148 that IS the win condition.",
        Abbrev(c.du.dmgTaken or 0)), "wonon"
end)
RC.Rule("howdied", "arc", function(c)
    if c.du.result ~= "loss" then return end
    local log = c.du.log
    if type(log) ~= "table" or #log == 0 then return end
    local kb
    for i = #log, 1, -1 do local e = log[i]; if e.dir == "in" and (e.val or 0) > 0 then kb = e; break end end
    if not kb then return end
    local windowDmg = 0
    for _, e in ipairs(log) do if e.dir == "in" and (e.val or 0) > 0 and e.t >= kb.t - 4000 and e.t <= kb.t then windowDmg = windowDmg + e.val end end
    local kbName
    for _, a in ipairs(c.du.takenTop or {}) do if a.id == kb.id then kbName = a.name; break end end
    local ccSetup = false
    for _, r in pairs((c.du.cc and c.du.cc.onMe) or {}) do
        if type(r) == "table" and (r.kind == "Stun" or r.kind == "Fear" or r.kind == "Disorient") and r.times then
            for _, t in ipairs(r.times) do if t >= kb.t - 4000 and t <= kb.t then ccSetup = true; break end end
        end
    end
    local defended = false
    for _, r in pairs((c.du.clutch and c.du.clutch.onMe) or {}) do
        if r.times then for _, t in ipairs(r.times) do if t >= kb.t - 4000 and t <= kb.t then defended = true; break end end end
    end
    local when = math.floor((kb.t or 0) / 1000)
    return 92, string.format("How you died: %s%s for %s at %d:%02d, closing a %s window over the final ~4s%s \226\128\148 %s",
        kbName or "their final hit", kb.crit and " (crit)" or "", Abbrev(kb.val or 0), math.floor(when / 60), when % 60, Abbrev(windowDmg),
        ccSetup and ", opened by a hard CC" or "",
        defended and "you were actively defending it and it landed anyway; that is a sustain/positioning loss, not a reaction loss."
            or "with no block or dodge inside it. That window is the read to take into the rematch."), "howdied"
end)
-- T1-02 -- two-ability dependency.
RC.Rule("twothreat", "offense", function(c)
    if not (c.top2 and c.dealtTot > 0 and c.top2OutShare >= 0.70) then return end
    return 55 + c.top2OutShare * 15,
        string.format("Two abilities were %d%% of your damage \226\128\148 one defensive read (block the first, dodge the second) shuts your whole game down. You are too predictable; the pressure has to come from more than one angle.", math.floor(c.top2OutShare * 100 + 0.5))
end)
-- T1-04 -- no damage-over-time pressure.
RC.Rule("nodot", "offense", function(c)
    if not (c.top1 and c.dealtTot > 0 and c.dotShareOut < 0.10) then return end
    return 44,
        "Almost none of your damage ticks over time \226\128\148 everything you throw is a discrete hit they can block or dodge the instant it lands. A purely defensive player can shut you off just by reacting; pressure that keeps working whether or not you are on them would change that."
end)
-- T2-08 -- Major Resolve uptime low.
RC.Rule("resolvelow", "defense", function(c)
    if not (c.resolveUptime > 0.05 and c.resolveUptime < 0.60) then return end
    return 45 + (0.60 - c.resolveUptime) * 25,
        string.format("Major Resolve was up only %d%% of the duel \226\128\148 every second it is down you take meaningfully more damage. That is a large chunk of avoidable damage that never reads as a mistake; it just quietly bleeds you.", math.floor(c.resolveUptime * 100 + 0.5))
end)
-- T2-11 -- one hit took a huge chunk of your health.
RC.Rule("onehit", "defense", function(c)
    local mx = c.du.maxTaken or 0
    local hp = c.du.stats and c.du.stats[21] and c.du.stats[21].avg
    if not (hp and hp > 0 and mx > 0 and mx / hp >= 0.40) then return end
    return 55 + math.min(15, (mx / hp - 0.40) * 40),
        string.format("One hit took roughly %d%% of your health in a single blow \226\128\148 that is the hit that decides the duel, and it has a source and a tell. Everything else is noise next to being ready for that one cast.", math.floor(mx / hp * 100 + 0.5))
end)
-- T4-04 -- sustain to spare (press harder).
RC.Rule("sustainspare", "resource", function(c)
    if not (c.du.timeline and next(c.du.timeline) and (c.res.floor or 0) > 0.60) then return end
    return 28 + (c.res.floor - 0.60) * 20,
        string.format("You never dropped below %d%% on either pool \226\128\148 you have gas you are not using. Playing that safe leaves damage and pressure on the table; you can afford to commit harder than you did.", math.floor((c.res.floor or 0) * 100 + 0.5))
end)
-- T4-12 -- holding ult too long.
RC.Rule("holdult", "resource", function(c)
    if not (c.res.ultHeldSecs and c.res.ultHeldSecs >= 8) then return end
    return 42 + math.min(10, c.res.ultHeldSecs - 8),
        string.format("You sat on a full ultimate for about %ds without using it \226\128\148 a charged ult doing nothing is wasted pressure and a wasted safety net. If the moment never comes, use it to force a window rather than waiting for one.", math.floor(c.res.ultHeldSecs))
end)
-- T4-13 -- lost with resources to spare.
RC.Rule("lostfull", "resource", function(c)
    if not (c.loss and c.du.timeline and next(c.du.timeline) and (c.res.floor or 0) > 0.55) then return end
    return 46,
        "You lost with resources still in the tank \226\128\148 sustain was not the problem, execution was. You had the fuel to defend or burst at the key moment and did something else with it. This one is on the reads, not the bar."
end)
-- T6-05 -- no self-heal (glass).
RC.Rule("noheal", "heal", function(c)
    if not ((c.du.dmgTaken or 0) > 40000 and (c.healReceived or 0) < (c.du.dmgTaken or 0) * 0.05) then return end
    return 44,
        "You barely healed all duel \226\128\148 you are pure glass. That works if you kill fast, but any duel that goes long you lose by default. You are relying entirely on offense to keep you alive, which only holds while it is landing."
end)
-- T7-03 -- offensive buff (Major Sorcery/Brutality) uptime low.
RC.Rule("offbuff", "buff", function(c)
    if not (c.offBuffUptime > 0.05 and c.offBuffUptime < 0.60) then return end
    return 44 + (0.60 - c.offBuffUptime) * 20,
        string.format("Your damage buff (Major Sorcery/Brutality) was up only %d%% of the duel \226\128\148 for the rest, your tooltip is lying to you. That is free damage you already slotted for and are not keeping active.", math.floor(c.offBuffUptime * 100 + 0.5))
end)
-- T7-08 -- Major Defile on you (explains weak heals).
RC.Rule("defileme", "debuff", function(c)
    if not (c.defileOnMe >= 0.40) then return end
    return 46 + c.defileOnMe * 12,
        string.format("They kept Defile on you %d%% of the duel \226\128\148 your healing was cut by up to half, which is why your heals felt useless. That was not your healing failing; it was being suppressed, and dealing with it changes the whole survival math.", math.floor(c.defileOnMe * 100 + 0.5))
end)
-- T8-01 -- front-loaded (sprinter).
RC.Rule("frontload", "arc", function(c)
    if not (c.du.timeline and next(c.du.timeline) and c.windows.totOut > 0 and c.frontLoadOut >= 0.55) then return end
    return 48 + (c.frontLoadOut - 0.55) * 20,
        string.format("You dealt %d%% of your damage in the first third and faded after \226\128\148 you are a sprinter. When the opener does not kill, you do not have a second gear, and the duel keeps going after your best window closes.", math.floor(c.frontLoadOut * 100 + 0.5))
end)
-- T8-02 -- lead-then-collapse.
RC.Rule("leadcollapse", "arc", function(c)
    if not c.lead.collapsed then return end
    return 55,
        string.format("You were up ~%s at the midpoint and lost it from there \226\128\148 something shifts once you are ahead. Recognizing the moment you have the lead, and not throwing it, is the skill this duel is asking for.", Abbrev(c.lead.peak))
end)
-- T8-03 -- comeback (good).
RC.Rule("comeback", "arc", function(c)
    if not c.lead.comeback then return end
    return 26,
        "You were behind at the midpoint and turned it around \226\128\148 that is composure most players do not have. Whatever adjustment you made once you were losing is your real strength; know what it was."
end)
-- T8-11 -- gank-speed duel (one burst decided it).
RC.Rule("gankspeed", "arc", function(c)
    if not (c.dur < 8 and ((c.du.dmgDealt or 0) > 15000 or (c.du.dmgTaken or 0) > 15000)) then return end
    return 32,
        "This one ended almost before it started \226\128\148 a single burst decided it. Fast duels are all about the opener and the first defensive read; there is no mid-game to correct in, so the prep and the first few seconds are everything."
end)
-- T9-11 -- opponent plays pure offense (near-zero active defense).
RC.Rule("oppoffense", "opponent", function(c)
    if not ((c.du.dmgDealt or 0) > 40000 and (c.clutch.oppBlock + c.clutch.oppDodge) == 0) then return end
    return 42,
        "They barely blocked or dodged all duel \226\128\148 a pure-offense player betting they kill you first. That is exploitable: a clean defensive read on their burst flips the whole fight, because they have no backup plan when the trade does not go their way."
end)
-- T3-04 -- CC converted to burst (good).
RC.Rule("ccconvgood", "cc", function(c)
    local burst = c.dimByKey.burst
    if not ((c.cc.oppN or 0) >= 3 and burst and burst.s >= 60) then return end
    return 24,
        string.format("You landed %d hard CCs and cashed them \226\128\148 your burst graded well, so the openings turned into real damage. That is exactly how the trade should work; keep creating and converting those windows.", c.cc.oppN)
end)
-- T3-07 -- CC wasted into immunity.
RC.Rule("ccimmunity", "cc", function(c)
    if not ((c.cc.immunityWaste or 0) >= 1) then return end
    return 40 + math.min(10, c.cc.immunityWaste * 3),
        "You threw a hard CC into their CC immunity \226\128\148 it did nothing. After a hard CC they get a window where they cannot be re-stunned; that window is for damage, not for a CC that is wasted."
end)
-- T3-08 -- one-note CC (predictable).
RC.Rule("onenotecc", "cc", function(c)
    if not ((c.cc.oppN or 0) >= 3 and c.cc.oppKinds == 1) then return end
    return 36,
        "All your hard CC was the same type \226\128\148 a good opponent pre-buffers against the one thing you do. Predictable lockdown lets them plan around it before it even happens."
end)
-- T3-10 -- caught by the same setup.
RC.Rule("caughtsetup", "cc", function(c)
    local r = c.cc.repeatSetup
    if not (r and r.n >= 3) then return end
    return 45 + math.min(12, (r.n - 3) * 3),
        string.format("%s caught you %d times \226\128\148 they are fishing the same setup and you keep walking into it. It is telegraphed; once you know it is their go-to, that animation should change what you do.", r.name or "One ability", r.n)
end)
-- T3-12 -- no hard CC landed (no openings created).
RC.Rule("nohardcc", "cc", function(c)
    if not ((c.du.dmgDealt or 0) > 30000 and (c.cc.oppN or 0) == 0) then return end
    return 44,
        "You landed no hard CC all duel \226\128\148 you created no openings. A stun is how a burst becomes a kill instead of chip; without one, good players just block through your best damage on their own timing."
end)
-- T5-03 -- sloppy weave timing.
RC.Rule("sloppyweave", "weave", function(c)
    if not (c.weaveDelay and c.weaveDelay > 200) then return end
    return 40 + math.min(14, (c.weaveDelay - 200) / 10),
        string.format("Your average weave delay was %dms \226\128\148 you are pausing between the light attack and the skill and losing part of each cast. The rhythm is loose; tightening it is pure free damage.", math.floor(c.weaveDelay))
end)
-- T5-07 -- weaving is a strength (positive).
RC.Rule("weavestrength", "weave", function(c)
    if not (c.weaveRatio and c.weaveRatio >= 0.90 and c.weaveDelay and c.weaveDelay < 130) then return end
    return 24,
        "Your weaving graded high \226\128\148 tight timing on nearly every cast. That is a genuine edge most players do not have; the uptime and pressure it gives you is worth building your game around."
end)
-- T7-09 -- Major Vulnerability kept up (positive).
RC.Rule("vulngood", "debuff", function(c)
    local up = 0
    for _, e in ipairs(c.du.debuffsOpp or {}) do if e.id == 106754 then up = math.min(1, (e.uptime or 0) / 1000 / c.dur); break end end
    if up < 0.50 then return end
    return 22 + up * 12,
        string.format("You kept Major Vulnerability up %d%% of the duel \226\128\148 every burst you landed was amplified. That is the debuff that turns a good combo into a kill; you are prioritizing the thing that matters most.", math.floor(up * 100 + 0.5))
end)
-- T7-11 -- no shred applied at all.
RC.Rule("noshred", "debuff", function(c)
    if (c.du.dmgDealt or 0) <= 30000 then return end
    for _, e in ipairs(c.du.debuffsOpp or {}) do local role = RC.EffKind(e); if role and role ~= "status" then return end end
    return 50,
        "You applied no meaningful debuffs all duel \226\128\148 no Breach, no Vulnerability, nothing that lowers their defenses. You are hitting them at full strength while your build has shred it is not using; this is one of the largest gaps between your damage and your potential."
end)
-- T7-12 -- status pressure kept up (positive).
RC.Rule("statusgood", "debuff", function(c)
    local best = 0
    for _, e in ipairs(c.du.debuffsOpp or {}) do if e.isStatus then best = math.max(best, math.min(1, (e.uptime or 0) / 1000 / c.dur)) end end
    if best < 0.40 then return end
    return 22 + best * 12,
        "You kept real status pressure going on them \226\128\148 that is free, build-agnostic damage and control most players leave on the table; you are collecting it."
end)
-- T9-06 -- opponent relied on DoT pressure.
RC.Rule("oppdot", "opponent", function(c)
    if not (c.opp.dotReliant and (c.takenTot or 0) > 20000) then return end
    return 45 + c.dotShareIn * 12,
        string.format("Most of their damage was DoTs ticking on you (%d%%) \226\128\148 pressure that keeps working whether they are on you or not. If your kit can shed it, great; if not, spacing and denying the reapplication is the answer, because healing through a stream that keeps renewing plays into it.", math.floor(c.dotShareIn * 100 + 0.5))
end)
-- T11-04 -- off night (well below your norm across the board).
RC.Rule("offnight", "stat", function(c)
    if RC.Calibrating() then return end
    local norm = RC.AvgGrade()
    if not norm then return end
    if RC.Overall(c.du, c.dims) > norm - 15 then return end
    return 36,
        "This graded well under your usual across the board \226\128\148 an off night, not a trend. One rough duel is noise; watch for whether it repeats before reading anything into it."
end)
-- T1-05 -- all tick, no kill threat.
RC.Rule("alltick", "offense", function(c)
    local burst = c.dimByKey.burst
    if not (c.top1 and c.dotShareOut >= 0.60 and burst and burst.s < 45) then return end
    return 46,
        string.format("You out-tick but never threaten a kill \226\128\148 %d%% of your damage was DoTs and your burst graded low. Against anyone with a heal, chip alone never closes; they simply out-sustain the ticks.", math.floor(c.dotShareOut * 100 + 0.5))
end)
-- T1-08 -- passive / proc-style reliance (damage you do not actively aim).
RC.Rule("procreliance", "offense", function(c)
    if not (c.top1 and c.dealtTot > 0) then return end
    local nonCrit = 0
    for _, a in ipairs(c.du.dealtTop or {}) do if (a.crit or 0) == 0 and (a.hits or 0) > 0 then nonCrit = nonCrit + (a.total or 0) end end
    local share = nonCrit / c.dealtTot
    if share < 0.55 then return end
    return 40 + share * 12,
        string.format("%d%% of your damage was passive proc-style damage you do not actively aim or time \226\128\148 it pads the meter but you cannot line it up into a kill. The damage you actually control has to be enough to close on its own.", math.floor(share * 100 + 0.5))
end)
-- T3-06 -- you had the interrupt read (positive).
RC.Rule("interruptread", "cc", function(c)
    if not ((c.cc.interruptsOpp or 0) >= 2) then return end
    return 24,
        string.format("You interrupted them %d times \226\128\148 you are reading their casts and denying key abilities. That denial wins duels in ways the damage meter never shows.", c.cc.interruptsOpp)
end)
-- T4-05 -- one skill eats your resource bar.
RC.Rule("spendhog", "resource", function(c)
    if not (c.spendTopShare and c.spendTopShare >= 0.40 and c.spendTopId) then return end
    local nm = (GetAbilityName and GetAbilityName(c.spendTopId)) or "One ability"
    if nm == "" then nm = "One ability" end
    return 40 + c.spendTopShare * 14,
        string.format("%s was %d%% of your resource spend \226\128\148 it is carrying your damage but it is also why you run dry. Getting more out of each cast is what stretches the bar.", nm, math.floor(c.spendTopShare * 100 + 0.5))
end)
-- T4-03 -- ran on empty (a pool spent much of the duel bottomed out).
RC.Rule("ranonempty", "resource", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl)) then return end
    local magMx, stamMx = 0, 0
    for _, b in pairs(tl) do magMx = math.max(magMx, b.mag or 0); stamMx = math.max(stamMx, b.stam or 0) end
    if magMx <= 0 and stamMx <= 0 then return end
    local low, tot = 0, 0
    for s = 0, math.floor(c.dur) do
        local b = tl[s]
        if b then
            tot = tot + 1
            local mf = magMx > 0 and (b.mag or 0) / magMx or 1
            local sf = stamMx > 0 and (b.stam or 0) / stamMx or 1
            if math.min(mf, sf) < 0.30 then low = low + 1 end
        end
    end
    if tot == 0 or low / tot < 0.40 then return end
    return 50,
        string.format("You spent %d%% of the duel with an empty pool \226\128\148 no roll, no break-free, no burst held back. Running that dry means every defensive option is gone exactly when you need one; something in your economy is not sustainable.", math.floor(low / tot * 100 + 0.5))
end)
-- T4-07 -- ult starvation (never generated your closeout).
RC.Rule("ultstarve", "resource", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl) and c.dur >= 25) then return end
    local casts = 0
    for _, b in pairs(tl) do casts = casts + (b.ultCast or 0) end
    if casts > 1 then return end
    return 40,
        string.format("You cast %d ultimate%s the whole duel \226\128\148 your ult economy is starving your best closeout. Ultimate builds from weaving and pressure; if it is never up, part of the reason is upstream in how you generate it.", casts, casts == 1 and "" or "s")
end)
-- T8-04 -- slow starter (ceded the opening).
RC.Rule("slowstart", "arc", function(c)
    if not (c.du.timeline and next(c.du.timeline) and (c.windows.totOut + c.windows.totIn) > 0 and c.slowStart) then return end
    return 42,
        "Almost nothing happened in the first 10 seconds \226\128\148 you gave away the opening. Against burst builds that early tempo is where duels are often decided; feeling it out for free lets them dictate the terms."
end)
-- T8-10 -- never held the lead.
RC.Rule("neverheld", "arc", function(c)
    if not (c.du.timeline and next(c.du.timeline) and c.lead.peak <= 0 and c.lead.trough < -8000) then return end
    return 50,
        "You were behind on the exchange from the first trade to the last \226\128\148 never once ahead. That is not a burst you lost to, it is a tempo you never took; something in your opening cedes control before the fight even develops."
end)
-- T10-03 -- class matchup pattern (your record vs this whole class).
RC.Rule("classmatchup", "matchup", function(c)
    if not c.oppClassId then return end
    local w, l = RC.ClassRecord(c.oppClassId)
    if (w + l) < 4 then return end
    if l > w * 1.5 then
        return 42, string.format("You are %d-%d against this class overall \226\128\148 that is a matchup pattern, not variance. It is worth solving for the class, not just reacting to this one player.", w, l), "classmatchup:l"
    elseif w > l * 1.5 then
        return 22, string.format("You are %d-%d against this class \226\128\148 it suits your game. Know which fights favor you and seek them out.", w, l), "classmatchup:w"
    end
end)
-- T10-07 -- revenge win (beat someone who had a winning record on you).
RC.Rule("revengewin", "matchup", function(c)
    if not (c.win and c.oppRec and (c.oppRec.losses or 0) >= 2 and (c.oppRec.losses or 0) > (c.oppRec.wins or 0)) then return end
    return 22, string.format("You beat someone who has had your number (you are %d-%d against them) \226\128\148 that is real improvement, not luck. The adjustment that got you here is worth holding onto.", c.oppRec.wins or 0, c.oppRec.losses or 0), "revengewin"
end)
-- T10-05 -- nemesis ability (one ability dominates your LOSSES to this opponent).
RC.Rule("nemesis", "matchup", function(c)
    if not (c.oppRec and c.oppRec.duels and #c.oppRec.duels >= 3) then return end
    local byId, total = {}, 0
    for _, d in ipairs(c.oppRec.duels) do
        if d.result == "loss" then
            for _, a in ipairs(d.takenTop or {}) do
                local id = a.id or 0
                byId[id] = { n = a.name or (byId[id] and byId[id].n) or "?", v = ((byId[id] and byId[id].v) or 0) + (a.total or 0) }
                total = total + (a.total or 0)
            end
        end
    end
    local topId, topRec
    for id, r in pairs(byId) do if not topRec or r.v > topRec.v then topRec, topId = r, id end end
    if not (topRec and total > 0 and topRec.v / total >= 0.35) then return end
    return 50, string.format("Across your losses to them, %s did most of the damage \226\128\148 that is a specific, solvable problem. Build or play around that one thing and the matchup can flip.", topRec.n), "nemesis:" .. tostring(topId)
end)
-- T11-09 -- dominant win / clean sheet (won taking very little).
RC.Rule("dominantwin", "stat", function(c)
    if not (c.win and c.oppRec and c.dimByKey.defense and c.dimByKey.defense.s >= 75) then return end
    return 22, "You barely took damage and closed it out \226\128\148 a clean, dominant win. Note what clicked: the spacing, the defensive reads, the tempo. That is the version of your game to reach for, not just admire.", "dominantwin"
end)
-- T11-07 -- on a heater (recent run above your norm).
RC.Rule("heater", "stat", function(c)
    local recent, norm = RC.Trend()
    if not (recent and norm and recent >= norm + 8) then return end
    return 28, "You are on a genuine hot streak \226\128\148 several duels above your norm in a row. If it holds, that is a real level-up, not variance; keep doing what is working.", "heater"
end)
-- T1-03 -- damage-type monoculture.
RC.Rule("monoculture", "offense", function(c)
    if not (c.top1 and c.typeOutTop and c.typeOutTopShare >= 0.80) then return end
    return 52 + c.typeOutTopShare * 12, string.format("%d%% of your damage was %s \226\128\148 against a single resist source or a shield tuned to that school, most of your pressure evaporates. Leaning on one damage type makes you easy to build against; a threat from a different direction is harder to blank.", math.floor(c.typeOutTopShare * 100 + 0.5), RC.DTYPE_NAME[c.typeOutTop] or "one damage type"), "monoculture"
end)
-- T1-06 -- missed the closeout (led, then let the damage taper).
RC.Rule("missedcloseout", "offense", function(c)
    if not (c.du.timeline and next(c.du.timeline) and c.lead.peak >= 15000 and (c.windows.totOut or 0) > 0 and c.lateOutShare < 0.22) then return end
    return 46, "You were ahead but your damage tapered at the end instead of rising \226\128\148 when you have the lead is exactly when duels are won or lost, and coasting hands them time to recover. You are not pressing your advantage when it is biggest.", "missedcloseout"
end)
-- T1-10 -- nothing bypasses block (they turtle and you have no unblockable pressure).
RC.Rule("nobypassblock", "offense", function(c)
    if not (c.top1 and (c.clutch.oppBlock or 0) >= 3 and c.dotShareOut < 0.15) then return end
    return 48, "They blocked a big share of your damage and almost nothing you do goes through block \226\128\148 a patient blocker just switches your offense off. You need a way to make holding block cost them, so the turtle stops being free.", "nobypassblock"
end)
-- T1-11 -- no concentrated burst (peak barely above your average output).
RC.Rule("flatoffense", "offense", function(c)
    if not (c.top1 and c.du.timeline and next(c.du.timeline) and (c.windows.totOut or 0) > 20000 and c.dur >= 8) then return end
    local peak, avg3 = RC.RollingPeak(c.du), c.windows.totOut / c.dur * 3
    if avg3 <= 0 or peak / avg3 >= 1.6 then return end
    return 44, "Your damage was spread evenly with no real spike \226\128\148 your best 3 seconds was barely above your average. Even pressure is fine, but with no concentrated burst there is never a point where they have to panic-defend or die.", "flatoffense"
end)
-- T2-05 -- faced their burst flat-footed (no active defense in their peak window).
RC.Rule("flatfooted", "defense", function(c)
    if not ((c.clutch.meBlock + c.clutch.meDodge) >= 2 and c.clutch.defInPeakWindow == 0 and c.peakInVal and c.peakInVal > 20000) then return end
    return 60, string.format("Their hardest 3 seconds (%s) came with no block or dodge from you at all \226\128\148 you ate the whole combo standing still. That window is where the duel was decided, and you were not defending it.", Abbrev(c.peakInVal)), "flatfooted"
end)
-- T2-06 -- over-blocking / turtling (blocked a lot but were never in real danger). NOT fired at a
-- block-weaver whose resources never suffered -- habit blocking that costs nothing isn't turtling.
RC.Rule("overblock", "defense", function(c)
    if c.clutch.meHabit and (c.res.floor or 1) >= 0.35 then return end
    if not ((c.clutch.meBlock or 0) >= 6 and c.peakInVal and c.peakInVal > 0 and c.windows.totIn > 0 and c.peakInVal / c.windows.totIn < 0.20) then return end
    return 42, "You blocked a lot but were never in real danger \226\128\148 you turtled through pressure you could have ignored and burned the resource you needed to answer with. Block their burst, not their chip.", "overblock"
end)
-- T2-07 -- dodging the wrong things (rolling chip/DoTs instead of the real hits).
RC.Rule("dodgingwrong", "defense", function(c)
    if not ((c.clutch.meDodge or 0) >= 4 and c.dotShareIn >= 0.40) then return end
    return 42, "You rolled a lot but kept taking damage anyway \226\128\148 the dodges are going to chip and DoTs instead of the hits that actually threaten you. The roll is a limited resource, and it is going to the wrong moments.", "dodgingwrong"
end)
-- T2-12 -- blocked yourself out of stamina.
RC.Rule("blockedoutofstam", "defense", function(c)
    if not ((c.clutch.meBlock or 0) >= 5 and c.du.timeline and next(c.du.timeline) and (c.res.floor or 1) < 0.20) then return end
    return 46, "You blocked so much that your stamina was gone when the hit that mattered came \226\128\148 no roll, no break-free left. Blocking everything is not free; spend it on what actually threatens you.", "blockedoutofstam"
end)
-- T2-13 -- zero active defense (played entirely passive).
RC.Rule("zerodefense", "defense", function(c)
    if not ((c.du.dmgTaken or 0) > 40000 and (c.clutch.meBlock + c.clutch.meDodge) == 0) then return end
    return 45, "You did not block or dodge once all duel \226\128\148 you played entirely passive, eating everything and answering only with offense or heals. Against any real burst that is a coin flip you will eventually lose.", "zerodefense"
end)
-- T5-02 -- weaving collapses under pressure (clean free, falls apart when CC'd/chased).
RC.Rule("weaveunderpressure", "weave", function(c)
    if not (c.weaveFreeRatio and c.weavePressuredRatio and c.weaveFreeRatio >= 0.70 and (c.weaveFreeRatio - c.weavePressuredRatio) >= 0.25) then return end
    return 50, string.format("Your weaving is clean when you are free (%d%%) and falls apart when you are pressured (%d%%) \226\128\148 which is exactly when the damage matters most. Holding your mechanics together while moving and after a break-free is the gap between practice numbers and duel numbers.", math.floor(c.weaveFreeRatio * 100 + 0.5), math.floor(c.weavePressuredRatio * 100 + 0.5)), "weaveunderpressure"
end)
-- T5-04 -- animation clipping (casting fast, dropping the light attack).
RC.Rule("clipping", "weave", function(c)
    if not (c.castRate and c.castRate > 1.4 and c.weaveRatio and c.weaveRatio < 0.60) then return end
    return 40, "You are firing skills into each other with no light attack between \226\128\148 casting fast but dropping a full light attack every time you clip. Faster is not more here; a touch slower, letting each weave land, is more damage.", "clipping"
end)
-- T5-06 -- downtime (a stretch with no casts at all).
RC.Rule("downtime", "weave", function(c)
    if not (c.maxCastGap and c.maxCastGap > 3500 and c.dur >= 15) then return end
    return 38, string.format("There was a stretch of about %ds where you cast nothing \226\128\148 repositioning or hesitating. Empty global cooldowns are lost damage in a duel; even while kiting or resetting, something should be going out.", math.floor(c.maxCastGap / 1000)), "downtime"
end)
-- T7-05 -- Off Balance set but never cashed with a heavy attack.
RC.Rule("offbalancewaste", "debuff", function(c)
    local count = 0
    for _, e in ipairs(c.du.debuffsOpp or {}) do if e.id == 45902 then count = e.count or 0 end end
    if not (count >= 2 and (c.heavyShareOut or 0) < 0.05 and (c.du.dmgDealt or 0) > 20000) then return end
    return 42, "You set Off Balance several times and never cashed it with a heavy attack \226\128\148 that is a big free hit plus a stun going unused each time. You are creating the opening and walking straight past it.", "offbalancewaste"
end)
-- T1-07 -- spammable-only offense (chipping steadily, no burst window).
RC.Rule("spammableonly", "offense", function(c)
    local burst = c.dimByKey.burst
    if not (c.top1 and (c.top1.hits or 0) >= 15 and not c.top1.dot and c.top1OutShare >= 0.30 and c.top1OutShare <= 0.65 and burst and burst.s < 45) then return end
    return 46, "Your damage was mostly a spammable and your burst graded low \226\128\148 you are chipping steadily but nothing forces them to panic. Sustained poke is not the same as a threat; you need a real burst window.", "spammableonly"
end)
-- T2-09 -- shield mistiming (wards soaked the chip, were down for the burst). ONLY judged on ACTIVE
-- wards the player casts and times (Hardened Ward, Harness Magicka...). Passive procs -- Concentrated
-- Barrier while blocking, Calculated Defense on any sorc cast, Tri Focus ice heavies -- fire from
-- natural rotation, so "your timing was off" would coach a decision the player never made.
RC.Rule("shieldmistiming", "defense", function(c)
    if not (c.clutch.meActiveWard and (c.clutch.meAbsorbed or 0) > 5000 and c.peakInVal and c.peakInVal > 15000 and c.du.clutch and type(c.du.clutch.onMe) == "table") then return end
    local inWin, tot = 0, 0
    for _, r in pairs(c.du.clutch.onMe) do
        if (r.shield or 0) > 0 and r.name and RC.ACTIVE_WARDS[r.name] and r.times then
            for _, t in ipairs(r.times) do tot = tot + 1; local ts = t / 1000; if ts >= c.peakInStart and ts <= c.peakInStart + 3 then inWin = inWin + 1 end end
        end
    end
    if tot < 2 or inWin / tot >= 0.34 then return end
    return 44, "Your wards soaked most of their damage in the calm and were down when the real burst came \226\128\148 a shield only counts if it is up for the hit that matters. Yours are timed to the chip, not the combo.", "shieldmistiming"
end)
-- T2-03 -- a blockable burst landed at full while you had stamina to defend it.
RC.Rule("blockableburst", "defense", function(c)
    local mt = c.du.maxTaken or 0
    if not (mt > 15000 and c.du.timeline and next(c.du.timeline) and (c.clutch.meBlock + c.clutch.meDodge) == 0) then return end
    local tl = c.du.timeline
    local stamMx = 0; for _, b in pairs(tl) do stamMx = math.max(stamMx, b.stam or 0) end
    local b = tl[c.peakInStart or 0]
    if not (b and stamMx > 0 and (b.stam or 0) / stamMx >= 0.40) then return end
    return 50, "Their biggest hit landed at full force while you still had the stamina to defend it \226\128\148 that is avoidable burst, not unavoidable. It has a tell, and it is a read you can win.", "blockableburst"
end)
-- T6-07 -- healed into the burst (topped off right before eating a spike).
RC.Rule("healedintoburst", "heal", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl) and (c.healReceived or 0) > 15000) then return end
    for s = 0, math.floor(c.dur) - 1 do
        local b = tl[s]
        local heal = b and (b.heal or 0) or 0
        local dmg = ((tl[s + 1] and tl[s + 1].dmgIn) or 0) + ((tl[s + 2] and tl[s + 2].dmgIn) or 0)
        if heal > 8000 and dmg > 18000 then
            return 44, "You healed to full right before eating their burst \226\128\148 the heal went on a health bar you were about to lose anyway. Reading the burst coming and defending it, instead of healing into it, is what that moment needed.", "healedintoburst"
        end
    end
end)
-- T9-03 -- their burst comes on a rhythm (3+ evenly spaced incoming peaks).
RC.Rule("burstcadence", "opponent", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl) and c.dur >= 20) then return end
    local ev = {}
    for s = 0, math.floor(c.dur) - 2 do
        local sum = ((tl[s] and tl[s].dmgIn) or 0) + ((tl[s + 1] and tl[s + 1].dmgIn) or 0) + ((tl[s + 2] and tl[s + 2].dmgIn) or 0)
        if sum > 12000 and (#ev == 0 or s - ev[#ev] >= 4) then ev[#ev + 1] = s end
    end
    if #ev < 3 then return end
    return 44, "Their burst came on a rhythm \226\128\148 you can feel roughly when the next one is coming (their ult or a proc cycling). Defending that window on purpose, instead of getting surprised by it, makes the whole duel easier.", "burstcadence"
end)
-- T10-10 -- off-class performance (you grade above/below your norm vs this class).
RC.Rule("offclassperf", "matchup", function(c)
    if RC.Calibrating() or not c.oppClassId then return end
    local arr = AllDuels()
    local sum, n = 0, 0
    for i = 1, math.min(#arr, RC.WINDOW) do
        if arr[i].du.oppClassId == c.oppClassId then sum = sum + RC.Overall(arr[i].du, RC.Dims(arr[i].du)); n = n + 1 end
    end
    if n < 4 then return end
    local classAvg, norm = sum / n, RC.AvgGrade()
    if not norm or math.abs(classAvg - norm) < 12 then return end
    if classAvg < norm then
        return 40, "You consistently play below your usual level against this class \226\128\148 it exposes a hole in your game. Worth naming so you can prepare for it instead of reacting to it every time.", "offclassperf:low"
    end
    return 22, "You consistently play above your usual level against this class \226\128\148 it suits your game. Know which fights favor you and seek them out.", "offclassperf:high"
end)
-- T1-09 -- light-attack carry (positive) or gap (name-gated; fires in-game).
RC.Rule("lashare", "offense", function(c)
    if not (c.top1 and c.dealtTot > 0) then return end
    if c.laShareOut >= 0.28 then
        return 22, string.format("Light attacks were %d%% of your damage \226\128\148 your weaving is doing real work, and that is a strength worth keeping clean.", math.floor(c.laShareOut * 100 + 0.5)), "lashare:good"
    elseif c.laShareOut > 0 and c.laShareOut < 0.05 then
        return 40, "Light attacks were almost none of your damage \226\128\148 a big share of free damage is going uncollected. Weaving is damage you already built for.", "lashare:low"
    end
end)
-- T1-13 -- heavy-attack reliance (slow, telegraphed pressure).
RC.Rule("heavyreliance", "offense", function(c)
    if not (c.top1 and c.dealtTot > 0 and (c.heavyShareOut or 0) >= 0.35) then return end
    return 40, string.format("A big chunk of your damage came from heavy attacks (%d%%) \226\128\148 they are slow and telegraphed and easy to block or dodge. Leaning on them means low, readable pressure; a heavy should be a moment you steal, not a pillar of your damage.", math.floor(c.heavyShareOut * 100 + 0.5)), "heavyreliance"
end)
-- T8-07 -- let a won duel drag.
RC.Rule("letitdrag", "arc", function(c)
    if not (c.win and c.dur >= 35 and c.du.timeline and next(c.du.timeline) and c.lead.peak >= 20000) then return end
    return 40, "Once you were clearly ahead you let it drag instead of closing \226\128\148 that is time for them to find a comeback or for a third party to arrive. When you have them, the advantage is a clock, and you let it run.", "letitdrag"
end)
-- T9-13 -- opponent execute threat (their damage spiked late).
RC.Rule("executethreat", "opponent", function(c)
    if not (c.du.timeline and next(c.du.timeline) and c.windows.totIn > 30000) then return end
    if (c.windows.lateIn / c.windows.totIn) < 0.45 then return end
    return 46, "Their damage spiked as the duel wore on \226\128\148 a lot of it landed in the final third, the classic execute pattern. Below a certain health you are in their kill zone, so the priority shifts from trading to getting out of execute range before their next cast.", "executethreat"
end)
-- T10-04 -- archetype weakness (you beat one archetype, lose to the other).
RC.Rule("archetypeweak", "matchup", function(c)
    if RC.Calibrating() then return end
    local function kindOf(du)
        local mag, phys = 0, 0
        for _, a in ipairs(du.takenTop or {}) do
            local t = a.dtype
            if t then if RC.DTYPE_MAGIC[t] then mag = mag + (a.total or 0) elseif RC.DTYPE_PHYS[t] then phys = phys + (a.total or 0) end end
        end
        local tot = mag + phys
        if tot <= 0 then return nil end
        if mag / tot >= 0.6 then return "ranged" elseif phys / tot >= 0.6 then return "melee" end
    end
    local arr = AllDuels()
    local rw, rl, mw, ml = 0, 0, 0, 0
    for i = 1, math.min(#arr, RC.WINDOW) do
        local k, res = kindOf(arr[i].du), arr[i].du.result
        if k == "ranged" then if res == "win" then rw = rw + 1 elseif res == "loss" then rl = rl + 1 end
        elseif k == "melee" then if res == "win" then mw = mw + 1 elseif res == "loss" then ml = ml + 1 end end
    end
    if (rw + rl) < 3 or (mw + ml) < 3 then return end
    local rr, mr = rw / (rw + rl), mw / (mw + ml)
    if math.abs(rr - mr) < 0.30 then return end
    if mr > rr then
        return 42, "Across your duels you beat brawlers and lose to kiters \226\128\148 your game wins the fight it can reach and loses the one it cannot. Closing that gap, literally, is your single biggest area to grow.", "archetypeweak:ranged"
    end
    return 42, "Across your duels you handle kiters but lose to brawlers \226\128\148 the ones who get on top of you give you trouble. Creating and holding space is the area to grow.", "archetypeweak:melee"
end)
-- T10-06 -- improving vs this opponent (flipped a losing matchup).
RC.Rule("improvingvs", "matchup", function(c)
    local o = c.oppRec
    if not (o and o.duels and #o.duels >= 4) then return end
    local half = math.floor(#o.duels / 2)
    local recent, early = 0, 0
    for i = #o.duels - math.min(4, half) + 1, #o.duels do local d = o.duels[i]; if d and d.result == "win" then recent = recent + 1 end end
    for i = 1, math.min(4, half) do local d = o.duels[i]; if d and d.result == "loss" then early = early + 1 end end
    if not (recent >= 3 and early >= 2) then return end
    return 22, "You have flipped this matchup \226\128\148 you were losing to them and now you are winning. Whatever you changed stuck, and it probably applies to the whole class, not just this player.", "improvingvs"
end)
-- T10-08 -- small sample caveat.
RC.Rule("smallsample", "matchup", function(c)
    local o = c.oppRec
    if not o then return end
    if ((o.wins or 0) + (o.losses or 0) + (o.draws or 0)) ~= 2 then return end
    return 16, "Only a couple of duels against them so far \226\128\148 not enough to read a pattern into. Do not overhaul anything off a small sample; play a few more before deciding what is real.", "smallsample"
end)
-- T10-09 -- winning this matchup comfortably (positive).
RC.Rule("winstreakvs", "matchup", function(c)
    local o = c.oppRec
    if not (o and (o.wins or 0) >= 3 and (o.wins or 0) > (o.losses or 0) * 2) then return end
    return 20, "You have their number \226\128\148 you are winning this matchup comfortably. You have found something that works against how they play; keep leaning on it.", "winstreakvs"
end)
-- T11-05 -- outlier axis (don't over-read one duel).
RC.Rule("outlier", "stat", function(c)
    if RC.Calibrating() then return end
    local norms = RC.DimNorms()
    local worst, dev = nil, 0
    for _, dm in ipairs(c.dims) do local d = dm.s - (norms[dm.key] or 50); if math.abs(d) > math.abs(dev) then dev, worst = d, dm end end
    if not (worst and math.abs(dev) >= 28) then return end
    return 30, string.format("Your %s this duel was a big outlier from your norm \226\128\148 most likely the matchup, not your play. Weight it lightly; your baseline is the real picture.", worst.label:lower()), "outlier:" .. worst.key
end)
-- T11-08 -- declining trend (grades slipping over the window).
RC.Rule("declining", "stat", function(c)
    local recent, norm = RC.Trend()
    if not (recent and norm and recent <= norm - 8) then return end
    return 34, "Your grade has slipped over your recent duels \226\128\148 not one bad game, a trend. Worth figuring out what changed before it settles into a habit; the axis dropping is where to look.", "declining"
end)
-- T7-04 -- status effects under-firing vs your status chance.
RC.Rule("statuslow", "debuff", function(c)
    local chance = c.du.stats and c.du.stats[25] and c.du.stats[25].avg
    if not (chance and chance >= 20 and (c.du.dmgDealt or 0) > 30000) then return end
    for _, e in ipairs(c.du.debuffsOpp or {}) do if e.isStatus and (e.uptime or 0) > 2000 then return end end
    return 42, "You have decent status chance but barely procced any status effects \226\128\148 your damage types and your build are not lined up to trigger them. There is a source of pressure your character is set up for and is not delivering.", "statuslow"
end)
-- T7-07 -- running the minor version of a key debuff but not the major.
RC.Rule("minoronly", "debuff", function(c)
    local maj, minr = {}, {}
    for _, e in ipairs(c.du.debuffsOpp or {}) do
        local role, w = RC.EffKind(e)
        if role and role ~= "status" and (e.uptime or 0) > 2000 then
            if w and w >= 0.8 then maj[role] = true else minr[role] = true end
        end
    end
    for role in pairs(minr) do if not maj[role] then
        return 40, "You are running the minor version of a key debuff but not the major \226\128\148 the major is worth far more. If your kit can bring it, that is one of the biggest single upgrades available to you.", "minoronly"
    end end
end)
-- T7-10 -- offensive amp buff (Major Berserk/Force) uptime low.
RC.Rule("ampbuffgap", "buff", function(c)
    local function up(id) for _, e in ipairs(c.du.buffsMe or {}) do if e.id == id then return math.min(1, (e.uptime or 0) / 1000 / c.dur) end end return 0 end
    local u = math.max(up(61745), up(61747))
    if not (u > 0.05 and u < 0.60) then return end
    return 40 + (0.60 - u) * 18, string.format("Your damage-amp buff (Major Berserk/Force) was up only %d%% of the duel \226\128\148 the burst windows where it was down hit for noticeably less. That is a multiplier on everything you do; letting it lapse shrinks every number.", math.floor(u * 100 + 0.5)), "ampbuffgap"
end)
-- T8-05 -- win short, lose long (cross-duel sprinter profile).
RC.Rule("sprinter", "arc", function(c)
    if RC.Calibrating() then return end
    local arr = AllDuels()
    local ws, wn, ls, ln = 0, 0, 0, 0
    for i = 1, math.min(#arr, RC.WINDOW) do
        local d = arr[i].du
        if d.result == "win" then ws = ws + (d.durationS or 0); wn = wn + 1
        elseif d.result == "loss" then ls = ls + (d.durationS or 0); ln = ln + 1 end
    end
    if wn < 3 or ln < 3 then return end
    local wavg, lavg = ws / wn, ls / ln
    if lavg < wavg * 1.4 then return end
    return 44, string.format("You win the fast duels and lose the long ones (wins avg %ds, losses avg %ds) \226\128\148 a sprinter in a marathon. Either the fight ends inside your strong window, or you need something to hold once it drags.", math.floor(wavg), math.floor(lavg)), "sprinter"
end)
-- T8-06 -- scrappy (the lead changed hands several times).
RC.Rule("scrappy", "arc", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl)) then return end
    local net, flips, sign = 0, 0, 0
    for s = 0, math.floor(c.dur) do
        local b = tl[s]
        if b then
            net = net + (b.dmgOut or 0) - (b.dmgIn or 0)
            local sg = net > 5000 and 1 or (net < -5000 and -1 or sign)
            if sg ~= sign and sign ~= 0 and sg ~= 0 then flips = flips + 1 end
            if sg ~= 0 then sign = sg end
        end
    end
    if flips < 3 then return end
    return 34, string.format("The lead changed hands %d times \226\128\148 this was a coin flip you happened to land on. Tightening one phase, your opener or your sustain, is what turns coin flips into duels you control.", flips), "scrappy"
end)
-- T8-08 -- stalemate / overtime (long duel, neither closes).
RC.Rule("stalemate", "arc", function(c)
    if not (c.du.timeline and next(c.du.timeline) and c.dur >= 40 and c.windows.totOut > 0 and c.windows.totIn > 0) then return end
    if math.min(c.windows.totOut, c.windows.totIn) / math.max(c.windows.totOut, c.windows.totIn) < 0.85 then return end
    return 38, "This went long with neither of you able to close \226\128\148 two walls grinding. Breaking that is not about more damage, it is about manufacturing a moment: forcing a mistake or a resource dump and making it count.", "stalemate"
end)
-- T9-07 -- their CC style (they kite with roots/snares, not stuns).
RC.Rule("theirccstyle", "opponent", function(c)
    if not (c.du.cc and type(c.du.cc.onMe) == "table") then return end
    local soft, hard = 0, 0
    for _, r in pairs(c.du.cc.onMe) do
        if r.kind == "Snare" or r.kind == "Immobilize" then soft = soft + (r.count or 0)
        elseif RC.HARD_CC[r.kind] then hard = hard + (r.count or 0) end
    end
    if not (soft >= 3 and soft > hard) then return end
    return 42, "They locked you down with roots and snares, not stuns \226\128\148 they are trying to control your movement and kite you. Staying mobile through that is the counter; the exact tool is up to your kit, but the goal is not letting them own the spacing.", "theirccstyle"
end)
-- T9-08 -- they out-sustain you (long duel, loss, you dealt plenty and couldn't close).
RC.Rule("outsustains", "opponent", function(c)
    if not (c.loss and c.dur >= 25 and (c.du.dmgDealt or 0) > 100000) then return end
    return 46, "They never ran out \226\128\148 the duel went long and their pressure never dropped. You are not grinding this one down; against a wall like that, the win comes from a decisive moment, not attrition.", "outsustains"
end)
-- T9-09 -- weapon-combo signature (two magic schools = classic ranged pairing).
RC.Rule("weaponcombo", "opponent", function(c)
    local schools = 0
    for t, v in pairs(c.typeIn or {}) do if RC.DTYPE_MAGIC[t] and v > (c.takenTot or 0) * 0.15 then schools = schools + 1 end end
    if schools < 2 then return end
    return 44, "Their damage came from two different magic schools \226\128\148 the classic ranged pairing (think shock plus frost). Expect a hard CC into a delayed burst; keeping your mitigation up and not getting caught out of position is the read.", "weaponcombo"
end)
-- T3-09 -- kite control (you kept snare/root on THEM, positive).
RC.Rule("kitecontrol", "cc", function(c)
    local ms = 0
    if c.du.cc and type(c.du.cc.onOpp) == "table" then
        for _, r in pairs(c.du.cc.onOpp) do if r.kind == "Snare" or r.kind == "Immobilize" then ms = ms + (r.uptime or 0) end end
    end
    local frac = ms / 1000 / c.dur
    if frac < 0.50 then return end
    return 24, string.format("You kept them snared or rooted %d%% of the duel \226\128\148 strong control of the space. If you are the one at range that leash is your whole game; if not, it is setup you should be cashing into damage.", math.floor(math.min(1, frac) * 100 + 0.5)), "kitecontrol"
end)
-- T3-11 -- a stun timed to a delayed detonation on you (Curse/PL/shalk archetype).
RC.Rule("detonationstun", "cc", function(c)
    if not (c.cc.hasTimes and #c.cc.meTimes > 0) then return end
    local ends = {}
    for _, e in ipairs(c.du.debuffsMe or {}) do for _, iv in ipairs(e.intervals or {}) do ends[#ends + 1] = iv.e end end
    if #ends == 0 then return end
    local hits = 0
    for _, t in ipairs(c.cc.meTimes) do
        for _, we in ipairs(ends) do if math.abs(t - we) <= 1200 then hits = hits + 1; break end end
    end
    if hits < 1 then return end
    return 55, "The stun that caught you landed right as a delayed effect on you was about to go off \226\128\148 that timing is the whole setup. Curse, Purifying Light, the second shalk: the good ones line the stun up with the detonation so you eat both at once. Feeling that clock and defending the two together is the read.", "detonationstun"
end)
-- T4-02 -- opener over-commitment (pool bottomed in the first third).
RC.Rule("openerdump", "resource", function(c)
    if not (c.du.timeline and next(c.du.timeline) and c.res.floorAtSec and (c.res.floorFrac or 1) < 0.30 and c.res.floorAtSec < c.dur / 3) then return end
    return 48, "You dumped most of your resource in the opening \226\128\148 your pool bottomed out in the first third going for an early kill. When the opener does not land you are broke for the part of the fight that decides it. Pace the aggression to the length of the duel.", "openerdump"
end)
-- T4-06 -- broke when their burst came (empty pool in their peak window).
RC.Rule("brokewhenburst", "resource", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl) and c.peakInVal and c.peakInVal > 15000) then return end
    local magMx, stamMx = 0, 0
    for _, b in pairs(tl) do magMx = math.max(magMx, b.mag or 0); stamMx = math.max(stamMx, b.stam or 0) end
    local b = tl[c.peakInStart]
    if not b then return end
    local mf = magMx > 0 and (b.mag or 0) / magMx or 1
    local sf = stamMx > 0 and (b.stam or 0) / stamMx or 1
    if math.min(mf, sf) >= 0.20 then return end
    return 58, "You were out of resource exactly when their burst landed \226\128\148 no roll available for the hit that mattered. You are spending your defensive lifeline on offense; something has to stay in reserve for the burst you know is coming.", "brokewhenburst"
end)
-- T4-08 -- ult with no payoff (spent an ult, burst still low).
RC.Rule("ultnopayoff", "resource", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl)) then return end
    local casts = 0; for _, b in pairs(tl) do casts = casts + (b.ultCast or 0) end
    local burst = c.dimByKey.burst
    if not (casts >= 1 and burst and burst.s < 45) then return end
    return 44, "You spent an ultimate and your burst still graded low \226\128\148 it whiffed or landed into block. Your ult is your highest-value moment; throwing it at a defended target wastes the one thing that should be closing the duel.", "ultnopayoff"
end)
-- T4-10 -- never disengaged to recover (traded non-stop the whole duel).
RC.Rule("neverdisengaged", "resource", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl) and c.dur >= 25) then return end
    for s = 3, math.floor(c.dur) - 3 do
        local b = tl[s]
        if not b or ((b.dmgOut or 0) == 0 and (b.dmgIn or 0) == 0) then return end
    end
    return 42, "You traded non-stop and never broke off to recover \226\128\148 against a sustain build, refusing to reset the tempo loses the attrition math by default. Sometimes the winning move is to stop trading for a beat.", "neverdisengaged"
end)
-- T6-02 -- healing mistimed vs their burst (heals in the calm, not the danger).
RC.Rule("healmistimed", "heal", function(c)
    local tl = c.du.timeline
    if not (tl and next(tl) and (c.healReceived or 0) > 20000 and c.peakInVal and c.peakInVal > 15000) then return end
    local totHeal, winHeal = 0, 0
    for s = 0, math.floor(c.dur) do
        local b = tl[s]
        if b then totHeal = totHeal + (b.heal or 0); if s >= c.peakInStart and s <= c.peakInStart + 3 then winHeal = winHeal + (b.heal or 0) end end
    end
    if totHeal <= 0 or winHeal / totHeal >= 0.10 then return end
    return 46, "Your heals landed in the calm and you were low again by the time their burst hit \226\128\148 a heal only matters relative to the damage, and yours are timed to the lulls, not the moments you are actually in danger.", "healmistimed"
end)
-- T6-03 -- turtled without offense (healed hard, dealt little).
RC.Rule("turtlenooffense", "heal", function(c)
    if not (c.loss and (c.healReceived or 0) > 30000 and (c.du.dmgDealt or 0) > 0 and (c.healReceived or 0) > (c.du.dmgDealt or 0) * 0.6) then return end
    return 44, "You spent the duel healing hard and dealing little \226\128\148 you survived but handed them a free reset. Healing keeps you alive; it does not win the duel. Without a threat back, you are only delaying the same problem.", "turtlenooffense"
end)
-- T6-04 -- healing through DoTs (no cleanse, no spacing).
RC.Rule("dotheal", "heal", function(c)
    if not (c.dotShareIn >= 0.40 and (c.healReceived or 0) > 20000 and (c.takenTot or 0) > 30000) then return end
    return 46, "You spent the duel healing through DoTs ticking on you \226\128\148 most builds cannot just cleanse it, so denying the reapplication with spacing beats out-healing a stream that keeps refreshing. The problem is the ticks, not your health bar.", "dotheal"
end)
-- T2-10 -- lost to chip, not burst (incoming damage was an even stream).
RC.Rule("chipdeath", "defense", function(c)
    if not (c.loss and c.du.timeline and next(c.du.timeline) and c.windows.totIn > 30000 and c.peakInVal and c.peakInVal > 0) then return end
    if c.peakInVal / c.windows.totIn >= 0.30 then return end
    return 47, "You did not lose to a burst \226\128\148 the damage came in an even stream and ground you down. This is a positioning and tempo problem, not a defensive-reaction one; trading evenly was a losing trade, and the rhythm needed breaking, not out-blocking.", "chipdeath"
end)
-- T3-13 -- you were kited (snare/root uptime on YOU was high).
RC.Rule("youwerekited", "cc", function(c)
    local ms = 0
    if c.du.cc and type(c.du.cc.onMe) == "table" then
        for _, r in pairs(c.du.cc.onMe) do
            if r.kind == "Snare" or r.kind == "Immobilize" or r.kind == "Silence" then ms = ms + (r.uptime or 0) end
        end
    end
    local frac = ms / 1000 / c.dur
    if frac < 0.50 then return end
    return 48, string.format("You spent %d%% of the duel snared or rooted \226\128\148 they controlled the spacing and you fought at the range they wanted. The control on you, not your damage, was the problem.", math.floor(math.min(1, frac) * 100 + 0.5)), "youwerekited"
end)
-- T4-09 -- hybrid double-bar tax (both pools worked hard).
RC.Rule("hybridtax", "resource", function(c)
    local r = c.du.resources
    if type(r) ~= "table" then return end
    local m = (r[COMBAT_MECHANIC_FLAGS_MAGICKA] and r[COMBAT_MECHANIC_FLAGS_MAGICKA].drains) or 0
    local s = (r[COMBAT_MECHANIC_FLAGS_STAMINA] and r[COMBAT_MECHANIC_FLAGS_STAMINA].drains) or 0
    if not (m > 20000 and s > 20000 and math.min(m, s) / math.max(m, s) >= 0.5) then return end
    return 36, "You leaned hard on both magicka and stamina \226\128\148 the hybrid tax means neither pool runs deep. If the payoff is not there, you are paying the cost of two resources without the depth of one.", "hybridtax"
end)
-- T6-06 -- out-healed (their sustained damage beat your healing + mitigation).
RC.Rule("outhealed", "heal", function(c)
    local heal = (c.healReceived or 0) + (c.clutch.meAbsorbed or 0)
    if not (c.loss and heal > 10000 and (c.du.dmgTaken or 0) > heal * 1.3) then return end
    return 48, "Their sustained damage beat your healing and mitigation combined \226\128\148 you were slowly losing the entire time. You cannot out-heal this one; the math only changes if you take less or end it faster.", "outhealed"
end)
-- T8-09 -- lost the opening exchange.
RC.Rule("lostopening", "arc", function(c)
    if not (c.du.timeline and next(c.du.timeline) and (c.windows.earlyOut + c.windows.earlyIn) > 10000) then return end
    if (c.windows.earlyIn - c.windows.earlyOut) < 8000 then return end
    return 42, "They won the opening exchange and set the tone \226\128\148 you spent the rest of the duel a step behind, reacting to their tempo. Whoever wins the first real trade usually dictates the fight, and you handed them that.", "lostopening"
end)
-- T7-02 -- multiple key debuffs kept at low uptime.
RC.Rule("multidebuffgap", "debuff", function(c)
    local lowKeys = 0
    for _, e in ipairs(c.du.debuffsOpp or {}) do
        local role = RC.EffKind(e)
        if role and role ~= "status" and math.min(1, (e.uptime or 0) / 1000 / c.dur) < 0.50 then lowKeys = lowKeys + 1 end
    end
    if lowKeys < 2 then return end
    return 52, "You kept two or more key debuffs at low uptime \226\128\148 a big chunk of your potential damage never happened. The shred is there to be applied; it is just not staying on the target.", "multidebuffgap"
end)
-- T11-06 -- inconsistent (your grades swing widely across the window).
RC.Rule("inconsistent", "stat", function(c)
    if RC.Calibrating() then return end
    local arr = AllDuels()
    local n = math.min(#arr, RC.WINDOW)
    if n < 10 then return end
    local sum, sum2 = 0, 0
    for i = 1, n do local s = RC.Overall(arr[i].du, RC.Dims(arr[i].du)); sum = sum + s; sum2 = sum2 + s * s end
    local mean = sum / n
    local sd = math.sqrt(math.max(0, sum2 / n - mean * mean))
    if sd < 15 then return end   -- recalibrated 18->15: the overall scale compressed when the raw-outcome weight dropped 30%->15%
    return 30, "Your duel-to-duel grades swing widely \226\128\148 a high ceiling and a low floor. In PvP, consistency beats peaks; the fundamentals that do not depend on the matchup are where that tightens up.", "inconsistent"
end)
-- T11-10 -- best/worst-graded duel on record.
RC.Rule("bestworst", "stat", function(c)
    if RC.Calibrating() or not c.oppRec then return end
    local arr = AllDuels()
    if #arr < 10 then return end
    local mine = RC.Overall(c.du, c.dims)
    local best, worst = true, true
    for i = 1, math.min(#arr, 50) do
        if arr[i].du ~= c.du then
            local s = RC.Overall(arr[i].du, RC.Dims(arr[i].du))
            if s >= mine then best = false end
            if s <= mine then worst = false end
        end
    end
    if best then return 28, "This was your best-graded duel on record \226\128\148 the outliers are where the lessons are loudest; a peak shows what your ceiling looks like when it all lines up.", "bestworst:best"
    elseif worst then return 34, "This was your worst-graded duel on record \226\128\148 a trough shows exactly which piece fell out. Worth a look while it is fresh.", "bestworst:worst" end
end)
-- T11-03 -- personal best (an axis is your highest in the recent window).
RC.Rule("personalbest", "stat", function(c)
    if RC.Calibrating() or not c.oppRec then return end
    local arr = AllDuels()
    if #arr < 10 then return end
    for _, key in ipairs({ "burst", "offense" }) do
        local mine = c.dimByKey[key]
        if mine and mine.s >= 70 then
            local top = true
            for i = 1, math.min(#arr, 30) do
                if arr[i].du ~= c.du then
                    for _, d in ipairs(RC.Dims(arr[i].du)) do if d.key == key and d.s >= mine.s then top = false; break end end
                end
                if not top then break end
            end
            if top then
                return 26, string.format("Your %s this duel was the highest in your last 30 \226\128\148 that is your ceiling showing. Figure out what lined up to make it happen and you can chase it on purpose.", mine.label:lower()), "personalbest:" .. key
            end
        end
    end
end)

-- Public insight list = legacy rules + registry rules (deduped by key), ranked. Every entry carries a
-- `cat` for category-diverse card selection.
function RC.Insights(du)
    local out = RC.LegacyInsights(du)
    local seen = {}
    for _, ins in ipairs(out) do ins.cat = ins.cat or RC.CatOf(ins.key); seen[ins.key] = true end
    local c = RC.Ctx(du)
    for _, r in ipairs(RC.RULES) do
        local ok, sev, text, key = pcall(r.fn, c)
        key = key or r.id
        if ok and sev and text and not seen[key] then
            out[#out + 1] = { sev = sev, key = key, cat = r.cat, text = text }; seen[key] = true
        end
    end
    table.sort(out, function(a, b) return a.sev > b.sev end)
    return out
end
-- Insight keys shown for the duel immediately BEFORE this one, for cross-duel novelty. (arr is
-- newest-first, so the previous duel is at index+1.)
function RC.PrevInsightKeys(du)
    local arr = AllDuels()
    for i = 1, #arr do
        if arr[i].du == du then
            local p = arr[i + 1]
            if not p then return {} end
            local set = {}
            for _, ins in ipairs(RC.Insights(p.du)) do set[ins.key] = true end
            return set
        end
    end
    return {}
end
-- Keys that RECURRED across your last `need` duels (a genuine streak, not a one-off). arr is newest-first,
-- so the duels immediately before `du` are at index+1, index+2, ... Returns {} until there's enough history.
function RC.RecurringKeys(du, need)
    need = need or 2
    local arr = AllDuels()
    for i = 1, #arr do
        if arr[i].du == du then
            local counts = {}
            for j = 1, need do
                local p = arr[i + j]
                if not p then return {} end
                for _, ins in ipairs(RC.Insights(p.du)) do counts[ins.key] = (counts[ins.key] or 0) + 1 end
            end
            local set = {}
            for k, n in pairs(counts) do if n >= need then set[k] = true end end
            return set
        end
    end
    return {}
end
-- Final cards: rank, GUARANTEE a "vs your average" tip when a meaningful deviation exists, and flag ONE
-- genuinely persistent problem (recurred across your last TWO duels) with an "Again --" prefix so it
-- escalates. A recurring issue is demoted slightly so fresh reads still surface. Returns the top maxN.
function RC.InsightCards(du, maxN)
    maxN = maxN or 4
    local list = RC.Insights(du)
    local recur = RC.RecurringKeys(du, 2)
    -- Outcome cards (wonon/howdied) are structural, not recurring problems: no novelty penalty, no "Again --".
    recur.wonon, recur.howdied = nil, nil
    for _, ins in ipairs(list) do if recur[ins.key] then ins.sev = ins.sev - 6 end end
    table.sort(list, function(a, b) return a.sev > b.sev end)
    local uniq, seen = {}, {}
    for _, ins in ipairs(list) do if not seen[ins.key] then seen[ins.key] = true; uniq[#uniq + 1] = ins end end
    -- Pick the top maxN with CATEGORY DIVERSITY: prefer a fresh lens before doubling up, so a card set
    -- never reads as three variations of the same point. Backfill by severity if diversity runs short.
    local cards, usedCat, inSet = {}, {}, {}
    for _, ins in ipairs(uniq) do
        if #cards >= maxN then break end
        local cat = ins.cat or "misc"
        if not usedCat[cat] then usedCat[cat] = true; cards[#cards + 1] = ins; inSet[ins] = true end
    end
    for _, ins in ipairs(uniq) do
        if #cards >= maxN then break end
        if not inSet[ins] then cards[#cards + 1] = ins; inSet[ins] = true end
    end
    -- Reserve a slot for the best vs-average tip if it didn't already make the cut.
    local hasVs = false
    for _, c in ipairs(cards) do if c.key:find("^vsnorm") then hasVs = true; break end end
    if not hasVs then
        for _, ins in ipairs(uniq) do
            if ins.key:find("^vsnorm") then
                if #cards >= maxN then cards[#cards] = ins else cards[#cards + 1] = ins end
                break
            end
        end
    end
    -- Reserve a slot for the OUTCOME card: every win says what won it, every loss says how you died.
    -- (High severity means it's usually already in; this is the guarantee.) Evicts the last card that
    -- isn't the guaranteed vs-average tip.
    local wantKey = (du.result == "win") and "wonon" or (du.result == "loss") and "howdied" or nil
    if wantKey then
        local have = false
        for _, cd in ipairs(cards) do if cd.key == wantKey then have = true; break end end
        if not have then
            for _, ins in ipairs(uniq) do
                if ins.key == wantKey then
                    if #cards < maxN then cards[#cards + 1] = ins
                    else
                        for i = #cards, 1, -1 do
                            if not cards[i].key:find("^vsnorm") then cards[i] = ins; break end
                        end
                    end
                    break
                end
            end
        end
    end
    -- Tag ONLY the single most-severe card that recurred (cards are already sev-ordered) as "Again --".
    for _, ins in ipairs(cards) do if recur[ins.key] then ins.repeated = true; break end end
    local out = {}
    for _, ins in ipairs(cards) do
        out[#out + 1] = { key = ins.key, sev = ins.sev, cat = ins.cat, text = ins.repeated and ("Again \226\128\148 " .. ins.text) or ins.text }
    end
    return out
end
local function GradeItems(du)
    local items = {}
    if RC.Calibrating() then   -- tab is locked in the UI; this only feeds the search index
        items[#items + 1] = { left = string.format("Report Card unlocks after %d duels (%d/%d).", RC.MINCAL, RC.DuelCount(), RC.MINCAL) }
        return items
    end
    local dims = RC.Dims(du)
    local overall = RC.Overall(du, dims)
    local gl = GradeLetter(overall)
    local opp = (currentDuel and currentDuel.o and (currentDuel.o.handle or currentDuel.o.name)) or "my opponent"
    local outLbl = (du.result == "win" and "Won") or (du.result == "draw" and "Draw") or "Lost"
    -- YOUR NORM (median-window grade) + a TREND (recent vs norm), so THIS duel reads against your norm.
    local normScore = RC.AvgGrade()
    local normGl = normScore and GradeLetter(normScore) or nil
    local recent, norm = RC.Trend()
    local trendV, trendC = "\226\134\146 Steady", C.mid
    if recent and norm then
        local d = recent - norm
        if d >= 2 then trendV, trendC = "\226\134\145 Improving", C.win
        elseif d <= -2 then trendV, trendC = "\226\134\147 Falling off", C.loss end
    end
    items[#items + 1] = { tiles = {
        { l = "THIS DUEL",    v = string.format("%s  |c8a8f9a%d/100|r", gl, math.floor(overall + 0.5)), c = RC.Color(gl),
          tip = "This duel's overall grade, out of 100.\nRight-click to post to chat.",
          post = string.format("my duel vs %s was graded %s (%d/100).", opp, gl, math.floor(overall + 0.5)) },
        { l = "OUTCOME",      v = outLbl,                               c = (du.result == "win" and C.win) or (du.result == "draw" and C.draw) or C.loss },
        { l = "YOUR NORM",    v = normGl and string.format("%s  |c8a8f9a%d/100|r", normGl, math.floor(normScore + 0.5)) or "\226\128\148",
          c = normGl and RC.Color(normGl) or C.lo,
          tip = string.format("Your typical grade \226\128\148 the median of your last %d duels. This duel is scored against it (50 = your usual).", math.min(RC.DuelCount(), RC.WINDOW)),
          post = normGl and string.format("my norm is %s (%d/100) over my last %d duels.", normGl, math.floor(normScore + 0.5), math.min(RC.DuelCount(), RC.WINDOW)) or nil },
        { l = "TREND",        v = trendV, c = trendC,
          tip = "Your last 10 duels' average grade vs your norm.\n\226\134\145 Improving = recently grading above your usual\n\226\134\147 Falling off = recently below\n\226\134\146 Steady = about the same as your norm",
          post = "my recent duels are " .. trendV:gsub("^%S+%s*", "") .. " vs my norm." },
    } }
    items[#items + 1] = { header = true, left = "Report Card" }
    -- Per-axis YOUR AVG (Shoyru): each strength shows your average for THAT strength across the
    -- baseline window, so a row reads "B+ ... your avg C+" at a glance without leaving the card.
    local dimNorms = RC.DimNorms()
    items[#items + 1] = { colHeader = true, srcLabel = "Strength", colTitles = { "GRADE", "SCORE", "YOUR AVG" },
        colAlign = { TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT } }
    for i, dm in ipairs(dims) do
        local dl = GradeLetter(dm.s)
        local col = RC.Color(dl)
        local nv = dimNorms and dimNorms[dm.key]
        -- Strength row: name | grade (left-aligned so letters line up A+..F) | score / 100 | your avg.
        -- No rule of its own; a separator divides one strength from the next so the grade groups with
        -- ITS name.
        items[#items + 1] = { left = dm.label, boldCol = 1, noRule = true,
            colAlign = { TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT },
            cols = { "|c" .. Hex(col) .. dl .. "|r", string.format("%d|c6a6f78 / 100|r", math.floor(dm.s + 0.5)),
                nv and string.format("|c8a8f9a%s (%d)|r", GradeLetter(nv), math.floor(nv + 0.5)) or "\226\128\148" } }
        items[#items + 1] = { left = "   " .. RC.Bar(dm.s, col) .. "  |c8a8f9a" .. dm.note .. "|r", wrap = true }
        if i < #dims then items[#items + 1] = { separator = true } end
    end
    -- Insights: personalized, duel-specific reads (see RC.Insights). Weakest strength gives a fallback
    -- so the section is never empty even on a clean duel; the fallback still cites this duel's number.
    items[#items + 1] = { header = true, left = "What this duel tells you" }
    local cards = RC.InsightCards(du, 4)
    if #cards > 0 then
        for _, ic in ipairs(cards) do
            items[#items + 1] = { bullet = "|cf0c060\226\128\162|r", left = ic.text, wrap = true }
        end
    else
        -- No rule fired -- surface the single weakest strength with its real number, or praise a clean sheet.
        local low = dims[1]
        for _, dm in ipairs(dims) do if dm.s < low.s then low = dm end end
        if low and low.s < 60 then
            items[#items + 1] = { bullet = "|cf0c060\226\128\162|r", left = string.format("Your weakest axis was %s (%s). %s", low.label, GradeLetter(low.s), low.note), wrap = true }
        else
            items[#items + 1] = { left = "|c7fbf7fClean sheet \226\128\148 no axis is dragging you down and nothing stood out as a fixable mistake this duel.|r", wrap = true }
        end
    end
    -- Matchup notes (Shoyru): DATA-VERIFIED first -- did THIS opponent actually run their class's
    -- textbook combo, did it land, did you answer it? Falls back to the curated rotating class read
    -- when we have no combo signature (or no class). So the 5th tip is always class-specific, but
    -- grounded in what actually happened instead of repeating the same stereotype every fight.
    -- Same-class fight -> the mirror lens pre-empts the (descriptive) class read with a comparative one.
    local mirror = RC.MirrorRead(du)
    local mread = not mirror and RC.MatchupRead(du) or nil
    local ctip = (not mirror) and du.oppClassId and RC.ClassTip(du.oppClassId, math.floor((du.date or 0))) or nil
    local read = mirror or mread or ctip
    if read then
        items[#items + 1] = { header = true, left = "Matchup notes" }
        items[#items + 1] = { bullet = "|c8ab4f8\194\187|r", left = read, wrap = true }
    end
    items[#items + 1] = { left = "" }
    items[#items + 1] = { left = "|c777777Opponent raw stats (spell damage, penetration, crit, resistances) are hidden by the ESO API, so grading uses observable results \226\128\148 your DPS, damage taken, uptimes, burst and outcome.|r", wrap = true }
    return items
end

-- ===========================================================================
-- BUILD tab (gear, sets & CP from the LibCombat fight snapshot)
-- ===========================================================================
local SB = {}   -- build-share namespace (chat links + viewer) — functions defined near EOF
local BD = {}   -- Build-tab two-column pane (controls created in BuildWindow)
-- qOverride: shared builds reconstruct item links minimally (quality isn't encodable in
-- them), so the decoded quality value is passed in directly instead of read off the link.
local function ItemQualityColorize(link, text, qOverride)
    local q = qOverride
    if not q then
        local ok = pcall(function() q = (GetItemLinkFunctionalQuality and GetItemLinkFunctionalQuality(link)) or GetItemLinkQuality(link) end)
        if not ok then q = nil end
    end
    if q then
        local cok, col = pcall(GetItemQualityColor, q)
        if cok and col and col.Colorize then return col:Colorize(text) end
    end
    return text
end
-- Build-tab content in TWO columns: LEFT = character/sets/gear, RIGHT = bars + champion.
-- BuildItems() concatenates them for the single-column consumers (share viewer, search, tests).
function BD.Cols(du)
    local b = du.build
    if not (b and b.equip) then
        return { { header = true, left = "Build" },
                 { left = "|c999999No build snapshot for this duel \226\128\148 LibCombat wasn't active.|r" } }, {}, nil
    end
    local equip = b.equip
    local setCount, setName, setMax, setLink, setOrder, gear = {}, {}, {}, {}, {}, {}
    for slot, link in pairs(equip) do
        if type(link) == "string" and link ~= "" then
            local hasSet, sName, _, _, maxEq, setId = GetItemLinkSetInfo(link, false)
            if hasSet and setId and setId ~= 0 then
                local inc = (GetItemLinkEquipType(link) == EQUIP_TYPE_TWO_HAND) and 2 or 1
                if not setCount[setId] then
                    setCount[setId] = 0; setName[setId] = zo_strformat("<<1>>", sName)
                    setLink[setId] = link   -- representative piece: right-click a set row -> link it in chat
                    -- Completion threshold from the API: 5 for normal sets, 2 for monster/arena, 1 for mythics.
                    setMax[setId] = (maxEq and maxEq > 0) and maxEq or 5
                    setOrder[#setOrder+1] = setId
                end
                setCount[setId] = setCount[setId] + inc
            end
            local nm = zo_strformat("<<1>>", GetItemLinkName(link))
            local fx = b.linkFix and b.linkFix[slot]      -- shared build: decoded quality/trait
            local trait = GetItemLinkTraitType(link)
            if (not trait or trait == 0) and fx and fx.t and fx.t ~= 0 then trait = fx.t end
            local traitStr = (trait and trait ~= 0) and (" |c565b66\226\128\162 " .. zo_strformat("<<1>>", GetString("SI_ITEMTRAITTYPE", trait)) .. "|r") or ""
            -- Exact enchant: NAME (header, "... Enchantment" trimmed — CMX pattern) coloured by
            -- GLYPH QUALITY (gold = Truly Superb tier; the game doesn't keep the glyph's item name
            -- after application, only the enchant + quality), then the value in parentheses.
            local enchStr = ""
            pcall(function()
                local hasE, header, desc = GetItemLinkEnchantInfo(link)
                if not hasE then return end
                local nm2 = (header and header ~= "") and zo_strformat("<<1>>", header):gsub("%s*[Ee]nchantment%s*$", "") or ""
                if nm2 ~= "" and GetEnchantQuality then
                    local qok, q = pcall(GetEnchantQuality, link)
                    if qok and q then
                        local cok, col = pcall(GetItemQualityColor, q)
                        if cok and col and col.Colorize then nm2 = col:Colorize(nm2) end
                    end
                end
                -- Enchant VALUE. Multi-Effect glyphs (Chudan, Serpent's Disdain tri-stat, Prismatic)
                -- return a MULTI-LINE desc -- one "Adds X ..." clause per stat -- which otherwise stacks
                -- onto 2-3 rows with the first row half-empty. Flatten to ONE line: strip every "Adds",
                -- drop the sentence periods, join the stat clauses with " \194\183 ", shorten "Maximum" -> "Max".
                local vals = ""
                if desc and desc ~= "" then
                    vals = zo_strformat("<<1>>", desc)
                    vals = vals:gsub("Adds%s+", "")                    -- every clause, not just the first
                    vals = vals:gsub("%s*%.", "")                      -- the period ending each clause
                    vals = vals:gsub("Maximum", "Max")
                    vals = vals:gsub("%s*[\r\n]+%s*", " \194\183 ")    -- line breaks -> " \194\183 " (mid-dot)
                    vals = vals:gsub("%s%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
                    vals = vals:gsub("%s*\194\183%s*$", "")            -- drop a dangling separator (desc ended in a newline)
                end
                -- INLINE (bullet separator) so a gear piece fits on ONE row where it can, instead of
                -- forcing the enchant onto a 2nd line (which made the left column scroll).
                local SEP = "  |c565b66\226\128\162|r  "
                if nm2 ~= "" and vals ~= "" then enchStr = SEP .. nm2 .. " |c6f9f8f(" .. vals .. ")|r"
                elseif nm2 ~= "" then enchStr = SEP .. nm2
                elseif vals ~= "" then enchStr = SEP .. "|c6f9f8f" .. vals .. "|r" end
            end)
            gear[#gear+1] = { slot = slot, link = link, icon = GetItemLinkIcon(link),
                text = ItemQualityColorize(link, nm, fx and fx.q) .. traitStr .. enchStr,
                right = zo_strformat("<<1>>", GetString("SI_EQUIPSLOT", slot)) }
        end
    end
    table.sort(gear, function(a, b2) return a.slot < b2.slot end)
    table.sort(setOrder, function(a, b2) return setCount[a] > setCount[b2] end)
    local items = {}
    -- headline tiles (SETS is postable: "my build ran 5× X, 5× Y, ...")
    local setsPost
    if #setOrder > 0 then
        local parts = {}
        for _, id in ipairs(setOrder) do parts[#parts+1] = string.format("%d\195\151 %s", setCount[id], setName[id]) end
        setsPost = "my build ran " .. table.concat(parts, ", ") .. " during this duel."
    end
    -- b.CP comes from LibCombat's fight.CP, which on real records can be a TABLE (not the scalar CP);
    -- du.myCP is the reliable number. Only trust b.CP when it's actually numeric.
    local cpv = (type(b.CP) == "number" and b.CP) or du.myCP or 0
    -- Tiles render in a FULL-WIDTH strip above both columns (returned separately), so the two
    -- column tops align (Front Bar level with the Race header).
    local tilesRow = { tiles = {
        { l = "CLASS", v = ClassName(b.classId or du.myClassId), c = C.hi },
        { l = "CHAMPION PTS", v = (cpv > 0) and Comma(cpv) or "\226\128\148", c = C.accent },
        { l = "SETS", v = tostring(#setOrder), c = C.hi, post = setsPost },
        { l = "PIECES", v = tostring(#gear), c = C.hi },
    } }
    -- SHARE tile (click -> put a build link in chat) when LibDataPacker can pack this record. pcall'd:
    -- packing goes through LibDataPacker's build schema, and a different/older LibDataPacker version can
    -- expose a partial schema -- a failure there must only drop the share tile, never break the Build tab.
    local okShr, shr = pcall(function() return SB.ShareTile and SB.ShareTile(du) end)
    if okShr and shr then tilesRow.tiles[#tilesRow.tiles+1] = shr end
    -- Race + duel-relevant passives (informational). Numeric bonuses are already reflected in your
    -- captured stats; element-specific racial resistances are folded into the Stats tab's Defense area.
    -- Curse rides on the header — the scanned stage buff beats the plain LibCombat curse flag.
    local function abilityName(id)
        local ok, nm = pcall(function() return zo_strformat("<<1>>", GetAbilityName(id)) end)
        return (ok and nm and nm ~= "" and nm) or ("Ability " .. tostring(id))
    end
    if du.myRaceId and du.myRaceId ~= 0 then
        local hdr = "Race \226\128\148 " .. RaceName(du.myRaceId)
        local VAMP_STAGE = { [135397] = 1, [135399] = 2, [135400] = 3, [135402] = 4 }
        if b.wwVamp == 35658 then hdr = hdr .. "  |cd6a05a\226\128\162 Werewolf|r"
        elseif b.wwVamp and VAMP_STAGE[b.wwVamp] then
            hdr = hdr .. string.format("  |cb98fd6\226\128\162 Vampire \194\183 Stage %d|r", VAMP_STAGE[b.wwVamp])
        elseif b.curse == 1 then hdr = hdr .. "  |cb98fd6\226\128\162 Vampire|r"
        elseif b.curse == 2 then hdr = hdr .. "  |cd6a05a\226\128\162 Werewolf|r" end
        items[#items+1] = { header = true, left = hdr }
        local rp = RACE.passives[du.myRaceId]
        if rp then items[#items+1] = { wrap = true, left = "|caeb4c2" .. rp .. "|r" } end
    end
    local at = b.attr
    if at and ((at.hp or 0) + (at.mag or 0) + (at.stam or 0)) > 0 then
        items[#items+1] = { wrap = true, left = string.format(
            "Attributes:  |c%s%d Health|r \194\183 |c%s%d Magicka|r \194\183 |c%s%d Stamina|r",
            Hex(C.health), at.hp or 0, Hex(C.magic), at.mag or 0, Hex(C.phys), at.stam or 0) }
    end
    -- Mundus boon(s), class skill lines (subclassing) and food, from the duel-start scan.
    if b.boons and b.boons[1] then
        for _, bid in ipairs(b.boons) do
            items[#items+1] = { h = 26, tipId = bid, icon = AbilityIcon(bid), left = (abilityName(bid):gsub("^Boon:%s*", "")),
                right = "Mundus", rcolor = C.accent }
        end
    end
    if b.lines and b.lines[1] then
        local names = {}
        for _, lid in ipairs(b.lines) do
            local ok, nm = pcall(function() return zo_strformat("<<1>>", GetSkillLineNameById(lid)) end)
            names[#names+1] = (ok and nm and nm ~= "" and nm) or ("Line " .. tostring(lid))
        end
        items[#items+1] = { wrap = true, h = 26, left = string.format("Class Lines:  |c%s%s|r", Hex(C.hi), table.concat(names, " \194\183 ")) }
    end
    -- Slotted class masteries (subclassing mastery line)
    if b.mastery and b.mastery[1] then
        for _, mid in ipairs(b.mastery) do
            items[#items+1] = { h = 26, tipId = mid, icon = AbilityIcon(mid), left = abilityName(mid), right = "Mastery", rcolor = C.magic }
        end
    end
    if b.food and b.food[1] then
        for _, fid in ipairs(b.food) do
            items[#items+1] = { h = 26, tipId = fid, icon = AbilityIcon(fid), left = abilityName(fid), right = "Food", rcolor = C.lo }
        end
    end
    -- sets, most-equipped first; completion judged against the set's OWN size (5pc/monster 2pc/mythic 1pc)
    items[#items+1] = { header = true, left = "Sets" }
    if #setOrder == 0 then
        items[#items+1] = { left = "|c999999No set items detected on this build.|r" }
    else
        for _, id in ipairs(setOrder) do
            local n, need = setCount[id], setMax[id] or 5
            local complete = n >= need
            items[#items+1] = { h = 26, postLink = setLink[id], left = string.format("%d\195\151 %s", n, setName[id]),
                right = complete and (need .. "-piece") or (n .. " of " .. need),
                rcolor = complete and C.win or C.mid }
        end
    end
    -- gear list (left column, under sets)
    items[#items+1] = { header = true, left = "Gear" }
    for _, g in ipairs(gear) do
        -- Slot stays a right-aligned tag in its own FAR-RIGHT column. The enchant no longer wraps early
        -- into that reserved strip now that multi-line glyph values are flattened to one line (above),
        -- so row 1 fills fully and only a genuinely long enchant wraps -- naturally, not prematurely.
        -- Reserve width for the ACTUAL slot label so long ones ("Main Hand Backup") never overlap the
        -- wrapping enchant text (the fixed rw=92 was too small for backup-bar weapon slots).
        local slotRw = math.max(92, #(g.right or "") * 9 + 20)
        items[#items+1] = { wrap = true, h = 26, rw = slotRw, postLink = g.link,
            icon = (g.icon ~= "" and g.icon) or nil, left = g.text, right = g.right, rcolor = C.lo }
    end
    -- ---- RIGHT column: action bars + champion slottables ----
    local ritems = {}
    -- action bars from the LibCombat snapshot (slots 3-7 + ultimate in slot 8). A bar only
    -- exists in the snapshot if it was ACTIVE at some point during the duel. Scribed skills get a
    -- dim sub-row listing their three chosen scripts.
    local bars = b.bars
    if bars and (bars[1] or bars[2]) then
        for bi = 1, 2 do
            local bar = bars[bi]
            if bar then
                ritems[#ritems+1] = { header = true, left = (bi == 1) and "Front Bar" or "Back Bar" }
                for slot = 3, 8 do
                    local id = bar[slot]
                    if id and id > 0 then
                        ritems[#ritems+1] = { h = 26, tipId = id, icon = AbilityIcon(id), left = abilityName(id),
                            right = (slot == 8) and "Ultimate" or nil, rcolor = C.accent }
                        local scr = b.scribed and b.scribed[id]
                        if scr and scr.s and scr.s[1] then
                            local names = {}
                            for _, sid in ipairs(scr.s) do
                                local ok, nm = pcall(function() return zo_strformat("<<1>>", GetCraftedAbilityScriptDisplayName(sid)) end)
                                names[#names+1] = (ok and nm and nm ~= "" and nm) or ("Script " .. tostring(sid))
                            end
                            ritems[#ritems+1] = { wrap = true, h = 24, tipId = id, left = "|c8a8f9a        \226\134\179 " .. table.concat(names, " \194\183 ") .. "|r" }
                        end
                    end
                end
            end
        end
        if bars[1] and not bars[2] then
            ritems[#ritems+1] = { wrap = true, h = 24, left = "|c999999Back bar not recorded \226\128\148 you never bar-swapped during this duel.|r" }
        end
    end
    -- champion point slottables (12 stars, 4 per discipline; names/points from the duel-start
    -- scan; stars have no unique art, so rows carry their DISCIPLINE's icon like the champion bar).
    if b.cpSlots and next(b.cpSlots) then
        local function discName(slotA, fallback)
            local ok, nm = pcall(function()
                return zo_strformat("<<1>>", GetChampionDisciplineName(GetRequiredChampionDisciplineIdForSlot(slotA, HOTBAR_CATEGORY_CHAMPION)))
            end)
            return (ok and nm and nm ~= "" and nm) or fallback
        end
        ritems[#ritems+1] = { header = true, left = "Champion Point Slottables" }
        local groups = { { 1, "Craft",   "EsoUI/Art/Champion/champion_points_stamina_icon.dds" },
                         { 5, "Warfare", "EsoUI/Art/Champion/champion_points_magicka_icon.dds" },
                         { 9, "Fitness", "EsoUI/Art/Champion/champion_points_health_icon.dds" } }
        for _, g in ipairs(groups) do
            local first, any = g[1], false
            for i = first, first + 3 do if b.cpSlots[i] then any = true end end
            if any then
                ritems[#ritems+1] = { h = 24, left = string.format("|c%s%s|r", Hex(C.mid), discName(first, g[2])) }
                for i = first, first + 3 do
                    local e = b.cpSlots[i]
                    if e and e.id then
                        local ok, nm = pcall(function() return zo_strformat("<<1>>", GetChampionSkillName(e.id)) end)
                        ritems[#ritems+1] = { h = 26, tipCp = e.id, icon = g[3],
                            left = (ok and nm and nm ~= "" and nm) or ("Star " .. tostring(e.id)),
                            right = (e.pts and e.pts > 0) and (e.pts .. " pts") or nil, rcolor = C.accent }
                    end
                end
            end
        end
    end
    return items, ritems, tilesRow
end
function BD.Items(du)
    local L, R, tiles = BD.Cols(du)
    local out = {}
    if tiles then out[#out+1] = tiles end
    for _, it in ipairs(L) do out[#out+1] = it end
    for _, it in ipairs(R) do out[#out+1] = it end
    return out
end

-- ===========================================================================
-- TIMELINE tab (Ebb & Flow) — custom canvas drawn into F.Pane
-- ===========================================================================
local function FlowTiles(du)
    local tl, pOut, pIn = du.timeline or {}, 0, 0
    for _, d in pairs(tl) do pOut = math.max(pOut, d.dmgOut or 0); pIn = math.max(pIn, d.dmgIn or 0) end
    return { tiles = {
        { l = "TIME",     v = FmtDur(du.durationS), c = C.hi },
        { l = "PEAK OUT", v = Abbrev(pOut) .. "/s", c = C.win },
        { l = "PEAK IN",  v = Abbrev(pIn) .. "/s",  c = C.loss },
        { l = "AVG OUT",  v = Abbrev(du.dpsOut),    c = C.win },
        { l = "AVG IN",   v = Abbrev(du.dpsIn),     c = C.loss },
    } }
end
-- solid colored rectangle from a pool (CT_BACKDROP: draws a fill without a texture).
local function GetBar(pool, parent, i)
    local c = pool[i]
    if not c then
        c = WM:CreateControl(nil, parent, CT_BACKDROP)
        c:SetEdgeColor(0, 0, 0, 0)
        pool[i] = c
    end
    return c
end

-- Report Card radar: the six strengths plotted on a hexagon. ESO can't rotate controls, so every
-- line is a run of small pooled dots interpolated between its endpoints (the Ebb & Flow technique).
-- Axes clockwise from the top: offense/burst/pressure on the right, weaving/sustain/defense on the left.
RC.AXES = { { "offense", "Offense" }, { "burst", "Burst" }, { "pressure", "Pressure" },
            { "weaving", "Weaving" }, { "sustain", "Sustain" }, { "defense", "Defense" } }
function RC.DrawRadar(dims)
    local canvas = RC.Radar
    if not canvas then return end
    local W2, H2 = canvas:GetWidth(), canvas:GetHeight()
    if W2 < 60 or H2 < 60 then return end
    local byKey = {}
    for _, dm in ipairs(dims) do byKey[dm.key] = dm end
    local cx, cy = W2 / 2, H2 / 2
    local R = math.min(W2, H2) / 2 - 60   -- leave a margin for the vertex labels
    if R < 24 then return end
    local di = 0
    local function dot(x, y, size, color)
        di = di + 1
        local c = GetBar(RC.Dots, canvas, di)
        c:SetHidden(false); c:SetCenterColor(color[1], color[2], color[3], color[4] or 1)
        c:ClearAnchors(); c:SetDimensions(size, size)
        c:SetAnchor(CENTER, canvas, TOPLEFT, math.floor(x + 0.5), math.floor(y + 0.5))
    end
    local function seg(x1, y1, x2, y2, size, spacing, color)
        local dx, dy = x2 - x1, y2 - y1
        local n = math.max(1, math.floor(math.sqrt(dx * dx + dy * dy) / spacing))
        for k = 0, n do local t = k / n; dot(x1 + dx * t, y1 + dy * t, size, color) end
    end
    local ax, ay, vx, vy = {}, {}, {}, {}
    for i = 1, 6 do
        local a = math.rad(-90 + (i - 1) * 60)
        ax[i], ay[i] = math.cos(a), math.sin(a)
        vx[i], vy[i] = cx + R * ax[i], cy + R * ay[i]
    end
    local grid = { C.line[1], C.line[2], C.line[3], 1 }
    for _, frac in ipairs({ 0.5, 1.0 }) do   -- two faint reference rings (drawn first, under everything)
        for i = 1, 6 do
            local j = i % 6 + 1
            seg(cx + R * frac * ax[i], cy + R * frac * ay[i], cx + R * frac * ax[j], cy + R * frac * ay[j], 2, 11, grid)
        end
    end
    for i = 1, 6 do seg(cx, cy, vx[i], vy[i], 2, 13, grid) end   -- spokes
    -- data points
    local sum, px, py = 0, {}, {}
    for i = 1, 6 do
        local s = (byKey[RC.AXES[i][1]] and byKey[RC.AXES[i][1]].s) or 0
        sum = sum + s
        px[i], py[i] = cx + R * s / 100 * ax[i], cy + R * s / 100 * ay[i]
    end
    local dataCol = RC.Color(GradeLetter(sum / 6))
    -- PURE solid FILL: ESO has no polygon-fill primitive, so scan-line rasterise it. For each row y,
    -- intersect the six edges, sort the crossings, and lay a solid rectangle between each entering/
    -- exiting pair (pairing handles a concave shape when one strength is very low).
    local fillCol = { dataCol[1], dataCol[2], dataCol[3], 0.15 }
    local minY, maxY = py[1], py[1]
    for i = 2, 6 do minY = math.min(minY, py[i]); maxY = math.max(maxY, py[i]) end
    local STEP = 3
    for yy = math.floor(minY), math.ceil(maxY), STEP do   -- height == step => rows tile exactly, no overlap banding
        local xs = {}
        for i = 1, 6 do
            local j = i % 6 + 1
            local y1, y2 = py[i], py[j]
            if (y1 <= yy and y2 > yy) or (y2 <= yy and y1 > yy) then
                xs[#xs + 1] = px[i] + (px[j] - px[i]) * (yy - y1) / (y2 - y1)
            end
        end
        table.sort(xs)
        for k = 1, #xs - 1, 2 do
            local x1, x2 = xs[k], xs[k + 1]
            if x2 - x1 > 0.5 then
                di = di + 1
                local c = GetBar(RC.Dots, canvas, di)
                c:SetHidden(false); c:SetCenterColor(fillCol[1], fillCol[2], fillCol[3], fillCol[4])
                c:ClearAnchors(); c:SetDimensions(math.ceil(x2 - x1), STEP)
                c:SetAnchor(TOPLEFT, canvas, TOPLEFT, math.floor(x1), yy)
            end
        end
    end
    -- data outline (thin but solid: 2px dots every 2px touch) + vertex markers on top
    for i = 1, 6 do local j = i % 6 + 1; seg(px[i], py[i], px[j], py[j], 2, 2, dataCol) end
    for i = 1, 6 do dot(px[i], py[i], 6, dataCol) end
    for k = di + 1, #RC.Dots do RC.Dots[k]:SetHidden(true) end
    RC.Labels = RC.Labels or {}
    for i = 1, 6 do
        local lbl = RC.Labels[i]
        if not lbl then lbl = label(canvas, 14, C.mid, TEXT_ALIGN_CENTER, "bold"); lbl:SetDimensions(120, 22); RC.Labels[i] = lbl end
        local dm = byKey[RC.AXES[i][1]]
        local col = RC.Color(GradeLetter(dm and dm.s or 0))
        lbl:SetText(string.format("|c%s%s|r  |c9a9aa2%d|r", Hex(col), RC.AXES[i][2], dm and math.floor(dm.s + 0.5) or 0))
        lbl:ClearAnchors()
        local lx, ly = cx + (R + 18) * ax[i], cy + (R + 18) * ay[i]
        if ax[i] > 0.5 then lbl:SetHorizontalAlignment(TEXT_ALIGN_LEFT); lbl:SetAnchor(LEFT, canvas, TOPLEFT, lx, ly)
        elseif ax[i] < -0.5 then lbl:SetHorizontalAlignment(TEXT_ALIGN_RIGHT); lbl:SetAnchor(RIGHT, canvas, TOPLEFT, lx, ly)
        else lbl:SetHorizontalAlignment(TEXT_ALIGN_CENTER); lbl:SetAnchor(CENTER, canvas, TOPLEFT, lx, ly) end
        lbl:SetHidden(false)
    end
end
F.resCol = { mag = { 0.42, 0.60, 0.96, 1 }, stam = { 0.55, 0.86, 0.45, 1 }, ult = { 0.80, 0.60, 0.98, 1 } }
F.ultYou = F.resCol.ult                         -- purple = YOUR ult casts
F.ultOpp = { 0.98, 0.62, 0.30, 1 }              -- orange = ENEMY ult casts
-- Ebb & Flow = Deadlock-style over-time analytics. A view selector (Damage / Healing / Sustain);
-- each shows a line graph over the duel + a source breakdown below it. Lines are drawn as a step
-- line (a horizontal dash per time bucket + vertical connectors) -- robust, no rotation math.
F.subTabs = { { key = "damage", label = "Damage" }, { key = "healing", label = "Healing" }, { key = "sustain", label = "Sustain" }, { key = "bursts", label = "Bursts" }, { key = "log", label = "Log" } }
F.subTab = F.subTab or "damage"
-- Combat-log direction filter (out = my damage, in = damage I took = theirs, heal = healing).
F.logFilters = { { key = "all", label = "All" }, { key = "out", label = "My Damage" }, { key = "in", label = "Their Damage" }, { key = "heal", label = "Healing" }, { key = "ult", label = "Ults" } }
F.logFilter = F.logFilter or "all"

-- Generic chip row: renders `defs` into `bar` (lazily building pooled chips), highlights `activeKey`,
-- calls onClick(key) on press. Reused for the Damage/Healing/Sustain/Log sub-tabs and the log filter.
local function RenderChipRow(bar, pool, defs, activeKey, onClick, h, fsz)
    if not bar then return end
    local x = 0
    for i, st in ipairs(defs) do
        local c = pool[i]
        if not c then
            c = {}
            c.btn = WM:CreateControl(nil, bar, CT_CONTROL); c.btn:SetHeight(h or 26); c.btn:SetMouseEnabled(true)
            c.bg = backdrop(c.btn, C.win0, C.line, 1)
            c.lbl = label(c.btn, fsz or 15, C.mid, TEXT_ALIGN_CENTER, "bold"); c.lbl:SetAnchorFill(c.btn); c.lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
            AddPress(c.btn); pool[i] = c
        end
        local act = (st.key == activeKey)
        c.btn:SetHidden(false); c.lbl:SetText(st.label)
        c.lbl:SetColor(unpack(act and C.accent or C.mid)); c.bg:SetCenterColor(unpack(act and C.chip or C.win0))
        local w = math.max(70, math.floor(c.lbl:GetTextWidth()) + 24)
        c.btn:SetWidth(w); c.btn:ClearAnchors(); c.btn:SetAnchor(LEFT, bar, LEFT, x, 0)
        x = x + w + 6
        local key = st.key
        c.btn:SetHandler("OnMouseUp", function(_, _, inside) if inside then onClick(key) end end)
    end
end

-- ---- BURSTS view: detect burst windows from the hit-by-hit event log ----
-- A burst = a ~3s stretch whose damage is >= 2x the fight's AVERAGE DPS over that span;
-- overlapping/adjacent qualifying windows merge into one burst EVENT. Pure math over
-- du.log (per side: dir = "out" for yours, "in" for theirs) -> offline-testable.
F.BWIN, F.BK, F.BJOIN = 3000, 2, 1000   -- window ms / x-avg-DPS threshold / merge-adjacency ms
function F.BurstEvents(du, dir)
    local BURST_WIN, BURST_K, BURST_JOIN = F.BWIN, F.BK, F.BJOIN
    local evs = {}
    for _, e in ipairs(du.log or {}) do
        if e.dir == dir and (e.val or 0) > 0 then evs[#evs+1] = e end
    end
    if #evs == 0 then return {} end
    local durS = (du.durationS and du.durationS > 0) and du.durationS or 1
    local total = 0
    for _, e in ipairs(evs) do total = total + e.val end
    local thresh = math.max(1, (total / durS) * (BURST_WIN / 1000) * BURST_K)
    local bursts, cur = {}, nil
    for i = 1, #evs do
        local t0 = evs[i].t or 0
        local sum, tEnd = 0, t0
        for j = i, #evs do
            local tj = evs[j].t or 0
            if tj >= t0 + BURST_WIN then break end
            sum = sum + (evs[j].val or 0); tEnd = tj
        end
        if sum >= thresh then
            if cur and t0 <= cur.t1 + BURST_JOIN then
                if tEnd > cur.t1 then cur.t1 = tEnd end
            else
                cur = { t0 = t0, t1 = math.max(tEnd, t0) }
                bursts[#bursts+1] = cur
            end
        end
    end
    for _, b in ipairs(bursts) do
        b.total, b.seq = 0, {}
        for _, e in ipairs(evs) do
            local t = e.t or 0
            if t >= b.t0 and t <= b.t1 then b.total = b.total + e.val; b.seq[#b.seq+1] = e end
        end
    end
    return bursts
end
-- Render a burst's hit sequence as arrow-joined per-hit tokens (name + value; crit values gilded) so the
-- ACTUAL order is readable -- each light attack, each tick, which individual hits crit -- instead of a lossy
-- "x3 crit" aggregate that hid whether all three crit or the light attacks were back-to-back. Consecutive
-- identical, same-crit hits collapse to "name xN" so a long DoT stream stays scannable without losing order.
function F.SeqRows(items, seq, nameOf, indent)
    local DIM = "|c8a8f9a"
    local toks = {}
    local i, n = 1, #(seq or {})
    while i <= n do
        local e = seq[i]
        if e.id and (e.val or 0) > 0 and e.dir ~= "ult" then
            -- fold a run of the SAME ability with the SAME crit flag landing back-to-back into one token
            local run, sum = 1, (e.val or 0)
            while i + run <= n and seq[i + run].id == e.id and (not seq[i + run].crit) == (not e.crit)
                and (seq[i + run].val or 0) > 0 and seq[i + run].dir ~= "ult" do
                sum = sum + (seq[i + run].val or 0); run = run + 1
            end
            local label = nameOf(e.id) .. (run > 1 and (" \195\151" .. run) or "")
            local v = Abbrev(sum)
            local val = e.crit and ("|cffd700" .. v .. " crit|r") or (DIM .. v .. "|r")
            toks[#toks + 1] = DIM .. label .. " |r" .. val
            i = i + run
        else
            i = i + 1
        end
    end
    local PER, sep = 3, "  " .. DIM .. "\226\134\146|r  "
    for c = 1, #toks, PER do
        items[#items + 1] = { left = (indent or "        ") .. table.concat(toks, sep, c, math.min(c + PER - 1, #toks)) }
    end
end
-- Burst list + headline tiles for the breakdown area. atMs = pinned time: only bursts started by then.
function F.BurstItems(du, atMs)
    local mine, theirs = F.BurstEvents(du, "out"), F.BurstEvents(du, "in")
    if atMs then
        local function upto(list) local o = {}; for _, b in ipairs(list) do if b.t0 <= atMs then o[#o+1] = b end end return o end
        mine, theirs = upto(mine), upto(theirs)
    end
    local meta = {}
    local function harvest(list) for _, a in ipairs(list or {}) do if a.id and not meta[a.id] then meta[a.id] = a end end end
    harvest(du.dealtTop); harvest(du.takenTop)
    local function nameOf(id)
        local m = meta[id]
        return (m and m.name) or ((GetAbilityName and zo_strformat("<<1>>", GetAbilityName(id))) or ("#" .. tostring(id)))
    end
    local function cadence(list)
        if #list < 2 then return nil end
        local s = 0
        for i = 2, #list do s = s + (list[i].t0 - list[i-1].t0) end
        return s / (#list - 1) / 1000
    end
    local big
    for _, b in ipairs(mine) do if not big or b.total > big.total then big = b end end
    local gy, gt = cadence(mine), cadence(theirs)
    local ttag = atMs and string.format(" \226\128\148 to %d:%02d", math.floor(atMs / 60000), math.floor((atMs % 60000) / 1000)) or ""
    local items = { { tiles = {
        { l = "YOUR BURSTS", v = tostring(#mine), c = C.win },
        { l = "BIGGEST", v = big and Abbrev(big.total) or "\226\128\148", c = C.win,
          post = big and string.format("my biggest burst window did %s damage in %.1f seconds during this duel.", Comma(big.total), math.max(0.1, (big.t1 - big.t0) / 1000)) or nil },
        { l = "YOUR CADENCE", v = gy and string.format("%.0fs", gy) or "\226\128\148", c = C.hi,
          post = gy and string.format("my burst windows came every %.0f seconds on average during this duel.", gy) or nil },
        { l = "THEIR BURSTS", v = tostring(#theirs), c = C.loss },
        { l = "THEIR CADENCE", v = gt and string.format("%.0fs", gt) or "\226\128\148", c = C.hi },
    } } }
    items[#items+1] = { wrap = true, left = string.format("|c8a8f9bA burst = a ~%ds window doing \226\137\165%dx the fight's average DPS. Gaps between bars are your tempo.|r", F.BWIN / 1000, F.BK) }
    -- KILLING BLOW -- ALWAYS shown (a kill is not always a detected "burst": a clean single-shot finish has
    -- no burst window). The final decisive hit + the damage that set it up in the ~4s before it, so you can
    -- always see what ended the duel. Decisive direction = your damage on a win, theirs on a loss (draws none).
    -- Hidden while the timeline is pinned to an earlier moment (atMs), where an end-of-duel fact would mislead.
    local kbDir3 = (du.result == "win" and "out") or (du.result == "loss" and "in") or nil
    if kbDir3 and not atMs then
        local devs = {}
        for _, e in ipairs(du.log or {}) do if e.dir == kbDir3 and (e.val or 0) > 0 then devs[#devs + 1] = e end end
        if #devs > 0 then
            local kb = devs[#devs]                                   -- the final decisive hit = the killing blow
            local LEAD = 4000
            local ws = (kb.t or 0) - LEAD
            local seq, tot = {}, 0
            for _, e in ipairs(devs) do if (e.t or 0) >= ws then seq[#seq + 1] = e; tot = tot + (e.val or 0) end end
            local won = du.result == "win"
            local kbCol = won and C.win or C.loss
            local kbt = string.format("%d:%02d", math.floor((kb.t or 0) / 60000), math.floor(((kb.t or 0) % 60000) / 1000))
            items[#items + 1] = { header = true, left = won and "Killing Blow" or "You Were Killed", color = kbCol, icon = AbilityIcon(kb.id) }
            items[#items + 1] = { left = string.format("|cffd700%s|r  \194\183  %s%s  \194\183  %s",
                nameOf(kb.id), Comma(kb.val or 0), kb.crit and " |cffd700crit|r" or "", kbt), color = kbCol, boldCol = 1 }
            -- The damage that led to it: the actual hit-by-hit sequence in the last ~4s (each light attack,
            -- each tick, which hits crit) ending on the killing blow -- so you can read the setup, not a total.
            if #seq > 1 then
                items[#items + 1] = { left = string.format("|c8a8f9bThe damage that led to it \226\128\148 last %.1fs, %s total:|r",
                    math.max(0.1, ((kb.t or 0) - ws) / 1000), Comma(tot)) }
                F.SeqRows(items, seq, nameOf)
            end
        end
    end
    -- KILLING BLOW (inline burst tag): the burst that ended the duel (win -> your last burst, loss -> theirs),
    -- if the duel ended within ~2.5s of that burst's last hit.
    local durMs = math.max(1, math.floor((du.durationS or 0) * 1000))
    local kbDir, kbIdx
    if du.result == "win" and #mine > 0 and durMs - mine[#mine].t1 <= 2500 then kbDir, kbIdx = "out", #mine
    elseif du.result == "loss" and #theirs > 0 and durMs - theirs[#theirs].t1 <= 2500 then kbDir, kbIdx = "in", #theirs end
    -- ULT-anchored: that side cast an ult inside (or up to 2.5s before) the burst window.
    local function ultIn(b, dirKey)
        for _, e in ipairs(du.log or {}) do
            if e.dir == "ult" and ((dirKey == "out" and e.actor ~= "opp") or (dirKey == "in" and e.actor == "opp")) then
                local t = e.t or 0
                if t >= b.t0 - 2500 and t <= b.t1 then return true end
            end
        end
        return false
    end
    F.burstSelItem = nil
    -- Sanity ceiling only — the list must mirror the lollipop chart (a 12-row cap silently hid
    -- the duel's later bursts, so clicking their bars found no row to scroll to: Shoyru's
    -- "anything right of the middle just goes back to the top").
    local SHOW = 40
    local function side(list, title, col, dirKey)
        items[#items+1] = { header = true, left = title .. ttag }
        if #list == 0 then items[#items+1] = { left = "|c777777No burst windows detected.|r" } return end
        items[#items+1] = { colHeader = true, srcLabel = "Burst", colTitles = { "DMG", "LENGTH", "GAP" } }
        local function row(i)
            local b = list[i]
            local t0s = string.format("%d:%02d", math.floor(b.t0 / 60000), math.floor((b.t0 % 60000) / 1000))
            local len = (#b.seq <= 1) and "1 hit" or string.format("%.1fs", math.max(0.1, (b.t1 - b.t0) / 1000))
            local gap = (i > 1) and string.format("+%.0fs", (b.t0 - list[i-1].t0) / 1000) or "\226\128\148"
            local tagStr = ""
            if ultIn(b, dirKey) then tagStr = tagStr .. string.format("  |c%sULT|r", Hex(dirKey == "out" and F.ultYou or F.ultOpp)) end
            if kbDir == dirKey and kbIdx == i then tagStr = tagStr .. "  |cffd700KILLING BLOW|r" end
            local selected = F.burstSel and F.burstSel.dir == dirKey and F.burstSel.i == i
            items[#items+1] = { left = string.format("%s%s  \194\183  %d hit%s%s", selected and "|cf0c060>>|r " or "",
                    t0s, #b.seq, #b.seq == 1 and "" or "s", tagStr),
                color = selected and C.accent or col, cols = { Abbrev(b.total), len, gap }, boldCol = 1 }
            if selected then F.burstSelItem = #items end
            -- composition: the actual hit-by-hit sequence in the window (each hit in the order it landed,
            -- crits gilded, back-to-back identical hits folded to "xN"), so you read the combo, not a total.
            F.SeqRows(items, b.seq, nameOf)
        end
        for i = 1, math.min(#list, SHOW) do row(i) end
        if #list > SHOW then
            -- Rows beyond the sanity cap: NEVER hide the killing blow or the burst the user just
            -- clicked (a truncated selection = dead click; the list must mirror the chart).
            local extra = {}
            if kbDir == dirKey and kbIdx and kbIdx > SHOW then extra[kbIdx] = true end
            if F.burstSel and F.burstSel.dir == dirKey and F.burstSel.i > SHOW and list[F.burstSel.i] then extra[F.burstSel.i] = true end
            local nExtra = 0
            for _ in pairs(extra) do nExtra = nExtra + 1 end
            local hidden = #list - SHOW - nExtra
            if hidden > 0 then items[#items+1] = { left = string.format("|c777777\226\128\166 %d more burst%s.|r", hidden, hidden == 1 and "" or "s") } end
            for i = SHOW + 1, #list do if extra[i] then row(i) end end
        end
    end
    side(mine, "Your Bursts", C.win, "out")
    side(theirs, "Their Bursts", C.loss, "in")
    if not du.log or #du.log == 0 then
        items[#items+1] = { left = "|c777777No event log for this duel \226\128\148 LibCombat wasn't active.|r" }
    end
    return items
end

-- Source breakdown under the graph. atMs = pinned time (ms): aggregate the log up to it; nil = full fight.
local function FlowBreakdown(du, atMs)
    local function topN(list, n)
        local a = {}; for _, e in ipairs(list or {}) do a[#a + 1] = e end
        table.sort(a, function(x, y) return (x.total or 0) > (y.total or 0) end)
        while #a > n do a[#a] = nil end
        return a
    end
    -- When scrubber is PINNED, aggregate the event log up to that time (atMs) so the source list
    -- reflects only what had landed by then (Deadlock-style). Otherwise use the full-fight totals.
    local function logAgg(dir)
        local meta = {}
        local function harvest(list) for _, a in ipairs(list or {}) do if a.id then meta[a.id] = a end end end
        harvest(du.dealtTop); harvest(du.takenTop); harvest(du.healTop)
        local agg = {}
        for _, e in ipairs(du.log or {}) do
            if e.dir == dir and (e.t or 0) <= atMs then
                local a = agg[e.id]
                if not a then local m = meta[e.id]; a = { id = e.id, name = (m and m.name) or ("#" .. tostring(e.id)), icon = (m and m.icon) or "", total = 0, hits = 0, crit = 0, over = 0, min = e.val, max = e.val }; agg[e.id] = a end
                a.total = a.total + (e.val or 0); a.hits = a.hits + 1
                if e.crit then a.crit = a.crit + 1 end
                if (e.val or 0) > a.max then a.max = e.val end
                if (e.val or 0) < a.min then a.min = e.val end
            end
        end
        local list = {}; for _, a in pairs(agg) do list[#list + 1] = a end
        return list
    end
    local ttag = atMs and string.format(" \226\128\148 to %d:%02d", math.floor(atMs / 60000), math.floor((atMs % 60000) / 1000)) or ""
    local durS = atMs and math.max(0.1, atMs / 1000) or du.durationS
    local items, sub = {}, F.subTab or "damage"
    if sub == "healing" then
        items[#items + 1] = { header = true, left = "Healing by Source" .. ttag }
        local src = atMs and logAgg("heal") or du.healTop
        if src and #src > 0 then
            AbilityRows(items, topN(src, 99), durS, { heal = true, titles = HEAL_COLS, srcLabel = "Heal source" })
        else items[#items + 1] = { left = "|c777777No healing recorded for this duel.|r" } end
    elseif sub == "sustain" then
        local MAG, STAM = COMBAT_MECHANIC_FLAGS_MAGICKA, COMBAT_MECHANIC_FLAGS_STAMINA
        -- one-line net summary (per 2s) so the "am I bleeding a pool?" number isn't lost
        if du.resources and (du.durationS or 0) > 0 then
            local dur = du.durationS
            local function netStr(pt)
                local r = du.resources[pt]; if not r then return "-" end
                local n = ((r.gains or 0) - (r.drains or 0)) / dur * 2
                return string.format("|c%s%s%s|r", Hex(n >= 0 and C.win or C.loss), n >= 0 and "+" or "-", Abbrev(math.abs(n)))
            end
            items[#items + 1] = { left = string.format("|c8a8f9bNet sustain / 2s:|r   Mag %s    Stam %s", netStr(MAG), netStr(STAM)) }
        end
        -- SPEND BY SOURCE: which abilities drained the most magicka / stamina (up-to-atMs when pinned)
        local function spendAgg(pt)
            local agg, sum = {}, 0
            for _, e in ipairs(du.spendLog or {}) do
                if e.pt == pt and (not atMs or (e.t or 0) <= atMs) then
                    local a = agg[e.id]; if not a then a = { id = e.id, total = 0, hits = 0 }; agg[e.id] = a end
                    a.total = a.total + (e.val or 0); a.hits = a.hits + 1; sum = sum + (e.val or 0)
                end
            end
            local list = {}; for _, a in pairs(agg) do list[#list + 1] = a end
            table.sort(list, function(x, y) return x.total > y.total end)
            return list, sum
        end
        local any = false
        for _, grp in ipairs({ { pt = MAG, label = "Magicka Spend", col = C.magic }, { pt = STAM, label = "Stamina Spend", col = C.phys } }) do
            local list, sum = spendAgg(grp.pt)
            if #list > 0 then
                any = true
                items[#items + 1] = { header = true, left = grp.label .. ttag }
                items[#items + 1] = { colHeader = true, srcLabel = "Ability", colTitles = { "SPENT", "%", "CASTS" } }
                for k = 1, math.min(#list, 8) do
                    local a = list[k]
                    local nm = (a.id ~= 0 and GetAbilityName and zo_strformat("<<1>>", GetAbilityName(a.id))) or ""
                    if nm == "" then nm = "Other (block / dodge / sprint)" end
                    items[#items + 1] = { icon = (a.id ~= 0) and AbilityIcon(a.id) or nil, left = nm, color = grp.col,
                        cols = { Abbrev(a.total), (sum > 0 and math.floor(a.total / sum * 100 + 0.5) or 0) .. "%", tostring(a.hits) } }
                end
            end
        end
        if not any then items[#items + 1] = { left = "|c777777No resource-spend data recorded \226\128\148 LibCombat wasn't active.|r" } end
    elseif sub == "bursts" then
        for _, it in ipairs(F.BurstItems(du, atMs)) do items[#items + 1] = it end
    else
        -- Follow the graph's line toggles: YOUR damage (green line = dealtTop) and/or the OPPONENT's
        -- (red line = what they dealt to you = takenTop). Both on => both sections, clearly labelled.
        local showYou, showThem = not F.hideYou, not F.hideThem
        local function section(title, src)
            items[#items + 1] = { header = true, left = title .. ttag }
            if src and #src > 0 then AbilityRows(items, topN(src, 99), durS, { srcLabel = "Damage source" })
            else items[#items + 1] = { left = "|c777777No per-ability breakdown \226\128\148 LibCombat wasn't active.|r" } end
        end
        if not showYou and not showThem then
            items[#items + 1] = { left = "|c777777Toggle a line above (You / Opponent) to see its damage by source.|r" }
        else
            if showYou then section("Your Damage by Source", atMs and logAgg("out") or du.dealtTop) end
            if showThem then section("Opponent's Damage by Source", atMs and logAgg("in") or du.takenTop) end
        end
    end
    return items
end

-- Combat log (CMX-style): the chronological event stream. time | icon | ability | amount, coloured
-- by direction (green = you dealt, red = you took, blue = healed), crit-flagged.
local function LogItems(du)
    local log = du.log
    if not log or #log == 0 then
        return { { header = true, left = "Combat Log" },
                 { left = "|c777777No event log for this duel \226\128\148 LibCombat wasn't active.|r" } }
    end
    local LOG_SHOW = 500   -- cap displayed rows (pooled controls); the record keeps up to 1000
    -- name/icon from the captured ability tables (reliable post-combat), keyed by ability id
    local meta = {}
    local function harvest(list) for _, a in ipairs(list or {}) do if a.id and not meta[a.id] then meta[a.id] = a end end end
    harvest(du.dealtTop); harvest(du.takenTop); harvest(du.healTop)
    local shown = math.min(#log, LOG_SHOW)
    -- The KILLING BLOW = the final decisive-direction damage event (your last hit on a win, theirs on a
    -- loss). Tag that exact row so the log shows what ended the duel. Draws have no killing blow.
    local kbDir = (du.result == "win" and "out") or (du.result == "loss" and "in") or nil
    local kbEvent
    if kbDir then
        for _, e in ipairs(log) do if e.dir == kbDir and (e.val or 0) > 0 then kbEvent = e end end
    end
    -- Filter by direction (F.logFilter: all / out / in / heal), capped at LOG_SHOW matching rows.
    local flt = F.logFilter or "all"
    local rows, total = {}, 0
    for k = 1, #log do
        local e = log[k]
        if flt == "all" or e.dir == flt then
            total = total + 1
            if #rows < LOG_SHOW then rows[#rows + 1] = e end
        end
    end
    local items = { { header = true, left = "Combat Log", right = (#rows < total and (#rows .. " of " .. total) or (total .. " events")), rcolor = C.lo },
                    -- colour key: what green/red/blue + the ult colours mean
                    { left = string.format("|c%s\226\151\143 My damage|r   |c%s\226\151\143 Their damage|r   |c%s\226\151\143 Healing|r   |c%s\226\151\143 My ult|r   |c%s\226\151\143 Enemy ult|r",
                        Hex(C.win), Hex(C.loss), Hex(C.magic), Hex(F.ultYou), Hex(F.ultOpp)) },
                    { colHeader = true, srcLabel = "Time \226\128\162 ability", colTitles = { "AMOUNT" } } }
    if total == 0 then items[#items + 1] = { left = "|c777777No matching events.|r" } end
    for _, e in ipairs(rows) do
        local t = e.t or 0   -- relative MS -> M:SS.mmm (millisecond precision, e.g. same-GCD hits)
        local ts = string.format("%d:%02d.%03d", math.floor(t / 60000), math.floor((t % 60000) / 1000), t % 1000)
        if e.dir == "ult" then
            -- ULT cast row: "ULT" tag + who cast what, coloured by actor (purple you / orange enemy).
            local ucol = (e.actor == "opp") and F.ultOpp or F.ultYou
            local who = (e.actor == "opp") and "Enemy cast" or "You cast"
            items[#items + 1] = { icon = (e.id and e.id > 0) and AbilityIcon(e.id) or nil, color = ucol,
                left = string.format("|c8a8f9b%s|r  |c%sULT|r  %s %s", ts, Hex(ucol), who, e.name or "Ultimate"),
                cols = { "" }, colColors = { ucol } }
        else
            local m = meta[e.id]
            local nm = (m and m.name) or ("#" .. tostring(e.id))
            local ic = (m and m.icon) or AbilityIcon(e.id)
            local col = (e.dir == "out" and C.win) or (e.dir == "heal" and C.magic) or C.loss
            -- direction shown by COLOUR (green dealt / red taken / blue heal); crit flagged with plain
            -- text. Whole row coloured by side so mine vs theirs reads at a glance; the time stays dim.
            local pre = (e.dir == "heal" and "+") or ""
            local val = pre .. Comma(e.val or 0) .. (e.crit and "  |cffd700crit|r" or "")
            items[#items + 1] = { icon = ic, color = col, left = string.format("|c8a8f9b%s|r  %s", ts, nm),
                cols = { val }, colColors = { col } }
            -- Killing blow gets its OWN full-width callout row (an inline tag competes with the amount
            -- column for width and gets clipped), so every character shows.
            if e == kbEvent then
                items[#items + 1] = { left = "|cffd700\226\152\160 KILLING BLOW \226\128\148 the hit that ended the duel|r", color = kbDir == "out" and C.win or C.loss }
            end
        end
    end
    return items
end

-- Draw the line graph for the active view + lay out the sub-regions (chips already drawn separately).
local function DrawFlow(du)
    local tl = du.timeline
    local maxSec = -1
    if tl then for s in pairs(tl) do if s > maxSec then maxSec = s end end end
    local hasData = maxSec >= 0
    local sub = F.subTab or "damage"
    F.lolliIdx = 0   -- interactive burst bars drawn this pass (leftovers hidden in the tail cleanup)

    if sub == "log" then
        -- Combat-log view: no graph -- hide the whole plot apparatus (the log renders as a scroll list).
        for _, c in ipairs({ F.PlotTitle, F.Plot, F.T0, F.Tend, F.YName, F.YMax, F.YZero, F.XName, F.Empty, F.LegYou, F.LegThem, F.LegHint, F.BreakScroll }) do
            if c then c:SetHidden(true) end
        end
        for _, t in ipairs(F.DmgBars) do t:SetHidden(true) end
        for _, t in ipairs(F.Marks) do t:SetHidden(true) end
        for _, t in ipairs(F.Lolli or {}) do t:SetHidden(true) end
        return
    end
    if F.Plot then F.Plot:SetHidden(false) end
    if F.BreakScroll then F.BreakScroll:SetHidden(false) end

    -- layout from the pane height (deterministic; no GetHeight timing dependence)
    local paneH = F.Pane:GetHeight(); if paneH < 120 then paneH = ((win and win:GetHeight()) or H) - 210 end
    local topY = 62                                   -- chip bar (28) + gap + title (20)
    local GUT = 44                                    -- left gutter for the Y-axis labels
    local plotH = math.max(140, math.floor((paneH - topY - 34) * 0.46))
    F.PlotTitle:ClearAnchors(); F.PlotTitle:SetAnchor(TOPLEFT, F.Pane, TOPLEFT, 2, 34)
    F.Plot:ClearAnchors(); F.Plot:SetAnchor(TOPLEFT, F.Pane, TOPLEFT, GUT, topY); F.Plot:SetDimensions(contentW - GUT, plotH)
    F.T0:ClearAnchors(); F.T0:SetAnchor(TOPLEFT, F.Plot, BOTTOMLEFT, 2, 3)
    F.Tend:ClearAnchors(); F.Tend:SetAnchor(TOPRIGHT, F.Plot, BOTTOMRIGHT, -2, 3)
    -- Y axis (all in the left gutter beside the plot, clear of the title above): peak value at the
    -- top, 0 at the bottom, unit name vertically centred between them.
    F.YMax:ClearAnchors();  F.YMax:SetAnchor(RIGHT, F.Plot, TOPLEFT, -4, 6); F.YMax:SetWidth(GUT - 6)
    F.YZero:ClearAnchors(); F.YZero:SetAnchor(RIGHT, F.Plot, BOTTOMLEFT, -4, -6); F.YZero:SetWidth(GUT - 6)
    F.YName:ClearAnchors(); F.YName:SetAnchor(RIGHT, F.Plot, LEFT, -6, 0); F.YName:SetWidth(GUT - 6); F.YName:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    -- X axis: "Time" centred under the plot, between the 0:00 and end-time labels.
    F.XName:ClearAnchors(); F.XName:SetAnchor(TOP, F.Plot, BOTTOM, 0, 3)
    F.BreakScroll:ClearAnchors()
    F.BreakScroll:SetAnchor(TOPLEFT, F.Pane, TOPLEFT, 0, topY + plotH + 26)
    F.BreakScroll:SetAnchor(BOTTOMRIGHT, F.Pane, BOTTOMRIGHT, 0, 0)   -- fixed height -> the list scrolls
    if F.BreakChild then F.BreakChild:SetWidth(contentW) end
    -- legacy resource band is unused in the new design
    if F.ResTitle then F.ResTitle:SetHidden(true) end
    if F.ResBand then F.ResBand:SetHidden(true) end
    if F.Legend then F.Legend:SetHidden(true) end
    if F.LegYou then F.LegYou:SetHidden(true) end       -- shown only in the Damage view (below)
    if F.LegThem then F.LegThem:SetHidden(true) end
    if F.LegHint then F.LegHint:SetHidden(true) end

    F.Empty:SetHidden(hasData)
    for _, l in ipairs({ F.YName, F.YMax, F.YZero, F.XName }) do l:SetHidden(not hasData) end
    F.PlotTitle:SetHidden(not hasData)
    F.T0:SetHidden(not hasData); F.Tend:SetHidden(not hasData)
    if not hasData then
        F.Empty:SetText("No timeline captured for this duel \226\128\148 LibCombat wasn't active.")
        for _, t in ipairs(F.DmgBars) do t:SetHidden(true) end
        for _, t in ipairs(F.Marks) do t:SetHidden(true) end
        return
    end

    -- bucket seconds down to <= NB columns
    local NB = 60
    local perBucket = math.max(1, math.ceil((maxSec + 1) / NB))
    local buckets = {}
    -- Resource POOLS (mag/stam/ult) are only sampled on seconds a resource event fired. Magicka/stamina
    -- fire constantly so they read fine, but ULTIMATE events are sparse -- between them the raw value is
    -- 0, which made the ult line collapse to zero instead of holding its level. Carry the last known pool
    -- value forward across unsampled seconds (a pool doesn't drop to 0 just because nothing logged it).
    local lastMag, lastStam, lastUlt = 0, 0, 0
    for s = 0, maxSec do
        local bi = math.floor(s / perBucket) + 1
        local bk = buckets[bi]
        if not bk then bk = { dmgOut = 0, dmgIn = 0, heal = 0, mag = 0, stam = 0, ult = 0, ultCast = 0, secs = 0 }; buckets[bi] = bk end
        local d = tl[s] or {}
        if (d.mag or 0) > 0 then lastMag = d.mag end
        if (d.stam or 0) > 0 then lastStam = d.stam end
        if (d.ult or 0) > 0 then lastUlt = d.ult end
        bk.dmgOut = bk.dmgOut + (d.dmgOut or 0); bk.dmgIn = bk.dmgIn + (d.dmgIn or 0); bk.heal = bk.heal + (d.heal or 0)
        bk.mag = math.max(bk.mag, lastMag); bk.stam = math.max(bk.stam, lastStam); bk.ult = math.max(bk.ult, lastUlt)
        bk.ultCast = bk.ultCast + (d.ultCast or 0); bk.secs = bk.secs + 1
    end
    local nb = #buckets
    if nb == 0 then return end
    local plotW = F.Plot:GetWidth(); if plotW < 10 then plotW = contentW end
    local colW = plotW / nb

    -- Rolling (moving) average -> the "stock chart" shape: smooths single-hit spikes but still rises
    -- into peaks on bursts and dips in lulls (a flat cumulative average would just drift).
    local halfWin = math.max(1, math.min(5, math.floor(nb / 12 + 0.5)))
    local function smooth(vals)
        local out = {}
        for i = 1, nb do
            local s, c = 0, 0
            for j = math.max(1, i - halfWin), math.min(nb, i + halfWin) do s = s + (vals[j] or 0); c = c + 1 end
            out[i] = s / math.max(1, c)
        end
        return out
    end

    -- True line graph, rotation-free: each connecting line is a dense run of small square dots
    -- interpolated straight between adjacent bucket points (points at each bucket's centre). No
    -- SetTransformRotationZ (its pivot was unreliable and left the segments disconnected).
    local dashIdx = 0
    local DOT = 4   -- dot size + spacing (dots touch -> reads as a solid ~4px line)
    local function plot(px, py, col)
        dashIdx = dashIdx + 1
        local dot = GetBar(F.DmgBars, F.Plot, dashIdx)
        dot:SetHidden(false); dot:SetCenterColor(unpack(col))
        dot:ClearAnchors(); dot:SetDimensions(DOT, DOT); dot:SetAnchor(CENTER, F.Plot, TOPLEFT, math.floor(px), math.floor(py))
    end
    local function step(vals, maxV, col)
        maxV = math.max(1, maxV)
        local function py(v) return (plotH - 6) - (v / maxV) * (plotH - 12) + 2 end
        local prevx, prevy
        for i = 1, nb do
            -- spread points across the FULL plot width so the line touches both edges (0:00 .. end),
            -- leaving no blank zone at the start/finish where a pin would land off the line.
            local x = (nb > 1) and ((i - 1) / (nb - 1) * plotW) or (plotW / 2)
            local y = py(vals[i] or 0)
            if prevx then
                local dx, dy = x - prevx, y - prevy
                local steps = math.max(1, math.floor(math.sqrt(dx * dx + dy * dy) / DOT))
                for k = 1, steps do local t = k / steps; plot(prevx + dx * t, prevy + dy * t, col) end
            else
                plot(x, y, col)
            end
            prevx, prevy = x, y
        end
    end
    -- ult-cast markers: a vertical line at each cast's real time, coloured by who cast it
    -- (purple = you, orange = enemy).
    local markIdx = 0
    local function drawMarks()
        local durMs = math.max(1, math.floor((du.durationS or (maxSec + 1)) * 1000))
        for _, e in ipairs(du.log or {}) do
            if e.dir == "ult" then
                local c = (e.actor == "opp") and F.ultOpp or F.ultYou
                local x = math.floor(math.min(1, (e.t or 0) / durMs) * plotW)
                -- faint full-height line (background) ...
                markIdx = markIdx + 1
                local mk = GetBar(F.Marks, F.Plot, markIdx)
                mk:SetHidden(false); mk:SetCenterColor(c[1], c[2], c[3], 0.32)
                mk:ClearAnchors(); mk:SetDimensions(2, plotH); mk:SetAnchor(TOPLEFT, F.Plot, TOPLEFT, x, 0)
                -- ... plus a solid cap at the top so every ult reads as one clear, uniform marker.
                markIdx = markIdx + 1
                local cap = GetBar(F.Marks, F.Plot, markIdx)
                cap:SetHidden(false); cap:SetCenterColor(c[1], c[2], c[3], 1)
                cap:ClearAnchors(); cap:SetDimensions(8, 8); cap:SetAnchor(TOPLEFT, F.Plot, TOPLEFT, x - 3, 0)
            end
        end
    end

    if sub == "healing" then
        -- Rolling-average HPS -> a smooth line with peaks/dips (not spiky per-second ticks).
        local raw, hps, mx = {}, {}, 1
        for i, bk in ipairs(buckets) do raw[i] = bk.heal / math.max(1, bk.secs) end
        hps = smooth(raw)
        for i = 1, nb do mx = math.max(mx, hps[i]) end
        step(hps, mx, C.win)
        F.plotData = { sub = "healing", hps = hps, nb = nb, dur = math.floor(du.durationS or (maxSec + 1)) }
        F.YName:SetText("HPS"); F.YMax:SetText(Abbrev(mx))
        F.PlotTitle:SetText(string.format("HPS over time \226\128\148 |c%syour healing received|r", Hex(C.win)))
    elseif sub == "sustain" then
        local magMax = (du.stats and du.stats[1] and du.stats[1].max) or 0
        local stamMax = (du.stats and du.stats[11] and du.stats[11].max) or 0
        for _, bk in ipairs(buckets) do magMax = math.max(magMax, bk.mag); stamMax = math.max(stamMax, bk.stam) end
        -- Ultimate is shown as % toward YOUR ult (100% = ready to cast), like the base-game ult indicator,
        -- NOT % of the raw 500 pool -- most ults cost well under 500, so "% of pool" capped ~50% and read
        -- as broken. The ult COST = the biggest single drop in the pool (a cast); scan the sampled
        -- per-second values for it, fall back to the raw pool if no cast happened this duel.
        local ultCost, lastU = 0, nil
        for sec = 0, maxSec do
            local d = tl[sec]
            local uv = d and d.ult
            if uv and uv > 0 then
                if lastU and (lastU - uv) > ultCost then ultCost = lastU - uv end
                lastU = uv
            end
        end
        if ultCost < 70 then ultCost = 500 end   -- no clear cast this duel -> raw pool
        local m, s, u = {}, {}, {}
        for i, bk in ipairs(buckets) do
            m[i] = bk.mag / math.max(1, magMax); s[i] = bk.stam / math.max(1, stamMax)
            u[i] = math.min(1, (bk.ult or 0) / ultCost)   -- capped: holding a ready ult sits at 100%
        end
        step(m, 1, F.resCol.mag); step(s, 1, F.resCol.stam); step(u, 1, F.resCol.ult)
        F.plotData = { sub = "sustain", mag = m, stam = s, ult = u, nb = nb, dur = math.floor(du.durationS or (maxSec + 1)) }
        F.YName:SetText("%"); F.YMax:SetText("100%")
        F.PlotTitle:SetText(string.format("|c%smagicka|r & |c%sstamina|r %% of pool  \226\128\162  |c%sultimate|r %% to your next cast (100%% = ready)", Hex(F.resCol.mag), Hex(F.resCol.stam), Hex(F.resCol.ult)))
    elseif sub == "bursts" then
        -- Lollipop chart: one bar per detected burst (green = yours, red = theirs), height = burst
        -- damage. The empty space BETWEEN bars is the point — it reads as your tempo. Ult markers
        -- stay for context. NO scrubber/pin here (bursts are discrete events, not a time-aggregate);
        -- instead each lollipop is interactive: hover = summary tooltip, click = highlight + scroll
        -- to that burst's row in the list below. Interactive bars live in their OWN pool (F.Lolli)
        -- so the line views' inert dots never inherit mouse handlers.
        F.plotData = nil
        F.Lolli = F.Lolli or {}
        F.lolliMap = {}   -- x -> burst mapping; the PLOT is the hover/click surface (see BuildWindow)
        local mine, theirs = F.BurstEvents(du, "out"), F.BurstEvents(du, "in")
        local durMs = math.max(1, math.floor((du.durationS or (maxSec + 1)) * 1000))
        local mx = 1
        for _, b in ipairs(mine) do mx = math.max(mx, b.total) end
        for _, b in ipairs(theirs) do mx = math.max(mx, b.total) end
        local kbDir, kbIdx
        if du.result == "win" and #mine > 0 and durMs - mine[#mine].t1 <= 2500 then kbDir, kbIdx = "out", #mine
        elseif du.result == "loss" and #theirs > 0 and durMs - theirs[#theirs].t1 <= 2500 then kbDir, kbIdx = "in", #theirs end
        local lolliIdx = 0
        local function lolli(list, col, xoff, dirKey)
            for bi, b in ipairs(list) do
                local mid = (b.t0 + b.t1) / 2
                local x = math.floor(math.min(1, mid / durMs) * plotW) + xoff
                local hgt = math.max(8, math.floor((b.total / mx) * (plotH - 16)))
                local kb = (kbDir == dirKey and kbIdx == bi)
                F.lolliMap[#F.lolliMap+1] = { x = x, dir = dirKey, i = bi,
                    tip = string.format("%d:%02d \226\128\148 %s in %s (%d hit%s)%s\nClick to highlight it in the list.",
                        math.floor(b.t0 / 60000), math.floor((b.t0 % 60000) / 1000), Abbrev(b.total),
                        (#b.seq <= 1) and "one hit" or string.format("%.1fs", math.max(0.1, (b.t1 - b.t0) / 1000)),
                        #b.seq, #b.seq == 1 and "" or "s", kb and " \226\128\148 KILLING BLOW" or "") }
                local selected = F.burstSel and F.burstSel.dir == dirKey and F.burstSel.i == bi
                for _, part in ipairs({ { w = selected and 7 or 5, h = hgt, cap = false }, { w = kb and 13 or 11, h = kb and 13 or 11, cap = true } }) do
                    lolliIdx = lolliIdx + 1
                    local ctl = GetBar(F.Lolli, F.Plot, lolliIdx)
                    ctl:SetHidden(false)
                    if part.cap then
                        local cc = kb and C.accent or col
                        ctl:SetCenterColor(cc[1], cc[2], cc[3], 1)
                        ctl:ClearAnchors(); ctl:SetDimensions(part.w, part.h)
                        ctl:SetAnchor(CENTER, F.Plot, BOTTOMLEFT, x, -hgt)
                    else
                        ctl:SetCenterColor(col[1], col[2], col[3], selected and 1 or 0.8)
                        ctl:ClearAnchors(); ctl:SetDimensions(part.w, part.h)
                        ctl:SetAnchor(BOTTOMLEFT, F.Plot, BOTTOMLEFT, x - math.floor(part.w / 2), 0)
                    end
                end
            end
        end
        lolli(mine, C.win, -3, "out"); lolli(theirs, C.loss, 4, "in")   -- nudged apart so same-moment trades both show
        drawMarks()
        F.lolliIdx = lolliIdx
        F.YName:SetText("Burst"); F.YMax:SetText(Abbrev(mx))
        F.PlotTitle:SetText(string.format("Burst windows \226\128\148 |c%s\226\151\143 you|r  |c%s\226\151\143 enemy|r  (bar height = burst damage)      |c8a8f9bUlts:|r  |c%s\226\151\143 You|r   |c%s\226\151\143 Enemy|r",
            Hex(C.win), Hex(C.loss), Hex(F.ultYou), Hex(F.ultOpp)))
    else -- damage: you vs opponent (rolling-average DPS -> stock-chart shape with peaks/dips)
        local ry, rt = {}, {}
        for i, bk in ipairs(buckets) do ry[i] = bk.dmgOut / math.max(1, bk.secs); rt[i] = bk.dmgIn / math.max(1, bk.secs) end
        local you, them, mx = smooth(ry), smooth(rt), 1
        for i = 1, nb do mx = math.max(mx, you[i], them[i]) end
        F.plotData = { sub = "damage", you = you, them = them, nb = nb, dur = math.floor(du.durationS or (maxSec + 1)) }
        if not F.hideYou then step(you, mx, C.win) end
        if not F.hideThem then step(them, mx, C.loss) end
        drawMarks()
        F.YName:SetText("DPS"); F.YMax:SetText(Abbrev(mx))
        -- legend toggle buttons (dim + darker chip when that line is off)
        local function legSet(chip, base, txt, off)
            chip:SetHidden(false)
            chip.lbl:SetText(txt); chip.lbl:SetColor(unpack(off and C.lo or base))
            chip.bg:SetCenterColor(unpack(off and C.win0 or C.chip))
            chip:SetWidth(math.max(64, math.floor(chip.lbl:GetTextWidth()) + 22))
        end
        -- legend OUTSIDE the plot, on the title row (top-right of the pane) so it never occludes the line
        legSet(F.LegThem, C.loss, "\226\151\143 Opponent", F.hideThem)
        legSet(F.LegYou, C.win, "\226\151\143 You", F.hideYou)
        F.LegThem:ClearAnchors(); F.LegThem:SetAnchor(TOPRIGHT, F.Pane, TOPRIGHT, -2, 32)
        F.LegYou:ClearAnchors(); F.LegYou:SetAnchor(TOPRIGHT, F.LegThem, TOPLEFT, -6, 0)
        F.LegHint:SetHidden(false); F.LegHint:ClearAnchors(); F.LegHint:SetAnchor(RIGHT, F.LegYou, LEFT, -8, 0)
        F.PlotTitle:SetText(string.format("DPS over time      |c8a8f9bUlts:|r  |c%s\226\151\143 You|r   |c%s\226\151\143 Enemy|r", Hex(F.ultYou), Hex(F.ultOpp)))
    end
    for i = dashIdx + 1, #F.DmgBars do F.DmgBars[i]:SetHidden(true) end
    for i = markIdx + 1, #F.Marks do F.Marks[i]:SetHidden(true) end
    for i = (F.lolliIdx or 0) + 1, #(F.Lolli or {}) do F.Lolli[i]:SetHidden(true) end

    F.YZero:SetText("0"); F.XName:SetText("Time")
    F.T0:SetText("0:00")
    local dur = math.floor(du.durationS or maxSec + 1)
    F.Tend:SetText(string.format("%d:%02d", math.floor(dur / 60), dur % 60))
end

local function TabItems(key, du)
    if key == "healing" then return HealingItems(du)
    elseif key == "stats" then return StatsItems(du)
    elseif key == "optim" then return GradeItems(du)
    elseif key == "build" then return BD.Items(du)
    else return HealingItems(du)   -- damage / buffs / flow use dedicated panes
    end
end

-- Sub-tab chips for the Buffs & Debuffs view (Buffs / Debuffs / Status / Control).
local function GetBuffSubChip(i)
    local c = buffSubChips[i]
    if c then return c end
    c = {}
    c.btn = WM:CreateControl(nil, buffTabBar, CT_CONTROL)
    c.btn:SetHeight(26)
    c.btn:SetMouseEnabled(true)
    c.bg = backdrop(c.btn, C.win0, C.line, 1)
    c.lbl = label(c.btn, 15, C.mid, TEXT_ALIGN_CENTER, "bold")
    c.lbl:SetAnchorFill(c.btn); c.lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    AddPress(c.btn)
    buffSubChips[i] = c
    return c
end
local function RenderSubChips()
    if not buffTabBar then return end
    local x = 0
    for i, st in ipairs(BUFF_SUBTABS) do
        local c = GetBuffSubChip(i)
        local act = (st.key == buffSubTab)
        c.btn:SetHidden(false)
        c.lbl:SetText(st.label)
        c.lbl:SetColor(unpack(act and C.accent or C.mid))
        c.bg:SetCenterColor(unpack(act and C.chip or C.win0))
        local w = math.max(72, math.floor(c.lbl:GetTextWidth()) + 26)
        c.btn:SetWidth(w)
        c.btn:ClearAnchors()
        c.btn:SetAnchor(LEFT, buffTabBar, LEFT, x, 0)
        x = x + w + 6
        local key = st.key
        c.btn:SetHandler("OnMouseUp", function(_, _, inside) if inside then UI.ShowBuffSub(key) end end)
    end
end

-- Auto-fit REMOVED (v1.16): switching tabs no longer resizes the window. The modal keeps a fixed
-- default (see UI.Init) or whatever size the USER dragged it to, and that size persists across tabs
-- and sessions; content just reflows/scrolls to fit. Kept as a no-op so the call sites stay simple.
local function FitHeight(top, contentH, capH)
    fitPending = false
end

local function RenderTab()
    if not currentDuel then return end
    for _, b in pairs(detailTabButtons) do
        local act = (b.key == currentTab)
        b.bg:SetCenterColor(unpack(act and C.chip or C.win0))
        b.lbl:SetColor(unpack(act and C.accent or C.mid))
    end
    local du = currentDuel.du
    if RC.Pane then RC.Pane:SetHidden(currentTab ~= "optim") end   -- Report Card pane is optim-only
    if currentTab == "damage" then
        -- Two independently-scrolling panels (Dealt / Taken) so 20+ sources each scroll
        -- on their own, CMX-style, instead of one giant page scroll.
        if duelScroll then duelScroll:SetHidden(true) end
        if buffPane then buffPane:SetHidden(true) end
        if F.Pane then F.Pane:SetHidden(true) end
        if BD.Pane then BD.Pane:SetHidden(true) end
        dmgPane:SetHidden(false)
        RenderLinesInto(nil, dmgTilesArea, dmgTilesPool, { DamageTiles(du) })
        dealtTitle:SetText("Damage Dealt   \226\128\162   Total " .. Abbrev(du.dmgDealt))
        takenTitle:SetText("Damage Taken   \226\128\162   Total " .. Abbrev(du.dmgTaken))
        -- Render both panels first so we know each one's content height.
        local dItems = {}; AbilityRows(dItems, du.dealtTop, du.durationS)
        local tItems = {}; AbilityRows(tItems, du.takenTop, du.durationS)
        RenderLinesInto(dealtScroll, dealtChild, dealtLines, dItems)
        RenderLinesInto(takenScroll, takenChild, takenLines, tItems)
        local tilesH = dmgTilesArea:GetHeight(); if tilesH < 10 then tilesH = 60 end
        local dealtH, takenH = dealtChild:GetHeight(), takenChild:GetHeight()
        -- Split the two panels PROPORTIONALLY to each side's content, so both stay balanced at any
        -- window size (each gets space ~ its share; both scroll when they overflow). >=90px per side.
        local bodyH = dmgPane:GetHeight()
        if bodyH < 80 then bodyH = ((win and win:GetHeight()) or H) - 210 end
        local avail = math.max(60, bodyH - tilesH - 62)
        local total = dealtH + takenH
        local dealtPanelH = math.max(90, math.min(avail - 90, math.floor(avail * dealtH / math.max(1, total))))
        local midY = math.floor(tilesH + 26 + dealtPanelH + 6)
        dmgSplit:ClearAnchors()
        dmgSplit:SetAnchor(TOPLEFT, dmgPane, TOPLEFT, 0, midY)
        dmgSplit:SetAnchor(TOPRIGHT, dmgPane, TOPRIGHT, 0, midY)
    elseif currentTab == "buffs" then
        -- Segmented: one sub-tab chip-bar + a single spacious, independently-scrolling panel.
        if duelScroll then duelScroll:SetHidden(true) end
        if dmgPane then dmgPane:SetHidden(true) end
        if F.Pane then F.Pane:SetHidden(true) end
        if BD.Pane then BD.Pane:SetHidden(true) end
        buffPane:SetHidden(false)
        RenderSubChips()
        local dur = du.durationS
        local oppName = (currentDuel.o and (currentDuel.o.name or currentDuel.o.handle)) or "Target"
        local oppIcon, myIcon = ClassIcon(du.oppClassId), ClassIcon(du.myClassId)
        local items = {}
        if buffSubTab == "buffs" then
            EffectRows(items, du.buffsMe, dur)
        elseif buffSubTab == "debuffs" then
            DirEffectRows(items, NonStatus(du.debuffsOpp), NonStatus(du.debuffsMe), dur, "Debuff", oppName, oppIcon, myIcon)
        elseif buffSubTab == "status" then
            DirEffectRows(items, StatusOnly(du.debuffsOpp), StatusOnly(du.debuffsMe), dur, "Status Effect", oppName, oppIcon, myIcon)
        else -- control
            ControlRows(items, du, oppName, oppIcon, myIcon)
        end
        RenderLinesInto(buffScroll, buffChild, buffLines, items)
        FitHeight(buffScroll, buffChild and buffChild:GetHeight() or 0)
    elseif currentTab == "flow" then
        -- Ebb & Flow — Damage/Healing/Sustain line graph (custom canvas via DrawFlow) + a source
        -- breakdown list under it (RenderLinesInto). Chip bar picks the view.
        if duelScroll then duelScroll:SetHidden(true) end
        if dmgPane then dmgPane:SetHidden(true) end
        if buffPane then buffPane:SetHidden(true) end
        if BD.Pane then BD.Pane:SetHidden(true) end
        F.Pane:SetHidden(false)
        if F.TilesArea then F.TilesArea:SetHidden(true) end   -- tiles removed from this view
        RenderChipRow(F.SubBar, F.SubChips, F.subTabs, F.subTab, UI.ShowFlowSub)
        DrawFlow(du)
        if F.subTab == "log" then
            F.LogFilterBar:SetHidden(false)
            RenderChipRow(F.LogFilterBar, F.LogFilterChips, F.logFilters, F.logFilter, UI.ShowLogFilter, 22, 13)
            F.LogScroll:ClearAnchors()
            F.LogScroll:SetAnchor(TOPLEFT, F.LogFilterBar, BOTTOMLEFT, 0, 6)
            F.LogScroll:SetAnchor(BOTTOMRIGHT, F.Pane, BOTTOMRIGHT, 0, 0)
            F.LogScroll:SetHidden(false)
            RenderLinesInto(F.LogScroll, F.LogChild, F.LogLines, LogItems(du))
        else
            if F.LogScroll then F.LogScroll:SetHidden(true) end
            if F.LogFilterBar then F.LogFilterBar:SetHidden(true) end
            local atMs = F.pinned and math.floor((F.pinFrac or 0) * math.max(1, (du.durationS or 1) * 1000)) or nil
            RenderLinesInto(F.BreakScroll, F.BreakChild, F.BreakLines, FlowBreakdown(du, atMs))
            -- Bursts: keep the selected burst's row lit (RenderLinesInto resets every hl; re-apply
            -- after render — the same order the find-in-tabs highlight uses).
            if F.subTab == "bursts" and F.burstSelItem and F.BreakLines[F.burstSelItem] then
                local ln = F.BreakLines[F.burstSelItem]
                if ln.hl then ln.hl:SetHidden(false) end
            end
        end
    elseif currentTab == "build" then
        -- Two side-by-side columns using the FULL width (character/sets/gear | bars/champion),
        -- so the whole build reads at a glance instead of a long half-empty scroll.
        if duelScroll then duelScroll:SetHidden(true) end
        if dmgPane then dmgPane:SetHidden(true) end
        if buffPane then buffPane:SetHidden(true) end
        if F.Pane then F.Pane:SetHidden(true) end
        BD.Pane:SetHidden(false)
        local L, R, tiles = BD.Cols(du)
        -- tiles strip first, at FULL width (renders above both columns; height set by content)
        RenderLinesInto(nil, BD.Tiles, BD.PT, tiles and { tiles } or {})
        if not tiles then BD.Tiles:SetHeight(1) end
        -- Left column (gear/set names + slot tags) needs more width than the right (skills/stars):
        -- gear rows carry name + trait + INLINE enchant, so bias the split hard to the left to keep a
        -- piece on ONE line. The right column (bar abilities / CP stars) has slack — its name<->value
        -- rows sit far apart — so taking width from it also TIGHTENS that gap (e.g. CP star <-> "N pts").
        local lW = math.floor((contentW - 12) * 0.66)   -- gear/sets column wider so a piece fits on one row
        local rW = contentW - 12 - lW
        BD.SL:SetWidth(lW); BD.SR:SetWidth(rW)
        -- rows render 20px narrower than the container (the scrollbar gutter CLIPS content —
        -- same -20 every other scroll child in this window uses), else right-edge tags cut off
        if BD.CL then BD.CL:SetWidth(lW - 20) end
        if BD.CR then BD.CR:SetWidth(rW - 20) end
        local saved = contentW
        contentW = lW - 20   -- rows size to their column, not the window
        RenderLinesInto(BD.SL, BD.CL, BD.PL, L)
        contentW = rW - 20
        RenderLinesInto(BD.SR, BD.CR, BD.PR, R)
        contentW = saved
    elseif currentTab == "optim" then
        -- Report Card: the strengths RADAR (left) + the graded report (right) -- or the LOCK overlay
        -- until MINCAL duels have been logged (so the personal baseline is meaningful).
        if duelScroll then duelScroll:SetHidden(true) end
        if dmgPane then dmgPane:SetHidden(true) end
        if buffPane then buffPane:SetHidden(true) end
        if F.Pane then F.Pane:SetHidden(true) end
        if BD.Pane then BD.Pane:SetHidden(true) end
        RC.Pane:SetHidden(false)
        local locked = RC.Calibrating()
        if RC.Radar then RC.Radar:SetHidden(locked) end
        if RC.Scroll then RC.Scroll:SetHidden(locked) end
        if RC.Caption then RC.Caption:SetHidden(locked) end
        if RC.Lock then RC.Lock:SetHidden(not locked) end
        if locked then
            if RC.UpdateLock then RC.UpdateLock() end
        else
            local dims = RC.Dims(du)
            pcall(RC.DrawRadar, dims)                              -- guarded: a canvas quirk can't abort the tab
            local saved = contentW
            contentW = math.max(200, contentW - RC.Radar:GetWidth() - 16 - 20)   -- report column = pane minus the radar
            RenderLinesInto(RC.Scroll, RC.Child, RC.Lines, GradeItems(du))
            contentW = saved
        end
    else
        if dmgPane then dmgPane:SetHidden(true) end
        if buffPane then buffPane:SetHidden(true) end
        if F.Pane then F.Pane:SetHidden(true) end
        if BD.Pane then BD.Pane:SetHidden(true) end
        if duelScroll then duelScroll:SetHidden(false) end
        RenderLines(TabItems(currentTab, du))
        FitHeight(duelScroll, duelChild and duelChild:GetHeight() or 0)
    end
end
function UI.ShowTab(key) currentTab = key; fitPending = true; RenderTab() end
function UI.ShowBuffSub(key) buffSubTab = key; fitPending = true; RenderTab() end
function UI.ShowFlowSub(key)
    F.subTab = key
    F.pinned = false   -- pin is per-view; clear it (and its readout) when switching sub-tabs
    F.burstSel = nil   -- burst selection likewise
    if F.Scrub then F.Scrub:SetHidden(true) end
    if F.ScrubBox then F.ScrubBox:SetHidden(true) end
    fitPending = true; RenderTab()
end
function UI.ShowLogFilter(key) F.logFilter = key; RenderTab() end

-- ---------------------------------------------------------------------------
-- Duel-detail search (find across every tab of the OPEN duel). Find-as-you-type: each
-- keystroke re-indexes, jumps to the first hit's tab/sub-tab, scrolls it into view and
-- highlights the exact row; ‹ › (or Enter) step through all hits across tabs; live N/M count.
-- ---------------------------------------------------------------------------
local function StripColor(s) return s and (s:gsub("|c%x%x%x%x%x%x", ""):gsub("|r", "")) or "" end
local function BuildSearchMatches(du, term)
    local m = {}
    if not du or term == "" then return m end
    term = term:lower()
    local oppName = (currentDuel and currentDuel.o and (currentDuel.o.name or currentDuel.o.handle)) or "Target"
    local function add(tab, subtab, items)
        -- idx = position in this built list. RenderLinesInto renders the SAME list with the
        -- SAME builder into an index-aligned pool, so idx == the on-screen row's pool index.
        for idx, it in ipairs(items) do
            local txt = it.left and StripColor(it.left)
            if txt and txt ~= "" and txt:lower():find(term, 1, true) then
                m[#m + 1] = { tab = tab, subtab = subtab, label = txt, idx = idx }
            end
        end
    end
    local dd = {}; AbilityRows(dd, du.dealtTop, du.durationS); add("damage", "dealt", dd)
    local dt = {}; AbilityRows(dt, du.takenTop, du.durationS); add("damage", "taken", dt)
    add("healing", nil, HealingItems(du))
    local bb = {}; EffectRows(bb, du.buffsMe, du.durationS); add("buffs", "buffs", bb)
    local dbf = {}; DirEffectRows(dbf, NonStatus(du.debuffsOpp), NonStatus(du.debuffsMe), du.durationS, "Debuff", oppName); add("buffs", "debuffs", dbf)
    local stf = {}; DirEffectRows(stf, StatusOnly(du.debuffsOpp), StatusOnly(du.debuffsMe), du.durationS, "Status Effect", oppName); add("buffs", "status", stf)
    local ccf = {}; ControlRows(ccf, du, oppName); add("buffs", "control", ccf)
    add("stats", nil, StatsItems(du))
    add("optim", nil, GradeItems(du))
    local bl, br = BD.Cols(du)
    add("build", "left", bl); add("build", "right", br)
    return m
end
local function UpdateSearchCount()
    if not DS.Count then return end
    local hasTerm = DS.Term ~= ""
    -- The count lives in its own chip "pill" (DS.CountBg) so N/M is always readable and never
    -- sits under the arrows. Pill is hidden entirely when the box is empty (no clutter).
    if DS.CountBg then DS.CountBg:SetHidden(not hasTerm) end
    if not hasTerm then
        DS.Count:SetText("")
    elseif #DS.Matches == 0 then
        DS.Count:SetText("none"); DS.Count:SetColor(unpack(C.lo))   -- calm, not an alarming "0/0"
    else
        DS.Count:SetText(string.format("%d/%d", (DS.Idx > 0 and DS.Idx or 1), #DS.Matches))
        DS.Count:SetColor(unpack(C.hi))
    end
    -- Arrows only make sense with something to step through; hide until there are 2+ matches.
    local many = #DS.Matches > 1
    if DS.Prev then DS.Prev:SetHidden(not many) end
    if DS.Next then DS.Next:SetHidden(not many) end
end

-- Resolve which scroll container + row pool the given match lives in, so we can scroll it
-- into view and light it up. Damage has two side-by-side panels (dealt/taken); buffs share
-- one panel across sub-tabs; the rest share the single duel scroll.
local function MatchTarget(mt)
    if mt.tab == "damage" then
        if mt.subtab == "taken" then return takenScroll, takenLines else return dealtScroll, dealtLines end
    elseif mt.tab == "buffs" then
        return buffScroll, buffLines
    elseif mt.tab == "build" then
        if mt.subtab == "right" then return BD.SR, BD.PR else return BD.SL, BD.PL end
    else
        return duelScroll, detailLines
    end
end
local function HighlightMatch(mt)
    if not mt then return end
    local scroll, pool = MatchTarget(mt)
    local ln = pool and pool[mt.idx]
    if not ln then return end
    if ln.hl then ln.hl:SetHidden(false) end
    if scroll then pcall(ZO_Scroll_ScrollControlIntoView, scroll, ln) end
end
local function GotoMatch(i)
    local n = #DS.Matches
    if n == 0 then return end
    if i < 1 then i = n elseif i > n then i = 1 end
    DS.Idx = i
    local mt = DS.Matches[i]
    currentTab = mt.tab
    -- Only buffs matches carry a real sub-tab; damage's "dealt"/"taken" subtab picks the panel
    -- in HighlightMatch and must NOT leak into buffSubTab (would corrupt the Buffs view).
    if mt.tab == "buffs" and mt.subtab then buffSubTab = mt.subtab end
    UpdateSearchCount()
    RenderTab()             -- clears highlights + rebuilds the target panel...
    HighlightMatch(mt)      -- ...then scroll to + highlight the exact row.
end
-- noJump = silent re-index (used when a duel opens with a term already in the box): recompute
-- the count but DON'T yank the user to another tab; only light the first hit if it's already
-- on the current tab. Fresh typing (noJump nil) does find-as-you-type: jump to hit #1 so the
-- count and the on-screen highlight stay in lock-step with each keystroke.
local function RunSearch(term, noJump)
    local prevIdx = DS.Idx
    DS.Term = (term or ""):gsub("^%s+", ""):gsub("%s+$", "")
    DS.Matches = (currentDuel and currentDuel.du) and BuildSearchMatches(currentDuel.du, DS.Term) or {}
    if #DS.Matches > 0 and not noJump then
        GotoMatch(1)
    else
        -- Silent re-index (duel open / window resize): keep the user's current match position when
        -- it's still valid, and re-highlight it if it's on the tab they're already viewing.
        local keep = (prevIdx >= 1 and prevIdx <= #DS.Matches) and prevIdx or (#DS.Matches > 0 and 1 or 0)
        DS.Idx = keep
        UpdateSearchCount()
        if currentDuel then RenderTab() end
        local mt = keep > 0 and DS.Matches[keep] or nil
        if mt and mt.tab == currentTab and (mt.tab ~= "buffs" or (mt.subtab or "buffs") == buffSubTab) then
            HighlightMatch(mt)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Header renderers
-- ---------------------------------------------------------------------------
local function RenderHero()
    local cid = (GetUnitClassId and GetUnitClassId("player")) or 0
    local ic = ClassIcon(cid)
    if ic then heroIcon:SetHidden(false); heroIcon:SetTexture(ic) else heroIcon:SetHidden(true) end
    heroName:SetText(PlayerName())
    local raceId = (GetUnitRaceId and GetUnitRaceId("player")) or 0
    local cp = (GetPlayerChampionPointsEarned and GetPlayerChampionPointsEarned()) or 0
    heroClass:SetText(string.format("%s %s   \226\128\162   %d CP", RaceName(raceId), ClassName(cid), cp))
    local w, l, dr = OverallStats()
    local rate, total = WinRate(w, l, dr)
    heroRecord:SetText(WLD(w, l, dr))
    heroRecordSub:SetText(total == 0 and "No duels yet" or string.format("%d%% Win Rate   \226\128\162   %d Duels", rate, total))
    local rk = RANK.Compute()
    if RANK.rungRows then for _, hl in pairs(RANK.rungRows) do hl:SetHidden(true) end end
    if rk.provisional then
        heroRankLetter:SetText("N/A")                                -- not enough rated rivals yet
        heroRankLetter:SetColor(unpack(C.lo))
        if RANK.suffix then RANK.suffix:SetText("") end
        if RANK.badge then RANK.badge:SetAlpha(1); RANK.badge:SetScale(1) end
        if RANK.chipBg then RANK.chipBg:SetEdgeColor(unpack(C.line)) end   -- neutral border until placed
        if RANK.anim then RANK.anim:Stop() end
        if RANK.burst then RANK.burst:SetHidden(true) end
        if RANK.label then RANK.label:SetText(string.format("%d/%d", rk.rivals, rk.need)) end
        local togo = rk.need - rk.rivals
        if RANK.progLbl then RANK.progLbl:SetText(string.format("Duel %d more rival%s to get placed (%d duels each)", togo, togo == 1 and "" or "s", rk.minduels or 2)) end
        if RANK.progFill then RANK.progFill:SetColor(unpack(C.lo)); RANK.progFill:SetWidth(math.max(1, 198 * (rk.rivals / rk.need))) end
    else
        local col = RANK.Color(rk.tier)
        RANK.PaintBadge(heroRankLetter, RANK.suffix, rk.tier, col)
        if RANK.chipBg then RANK.chipBg:SetEdgeColor(unpack(col)) end       -- chip border in the tier colour
        if RANK.burst then RANK.burst:SetColor(col[1], col[2], col[3], 0.38) end  -- dim glow so the letter stays legible
        if RANK.progFill then RANK.progFill:SetColor(unpack(col)) end
        if RANK.label then RANK.label:SetText("RANK") end
        -- S-band tiers (S+/S/S-) get the premium treatment: spinning burst + badge shimmer.
        -- Everything else sits static and crisp.
        local premium = rk.tier:sub(1, 1) == "S"
        if RANK.burst then RANK.burst:SetHidden(not premium) end   -- OnUpdate spins it only while shown
        if RANK.anim then
            if premium then
                if not RANK.anim:IsPlaying() then RANK.anim:PlayFromStart() end
            else
                RANK.anim:Stop()
                if RANK.badge then RANK.badge:SetAlpha(1); RANK.badge:SetScale(1) end
            end
        end
        if RANK.rungRows and RANK.rungRows[rk.tier] then RANK.rungRows[rk.tier]:SetHidden(false) end
        local nextTier, frac, need = RANK.Progress(rk)
        if not nextTier then
            if RANK.progLbl then RANK.progLbl:SetText(RANK.TopRankLabel((GetDisplayName and GetDisplayName()) or "")) end
            if RANK.progFill then RANK.progFill:SetWidth(198) end
        else
            local fill = frac
            if nextTier == "S+" and rk.worst < RANK.SPLUS_WORST then
                if RANK.progLbl then RANK.progLbl:SetText(string.format("For S+: beat every rival \226\137\165 65%% (worst now %d%%)", math.floor(rk.worst + 0.5))) end
                fill = math.max(0, math.min(1, rk.worst / RANK.SPLUS_WORST))
            elseif RANK.progLbl then
                RANK.progLbl:SetText(string.format("Next: %s  \226\128\162  avg %d%% \226\134\146 %d%%", nextTier, math.floor(rk.mean + 0.5), need))
            end
            if RANK.progFill then RANK.progFill:SetWidth(math.max(1, 198 * fill)) end
        end
    end
end

local function RenderNav()
    for _, b in pairs(navButtons) do
        local act = (b.key == homeTab)
        b.lbl:SetColor(unpack(act and C.hi or C.mid))
        b.underline:SetHidden(not act)
    end
end

local function GetSortChip(i)
    local c = sortChips[i]
    if c then return c end
    c = {}
    c.btn = WM:CreateControl(nil, sortPane, CT_CONTROL)
    c.btn:SetHeight(24)
    c.btn:SetMouseEnabled(true)
    c.bg = backdrop(c.btn, C.win0, C.line, 1)
    c.lbl = label(c.btn, 14, C.mid, TEXT_ALIGN_CENTER)
    c.lbl:SetAnchorFill(c.btn); c.lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    AddPress(c.btn)
    sortChips[i] = c
    return c
end

-- Draw the sort-chip row for the active home tab. Clicking a chip sorts by that key;
-- clicking the active chip again flips direction (arrow shows asc/desc).
local function RenderSortBar()
    local opts, st = SORTS[homeTab], sortState[homeTab]
    local x = 44
    for i, opt in ipairs(opts) do
        local c = GetSortChip(i)
        local act = (opt.key == st.key)
        c.btn:SetHidden(false)
        -- Direction shown with ESO's built-in sort-arrow textures (font lacks ▲/▼ glyphs).
        local arrow = act and (st.dir < 0
            and "  |t14:14:EsoUI/Art/Miscellaneous/list_sortdown.dds|t"
            or  "  |t14:14:EsoUI/Art/Miscellaneous/list_sortup.dds|t") or ""
        c.lbl:SetText(opt.label .. arrow)
        c.lbl:SetColor(unpack(act and C.accent or C.mid))
        c.bg:SetCenterColor(unpack(act and C.chip or C.win0))
        local w = math.max(52, math.floor(c.lbl:GetTextWidth()) + 22 + (act and 16 or 0))
        c.btn:SetWidth(w)
        c.btn:ClearAnchors()
        c.btn:SetAnchor(LEFT, sortPane, LEFT, x, 0)
        x = x + w + 6
        local key = opt.key
        c.btn:SetHandler("OnMouseUp", function(_, _, inside)
            if not inside then return end
            if st.key == key then st.dir = -st.dir else st.key = key; st.dir = (key == "name") and 1 or -1 end
            Render()
        end)
    end
    for i = #opts + 1, #sortChips do sortChips[i].btn:SetHidden(true) end
end

-- Toggle between the text crumb (opponent/class views) and the duel matchup crumb.
local function CrumbMatchup(show)
    for _, c in ipairs({ CR.IconMe, CR.MeName, CR.Vs, CR.IconOpp, CR.OppName }) do c:SetHidden(not show) end
    CR.Prev.btn:SetHidden(not show)
    CR.Next.btn:SetHidden(not show)
    CR.Title:SetHidden(show)
end
local function RenderCrumb(title, sub, right)
    CrumbMatchup(false)
    CR.Sub:ClearAnchors()
    CR.Sub:SetAnchor(TOPLEFT, CR.Title, BOTTOMLEFT, 0, 4)
    CR.Sub:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
    CR.Title:SetText(title or "")
    CR.Sub:SetText(sub or "")
    -- Non-duel views: the Tab Guide (i) pill is hidden, so CR.Right owns the corner.
    CR.Right:ClearAnchors()
    CR.Right:SetAnchor(TOPRIGHT, CR.Pane, TOPRIGHT, 0, 8)
    CR.Right:SetText(right or "")
end
local function RenderDuelCrumb(du, o)
    CrumbMatchup(true)
    local myIc, oppIc = ClassIcon(du.myClassId), ClassIcon(du.oppClassId)
    if myIc then CR.IconMe:SetHidden(false); CR.IconMe:SetTexture(myIc) else CR.IconMe:SetHidden(true) end
    if oppIc then CR.IconOpp:SetHidden(false); CR.IconOpp:SetTexture(oppIc) else CR.IconOpp:SetHidden(true) end
    CR.MeName:SetText((du.myHandle and du.myHandle ~= "" and du.myHandle) or "@you")
    CR.OppName:SetText((o.handle and o.handle ~= "" and o.handle) or (o.name or "?"))
    -- Center the fight-card title (kept clear of the back/prev/next buttons on the left). The
    -- search bar now lives on the tab-bar row, so the title reclaims the full crumb width.
    local totalW = 30 + 8 + CR.MeName:GetTextWidth() + 12 + CR.Vs:GetTextWidth() + 12 + 30 + 8 + CR.OppName:GetTextWidth()
    local paneW = CR.Pane:GetWidth(); if paneW < 100 then paneW = contentW end
    CR.IconMe:ClearAnchors()
    CR.IconMe:SetAnchor(TOPLEFT, CR.Pane, TOPLEFT, math.max(276, math.floor((paneW - totalW) / 2)), 6)
    -- Sub-line (characters, classes, result, date, series) sits below; the matchup header above is
    -- raised to align with the Back-button row so it's not floating low.
    local rc = RCLR[du.result] or C.mid
    CR.Sub:ClearAnchors()
    CR.Sub:SetAnchor(TOPLEFT, CR.Pane, TOPLEFT, 0, 46)
    CR.Sub:SetAnchor(TOPRIGHT, CR.Pane, TOPRIGHT, 0, 46)
    CR.Sub:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
    local function fighter(name, raceId, classId, cp)
        local race = RaceName(raceId)
        return string.format("%s \226\128\162 %s%s \226\128\162 %s CP", name or "?", (race ~= "" and (race .. " ") or ""), ClassName(classId), cp and tostring(cp) or "?")
    end
    CR.Sub:SetText(string.format("%s      vs      %s      \226\128\162   |c%s%s|r   \226\128\162   %s   \226\128\162   Overall %s",
        fighter(du.myName, du.myRaceId, du.myClassId, du.myCP),
        fighter(o.name, du.oppRaceId, du.oppClassId, du.oppCP),
        Hex(rc), (du.result or "?"):upper(), DateStr(du.date, true), WLD(o.wins, o.losses, o.draws)))
    -- Stable duel id so a specific duel can be called out by number. The Tab Guide (i) pill owns the
    -- fight card's top-right corner, so the badge docks just LEFT of it (was colliding underneath).
    CR.Right:ClearAnchors()
    if UI.guide.Btn then CR.Right:SetAnchor(RIGHT, UI.guide.Btn, LEFT, -14, 0)
    else CR.Right:SetAnchor(TOPRIGHT, CR.Pane, TOPRIGHT, 0, 8) end
    CR.Right:SetText(du.id and ("|c6a6f7bDuel|r  #" .. tostring(du.id)) or "")
    -- Prev (older) / Next (more recent) within the list you drilled in from.
    local cur = currentDuel
    local parent = nav[#nav - 1]
    local sibs
    if parent and parent.kind == "opponent" then sibs = DuelsVsOpponent(parent.handle)
    elseif parent and parent.kind == "class" then sibs = DuelsVsClass(parent.classId)
    else sibs = AllDuels() end
    local pos
    for i, e in ipairs(sibs) do if e.handle == cur.handle and e.idx == cur.idx then pos = i; break end end
    local hasNext = pos and pos > 1               -- more recent
    local hasPrev = pos and pos < #sibs           -- older
    CR.Next.lbl:SetColor(unpack(hasNext and C.accent or C.dim))
    CR.Prev.lbl:SetColor(unpack(hasPrev and C.accent or C.dim))
    CR.Next.btn:SetHandler("OnMouseUp", function(_, _, ins)
        if ins and hasNext then local e = sibs[pos - 1]; nav[#nav] = { kind = "duel", handle = e.handle, idx = e.idx }; Render() end
    end)
    CR.Prev.btn:SetHandler("OnMouseUp", function(_, _, ins)
        if ins and hasPrev then local e = sibs[pos + 1]; nav[#nav] = { kind = "duel", handle = e.handle, idx = e.idx }; Render() end
    end)
end

-- ---------------------------------------------------------------------------
-- Render dispatch (assigns the forward-declared `Render`)
-- ---------------------------------------------------------------------------
-- Set pane visibility for the target view WITHOUT toggling shared panes off-then-on.
-- (Hiding navPane even momentarily drops the search box's keyboard focus, which killed
-- typing after one character.) SetHidden(false) on an already-visible pane is a no-op.
local function SetChrome(kind)
    local home = (kind == "home")
    if heroPane then heroPane:SetHidden(not home) end
    if navPane then navPane:SetHidden(not home) end
    if footer then footer:SetHidden(not home) end
    if sortPane and not home then sortPane:SetHidden(true) end
    if CR.Pane then CR.Pane:SetHidden(home) end
    if detailTabBar then detailTabBar:SetHidden(kind ~= "duel") end
    if DS.Bar then DS.Bar:SetHidden(kind ~= "duel") end   -- find-in-tabs only in the duel view
    if UI.guide.Btn then UI.guide.Btn:SetHidden(kind ~= "duel") end   -- Tab Guide (i) only in the duel view
    if UI.guide.modal and kind ~= "duel" then UI.guide.modal:SetHidden(true) end   -- never leave the overlay up when leaving a duel
end
local function AnchorList(below, bottomTarget)
    listScroll:SetHidden(false); duelScroll:SetHidden(true)
    if dmgPane then dmgPane:SetHidden(true) end
    if buffPane then buffPane:SetHidden(true) end
    if F.Pane then F.Pane:SetHidden(true) end
    if BD.Pane then BD.Pane:SetHidden(true) end
    if RC.Pane then RC.Pane:SetHidden(true) end   -- else the Report Card radar/report layers over the home list
    listScroll:ClearAnchors()
    listScroll:SetAnchor(TOPLEFT, below, BOTTOMLEFT, 0, 8)
    if bottomTarget then listScroll:SetAnchor(BOTTOMRIGHT, bottomTarget, TOPRIGHT, 0, -6)
    else listScroll:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0) end
end

Render = function()
    if not win then return end
    local v = nav[#nav] or { kind = "home" }
    SetChrome(v.kind)

    if v.kind == "home" then
        footer:SetText(string.format("%s   \226\128\162   %s   \226\128\162   Shoyru's PvP Metrics  v%s", (GetDisplayName and GetDisplayName()) or "", DateStr(), UI.VERSION or "?"))
        RenderHero(); RenderNav()
        if homeTab == "recent" then           -- Recent stays newest-first, no sort bar
            sortPane:SetHidden(true)
            AnchorList(navPane, footer)
        else
            sortPane:SetHidden(false)
            RenderSortBar()
            AnchorList(sortPane, footer)
        end
        local empty = homeTab == "recent" and "No duels yet \226\128\148 go duel someone, or run /smxdemo to preview."
            or (homeTab == "opponents" and "No opponents yet." or "No matchups yet.")
        RenderList(FilterItems(HomeItems(homeTab)), empty)
        FitHeight(listScroll, (listChild and listChild:GetHeight() or 0) + 26, 860)   -- +footer, capped browse height

    elseif v.kind == "opponent" then
        CR.Pane:SetHidden(false)
        local o = sv and sv.opponents and sv.opponents[v.handle]
        if o then
            local rate = WinRate(o.wins, o.losses, o.draws)
            RenderCrumb((o.handle and o.handle ~= "" and o.handle) or o.name or "?", string.format("|c%s%s|r   \226\128\162  %s", Hex(C.lo), o.name or "", ClassName(o.classId)),
                string.format("%s    %d%% wr", WLD(o.wins, o.losses, o.draws), rate))
        end
        AnchorList(CR.Pane)
        local items = {}
        for _, e in ipairs(DuelsVsOpponent(v.handle)) do items[#items+1] = DuelItem(e) end
        RenderList(items, "No duels recorded vs this opponent.")
        FitHeight(listScroll, (listChild and listChild:GetHeight() or 0), 860)

    elseif v.kind == "class" then
        CR.Pane:SetHidden(false)
        local w, l, dr, n = 0, 0, 0, 0
        local items = {}
        for _, e in ipairs(DuelsVsClass(v.classId)) do
            items[#items+1] = DuelItem(e); n = n + 1
            if e.du.result == "win" then w = w + 1 elseif e.du.result == "draw" then dr = dr + 1 else l = l + 1 end
        end
        local rate = WinRate(w, l, dr)
        RenderCrumb(ClassName(v.classId) .. " matchups", string.format("%d duel%s", n, n == 1 and "" or "s"),
            string.format("%s    %d%% wr", WLD(w, l, dr), rate))
        AnchorList(CR.Pane)
        RenderList(items, "No duels recorded vs this class.")
        FitHeight(listScroll, (listChild and listChild:GetHeight() or 0), 860)

    else -- duel detail
        CR.Pane:SetHidden(false); detailTabBar:SetHidden(false)
        listScroll:SetHidden(true); duelScroll:SetHidden(false)
        local o = sv and sv.opponents and sv.opponents[v.handle]
        local du = o and o.duels and o.duels[v.idx]
        if not du then Back(); return end
        currentDuel = { handle = v.handle, idx = v.idx, o = o, du = du }
        currentTab = currentTab or "damage"
        RenderDuelCrumb(du, o)
        duelScroll:ClearAnchors()
        duelScroll:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
        duelScroll:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
        RenderTab()
        -- Re-index the now-open duel WITHOUT auto-switching tabs (silent); runs after RenderTab
        -- so its highlight (if the first hit is on this tab) isn't wiped by the render.
        if DS.Edit then RunSearch(DS.Edit:GetText(), true) end
    end
end

-- ---------------------------------------------------------------------------
-- Window construction
-- ---------------------------------------------------------------------------
local SEARCH_W, SEARCH_GAP = 300, 16   -- room reserved at the right of the tab row for DS.Bar
local function LayoutTabs()
    if not detailTabBar then return end
    detailTabBar:SetWidth(tabBarW)
    -- The duel search bar sits at the right end of this row (it navigates tabs); tabs share the rest.
    if DS.Bar then
        DS.Bar:ClearAnchors()
        DS.Bar:SetAnchor(RIGHT, detailTabBar, RIGHT, 0, 0)   -- RIGHT anchor => vertically centred in the row
        DS.Bar:SetWidth(SEARCH_W)
    end
    local tabsW = math.max(240, tabBarW - SEARCH_W - SEARCH_GAP)
    local gaps = 5
    local bw = math.floor((tabsW - gaps * (#TABS - 1)) / #TABS)
    for i, t in ipairs(TABS) do
        local e = detailTabButtons[t.key]
        if e and e.btn then
            e.btn:SetWidth(bw)
            e.btn:ClearAnchors()
            e.btn:SetAnchor(LEFT, detailTabBar, LEFT, (i - 1) * (bw + gaps), 0)
        end
    end
end
local function Relayout()
    if not win then return end
    local ww = win:GetWidth()
    contentW = math.max(240, ww - PAD * 2 - 24)
    tabBarW  = math.max(240, ww - PAD * 2)
    if listChild then listChild:SetWidth(ww - PAD * 2 - 20) end
    if duelChild then duelChild:SetWidth(ww - PAD * 2 - 20) end
    if dealtChild then dealtChild:SetWidth(ww - PAD * 2 - 20) end
    if takenChild then takenChild:SetWidth(ww - PAD * 2 - 20) end
    if buffChild then buffChild:SetWidth(ww - PAD * 2 - 20) end
    if F.LogChild then F.LogChild:SetWidth(ww - PAD * 2 - 20) end
    if F.BreakChild then F.BreakChild:SetWidth(ww - PAD * 2 - 20) end
    LayoutTabs()
    if sv then sv.win = sv.win or {}; sv.win.w = ww; sv.win.h = win:GetHeight() end
    Render()
end

local function detailTabButton(t)
    local btn = WM:CreateControl(nil, detailTabBar, CT_CONTROL)
    btn:SetHeight(37)
    btn:SetMouseEnabled(true)
    local bg = backdrop(btn, C.win0, C.line, 1)
    local ic = WM:CreateControl(nil, btn, CT_TEXTURE)
    ic:SetDimensions(22, 22)
    ic:SetAnchor(LEFT, btn, LEFT, 9, 0)
    if TAB_ICON[t.key] then ic:SetTexture(TAB_ICON[t.key]) else ic:SetHidden(true) end
    local lbl = label(btn, 15, C.mid, TEXT_ALIGN_LEFT)
    lbl:SetAnchor(LEFT, ic, RIGHT, 6, 0)
    lbl:SetAnchor(RIGHT, btn, RIGHT, -4, 0)
    lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    lbl:SetText(t.label)
    btn:SetHandler("OnMouseUp", function(_, _, inside) if inside then UI.ShowTab(t.key) end end)
    AddPress(btn)
    detailTabButtons[t.key] = { key = t.key, btn = btn, bg = bg, lbl = lbl, icon = ic }
end

local function navButton(key, text, x, w)
    local btn = WM:CreateControl(nil, navPane, CT_CONTROL)
    btn:SetDimensions(w, 34)
    btn:SetAnchor(TOPLEFT, navPane, TOPLEFT, x, 0)
    btn:SetMouseEnabled(true)
    local lbl = label(btn, 17, C.mid, TEXT_ALIGN_CENTER, "bold")
    lbl:SetAnchorFill(btn); lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    lbl:SetText(text)
    local underline = WM:CreateControl(nil, btn, CT_BACKDROP)
    underline:SetDimensions(w - 20, 3)
    underline:SetAnchor(BOTTOM, btn, BOTTOM, 0, 0)
    underline:SetCenterColor(unpack(C.accent))
    underline:SetEdgeColor(0, 0, 0, 0)
    underline:SetHidden(true)
    btn:SetHandler("OnMouseUp", function(_, _, inside) if inside then homeTab = key; Render() end end)
    AddPress(btn)
    navButtons[key] = { key = key, btn = btn, lbl = lbl, underline = underline }
end

local function BuildWindow()
    win = WM:CreateTopLevelWindow("ShoyrUI_DuelMetricsWindow")
    local w0 = math.max(MINW, math.min(MAXW, (sv and sv.win and sv.win.w) or W))
    local h0 = math.max(MINH, math.min(MAXH, (sv and sv.win and sv.win.h) or H))
    win:SetDimensions(w0, h0)
    win:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0)
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:SetMouseEnabled(true)
    win:SetDrawTier(DT_HIGH)
    win:SetHidden(true)
    win:SetDimensionConstraints(MINW, MINH, MAXW, MAXH)
    win:SetResizeHandleSize(8)
    -- Reflow whenever the window's SIZE changes (fires during the drag). Guarded on
    -- w/h so merely moving the window doesn't re-render. OnResizeStop kept as a backstop.
    win:SetHandler("OnRectChanged", function()
        if not (win and built) then return end
        local ww, hh = win:GetWidth(), win:GetHeight()
        if math.abs(ww - lastW) >= 1 or math.abs(hh - lastH) >= 1 then
            lastW, lastH = ww, hh
            Relayout()
        end
    end)
    win:SetHandler("OnResizeStop", function() Relayout() end)
    backdrop(win, C.win0, C.line, 2)

    local title = label(win, 22, C.accent, nil, "bold")
    title:SetAnchor(TOPLEFT, win, TOPLEFT, PAD, 14)
    title:SetText("Shoyru's PvP Metrics - Duels")
    local hint = label(win, 13, C.lo)
    hint:SetAnchor(BOTTOMLEFT, title, BOTTOMRIGHT, 10, -2)
    hint:SetText("/SMX")

    local close = WM:CreateControlFromVirtual("ShoyrUI_DMUIClose", win, "ZO_CloseButton")
    close:SetAnchor(TOPRIGHT, win, TOPRIGHT, -10, 12)
    close:SetHandler("OnClicked", function() UI.Hide() end)
    close:SetHandler("OnMouseUp", function(_, _, inside) if inside then UI.Hide() end end)

    content = WM:CreateControl(nil, win, CT_CONTROL)
    content:SetAnchor(TOPLEFT, win, TOPLEFT, PAD, TOP)
    content:SetAnchor(BOTTOMRIGHT, win, BOTTOMRIGHT, -PAD, -PAD)

    -- ---- HERO panel (home) ----
    heroPane = WM:CreateControl(nil, content, CT_CONTROL)
    heroPane:SetAnchor(TOPLEFT, content, TOPLEFT, 0, 0)
    heroPane:SetAnchor(TOPRIGHT, content, TOPRIGHT, 0, 0)
    heroPane:SetHeight(132)   -- tall enough that the rank progression bar sits INSIDE the card, right under the record
    backdrop(heroPane, C.card, C.line, 1)
    heroIcon = WM:CreateControl(nil, heroPane, CT_TEXTURE)
    heroIcon:SetDimensions(54, 54)
    heroIcon:SetAnchor(LEFT, heroPane, LEFT, 18, 0)
    heroName = label(heroPane, 26, C.hi, nil, "bold")
    heroName:SetAnchor(TOPLEFT, heroIcon, TOPRIGHT, 16, 4)
    heroClass = label(heroPane, 15, C.mid)
    heroClass:SetAnchor(TOPLEFT, heroName, BOTTOMLEFT, 2, 4)
    -- rank chip (right)
    local rankChip = WM:CreateControl(nil, heroPane, CT_CONTROL)
    rankChip:SetDimensions(74, 66)
    rankChip:SetAnchor(TOPRIGHT, heroPane, TOPRIGHT, -18, 11)
    RANK.chipBg = backdrop(rankChip, C.chip, C.line, 2)   -- border recoloured to the tier in RenderHero
    -- Badge = a container holding the base letter + its +/- modifier as SEPARATE labels, so the base
    -- letter always sits at the same spot (a lone "S" used to center differently from "S+"/"S-"). The
    -- shimmer animates the CONTAINER, so letter and modifier breathe together.
    RANK.badge = WM:CreateControl(nil, rankChip, CT_CONTROL)
    RANK.badge:SetDimensions(74, 44); RANK.badge:SetAnchor(CENTER, rankChip, CENTER, 0, -4)
    heroRankLetter = label(RANK.badge, 30, C.accent, TEXT_ALIGN_CENTER, "bold")
    heroRankLetter:SetDimensions(74, 44); heroRankLetter:SetAnchor(CENTER, RANK.badge, CENTER, 0, 0)  -- full width: the whole tier ("A+") centres here
    heroRankLetter:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    RANK.suffix = label(RANK.badge, 20, C.accent, TEXT_ALIGN_LEFT, "bold")   -- legacy split label, now always empty
    RANK.suffix:SetAnchor(LEFT, heroRankLetter, RIGHT, 0, 0)
    RANK.label = label(rankChip, 11, C.lo, TEXT_ALIGN_CENTER)
    RANK.label:SetAnchor(BOTTOM, rankChip, BOTTOM, 0, -6)
    RANK.label:SetWidth(74); RANK.label:SetText("RANK")
    -- PREMIUM S TIERS: a gold ray-burst (ESO's crafting white_burst, additive-blended + tinted)
    -- slowly ROTATES behind the badge, and the letter shimmers. RenderHero shows these only for
    -- S-band tiers (S+/S/S-). Rotation = per-frame SetTextureRotation (the reference addons' proven
    -- method; ANIMATION_ROTATE is NOT reliable) and OnUpdate only fires while the burst is shown, so
    -- lower tiers pay nothing. Whole block is pcall-guarded so a texture/anim quirk can NEVER abort
    -- BuildWindow (that leaves an orphaned top-level window -> "duplicate name" on the next open).
    heroRankLetter:SetDrawLevel(2)   -- keep the letter above the burst
    pcall(function()
        RANK.burst = WM:CreateControl(nil, rankChip, CT_TEXTURE)
        RANK.burst:SetTexture("EsoUI/Art/Crafting/white_burst.dds")
        RANK.burst:SetDimensions(76, 76)
        RANK.burst:SetAnchor(CENTER, rankChip, CENTER, 0, -3)
        RANK.burst:SetColor(unpack(C.accent))
        RANK.burst:SetDrawLevel(0); RANK.burst:SetHidden(true)
        pcall(function() RANK.burst:SetBlendMode(TEX_BLEND_MODE_ADD) end)   -- glow, not a flat overlay
        RANK.burst:SetHandler("OnUpdate", function(self)
            self:SetTextureRotation(((GetGameTimeMilliseconds() % 9000) / 9000) * (2 * math.pi), 0.5, 0.5)
        end)
    end)
    pcall(function()
        RANK.anim = ANIMATION_MANAGER:CreateTimeline()   -- badge shimmer (alpha + scale breathing)
        local shA = RANK.anim:InsertAnimation(ANIMATION_ALPHA, RANK.badge, 0)
        shA:SetAlphaValues(0.62, 1.0); shA:SetDuration(850)
        local shS = RANK.anim:InsertAnimation(ANIMATION_SCALE, RANK.badge, 0)
        shS:SetScaleValues(0.97, 1.12); shS:SetDuration(850)
        RANK.anim:SetPlaybackType(ANIMATION_PLAYBACK_PING_PONG, LOOP_INDEFINITELY)
    end)
    -- little (i) button just off the chip's top-right -> opens the "how ranks work" modal.
    local info = WM:CreateControl(nil, heroPane, CT_CONTROL)
    info:SetDimensions(16, 16)
    info:SetAnchor(TOPRIGHT, rankChip, TOPRIGHT, -2, 2)   -- tucked into the chip's top-right corner
    backdrop(info, C.chip, C.line, 1)
    local infoL = label(info, 13, C.accent, TEXT_ALIGN_CENTER, "bold")
    infoL:SetAnchorFill(info); infoL:SetVerticalAlignment(TEXT_ALIGN_CENTER); infoL:SetText("i")
    info:SetMouseEnabled(true)
    info:SetHandler("OnMouseUp", function(_, _, inside) if inside then RANK.ToggleModal() end end)
    info:SetHandler("OnMouseEnter", function()
        InitializeTooltip(InformationTooltip, info, BOTTOMRIGHT, 0, 4, TOPRIGHT)   -- just below the (i), consistent
        SetTooltipText(InformationTooltip, "Progression System Info")
    end)
    info:SetHandler("OnMouseExit", function() ClearTooltip(InformationTooltip) end)
    -- Hover the chip: explain HOW the rank was earned (mean win rate + rival/peer/nemesis
    -- makeup, or how far off ranking you still are). relativePoint passed explicitly (an
    -- omitted one mirrors the point and clamps the tooltip to a screen edge).
    rankChip:SetMouseEnabled(true)
    rankChip:SetHandler("OnMouseEnter", function()
        local rk = RANK.Compute()
        local tip
        if rk.provisional then
            local togo = rk.need - rk.rivals
            tip = string.format("Tier: Unranked\nRivals Rated: %d / %d  (a rival = %d+ decisive duels, win or loss)\n\nDuel %d more rival%s to be placed.",
                rk.rivals, rk.need, rk.minduels or 2, togo, togo == 1 and "" or "s")
            if rk.partial and #rk.partial > 0 then
                tip = tip .. "\n\nAlmost rated (re-duel to count):"
                for _, p in ipairs(rk.partial) do
                    tip = tip .. string.format("\n  %s  \226\128\148  %d more duel%s", p.name, p.need, p.need == 1 and "" or "s")
                end
            end
        else
            tip = string.format("Tier: %s\nAverage Win Rate: %d%%\nWorst Matchup: %d%%\nRivals Rated: %d",
                rk.tier, math.floor(rk.mean + 0.5), math.floor(rk.worst + 0.5), rk.rivals)
        end
        InitializeTooltip(InformationTooltip, rankChip, BOTTOM, 0, 4, TOP)   -- centred just below the rank chip
        SetTooltipText(InformationTooltip, tip)
    end)
    rankChip:SetHandler("OnMouseExit", function() ClearTooltip(InformationTooltip) end)
    -- record + Win%/Duels, aligned on the same line as the rank chip
    heroRecord = label(heroPane, 29, C.hi, TEXT_ALIGN_RIGHT, "bold")
    heroRecord:SetAnchor(TOPRIGHT, rankChip, TOPLEFT, -24, 3)
    heroRecordSub = label(heroPane, 17, C.hi, TEXT_ALIGN_RIGHT, "bold")
    heroRecordSub:SetAnchor(TOPRIGHT, heroRecord, BOTTOMRIGHT, 0, 8)
    -- rank progression: a caption + a thin fill bar showing how far to the next rung.
    RANK.progLbl = label(heroPane, 12, C.mid, TEXT_ALIGN_RIGHT)
    RANK.progLbl:SetAnchor(TOPRIGHT, heroRecordSub, BOTTOMRIGHT, 0, 9)
    RANK.progLbl:SetWidth(320)
    RANK.progBg = WM:CreateControl(nil, heroPane, CT_CONTROL)
    RANK.progBg:SetDimensions(200, 6)
    RANK.progBg:SetAnchor(TOPRIGHT, RANK.progLbl, BOTTOMRIGHT, 0, 4)
    backdrop(RANK.progBg, C.chip, C.line, 1)
    RANK.progFill = WM:CreateControl(nil, RANK.progBg, CT_TEXTURE)
    RANK.progFill:SetAnchor(LEFT, RANK.progBg, LEFT, 1, 0)
    RANK.progFill:SetHeight(4)
    RANK.progFill:SetColor(unpack(C.accent))
    pcall(RANK.BuildModal, win)   -- the "how ranks work" overlay (hidden until the (i) is clicked); guarded so it can't abort the build
    pcall(UI.guide.BuildModal, win)  -- the per-tab "what's on this tab" overlay (opened by the header (i)); guarded like the rank modal

    -- ---- NAV bar (home) ----
    navPane = WM:CreateControl(nil, content, CT_CONTROL)
    navPane:SetAnchor(TOPLEFT, heroPane, BOTTOMLEFT, 0, 12)
    navPane:SetAnchor(TOPRIGHT, heroPane, BOTTOMRIGHT, 0, 12)
    navPane:SetHeight(36)
    navButton("recent", "Recent", 0, 130)
    navButton("opponents", "Opponents", 138, 150)
    navButton("classes", "Classes", 296, 130)
    -- search (right of nav) — ZO_DefaultEdit virtual so text entry actually works
    -- (a bare CT_EDITBOX doesn't get ESO's input/focus setup).
    local searchBg = WM:CreateControl(nil, navPane, CT_BACKDROP)
    searchBg:SetHeight(32)   -- identical spec to the duel-detail search box (insets, height, placeholder)
    searchBg:SetAnchor(RIGHT, navPane, RIGHT, 0, 2)
    searchBg:SetWidth(260)
    searchBg:SetCenterColor(0.03, 0.035, 0.045, 1)
    Border(searchBg, C.line, 1)
    searchBg:SetMouseEnabled(true)
    searchEdit = WM:CreateControlFromVirtual("ShoyrUI_DMUI_Search", searchBg, "ZO_DefaultEdit")
    searchEdit:ClearAnchors()
    searchEdit:SetAnchor(LEFT, searchBg, LEFT, 12, 0)
    searchEdit:SetAnchor(RIGHT, searchBg, RIGHT, -10, 0)
    searchEdit:SetHeight(22)
    searchEdit:SetColor(unpack(C.hi))
    searchEdit:SetMaxInputChars(40)
    searchEdit:SetMouseEnabled(true)
    searchEdit:SetEditEnabled(true)
    -- Faint in-box placeholder — same fill + vertical-centre + wording style as the duel search.
    local searchPH = label(searchBg, 15, C.lo)
    searchPH:SetAnchor(TOPLEFT, searchBg, TOPLEFT, 12, 0)
    searchPH:SetAnchor(BOTTOMRIGHT, searchBg, BOTTOMRIGHT, -8, 0)
    searchPH:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    searchPH:SetText("Search duels")
    searchPH:SetMouseEnabled(false)
    local function updatePH() searchPH:SetHidden((searchEdit:GetText() or "") ~= "") end
    searchEdit:SetHandler("OnTextChanged", function()
        filterText = (searchEdit:GetText() or ""):gsub("^%s+", ""):gsub("%s+$", "")
        updatePH()
        Render()
    end)
    searchEdit:SetHandler("OnEnter", function() searchEdit:LoseFocus() end)
    searchEdit:SetHandler("OnEscape", function() searchEdit:SetText(""); searchEdit:LoseFocus() end)
    searchBg:SetHandler("OnMouseUp", function() searchEdit:TakeFocus() end)
    updatePH()

    -- ---- SORT bar (home) ----
    sortPane = WM:CreateControl(nil, content, CT_CONTROL)
    sortPane:SetAnchor(TOPLEFT, navPane, BOTTOMLEFT, 0, 8)
    sortPane:SetAnchor(TOPRIGHT, navPane, BOTTOMRIGHT, 0, 8)
    sortPane:SetHeight(26)
    local sortLbl = label(sortPane, 12, C.lo)
    sortLbl:SetAnchor(LEFT, sortPane, LEFT, 2, 0)
    sortLbl:SetText("SORT")

    -- ---- CRUMB header (opponent / class / duel) ----
    CR.Pane = WM:CreateControl(nil, content, CT_CONTROL)
    CR.Pane:SetAnchor(TOPLEFT, content, TOPLEFT, 0, 0)
    CR.Pane:SetAnchor(TOPRIGHT, content, TOPRIGHT, 0, 0)
    CR.Pane:SetHeight(70)   -- 64 + the row's 6px drop, so the sub-line keeps its clearance
    local back = WM:CreateControl(nil, CR.Pane, CT_CONTROL)
    back:SetDimensions(96, 28)
    -- 6px of air below the addon title -- the button row sat too tight against it (Shoyru).
    -- Everything on this row chains off `back` or matches its offset (pill y7, icons y6).
    back:SetAnchor(TOPLEFT, CR.Pane, TOPLEFT, 0, 6)
    back:SetMouseEnabled(true)
    backdrop(back, C.chip, C.line, 1)
    local backLbl = label(back, 14, C.accent, TEXT_ALIGN_CENTER)
    backLbl:SetAnchorFill(back); backLbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    backLbl:SetText("\226\128\185  Back")
    back:SetHandler("OnMouseUp", function(_, _, inside) if inside then Back() end end)
    AddPress(back)
    -- Prev / Next fight (only shown on the duel view; wired in RenderDuelCrumb)
    CR.Prev = { btn = WM:CreateControl(nil, CR.Pane, CT_CONTROL) }
    CR.Prev.btn:SetDimensions(74, 28)
    CR.Prev.btn:SetAnchor(LEFT, back, RIGHT, 8, 0)
    CR.Prev.btn:SetMouseEnabled(true)
    backdrop(CR.Prev.btn, C.chip, C.line, 1)
    CR.Prev.lbl = label(CR.Prev.btn, 13, C.mid, TEXT_ALIGN_CENTER)
    CR.Prev.lbl:SetAnchorFill(CR.Prev.btn); CR.Prev.lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    CR.Prev.lbl:SetText("\226\128\185 Prev")
    CR.Next = { btn = WM:CreateControl(nil, CR.Pane, CT_CONTROL) }
    CR.Next.btn:SetDimensions(74, 28)
    CR.Next.btn:SetAnchor(LEFT, CR.Prev.btn, RIGHT, 6, 0)
    CR.Next.btn:SetMouseEnabled(true)
    backdrop(CR.Next.btn, C.chip, C.line, 1)
    CR.Next.lbl = label(CR.Next.btn, 13, C.mid, TEXT_ALIGN_CENTER)
    CR.Next.lbl:SetAnchorFill(CR.Next.btn); CR.Next.lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    CR.Next.lbl:SetText("Next \226\128\186")
    AddPress(CR.Prev.btn)
    AddPress(CR.Next.btn)
    CR.Title = label(CR.Pane, 22, C.hi, nil, "bold")
    CR.Title:SetAnchor(TOPLEFT, back, TOPRIGHT, 16, 0)
    CR.Sub = label(CR.Pane, 14, C.mid)
    CR.Sub:SetMaxLineCount(1)   -- never wrap the long fighter/result line into the tab bar below
    CR.Sub:SetAnchor(TOPLEFT, back, BOTTOMLEFT, 4, 8)
    CR.Right = label(CR.Pane, 16, C.hi, TEXT_ALIGN_RIGHT, "bold")
    CR.Right:SetAnchor(TOPRIGHT, CR.Pane, TOPRIGHT, 0, 2)

    -- Duel-detail search: [ input ][ N/M pill ][ ‹ ][ › ]. Lives at the RIGHT END OF THE TAB BAR
    -- (positioned in LayoutTabs, since it navigates tabs); sibling of detailTabBar under `content`.
    -- Shown only in the duel view (SetChrome toggles it). Right-packed with NEGATIVE offsets so
    -- the input, count pill and arrows never overlap.
    DS.Bar = WM:CreateControl(nil, content, CT_CONTROL)
    DS.Bar:SetDimensions(300, 32)
    DS.Bar:SetHidden(true)
    local function dNavBtn(txt)
        local b = WM:CreateControl(nil, DS.Bar, CT_CONTROL)
        b:SetDimensions(28, 28); b:SetMouseEnabled(true)
        backdrop(b, C.chip, C.line, 1)
        local l = label(b, 18, C.accent, TEXT_ALIGN_CENTER); l:SetAnchorFill(b); l:SetVerticalAlignment(TEXT_ALIGN_CENTER); l:SetText(txt)
        AddPress(b)
        return b
    end
    DS.Next = dNavBtn("\226\128\186")   -- ›  (next match; hidden until 2+ matches)
    DS.Next:SetAnchor(RIGHT, DS.Bar, RIGHT, 0, 0)
    DS.Prev = dNavBtn("\226\128\185")   -- ‹  (previous match)
    DS.Prev:SetAnchor(RIGHT, DS.Next, LEFT, -6, 0)
    -- Count read-out in its own chip "pill" so N/M is always legible (never under the arrows).
    -- backdrop() fills its parent (2 anchors); clear them before re-anchoring it as a fixed pill.
    DS.CountBg = backdrop(DS.Bar, C.chip, C.line, 1)
    DS.CountBg:ClearAnchors()
    DS.CountBg:SetDimensions(62, 28)
    DS.CountBg:SetAnchor(RIGHT, DS.Prev, LEFT, -8, 0)
    DS.Count = label(DS.CountBg, 16, C.hi, TEXT_ALIGN_CENTER, "bold")
    DS.Count:SetAnchorFill(DS.CountBg); DS.Count:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    -- Input field fills the remaining width, left of the pill.
    DS.Bg = WM:CreateControl(nil, DS.Bar, CT_BACKDROP)
    DS.Bg:SetAnchor(TOPLEFT, DS.Bar, TOPLEFT, 0, 2)     -- 28px tall band, matching the pill + arrows
    DS.Bg:SetAnchor(BOTTOMRIGHT, DS.CountBg, BOTTOMLEFT, -8, 0)
    DS.Bg:SetCenterColor(0.03, 0.035, 0.045, 1); Border(DS.Bg, C.line, 1); DS.Bg:SetMouseEnabled(true)
    DS.Edit = WM:CreateControlFromVirtual("ShoyrUI_DMUI_DSearch", DS.Bg, "ZO_DefaultEdit")
    DS.Edit:ClearAnchors(); DS.Edit:SetAnchor(LEFT, DS.Bg, LEFT, 12, 0); DS.Edit:SetAnchor(RIGHT, DS.Bg, RIGHT, -10, 0); DS.Edit:SetHeight(22)
    DS.Edit:SetColor(unpack(C.hi)); DS.Edit:SetMaxInputChars(40); DS.Edit:SetMouseEnabled(true); DS.Edit:SetEditEnabled(true)
    -- Placeholder fills the field + vertically centred so it lines up exactly with typed text.
    DS.PH = label(DS.Bg, 15, C.lo)
    DS.PH:SetAnchor(TOPLEFT, DS.Bg, TOPLEFT, 12, 0); DS.PH:SetAnchor(BOTTOMRIGHT, DS.Bg, BOTTOMRIGHT, -8, 0)
    DS.PH:SetVerticalAlignment(TEXT_ALIGN_CENTER); DS.PH:SetText("Search this duel"); DS.PH:SetMouseEnabled(false)
    local function dPH() DS.PH:SetHidden((DS.Edit:GetText() or "") ~= "") end
    DS.Edit:SetHandler("OnTextChanged", function() RunSearch(DS.Edit:GetText()); dPH() end)
    DS.Edit:SetHandler("OnEnter", function() GotoMatch(DS.Idx + 1) end)
    DS.Edit:SetHandler("OnEscape", function() DS.Edit:SetText(""); RunSearch(""); dPH(); DS.Edit:LoseFocus() end)
    DS.Bg:SetHandler("OnMouseUp", function() DS.Edit:TakeFocus() end)
    DS.Next:SetHandler("OnMouseUp", function(_, _, ins) if ins then GotoMatch(DS.Idx + 1) end end)
    DS.Prev:SetHandler("OnMouseUp", function(_, _, ins) if ins then GotoMatch(DS.Idx - 1) end end)
    dPH()

    -- duel matchup title (fight-card style): [myClassIcon] @MyHandle  vs.  [oppClassIcon] @Opp
    CR.IconMe = WM:CreateControl(nil, CR.Pane, CT_TEXTURE)
    CR.IconMe:SetDimensions(30, 30)
    CR.IconMe:SetAnchor(LEFT, back, RIGHT, 16, -9)
    CR.MeName = label(CR.Pane, 25, C.hi, nil, "bold")
    CR.MeName:SetAnchor(LEFT, CR.IconMe, RIGHT, 8, 0)
    CR.Vs = label(CR.Pane, 17, C.accent, nil, "bold")
    CR.Vs:SetAnchor(LEFT, CR.MeName, RIGHT, 12, 0)
    CR.Vs:SetText("vs.")
    CR.IconOpp = WM:CreateControl(nil, CR.Pane, CT_TEXTURE)
    CR.IconOpp:SetDimensions(30, 30)
    CR.IconOpp:SetAnchor(LEFT, CR.Vs, RIGHT, 12, -1)
    CR.OppName = label(CR.Pane, 25, C.hi, nil, "bold")
    CR.OppName:SetAnchor(LEFT, CR.IconOpp, RIGHT, 8, 0)

    -- Tab Guide button: a persistent (i) pill in the header's top-right (CR.Right is empty in the
    -- duel view, so this corner is free). Present on every tab; opens a breakdown of the CURRENT tab.
    -- Shown only in the duel view (toggled in SetChrome, alongside the tab bar + search).
    UI.guide.Btn = WM:CreateControl(nil, CR.Pane, CT_CONTROL)
    UI.guide.Btn:SetDimensions(104, 28)
    UI.guide.Btn:SetAnchor(TOPRIGHT, CR.Pane, TOPRIGHT, 0, 7)
    UI.guide.Btn:SetMouseEnabled(true)
    backdrop(UI.guide.Btn, C.chip, C.line, 1)
    local gBadge = WM:CreateControl(nil, UI.guide.Btn, CT_BACKDROP)
    gBadge:SetDimensions(18, 18); gBadge:SetAnchor(LEFT, UI.guide.Btn, LEFT, 9, 0)
    gBadge:SetCenterColor(unpack(C.card)); Border(gBadge, C.accent, 1)
    local gBadgeL = label(gBadge, 12, C.accent, TEXT_ALIGN_CENTER, "bold")
    gBadgeL:SetAnchorFill(gBadge); gBadgeL:SetVerticalAlignment(TEXT_ALIGN_CENTER); gBadgeL:SetText("i")
    local gLbl = label(UI.guide.Btn, 14, C.hi, TEXT_ALIGN_LEFT)
    gLbl:SetAnchor(LEFT, gBadge, RIGHT, 7, 0); gLbl:SetVerticalAlignment(TEXT_ALIGN_CENTER); gLbl:SetText("Tab Guide")
    UI.guide.Btn:SetHandler("OnMouseUp", function(_, _, inside) if inside then UI.guide.Toggle(currentTab) end end)
    UI.guide.Btn:SetHandler("OnMouseEnter", function()
        InitializeTooltip(InformationTooltip, UI.guide.Btn, BOTTOMRIGHT, 0, 4, TOPRIGHT)
        SetTooltipText(InformationTooltip, "What's on this tab \226\128\148 full breakdown")
    end)
    UI.guide.Btn:SetHandler("OnMouseExit", function() ClearTooltip(InformationTooltip) end)
    AddPress(UI.guide.Btn)

    -- ---- duel tab bar ----
    detailTabBar = WM:CreateControl(nil, content, CT_CONTROL)
    detailTabBar:SetAnchor(TOPLEFT, CR.Pane, BOTTOMLEFT, 0, 6)
    detailTabBar:SetHeight(37)
    for _, t in ipairs(TABS) do detailTabButton(t) end

    -- ---- bodies: list scroll + duel scroll ----
    listScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_ListScroll", content, "ZO_ScrollContainer")
    listScroll:SetAnchor(TOPLEFT, navPane, BOTTOMLEFT, 0, 8)
    listScroll:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    listChild = listScroll:GetNamedChild("ScrollChild")
    if listChild then listChild:SetWidth(w0 - PAD * 2 - 20); listChild:SetResizeToFitDescendents(false) end
    listEmpty = label(content, 16, C.mid, TEXT_ALIGN_CENTER)
    listEmpty:SetAnchor(TOP, listScroll, TOP, 0, 34)
    listEmpty:SetWidth(w0 - PAD * 2 - 60)
    listEmpty:SetHidden(true)

    duelScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_DuelScroll", content, "ZO_ScrollContainer")
    duelScroll:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
    duelScroll:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    duelChild = duelScroll:GetNamedChild("ScrollChild")
    if duelChild then duelChild:SetWidth(w0 - PAD * 2 - 20); duelChild:SetResizeToFitDescendents(false) end

    -- Damage tab: tiles strip + two independently-scrolling panels (Dealt / Taken).
    dmgPane = WM:CreateControl(nil, content, CT_CONTROL)
    dmgPane:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
    dmgPane:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    dmgPane:SetHidden(true)
    dmgTilesArea = WM:CreateControl(nil, dmgPane, CT_CONTROL)
    dmgTilesArea:SetAnchor(TOPLEFT, dmgPane, TOPLEFT, 0, 0)
    dmgTilesArea:SetAnchor(TOPRIGHT, dmgPane, TOPRIGHT, 0, 0)
    dmgTilesArea:SetHeight(64)
    -- A movable horizontal divider; its Y (set per render) splits the two panels so each
    -- scroll gets a real top+bottom anchor pair (which is what actually scrolls).
    dmgSplit = WM:CreateControl(nil, dmgPane, CT_CONTROL)
    dmgSplit:SetHeight(1)
    dmgSplit:SetAnchor(TOPLEFT, dmgPane, TOPLEFT, 0, 300)
    dmgSplit:SetAnchor(TOPRIGHT, dmgPane, TOPRIGHT, 0, 300)
    dealtTitle = label(dmgPane, 15, C.accent, nil, "bold")
    dealtTitle:SetAnchor(TOPLEFT, dmgTilesArea, BOTTOMLEFT, 2, 4)
    dealtTitle:SetHeight(20)
    dealtScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_DealtScroll", dmgPane, "ZO_ScrollContainer")
    dealtScroll:SetAnchor(TOPLEFT, dealtTitle, BOTTOMLEFT, -2, 4)
    dealtScroll:SetAnchor(BOTTOMRIGHT, dmgSplit, TOPRIGHT, 0, -4)
    dealtChild = dealtScroll:GetNamedChild("ScrollChild")
    if dealtChild then dealtChild:SetWidth(w0 - PAD * 2 - 20); dealtChild:SetResizeToFitDescendents(false) end
    takenTitle = label(dmgPane, 15, C.accent, nil, "bold")
    takenTitle:SetAnchor(TOPLEFT, dmgSplit, BOTTOMLEFT, 2, 6)
    takenTitle:SetHeight(20)
    takenScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_TakenScroll", dmgPane, "ZO_ScrollContainer")
    takenScroll:SetAnchor(TOPLEFT, takenTitle, BOTTOMLEFT, -2, 4)
    takenScroll:SetAnchor(BOTTOMRIGHT, dmgPane, BOTTOMRIGHT, 0, 0)
    takenChild = takenScroll:GetNamedChild("ScrollChild")
    if takenChild then takenChild:SetWidth(w0 - PAD * 2 - 20); takenChild:SetResizeToFitDescendents(false) end

    -- Buffs & Debuffs tab: a segmented sub-tab chip-bar + ONE spacious, independently-scrolling panel.
    buffPane = WM:CreateControl(nil, content, CT_CONTROL)
    buffPane:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
    buffPane:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    buffPane:SetHidden(true)
    buffTabBar = WM:CreateControl(nil, buffPane, CT_CONTROL)
    buffTabBar:SetAnchor(TOPLEFT, buffPane, TOPLEFT, 0, 0)
    buffTabBar:SetAnchor(TOPRIGHT, buffPane, TOPRIGHT, 0, 0)
    buffTabBar:SetHeight(28)
    buffScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_BuffScroll", buffPane, "ZO_ScrollContainer")
    buffScroll:SetAnchor(TOPLEFT, buffTabBar, BOTTOMLEFT, 0, 8)
    buffScroll:SetAnchor(BOTTOMRIGHT, buffPane, BOTTOMRIGHT, 0, 0)
    buffChild = buffScroll:GetNamedChild("ScrollChild")
    if buffChild then buffChild:SetWidth(w0 - PAD * 2 - 20); buffChild:SetResizeToFitDescendents(false) end

    -- Build tab: TWO side-by-side columns (character/sets/gear | bars/champion) so the whole
    -- build reads on one screen instead of a long single-column scroll.
    BD.Pane = WM:CreateControl(nil, content, CT_CONTROL)
    BD.Pane:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
    BD.Pane:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    BD.Pane:SetHidden(true)
    -- full-width tiles strip above BOTH columns, so the column tops align cleanly
    BD.Tiles = WM:CreateControl(nil, BD.Pane, CT_CONTROL)
    BD.Tiles:SetAnchor(TOPLEFT, BD.Pane, TOPLEFT, 0, 0)
    BD.Tiles:SetAnchor(TOPRIGHT, BD.Pane, TOPRIGHT, 0, 0)
    BD.SL = WM:CreateControlFromVirtual("ShoyrUI_DMUI_BuildL", BD.Pane, "ZO_ScrollContainer")
    BD.SL:SetAnchor(TOPLEFT, BD.Tiles, BOTTOMLEFT, 0, 10)
    BD.SL:SetAnchor(BOTTOMLEFT, BD.Pane, BOTTOMLEFT, 0, 0)
    BD.CL = BD.SL:GetNamedChild("ScrollChild")
    BD.SR = WM:CreateControlFromVirtual("ShoyrUI_DMUI_BuildR", BD.Pane, "ZO_ScrollContainer")
    BD.SR:SetAnchor(TOPRIGHT, BD.Tiles, BOTTOMRIGHT, 0, 10)
    BD.SR:SetAnchor(BOTTOMRIGHT, BD.Pane, BOTTOMRIGHT, 0, 0)
    BD.CR = BD.SR:GetNamedChild("ScrollChild")
    for _, c in ipairs({ BD.CL, BD.CR }) do if c then c:SetResizeToFitDescendents(false) end end
    BD.PL, BD.PR, BD.PT = {}, {}, {}

    -- Report Card pane: the strengths RADAR (left) + the graded report scroll (right).
    RC.Pane = WM:CreateControl(nil, content, CT_CONTROL)
    RC.Pane:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
    RC.Pane:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    RC.Pane:SetHidden(true)
    RC.Radar = WM:CreateControl(nil, RC.Pane, CT_CONTROL)
    RC.Radar:SetDimensions(470, 380)
    RC.Radar:SetAnchor(TOPLEFT, RC.Pane, TOPLEFT, 6, 8)
    RC.Caption = label(RC.Pane, 13, C.lo, TEXT_ALIGN_CENTER)
    RC.Caption:SetAnchor(TOPLEFT, RC.Radar, BOTTOMLEFT, 10, 4)
    RC.Caption:SetAnchor(TOPRIGHT, RC.Radar, BOTTOMRIGHT, -10, 4)
    RC.Caption:SetHeight(22)
    RC.Caption:SetText("Bigger shape = stronger duel.   |c66d47aGreen|r = strong, |cf26a66red|r = weak.")
    RC.Scroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_RCScroll", RC.Pane, "ZO_ScrollContainer")
    RC.Scroll:SetAnchor(TOPLEFT, RC.Radar, TOPRIGHT, 16, 0)
    RC.Scroll:SetAnchor(BOTTOMRIGHT, RC.Pane, BOTTOMRIGHT, 0, 0)
    RC.Child = RC.Scroll:GetNamedChild("ScrollChild")
    if RC.Child then RC.Child:SetResizeToFitDescendents(false) end
    RC.Lines, RC.Dots = {}, {}
    -- Calibration LOCK overlay: fills the pane until MINCAL duels. Every element is anchored
    -- INDEPENDENTLY to the pane centre (no chaining) with explicit dimensions + vertical centring,
    -- so nothing can drift off-centre.
    RC.Lock = WM:CreateControl(nil, RC.Pane, CT_CONTROL)
    RC.Lock:SetAnchorFill(RC.Pane)
    RC.Lock:SetHidden(true)
    local licon = WM:CreateControl(nil, RC.Lock, CT_TEXTURE)
    licon:SetDimensions(56, 56); licon:SetAnchor(CENTER, RC.Lock, CENTER, 0, -108)
    pcall(function() licon:SetTexture("/esoui/art/miscellaneous/locked_up.dds") end)
    licon:SetColor(unpack(C.accent))
    local ltitle = label(RC.Lock, 23, C.accent, TEXT_ALIGN_CENTER, "bold")
    ltitle:SetDimensions(560, 28); ltitle:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    ltitle:SetAnchor(CENTER, RC.Lock, CENTER, 0, -58); ltitle:SetText("Report Card locked")
    RC.LockCount = label(RC.Lock, 46, C.hi, TEXT_ALIGN_CENTER, "bold")
    RC.LockCount:SetDimensions(320, 56); RC.LockCount:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    RC.LockCount:SetAnchor(CENTER, RC.Lock, CENTER, 0, -4)
    RC.LockBarBg = WM:CreateControl(nil, RC.Lock, CT_CONTROL)
    RC.LockBarBg:SetDimensions(340, 12); RC.LockBarBg:SetAnchor(CENTER, RC.Lock, CENTER, 0, 46)
    backdrop(RC.LockBarBg, C.chip, C.line, 1)
    RC.LockBarFill = WM:CreateControl(nil, RC.LockBarBg, CT_TEXTURE)
    RC.LockBarFill:SetAnchor(LEFT, RC.LockBarBg, LEFT, 1, 0); RC.LockBarFill:SetHeight(10); RC.LockBarFill:SetColor(unpack(C.accent))
    RC.LockSub = label(RC.Lock, 15, C.mid, TEXT_ALIGN_CENTER)
    RC.LockSub:SetDimensions(620, 40); RC.LockSub:SetVerticalAlignment(TEXT_ALIGN_CENTER)
    RC.LockSub:SetAnchor(CENTER, RC.Lock, CENTER, 0, 86)
    function RC.UpdateLock()
        local n, need = RC.DuelCount(), RC.MINCAL
        RC.LockCount:SetText(string.format("%d / %d", math.min(n, need), need))
        RC.LockBarFill:SetWidth(math.max(1, 338 * math.min(1, n / need)))
        local togo = math.max(0, need - n)
        RC.LockSub:SetText(togo == 0 and "Calibrated \226\128\148 open a duel to see your grade."
            or string.format("Complete %d more duel%s so your grades calibrate to your own performance.", togo, togo == 1 and "" or "s"))
    end

    -- Timeline (Ebb & Flow) pane: tiles strip + mirrored damage histogram + resource band.
    -- Bars are pooled CT_BACKDROPs laid out in DrawTimeline (all geometry set there).
    F.Pane = WM:CreateControl(nil, content, CT_CONTROL)
    F.Pane:SetAnchor(TOPLEFT, detailTabBar, BOTTOMLEFT, 0, 8)
    F.Pane:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, 0)
    F.Pane:SetHidden(true)
    F.SubBar = WM:CreateControl(nil, F.Pane, CT_CONTROL)   -- Damage/Healing/Sustain/Log chip bar
    F.SubBar:SetAnchor(TOPLEFT, F.Pane, TOPLEFT, 0, 0); F.SubBar:SetAnchor(TOPRIGHT, F.Pane, TOPRIGHT, 0, 0); F.SubBar:SetHeight(28)
    F.BreakScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_FlowBreakScroll", F.Pane, "ZO_ScrollContainer")  -- source-breakdown list under the graph (scrollable)
    F.BreakChild = F.BreakScroll:GetNamedChild("ScrollChild")
    if F.BreakChild then F.BreakChild:SetWidth(w0 - PAD * 2 - 20); F.BreakChild:SetResizeToFitDescendents(false) end
    F.LogFilterBar = WM:CreateControl(nil, F.Pane, CT_CONTROL)   -- combat-log direction filter row (Log view)
    F.LogFilterBar:SetAnchor(TOPLEFT, F.SubBar, BOTTOMLEFT, 0, 6); F.LogFilterBar:SetHeight(24); F.LogFilterBar:SetHidden(true)
    F.LogFilterChips = {}
    F.LogScroll = WM:CreateControlFromVirtual("ShoyrUI_DMUI_FlowLogScroll", F.Pane, "ZO_ScrollContainer")  -- combat-log view
    F.LogScroll:SetAnchor(TOPLEFT, F.SubBar, BOTTOMLEFT, 0, 8); F.LogScroll:SetAnchor(BOTTOMRIGHT, F.Pane, BOTTOMRIGHT, 0, 0); F.LogScroll:SetHidden(true)
    F.LogChild = F.LogScroll:GetNamedChild("ScrollChild")
    if F.LogChild then F.LogChild:SetWidth(w0 - PAD * 2 - 20); F.LogChild:SetResizeToFitDescendents(false) end
    F.LogLines = {}
    F.TilesArea = WM:CreateControl(nil, F.Pane, CT_CONTROL)
    F.TilesArea:SetAnchor(TOPLEFT, F.Pane, TOPLEFT, 0, 0)
    F.TilesArea:SetAnchor(TOPRIGHT, F.Pane, TOPRIGHT, 0, 0)
    F.TilesArea:SetHeight(60)
    F.PlotTitle = label(F.Pane, 15, C.accent, nil, "bold"); F.PlotTitle:SetHeight(20)
    F.Plot = WM:CreateControl(nil, F.Pane, CT_CONTROL)
    backdrop(F.Plot, C.card, C.line, 1)
    F.Baseline = WM:CreateControl(nil, F.Plot, CT_BACKDROP)
    F.Baseline:SetHeight(1); F.Baseline:SetEdgeColor(0, 0, 0, 0); F.Baseline:SetCenterColor(0.30, 0.33, 0.40, 0.9)
    F.ResTitle = label(F.Pane, 14, C.accent, nil, "bold"); F.ResTitle:SetHeight(18)
    F.ResBand = WM:CreateControl(nil, F.Pane, CT_CONTROL)
    backdrop(F.ResBand, C.card, C.line, 1)
    F.Legend = label(F.Pane, 12, C.mid); F.Legend:SetHidden(true)
    F.T0 = label(F.Pane, 12, C.lo)
    F.Tend = label(F.Pane, 12, C.lo, TEXT_ALIGN_RIGHT)
    F.Empty = label(F.Pane, 16, C.mid, TEXT_ALIGN_CENTER)
    -- Axis labels: Y = metric/unit (top) + scale (peak at top, 0 at bottom); X = "Time".
    F.YName = label(F.Pane, 12, C.mid, TEXT_ALIGN_RIGHT, "bold")
    F.YMax  = label(F.Pane, 12, C.lo, TEXT_ALIGN_RIGHT)
    F.YZero = label(F.Pane, 12, C.lo, TEXT_ALIGN_RIGHT)
    F.XName = label(F.Pane, 12, C.mid, TEXT_ALIGN_CENTER, "bold")
    -- Legend TOGGLE BUTTONS (Damage view): look like buttons (chip bg + press) so it's obvious you
    -- can click to hide/show each line; a "Lines:" hint sits beside them.
    F.LegHint = label(F.Pane, 12, C.lo, TEXT_ALIGN_RIGHT); F.LegHint:SetText("Lines:"); F.LegHint:SetHidden(true)
    local function legChip(col, onUp)
        local b = WM:CreateControl(nil, F.Pane, CT_CONTROL); b:SetMouseEnabled(true); b:SetHidden(true); b:SetHeight(22)
        b.bg = backdrop(b, C.chip, C.line, 1)
        b.lbl = label(b, 13, col, TEXT_ALIGN_CENTER, "bold"); b.lbl:SetAnchorFill(b); b.lbl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
        AddPress(b)
        b:SetHandler("OnMouseUp", function(_, _, inside) if inside then onUp() end end)
        return b
    end
    F.LegYou = legChip(C.win, function() F.hideYou = not F.hideYou; RenderTab() end)
    F.LegThem = legChip(C.loss, function() F.hideThem = not F.hideThem; RenderTab() end)
    -- Scrubber: hover the plot -> a vertical line follows the cursor + a readout of the values at that
    -- time. (Phase A: value readout; the source-breakdown-up-to-T recompute is Phase B.)
    F.Scrub = WM:CreateControl(nil, F.Plot, CT_BACKDROP)
    F.Scrub:SetWidth(1); F.Scrub:SetEdgeColor(0, 0, 0, 0); F.Scrub:SetCenterColor(0.92, 0.94, 0.99, 0.55); F.Scrub:SetHidden(true)
    F.ScrubBox = WM:CreateControl(nil, F.Pane, CT_BACKDROP)
    F.ScrubBox:SetDimensions(150, 58); backdrop(F.ScrubBox, { 0.05, 0.06, 0.08, 0.96 }, C.line, 1); F.ScrubBox:SetHidden(true); F.ScrubBox:SetDrawLevel(5)
    F.ScrubLbl = label(F.ScrubBox, 13, C.hi, TEXT_ALIGN_LEFT)
    F.ScrubLbl:SetAnchor(TOPLEFT, F.ScrubBox, TOPLEFT, 9, 5)   -- only TOPLEFT -> label auto-sizes; box is fit to it
    F.Plot:SetMouseEnabled(true)
    local function scrubUpdate()
        local d = F.plotData
        if not d then return end
        local left, width = F.Plot:GetLeft(), F.Plot:GetWidth()
        if width <= 1 then return end
        local mfrac = (GetUIMousePosition() - left) / width
        if mfrac < 0 then mfrac = 0 elseif mfrac > 1 then mfrac = 1 end
        local frac = (F.pinned and F.pinFrac) or mfrac   -- frozen at the pin when pinned
        local sx = math.floor(frac * width)
        F.Scrub:ClearAnchors(); F.Scrub:SetHeight(F.Plot:GetHeight()); F.Scrub:SetAnchor(TOPLEFT, F.Plot, TOPLEFT, sx, 0)
        local i = math.max(1, math.min(d.nb, math.floor(frac * (d.nb - 1) + 0.5) + 1))   -- nearest point (points span full width)
        local t = math.floor(frac * (d.dur or 0))
        local ts = string.format("%d:%02d", math.floor(t / 60), t % 60)
        -- exact values (Comma), so even small changes show as you scrub across the line
        local hd = "|c8a8f9b" .. ts .. (F.pinned and "  pinned" or "") .. "|r"
        local txt
        if d.sub == "healing" then
            txt = string.format("%s\n|c%sHPS: %s|r", hd, Hex(C.win), Comma(math.floor(d.hps[i] or 0)))
        elseif d.sub == "sustain" then
            txt = string.format("%s\nMag: %d%%\nStam: %d%%\nUlt: %d%%", hd, math.floor((d.mag[i] or 0) * 100 + 0.5), math.floor((d.stam[i] or 0) * 100 + 0.5), math.floor((d.ult[i] or 0) * 100 + 0.5))
        else
            txt = string.format("%s\n|c%sYou: %s|r\n|c%sEnemy: %s|r", hd, Hex(C.win), Comma(math.floor(d.you[i] or 0)), Hex(C.loss), Comma(math.floor(d.them[i] or 0)))
        end
        F.ScrubLbl:SetText(txt)
        -- fit the box tightly to the text (no dead space)
        local bw = math.max(64, math.floor(F.ScrubLbl:GetTextWidth()) + 18)
        F.ScrubBox:SetDimensions(bw, math.max(38, math.floor(F.ScrubLbl:GetHeight()) + 10))
        local boxX = (F.Plot:GetLeft() - F.Pane:GetLeft()) + sx + 10
        if boxX + bw > contentW then boxX = boxX - bw - 20 end
        F.ScrubBox:ClearAnchors(); F.ScrubBox:SetAnchor(TOPLEFT, F.Pane, TOPLEFT, math.max(0, boxX), 66)
    end
    -- Bursts view: the PLOT is the interactive surface (per-bar mouse on pooled backdrops didn't
    -- take clicks in-game) — hover/click map to the nearest lollipop within ~14px of the cursor.
    local function NearestBurst()
        if not (F.subTab == "bursts" and F.lolliMap) then return nil end
        local mx = GetUIMousePosition() - F.Plot:GetLeft()
        local best, bd
        for _, e in ipairs(F.lolliMap) do
            local d = math.abs(mx - e.x)
            if d <= 14 and (not bd or d < bd) then best, bd = e, d end
        end
        return best
    end
    local function BurstHover()
        local e = NearestBurst()
        local key = e and (e.dir .. e.i) or nil
        if key == F.lolliTipKey then return end   -- only re-anchor the tooltip when the target changes
        F.lolliTipKey = key
        if e then
            local mxp, myp = GetUIMousePosition()
            -- relativePoint MUST be explicit: omitted, SetOwner mirrors the point (TOPLEFT anchors
            -- to GuiRoot's BOTTOMRIGHT -> tooltip clamps to the screen's right edge).
            InitializeTooltip(InformationTooltip, GuiRoot, TOPLEFT, (mxp or 0) + 14, (myp or 0) + 16, TOPLEFT)
            SetTooltipText(InformationTooltip, e.tip)
        else
            ClearTooltip(InformationTooltip)
        end
    end
    F.Plot:SetHandler("OnMouseEnter", function()
        if F.subTab == "bursts" then F.lolliTipKey = nil; F.Plot:SetHandler("OnUpdate", BurstHover); return end
        if F.plotData then F.Scrub:SetHidden(false); F.ScrubBox:SetHidden(false); F.Plot:SetHandler("OnUpdate", scrubUpdate) end
    end)
    F.Plot:SetHandler("OnMouseExit", function()
        F.Plot:SetHandler("OnUpdate", nil)
        F.lolliTipKey = nil; ClearTooltip(InformationTooltip)
        if not F.pinned then F.Scrub:SetHidden(true); F.ScrubBox:SetHidden(true) end
    end)
    -- Click to PIN the scrubber at that point (freezes the line + readout, and the source breakdown
    -- recomputes to only what landed up to that time). Click again to unpin. On the Bursts view a
    -- click instead selects the nearest lollipop (highlight + scroll to its row).
    F.Plot:SetHandler("OnMouseUp", function(_, _, inside)
        if inside and F.subTab == "bursts" then
            local e = NearestBurst()
            if e then
                -- ALWAYS select + navigate (no toggle-off: deselecting on a re-click read as
                -- "nothing happened" since the removed highlight was usually below the fold).
                F.burstSel = { dir = e.dir, i = e.i }
                F.lolliTipKey = nil; ClearTooltip(InformationTooltip)
                RenderTab()   -- re-renders list + re-applies the hl fill on the selected row
                local ln = F.burstSelItem and F.BreakLines and F.BreakLines[F.burstSelItem]
                if ln then
                    -- Defer the centering a tick: the re-render just issued ZO_Scroll_ResetToTop on
                    -- this scroll, and two scroll ops in one frame race (center sometimes lost).
                    zo_callLater(function()
                        -- Deterministic centering: compute the row's FIXED offset inside the scroll
                        -- child and set the scroll position directly — no ZO scroll helper, no
                        -- animation. (IntoView/IntoCentralView kept dumping deep rows back at the
                        -- top for bursts in the duel's second half — Shoyru, twice.)
                        local sc = F.BreakScroll:GetNamedChild("Scroll") or F.BreakScroll.scroll
                        if sc and sc.SetVerticalScroll and F.BreakChild then
                            local rowY = ln:GetTop() - F.BreakChild:GetTop()   -- scroll-independent: both move together
                            local y = rowY - (sc:GetHeight() - ln:GetHeight()) / 2
                            y = math.max(0, math.min(y, math.max(0, F.BreakChild:GetHeight() - sc:GetHeight())))
                            sc:SetVerticalScroll(y)
                            pcall(ZO_Scroll_UpdateScrollBar, F.BreakScroll)
                        elseif not (ZO_Scroll_ScrollControlIntoCentralView and pcall(ZO_Scroll_ScrollControlIntoCentralView, F.BreakScroll, ln)) then
                            pcall(ZO_Scroll_ScrollControlIntoView, F.BreakScroll, ln)
                        end
                    end, 50)
                end
            end
            return
        end
        if not (inside and F.plotData) then return end
        local left, width = F.Plot:GetLeft(), F.Plot:GetWidth()
        if width <= 1 then return end
        local mf = (GetUIMousePosition() - left) / width
        mf = (mf < 0 and 0) or (mf > 1 and 1) or mf
        -- Click SETS or MOVES the pin; clicking on the existing pin (within ~8px) removes it. (A plain
        -- toggle made the line vanish whenever you clicked a second time.)
        if F.pinned and math.abs(mf - (F.pinFrac or 0)) * width < 8 then
            F.pinned = false
        else
            F.pinFrac = mf; F.pinned = true
        end
        F.Scrub:SetHidden(false); F.ScrubBox:SetHidden(false)
        RenderTab()      -- rebuild the breakdown for the pinned (or full) time
        scrubUpdate()    -- reposition the frozen line/readout
    end)
    F.Empty:SetAnchor(TOP, F.Pane, TOP, 0, 120); F.Empty:SetWidth(w0 - PAD * 2 - 60); F.Empty:SetHidden(true)

    -- footer: @account + app version (home only)
    footer = label(content, 12, C.lo, TEXT_ALIGN_CENTER)
    footer:SetAnchor(BOTTOMLEFT, content, BOTTOMLEFT, 0, -2)
    footer:SetAnchor(BOTTOMRIGHT, content, BOTTOMRIGHT, 0, -2)
    footer:SetHidden(true)

    Relayout()
    lastW, lastH = win:GetWidth(), win:GetHeight()
    built = true
end

-- ---------------------------------------------------------------------------
-- Scene wiring (cursor + ESC), public API
-- ---------------------------------------------------------------------------
local SCENE_NAME = "ShoyrUI_SMXScene"

local function EnsureWindow()
    if win then return true end
    local ok, err = pcall(function()
        BuildWindow()
        if SCENE_MANAGER and ZO_Scene and ZO_FadeSceneFragment then
            smxScene = ZO_Scene:New(SCENE_NAME, SCENE_MANAGER)
            smxScene:AddFragment(ZO_FadeSceneFragment:New(win))
        end
    end)
    if not ok then
        win, smxScene = nil, nil
        d("|cFFD700[Duel Metrics]|r window error: " .. tostring(err) .. " \226\128\148 use /SMX <name> for the text report.")
        return false
    end
    return true
end
local function SceneShowing()
    if smxScene and SCENE_MANAGER then return SCENE_MANAGER:IsShowing(SCENE_NAME) end
    return win and not win:IsHidden()
end
local function ShowScene()
    if smxScene and SCENE_MANAGER then
        if not SCENE_MANAGER:IsShowing(SCENE_NAME) then SCENE_MANAGER:Show(SCENE_NAME) end
    elseif win then win:SetHidden(false) end
end
local function HideScene()
    if smxScene and SCENE_MANAGER then
        if SCENE_MANAGER:IsShowing(SCENE_NAME) then SCENE_MANAGER:Hide(SCENE_NAME) end
    elseif win then win:SetHidden(true) end
    -- a build viewer "riding" this scene's cursor must not outlive it
    if SB.Win and not (SB.Scene and SCENE_MANAGER and SCENE_MANAGER:IsShowing(SB.SCENE_NAME)) then SB.Win:SetHidden(true) end
end

-- Open the home dashboard (optionally with a search term pre-filled).
function UI.ShowHome(term)
    if not EnsureWindow() then return end
    filterText = (term or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if searchEdit then searchEdit:SetText(filterText) end
    nav = { { kind = "home" } }
    fitPending = true
    Render()
    ShowScene()
end
UI.ShowLog = UI.ShowHome   -- back-compat alias

-- Jump straight to a duel's detail (used by auto-open on duel finish).
function UI.OpenDuel(handle, idx)
    if not EnsureWindow() then return end
    local o = sv and sv.opponents and sv.opponents[handle]
    if not (o and o.duels and o.duels[idx]) then UI.ShowHome() return end
    nav = { { kind = "home" }, { kind = "duel", handle = handle, idx = idx } }
    fitPending = true
    Render()
    ShowScene()
end

function UI.Hide() HideScene() end

function UI.RefreshIfOpen()
    if not SceneShowing() then return end
    nav = { { kind = "home" } }
    fitPending = true
    Render()
end
-- Called by DuelMetrics when the active store swaps (real <-> demo), so the cached baseline/norms don't
-- carry across from the other dataset.
function UI.ResetAnalytics() RC._bl = nil; RC._dn = nil end

function UI.Toggle(arg)
    if SceneShowing() then UI.Hide() return end
    UI.ShowHome(arg)
end

function UI.Init(dmSv)
    sv = dmSv
    -- v1.16 dropped auto-fit-to-content. Reset ONCE to a clean medium default (the old persisted size
    -- could be a stale per-tab auto-fit height); after this, the user's manual resizes persist.
    if not (sv.win and sv.win.fixedPreset) then sv.win = { w = W, h = H, fixedPreset = true } end
    -- Build-share links: retry claiming the link type in case LINK_HANDLER wasn't ready at file load.
    if SB.Register then SB.Register() end
end

-- ===========================================================================
-- BUILD SHARE (v1.62) — SuperStar-style clickable build links.
-- The CAPTURED duel build is bit-packed into LibDataPacker's short-build wire
-- format (the SuperStar/ImpressiveStats codec) and shared as a custom
-- |H1:SMXbuild:<data>|h chat link. Any ShoyrUI user who clicks it gets the
-- build rendered through the SAME BuildItems pipeline in a viewer window.
-- LibDataPacker is optional on both ends: without it the SHARE tile simply
-- doesn't appear, and clicking a link explains what's missing.
-- ===========================================================================
SB.LINK = "smxb"   -- lowercase single word, like every stock type ("item", "achievement", pChat's "p")
SB.SCENE_NAME = "ShoyrUI_SMXBuildScene"
function SB.LDPX()
    local L = rawget(_G, "LibDataPacker")   -- rawget: the test env auto-stubs unknown globals
    local X = L and L.Extra and L.Extra.Build
    if type(X) ~= "table" then return nil end
    -- A different/older LibDataPacker can expose a PARTIAL build schema. We index t[X.FIELD] for each of
    -- these, so a nil FIELD would crash with "table index is nil". Require them all; otherwise treat this
    -- LibDataPacker as unsupported for sharing (the rest of the Build tab still works fine).
    for _, f in ipairs({ "RACE", "CLASS", "SKILLS", "FIRST_BOON", "SECOND_BOON", "WW_VAMP_BUFF", "GEAR",
        "GEAR_SLOTS", "CONSTELLATIONS", "FOOD", "CLASS_SKILL_LINES", "CLASS_MASTERY" }) do
        if X[f] == nil then return nil end
    end
    return X
end

-- Chat-transport codec. LibDataPacker packs into its "link-safe" alphabet, but that alphabet still
-- contains symbols (<>;,{}!@# ...) that chat addons like pChat mangle when they proxy a link, which
-- is what broke click-to-view. We remap the packed string into strict base64url [A-Za-z0-9-_]: both
-- alphabets are 64 chars / 6 bits, so it's a lossless 1:1 character swap (no bit realignment). The
-- resulting data has zero problem characters, so the clickable link survives pChat and stays ONE
-- CLICK. All pcall-guarded; if the library is missing we just pass the string through unchanged.
function SB.Codec()
    if SB.codec ~= nil then return SB.codec or nil end
    local L = rawget(_G, "LibDataPacker")
    local B = L and L.Base
    if B and B.CustomAlphabet and B.Base64LinkSafe then
        SB.codec = { src = B.Base64LinkSafe,
            dst = B.CustomAlphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_") }
    else
        SB.codec = false
    end
    return SB.codec or nil
end
function SB.Encode(packed)   -- packed (link-safe) -> base64url wire code
    local c = SB.Codec(); if not c then return packed end
    local ok, out = pcall(function() return c.dst:Encode(c.src:Decode(packed)) end)
    return (ok and type(out) == "string" and out) or packed
end
function SB.Decode(code)     -- base64url wire code -> packed (link-safe); tolerates a raw packed (old links)
    local c = SB.Codec(); if not c then return code end
    local ok, out = pcall(function() return c.src:Encode(c.dst:Decode(code)) end)
    return (ok and type(out) == "string" and out) or code
end

-- Our captured build -> LibDataPacker's SHORT-build table (schema in LibDataPacker/extra/build).
-- Returns nil when the record predates v1.61 (no class lines / scan data to encode).
-- opts.noFood / opts.noScribe are degrade steps: an exotic food id or an out-of-budget script id
-- must cost that DETAIL, not the whole share.
function SB.ToShort(du, opts)
    local X = SB.LDPX(); local b = du and du.build; opts = opts or {}
    if not (X and b and b.equip and b.lines and b.lines[1] and b.lines[2] and b.lines[3]) then return nil end
    local race, cls = du.myRaceId, b.classId or du.myClassId
    if not (race and race ~= 0 and cls and cls ~= 0) then return nil end
    local t = {}
    t[X.RACE], t[X.CLASS] = race, cls
    local skills = { [HOTBAR_CATEGORY_PRIMARY] = {}, [HOTBAR_CATEGORY_BACKUP] = {} }
    for bi = 1, 2 do
        local cat = (bi == 1) and HOTBAR_CATEGORY_PRIMARY or HOTBAR_CATEGORY_BACKUP
        local bar = b.bars and b.bars[bi]
        for slot = 3, 8 do
            local id = (bar and bar[slot]) or 0
            local scr = (not opts.noScribe) and id ~= 0 and b.scribed and b.scribed[id] or nil
            if scr and scr.crafted and scr.s then
                skills[cat][slot] = { scr.crafted, scr.s[1] or 0, scr.s[2] or 0, scr.s[3] or 0 }
            else
                skills[cat][slot] = id
            end
        end
    end
    t[X.SKILLS] = skills
    t[X.FIRST_BOON] = (b.boons and b.boons[1]) or 0
    t[X.SECOND_BOON] = (b.boons and b.boons[2]) or 0
    t[X.WW_VAMP_BUFF] = b.wwVamp or 0
    local gear = {}
    for _, slot in ipairs(X.GEAR_SLOTS) do
        local link = b.equip[slot]
        if type(link) == "string" and link ~= "" then
            local id = (GetItemLinkItemId and GetItemLinkItemId(link)) or 0
            local q; pcall(function() q = (GetItemLinkDisplayQuality and GetItemLinkDisplayQuality(link)) or GetItemLinkQuality(link) end)
            local tr; pcall(function() tr = GetItemLinkTraitType(link) end)
            local en = tonumber(link:match("|H[^:]+:item:[^:]+:[^:]+:[^:]+:([^:]+):")) or 0
            gear[slot] = { (type(id) == "number") and id or 0, q or 0, tr or 0, en }
        else
            gear[slot] = { 0, 0, 0, 0 }
        end
    end
    t[X.GEAR] = gear
    local cons = {}
    for i = 1, 12 do cons[i] = (b.cpSlots and b.cpSlots[i] and b.cpSlots[i].id) or 0 end
    t[X.CONSTELLATIONS] = cons
    t[X.FOOD] = ((not opts.noFood) and b.food and b.food[1]) or 0
    t[X.CLASS_SKILL_LINES] = { b.lines[1], b.lines[2], b.lines[3] }
    local cm = {}
    if b.mastery then cm[1] = b.mastery[1]; cm[2] = b.mastery[2] end   -- schema carries up to 2
    t[X.CLASS_MASTERY] = cm
    return t
end

-- Pack with a degrade ladder: full -> drop food -> drop food+scripts. PackShortBuild mutates
-- its input, so each attempt rebuilds the table fresh.
function SB.Pack(du)
    local X = SB.LDPX(); if not X then return nil end
    for _, o in ipairs({ {}, { noFood = true }, { noFood = true, noScribe = true } }) do
        local t = SB.ToShort(du, o)
        if not t then return nil end
        local ok, packed = pcall(X.PackShortBuild, t)
        if ok and type(packed) == "string" and #packed > 0 and #packed <= 290 then return packed end
    end
    return nil
end
-- Memoized per record — BuildItems re-runs on every find-in-tabs keystroke.
SB.cache = setmetatable({}, { __mode = "k" })
function SB.PackCached(du)
    local c = SB.cache[du]
    if c == nil then c = SB.Pack(du) or false; SB.cache[du] = c end
    return c or nil
end
function SB.ShareTile(du)
    if not (du and du.build) or du.__shared then return nil end
    local packed = SB.PackCached(du)
    if not packed then return nil end
    -- Plain-text CODE, never a |H..|h link. pChat wraps ANY message containing a link in its own "p"
    -- copy-proxy that crashes on click (confirmed regardless of our link's data), and chat is the only
    -- clickable-in-combat surface, so a working clickable custom link is impossible alongside pChat.
    -- Plain text is left untouched. The code is base64url (easy to select/copy); recipients who have
    -- the addon get an auto-prompt when it lands in their chat (see SB.Register) and open it with a
    -- single /smxbuild -- no code-copying needed.
    local code = SB.Encode(packed)
    local line = "Shoyru's PvP Metrics \226\128\148 my build from this duel. View it with:  /smxbuild " .. code
    return { l = "SHARE BUILD", v = "Post Code", c = C.accent,
        tip = "Drops a build code into your chat box \226\128\148 press Enter to send.\nAnyone with Shoyru's PvP Metrics gets a one-line prompt and opens it with a single |cFFD700/smxbuild|r.\n\n(Chat addons like pChat break clickable custom links, so a code is used \226\128\148 it always survives.)",
        click = function() if StartChatInput then StartChatInput(line) end end,
        post = line }
end

-- Minimal item link from an itemId — enough for name/set/trait/icon lookups (those are
-- intrinsic to the id). Field list copied verbatim from LibLazyCrafting (in-game proven);
-- fields 4-6 after the id are enchantId/subtype/level so the shared build's exact enchant
-- resolves too (pcall'd at render — a bad combo just shows no enchant).
function SB.ItemLink(itemId, enchantId)
    return ZO_LinkHandler_CreateLink("L", nil, "item", itemId, 1, 26, enchantId or 0, (enchantId and enchantId ~= 0) and 370 or 0, (enchantId and enchantId ~= 0) and 50 or 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 10000, 0)
end

-- Unpacked LDP short-build -> the same `build` table shape BuildItems renders. Returns build, raceId.
function SB.FromShort(u)
    local X = SB.LDPX(); if not (X and u) then return nil end
    local b = { equip = {}, linkFix = {}, bars = {}, scribed = {}, cpSlots = {} }
    b.classId = u[X.CLASS]
    local sk = u[X.SKILLS] or {}
    for bi = 1, 2 do
        local src = sk[(bi == 1) and HOTBAR_CATEGORY_PRIMARY or HOTBAR_CATEGORY_BACKUP]
        local bar, any = {}, false
        for slot = 3, 8 do
            local v = src and src[slot]
            if type(v) == "table" then
                -- crafted (scribed) skill: {craftedAbilityId, s1, s2, s3}
                local aid = 0
                pcall(function() aid = GetAbilityIdForCraftedAbilityId(v[1]) or 0 end)
                if aid ~= 0 then
                    bar[slot] = aid; any = true
                    b.scribed[aid] = { crafted = v[1], s = { v[2], v[3], v[4] } }
                end
            elseif type(v) == "number" and v ~= 0 then bar[slot] = v; any = true end
        end
        if any then b.bars[bi] = bar end
    end
    if u[X.FIRST_BOON] or u[X.SECOND_BOON] then
        b.boons = {}
        if u[X.FIRST_BOON] then b.boons[#b.boons+1] = u[X.FIRST_BOON] end
        if u[X.SECOND_BOON] then b.boons[#b.boons+1] = u[X.SECOND_BOON] end
    end
    b.wwVamp = u[X.WW_VAMP_BUFF]
    for slot, item in pairs(u[X.GEAR] or {}) do
        if item[1] and item[1] > 0 then
            b.equip[slot] = SB.ItemLink(item[1], item[4])
            b.linkFix[slot] = { q = item[2], t = item[3] }
        end
    end
    for i, star in ipairs(u[X.CONSTELLATIONS] or {}) do
        if star and star ~= 0 then b.cpSlots[i] = { id = star, pts = 0 } end
    end
    if u[X.FOOD] then b.food = { u[X.FOOD] } end
    b.lines = u[X.CLASS_SKILL_LINES]
    local mm = u[X.CLASS_MASTERY]
    if mm then
        local out = {}
        for i = 1, 2 do
            local v = mm[i]
            if type(v) == "number" and v ~= 0 then out[#out+1] = v
            elseif type(v) == "table" and v[1] then
                local aid; pcall(function() aid = GetAbilityIdForCraftedAbilityId(v[1]) end)
                if aid and aid ~= 0 then out[#out+1] = aid end
            end
        end
        if out[1] then b.mastery = out end
    end
    return b, u[X.RACE]
end

-- ---- viewer window (mirrors the main window's style; its own scene for ESC/cursor) ----
function SB.Ensure()
    if SB.Win then return true end
    local ok = pcall(function()
        local w = WM:CreateTopLevelWindow("ShoyrUI_SMXBuildViewer")
        -- Open LARGE by default (near-fullscreen, clamped to the screen and MAX) so a full build's two
        -- columns are visible without resizing -- the old W×H default needed manual maxing to read it all.
        -- Guarded so a GuiRoot hiccup falls back to W×H instead of aborting the whole window build.
        local dw, dh = W, H
        pcall(function()
            local sw, sh = GuiRoot:GetDimensions()
            dw = math.min(MAXW, math.max(W, math.floor((sw or W) * 0.92)))
            dh = math.min(MAXH, math.max(H, math.floor((sh or H) * 0.92)))
        end)
        w:SetDimensions(dw, dh)
        w:SetAnchor(CENTER, GuiRoot, CENTER, 0, 0)
        w:SetClampedToScreen(true)
        w:SetMovable(true)
        w:SetMouseEnabled(true)
        w:SetResizeHandleSize(8)                     -- drag any edge/corner, like the main /SMX window
        w:SetDimensionConstraints(760, 460, MAXW, MAXH)
        w:SetDrawTier(DT_HIGH)
        w:SetHidden(true)
        backdrop(w, C.win0, C.line, 2)
        SB.Title = label(w, 20, C.accent, nil, "bold")
        SB.Title:SetAnchor(TOPLEFT, w, TOPLEFT, PAD, 14)
        SB.Title:SetText("Shared build")
        local close = WM:CreateControlFromVirtual("ShoyrUI_SMXBVClose", w, "ZO_CloseButton")
        close:SetAnchor(TOPRIGHT, w, TOPRIGHT, -10, 12)
        close:SetHandler("OnClicked", function() SB.HideWin() end)
        close:SetHandler("OnMouseUp", function(_, _, inside) if inside then SB.HideWin() end end)
        -- Same TWO-column layout as the Build tab: a full-width tiles strip, then gear/sets on the
        -- LEFT and action bars + champion on the RIGHT (via BD.Cols) -- not one long single scroll.
        SB.Tiles = WM:CreateControl(nil, w, CT_CONTROL)
        SB.Tiles:SetAnchor(TOPLEFT, w, TOPLEFT, PAD, 52)
        SB.Tiles:SetAnchor(TOPRIGHT, w, TOPRIGHT, -PAD, 52)
        -- Columns anchor to a FIXED top (below the one-row tiles strip), NOT to SB.Tiles' dynamic
        -- bottom: on the FIRST render the tiles height hasn't propagated yet, so a sibling-bottom anchor
        -- resolved to the window top and the columns rode up over the title/tiles until a resize forced
        -- a re-layout. A fixed offset is deterministic on the very first show. (Tiles are always one row
        -- in this wide window.)
        SB.COLTOP = 128
        SB.SL = WM:CreateControlFromVirtual("ShoyrUI_SMXBVBuildL", w, "ZO_ScrollContainer")
        SB.SL:SetAnchor(TOPLEFT, w, TOPLEFT, PAD, SB.COLTOP)
        SB.SL:SetAnchor(BOTTOMLEFT, w, BOTTOMLEFT, PAD, -PAD)
        SB.CL = SB.SL:GetNamedChild("ScrollChild")
        SB.SR = WM:CreateControlFromVirtual("ShoyrUI_SMXBVBuildR", w, "ZO_ScrollContainer")
        SB.SR:SetAnchor(TOPRIGHT, w, TOPRIGHT, -PAD, SB.COLTOP)
        SB.SR:SetAnchor(BOTTOMRIGHT, w, BOTTOMRIGHT, -PAD, -PAD)
        SB.CR = SB.SR:GetNamedChild("ScrollChild")
        for _, c in ipairs({ SB.CL, SB.CR }) do if c then c:SetResizeToFitDescendents(false) end end
        SB.PL, SB.PR, SB.PT = {}, {}, {}
        SB.Win = w
        -- Reflow the build to the new width on resize (guarded on size so a MOVE doesn't re-render).
        local lw, lh = w:GetWidth(), w:GetHeight()
        w:SetHandler("OnRectChanged", function()
            if not (SB.Win and SB.current) then return end
            local ww, hh = w:GetWidth(), w:GetHeight()
            if math.abs(ww - lw) >= 1 or math.abs(hh - lh) >= 1 then
                lw, lh = ww, hh
                SB.RenderInto(SB.current)
            end
        end)
        w:SetHandler("OnResizeStop", function() if SB.current then SB.RenderInto(SB.current) end end)
        -- Fires the instant the window becomes effectively visible AND laid out -- the deterministic hook
        -- for the first-open reflow (no timing guess). Guarded by SB._busy so it can't recurse on SetHeight.
        w:SetHandler("OnEffectivelyShown", function() if SB.current then SB.RenderInto(SB.current) end end)
        if SCENE_MANAGER and ZO_Scene and ZO_FadeSceneFragment then
            SB.Scene = ZO_Scene:New(SB.SCENE_NAME, SCENE_MANAGER)
            SB.Scene:AddFragment(ZO_FadeSceneFragment:New(w))
        end
    end)
    if not ok then SB.Win = nil end
    return SB.Win ~= nil
end
function SB.ShowWin()
    if SceneShowing() then SB.Win:SetHidden(false)          -- SMX window open: ride its cursor/scene
    elseif SB.Scene and SCENE_MANAGER then SCENE_MANAGER:Show(SB.SCENE_NAME)
    elseif SB.Win then SB.Win:SetHidden(false) end
end
function SB.HideWin()
    if SB.Scene and SCENE_MANAGER and SCENE_MANAGER:IsShowing(SB.SCENE_NAME) then SCENE_MANAGER:Hide(SB.SCENE_NAME) end
    if SB.Win then SB.Win:SetHidden(true) end
end

-- Render a build into the viewer at the CURRENT window width, and remember it (SB.current) so a
-- resize can reflow the same build. contentW is the shared width var the Build layout reads, so we
-- set it to our window, render, then restore it for the main window.
function SB.RenderInto(fake)
    if not (fake and SB.Win and SB.CL and SB.CR) then return end
    if SB._busy then return end                                            -- re-entrancy guard: our own SetHeight re-fires OnRectChanged
    SB._busy = true
    SB.current = fake
    local saved = contentW
    local rok, err = pcall(function()
        local ww = SB.Win:GetWidth(); if ww < 100 then ww = W end          -- first show can report 0 before layout settles
        local cw = ww - PAD * 2                                            -- inner width the two columns share
        local L, R, tiles = BD.Cols(fake)
        contentW = cw                                                      -- tiles size to THIS window, not the main one (was overflowing)
        RenderLinesInto(nil, SB.Tiles, SB.PT, tiles and { tiles } or {})   -- full-width tiles strip above both columns
        if not tiles then SB.Tiles:SetHeight(1) end
        local lW = math.floor((cw - 12) * 0.66)                           -- gear/sets wider so a piece fits on one row (matches the Build tab)
        local rW = cw - 12 - lW
        SB.SL:SetWidth(lW); SB.SR:SetWidth(rW)
        SB.CL:SetWidth(lW - 20); SB.CR:SetWidth(rW - 20)                   -- -20: scrollbar gutter clips right-edge tags
        contentW = lW - 20; RenderLinesInto(SB.SL, SB.CL, SB.PL, L)        -- rows size to their column, not the window
        contentW = rW - 20; RenderLinesInto(SB.SR, SB.CR, SB.PR, R)
        -- Fit the window HEIGHT to the taller column so there is NO empty scroll space below the build.
        -- Columns sit at the fixed SB.COLTOP; bottom pad = PAD.
        local contentH = math.max(SB.CL:GetHeight() or 0, SB.CR:GetHeight() or 0)
        local want = (SB.COLTOP or 128) + contentH + PAD
        local capH = MAXH
        pcall(function() local _, sh = GuiRoot:GetDimensions(); if sh and sh > 0 then capH = math.min(MAXH, math.floor(sh * 0.96)) end end)
        want = math.max(460, math.min(capH, want))                        -- >= the min constraint, <= screen/MAX (scrolls if a build is huge)
        if math.abs((SB.Win:GetHeight() or 0) - want) >= 2 then SB.Win:SetHeight(want) end
    end)
    contentW = saved
    SB._busy = false
    if not rok then d("|cFFD700[Duel Metrics]|r build viewer error: " .. tostring(err)) end
end

function SB.View(packed)
    local X = SB.LDPX()
    if not X then
        d("|cFFD700[Duel Metrics]|r Viewing shared builds needs the LibDataPacker library (free on ESOUI; installed with ImpressiveStats).")
        return
    end
    local ok, u = pcall(X.UnpackShortBuild, packed)
    if not (ok and u) then
        d("|cFFD700[Duel Metrics]|r Couldn't read that build link (made by a different version?).")
        return
    end
    local b, race = SB.FromShort(u)
    if not b or not SB.Ensure() then return end
    SB.Title:SetText(string.format("Shared build \226\128\148 %s %s", RaceName(race) or "", ClassName(b.classId)))
    local fake = { build = b, myRaceId = race, myClassId = b.classId, __shared = true }
    -- FIRST-render fix: SHOW the window BEFORE rendering. Rendering while hidden measured the tiles strip
    -- and columns against un-propagated layout, so on the very first click the header (title + tiles) rode
    -- down over the left column and only a manual resize forced a correct re-flow. Setting SB.current first
    -- also lets the window's OnEffectivelyShown handler (in SB.Ensure) re-render the instant it's laid out.
    SB.current = fake
    SB.ShowWin()
    SB.RenderInto(fake)
    -- Belt-and-braces: re-render on the next couple of frames in case the first show settles a frame late.
    if zo_callLater then
        zo_callLater(function() if SB.Win and SB.current == fake then SB.RenderInto(fake) end end, 50)
        zo_callLater(function() if SB.Win and SB.current == fake then SB.RenderInto(fake) end end, 150)
    end
end

-- LINK_HANDLER callback: (link, button, linkText, color, linkType, ...data) — pChat-verified
-- layout. Registered for CLICKED + MOUSE_UP + NOT_HANDLED (belt and braces); case-insensitive
-- type match; debounced so one click can't double-open.
function SB.HandleLink(_, button, _, _, linkType, data)
    if SB.debug then d("[SMX] link event: type=" .. tostring(linkType) .. " btn=" .. tostring(button) .. " data=" .. tostring(data and #tostring(data)) .. "ch") end
    if tostring(linkType or ""):lower() ~= SB.LINK then return end
    if button and MOUSE_BUTTON_INDEX_RIGHT and button == MOUSE_BUTTON_INDEX_RIGHT then return true end
    local now = (GetGameTimeMilliseconds and GetGameTimeMilliseconds()) or 0
    if SB.lastData == data and (now - (SB.lastAt or 0)) < 500 then return true end
    SB.lastData, SB.lastAt = data, now
    SB.View(SB.Decode(data))   -- data is base64url; Decode -> packed (and tolerates raw packed from old links)
    return true
end
function SB.Register()
    if SB.registered then return end
    SB.registered = pcall(function()
        LINK_HANDLER:RegisterCallback(LINK_HANDLER.LINK_CLICKED_EVENT, SB.HandleLink)
        LINK_HANDLER:RegisterCallback(LINK_HANDLER.LINK_MOUSE_UP_EVENT, SB.HandleLink)
        LINK_HANDLER:RegisterCallback(LINK_HANDLER.LINK_NOT_HANDLED_EVENT, SB.HandleLink)
    end) or nil
    pcall(function()
        -- /smxbuild [code] — open a shared build. With no code, opens the most recent one seen in chat.
        SLASH_COMMANDS["/smxbuild"] = function(arg)
            local code = tostring(arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
            if code == "" then code = SB.inbox end
            if not code or code == "" then
                d("|cFFD700[Shoyru's PvP Metrics]|r No build yet \226\128\148 paste a code (|cFFD700/smxbuild <code>|r) or wait for one to be shared in chat.")
                return
            end
            SB.View(SB.Decode(code))
        end
        if ShoyrUI.DuelMetrics and ShoyrUI.DuelMetrics.DEV then   -- dev-only link-handler debug
            SLASH_COMMANDS["/smxlinkdebug"] = function()
                SB.debug = not SB.debug
                d("[SMX] link debug " .. (SB.debug and "ON \226\128\148 now click a build link" or "off")
                    .. "; handler registered: " .. tostring(SB.registered == true))
            end
        end
    end)
    -- Watch chat for shared build codes and print OUR OWN prompt with a clickable [View this build].
    -- Chat is the only clickable-in-combat surface, but pChat proxies real chat links into a crashing
    -- "p" wrapper -- so instead of relying on the sender's link, each recipient's addon spots the
    -- plain-text code as it arrives and offers its own link + a /smxbuild fallback. Guarded so a chat
    -- API change can never break chat.
    pcall(function()
        EVENT_MANAGER:RegisterForEvent("ShoyrUI_SMXBuildRecv", EVENT_CHAT_MESSAGE_CHANNEL,
            function(_, _, fromRaw, text, _, fromDisp)
                if type(text) ~= "string" then return end
                local code = text:match("/smxbuild%s+([%w%-_]+)")
                if not code then return end
                SB.inbox = code
                local who = (fromDisp and fromDisp ~= "" and fromDisp) or fromRaw or "Someone"
                who = tostring(who):gsub("|H.-|h(.-)|h", "%1")
                local link = ZO_LinkHandler_CreateLink and ZO_LinkHandler_CreateLink("View this build", nil, SB.LINK, code)
                d(string.format("|cFFD700[Shoyru's PvP Metrics]|r %s shared a build \226\128\148 %s",
                    who, link and (link .. "  |c9a9aa2(or /smxbuild)|r") or "type |cFFD700/smxbuild|r to view it."))
            end)
    end)
    -- Belt-and-braces: some chat addons (pChat) proxy links into a "p" wrapper that ESO's default
    -- handler chokes on when clicked (the malformed-link tooltip error). Swallow just that failure so
    -- a stray click is a harmless no-op, not an error dump; valid link tooltips are unaffected.
    pcall(function()
        if type(ZO_PopupTooltip_SetLink) == "function" and not SB.tipGuard then
            SB.tipGuard = true
            local orig = ZO_PopupTooltip_SetLink
            ZO_PopupTooltip_SetLink = function(...) return (pcall(orig, ...)) end
        end
    end)
end
SB.Register()   -- at load; UI.Init retries in case LINK_HANDLER wasn't ready yet

-- Headless regression-test seam. Inert in-game (ShoyrUI._TEST is nil); the test harness in
-- ShoyrUI/tests/ sets ShoyrUI._TEST before load to expose the pure data builders for verification.
if rawget(ShoyrUI, "_TEST") then
    UI._test = {
        StatsItems = StatsItems, HealingItems = HealingItems, GradeItems = GradeItems,
        BuildItems = BD.Items, DamageTiles = DamageTiles, DamageItems = DamageItems,
        AbilityRows = AbilityRows, EffectRows = EffectRows, DirEffectRows = DirEffectRows,
        ControlRows = ControlRows, StatusOnly = StatusOnly, NonStatus = NonStatus,
        FlowTiles = FlowTiles, FlowBreakdown = FlowBreakdown, LogItems = LogItems, TabItems = TabItems,
        BurstEvents = F.BurstEvents, BurstItems = F.BurstItems,
        Comma = Comma, Abbrev = Abbrev, MyAverages = MyAverages, F = F, SB = SB,
        PlayerRank = RANK.Compute, RANK = RANK,
        ReportDims = RC.Dims, OverallScore = RC.Overall, GradeLetter = GradeLetter,
        DuelGrade = DuelGrade, AvgGrade = RC.AvgGrade,
        Calibrating = RC.Calibrating, DuelCount = RC.DuelCount, Baseline = RC.Baseline, Trend = RC.Trend, RC = RC,
        Insights = RC.Insights, InsightCards = RC.InsightCards, EffKind = RC.EffKind, Ctx = RC.Ctx, ClassTip = RC.ClassTip,
        ComboScan = RC.ComboScan, MatchupRead = RC.MatchupRead, BarSplit = RC.BarSplit,
        MirrorRead = RC.MirrorRead, MirrorVerdict = RC.MirrorVerdict,
        PurgeCount = PurgeCount, FmtMS = UI._FmtMS,
        HardCC = RC.HardCC, ResourceFloor = RC.ResourceFloor, PressureScore = RC.PressureScore,
        Mitigation = RC.Mitigation, Interrupts = RC.Interrupts, DimNorms = RC.DimNorms, BuildFlags = BuildFlags,
        guide = UI.guide, TABS = TABS,
    }
end
