-- Shoyru's PvP Metrics :: bootstrap
-- Standalone addon extracted from Shoyru's UI (2026-07-06). It owns the two SMX modules —
-- DuelMetrics (LibCombat capture) + DuelMetricsUI (the /SMX window) — and will grow to cover
-- Open World; Duels is the first mode. The modules still register onto the
-- shared `ShoyrUI` global bucket, so they needed no rename when they moved out.

ShoyrUI = ShoyrUI or {}

local ADDON   = "ShoyruPvPMetrics"
local SV_NAME = "ShoyruPvPMetricsSavedVariables"
local VERSION = "1.0.19"

-- The duel store now lives at the SV ROOT (it used to be ShoyrUISavedVariables.duels).
-- DuelMetrics/DuelMetricsUI fill opponents/win on init; autoOpen defaults on.
-- autoOpen defaults OFF: a cursor-grabbing window popping up right after a duel (maybe mid-next-fight)
-- is intrusive. Review on demand with /smx; opt into auto-open with /smxauto.
local defaults = { opponents = {}, autoOpen = false, version = 2 }

local function chat(msg)
    if CHAT_ROUTER and CHAT_ROUTER.AddSystemMessage then CHAT_ROUTER:AddSystemMessage(msg)
    elseif CHAT_SYSTEM and CHAT_SYSTEM.AddMessage then CHAT_SYSTEM:AddMessage(msg) end
end

-- One-time, NON-destructive migration. If the old Shoyru's UI addon is still installed, lift its
-- captured duels into this addon the first time we run with an empty store. The old data is left
-- untouched (so nothing is lost if this addon is removed), and demo/rank-test opponents (@Demo*)
-- are skipped so junk doesn't carry over.
local function Migrate(sv)
    -- One-time: once we've migrated (or the store already has data, or a /smxwipe marked it), never
    -- re-import. The `migrated` flag is what makes a /smxwipe survive a reloadui instead of the old
    -- Shoyru's UI duels flooding back in from the migration source.
    if sv.migrated or next(sv.opponents) then sv.migrated = true; return end
    local ok, old = pcall(function() return ZO_SavedVars:NewAccountWide("ShoyrUISavedVariables", 1, nil, {}) end)
    if ok and old and type(old.duels) == "table" and type(old.duels.opponents) == "table" then
        local moved = 0
        for handle, o in pairs(old.duels.opponents) do
            if not (type(handle) == "string" and handle:find("^@Demo")) then
                sv.opponents[handle] = ZO_DeepTableCopy(o)
                moved = moved + 1
            end
        end
        if old.duels.autoOpen ~= nil then sv.autoOpen = old.duels.autoOpen end
        if moved > 0 then chat(string.format("|cFFD700[Shoyru's PvP Metrics]|r migrated %d opponent record%s from Shoyru's UI.", moved, moved == 1 and "" or "s")) end
    end
    sv.migrated = true                                         -- mark done even if there was nothing to import
end

local function BuildSettings()
    local LAM = LibAddonMenu2
    if not LAM then return end
    LAM:RegisterAddonPanel("ShoyruPvPMetricsPanel", {
        type = "panel", name = "Shoyru's PvP Metrics", displayName = "Shoyru's PvP Metrics",
        author = "Shoyru", version = VERSION, slashCommand = "/shoyrpvp",
        registerForRefresh = true,
    })
    local HUD = ShoyrUI.DuelHUD
    local hud = function() return HUD and HUD.Cfg and HUD.Cfg() end
    LAM:RegisterOptionControls("ShoyruPvPMetricsPanel", {
        { type = "description", text = "PvP performance metrics. Type |cFFD700/SMX|r (or /smx) to open the Duels analyzer." },
        { type = "header", name = "Duels" },
        { type = "description", text = "Every duel is read from live combat through LibCombat's event stream; SMX then computes its own breakdowns \226\128\148 damage, healing, buffs & debuffs, stats, an over-time timeline, the opponent's build, and an overall dueling tier across your rivals. LibCombat is required for the combat data; LibDataPacker enables shareable build links." },
        { type = "header", name = "Live Duel HUD" },
        { type = "description", text = "A small card that stays on your screen and comes alive during a duel \226\128\148 live DPS, healing, incoming damage and duel time, with a \"tempo\" bar for who is winning the exchange. It's always shown while enabled; untick \"Enable HUD\" to hide it. Tick \"Unlock\" below to reposition it \226\128\148 then drag the card to move it, or drag the corner grabber to resize." },
        {
            type = "checkbox", name = "Enable HUD", width = "full",
            getFunc = function() local h = hud(); return h and h.enabled end,
            setFunc = function(v) local h = hud(); if h then h.enabled = v; HUD.Refresh() end end,
        },
        {
            type = "checkbox", name = "Unlock (move & resize)", width = "full",
            tooltip = "Unlocked shows a preview: drag the card to move it, drag the bottom-right grabber (or scroll the wheel) to resize. Lock again when placed.",
            getFunc = function() local h = hud(); return h and not h.locked end,
            setFunc = function(v) if HUD then HUD.SetLocked(not v) end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "slider", name = "Opacity", min = 20, max = 100, step = 5, width = "full",
            getFunc = function() local h = hud(); return math.floor((h and h.opacity or 0.92) * 100) end,
            setFunc = function(v) local h = hud(); if h then h.opacity = v / 100; HUD.Refresh() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "checkbox", name = "Keep final numbers up after the duel", width = "full",
            tooltip = "On: this duel's final numbers stay until your next duel. Off: they hold for a few seconds, then the card settles back to a resting state (it stays on screen either way).",
            getFunc = function() local h = hud(); return h and h.endStay end,
            setFunc = function(v) local h = hud(); if h then h.endStay = v end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        { type = "description", text = "Show which stats:" },
        {
            type = "checkbox", name = "OUT (your DPS)", width = "half",
            getFunc = function() local h = hud(); return h and h.show and h.show.out end,
            setFunc = function(v) local h = hud(); if h then h.show.out = v; HUD.Refresh() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "checkbox", name = "HEAL (your HPS)", width = "half",
            getFunc = function() local h = hud(); return h and h.show and h.show.heal end,
            setFunc = function(v) local h = hud(); if h then h.show.heal = v; HUD.Refresh() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "checkbox", name = "IN (incoming DPS)", width = "half",
            getFunc = function() local h = hud(); return h and h.show and h.show.inc end,
            setFunc = function(v) local h = hud(); if h then h.show.inc = v; HUD.Refresh() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "checkbox", name = "TIME (duel duration)", width = "half",
            getFunc = function() local h = hud(); return h and h.show and h.show.time end,
            setFunc = function(v) local h = hud(); if h then h.show.time = v; HUD.Refresh() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "checkbox", name = "Tempo bar (damage-war)", width = "half",
            getFunc = function() local h = hud(); return h and h.show and h.show.tempo end,
            setFunc = function(v) local h = hud(); if h then h.show.tempo = v; HUD.Refresh() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        {
            type = "button", name = "Reset HUD position", width = "half",
            func = function() if HUD then HUD.ResetPos() end end,
            disabled = function() local h = hud(); return not (h and h.enabled) end,
        },
        { type = "header", name = "Open World \226\128\148 coming soon" },
    })
end

local function OnLoaded(_, name)
    if name ~= ADDON then return end
    EVENT_MANAGER:UnregisterForEvent(ADDON, EVENT_ADD_ON_LOADED)

    local sv = ZO_SavedVars:NewAccountWide(SV_NAME, 1, nil, defaults)
    Migrate(sv)
    -- One-time: auto-open used to default ON with no way to turn it off. It now defaults OFF (a window
    -- grabbing the cursor after every duel is intrusive). Flip any pre-existing stored value to the new
    -- default once; after this, /smxauto choices persist.
    if not sv.autoOpenReset then sv.autoOpen = false; sv.autoOpenReset = true end

    if ShoyrUI.DuelMetrics then ShoyrUI.DuelMetrics.Init(sv) end
    if ShoyrUI.DuelMetricsUI then ShoyrUI.DuelMetricsUI.VERSION = VERSION; ShoyrUI.DuelMetricsUI.Init(sv) end
    if ShoyrUI.DuelHUD then ShoyrUI.DuelHUD.Init(sv) end
    BuildSettings()
    -- /shoyrpvp opens THE WINDOW, same as /smx -- typing the addon's name should show the addon,
    -- not silently claim the LAM settings slash (Shoyru hit this expecting the analyzer). Registered
    -- AFTER BuildSettings so it wins over LAM's registration; settings stay reachable via the menu.
    if SLASH_COMMANDS["/smx"] then SLASH_COMMANDS["/shoyrpvp"] = SLASH_COMMANDS["/smx"] end
end

-- ---- Keybinds (Bindings.xml) -------------------------------------------------
-- Two bindable actions so nothing needs a slash command: open/close the Duels window (same as /smx)
-- and show/hide the live HUD (same as the settings "Enable HUD" box). Bind them in the game's
-- Controls > Keybindings menu, under the "Shoyru's PvP Metrics" category.
ZO_CreateStringId("SI_BINDING_NAME_SHOYRU_PVP_TOGGLE_WINDOW", "Open / close the Duels window")
ZO_CreateStringId("SI_BINDING_NAME_SHOYRU_PVP_TOGGLE_HUD", "Show / hide the live HUD")

function ShoyruPvPMetrics_ToggleWindow()
    local UI = ShoyrUI and ShoyrUI.DuelMetricsUI
    if UI and UI.Toggle then UI.Toggle() end
end

function ShoyruPvPMetrics_ToggleHUD()
    local HUD = ShoyrUI and ShoyrUI.DuelHUD
    if not (HUD and HUD.ToggleEnabled) then return end
    local on = HUD.ToggleEnabled()
    d("|cFFD700[Shoyru's PvP Metrics]|r Live HUD " .. (on and "|c66DD66shown|r" or "|cDD6666hidden|r") .. ".")
end

EVENT_MANAGER:RegisterForEvent(ADDON, EVENT_ADD_ON_LOADED, OnLoaded)
