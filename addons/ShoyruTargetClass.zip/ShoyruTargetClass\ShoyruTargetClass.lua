ShoyruTargetClass = {}
ShoyruTargetClass.name    = "ShoyruTargetClass"
ShoyruTargetClass.version = "1.0"

local TC  = ShoyruTargetClass
local WM  = WINDOW_MANAGER
-- Use the LibAddonMenu2 global directly. LAM only optionally depends on
-- LibStub, so LibStub(...) can be nil at file-load time depending on which
-- other addons are installed.
local LAM = LibAddonMenu2

-- ---------------------------------------------------------------------------
-- Class info table: classId -> { name, icon }
-- Built once at load via GetClassInfo(classIndex) — mirrors LUI's pattern.
-- GetClassInfo returns multiple values; index [1] = classId, [4] = localized
-- name, [8] = icon path.
-- ---------------------------------------------------------------------------

local CLASS_INFO = {}

local function BuildClassInfo()
    CLASS_INFO = {}
    for i = 1, GetNumClasses() do
        local info = { GetClassInfo(i) }
        local classId = info[1]
        local name    = info[4] or ""
        local icon    = info[8] or ""
        if classId then
            CLASS_INFO[classId] = { name = name, icon = icon }
        end
    end
end

-- Reasonable defaults for class label tinting. Keyed by classId; pulled from
-- CLASS_INFO at runtime for unknown IDs (falls back to white).
local DEFAULT_CLASS_COLORS = {
    [1]   = { r = 0.85, g = 0.28, b = 0.20 }, -- Dragonknight  (red)
    [2]   = { r = 0.95, g = 0.83, b = 0.35 }, -- Sorcerer      (gold)
    [3]   = { r = 0.65, g = 0.40, b = 0.85 }, -- Nightblade    (purple)
    [4]   = { r = 0.45, g = 0.80, b = 0.45 }, -- Warden        (green)
    [5]   = { r = 0.55, g = 0.75, b = 0.45 }, -- Necromancer   (olive)
    [6]   = { r = 0.95, g = 0.85, b = 0.55 }, -- Templar       (cream)
    [117] = { r = 0.35, g = 0.85, b = 0.85 }, -- Arcanist      (teal)
}

-- ---------------------------------------------------------------------------
-- Defaults
-- ---------------------------------------------------------------------------

local DEFAULTS = {
    enabled         = true,

    -- Content
    showIcon        = true,
    showName        = true,
    iconSize        = 36,
    fontSize        = 22,
    iconOnLeft      = true,
    spacing         = 6,

    -- Color
    useClassColor   = true,
    textColor       = { r = 1, g = 1, b = 1, a = 1 },

    -- Filtering
    playersOnly     = true,
    hideDead        = true,
    onlyInCombat    = false,

    -- Position — anchored CENTER to GuiRoot TOP with these offsets.
    -- Default places it just below the default target nameplate area.
    x               = 0,
    y               = 120,

    -- Layout
    locked          = true,
}

-- ---------------------------------------------------------------------------
-- State
-- ---------------------------------------------------------------------------

local window, iconCtrl, nameCtrl
local previewMode = false

local function Log(fmt, ...)
    -- Reserved for future debugging.
end

-- ---------------------------------------------------------------------------
-- UI
-- ---------------------------------------------------------------------------

local function ApplyFontStyle()
    if not nameCtrl then return end
    local font = string.format("$(BOLD_FONT)|%d|soft-shadow-thick", math.max(10, TC.sv.fontSize))
    nameCtrl:SetFont(font)
end

local function LayoutChildren()
    if not window then return end
    local sv = TC.sv
    local pad = sv.spacing

    -- Hide elements that are disabled, then size and place what remains.
    iconCtrl:SetHidden(not sv.showIcon)
    nameCtrl:SetHidden(not sv.showName)

    iconCtrl:SetDimensions(sv.iconSize, sv.iconSize)
    ApplyFontStyle()

    -- Compute width: icon + spacing + measured text. Text width is hard to
    -- measure pre-render; we let nameCtrl auto-size and the parent window
    -- just tracks roughly. We anchor name to icon and let it grow outward.
    iconCtrl:ClearAnchors()
    nameCtrl:ClearAnchors()

    if sv.showIcon and sv.showName then
        if sv.iconOnLeft then
            iconCtrl:SetAnchor(LEFT, window, LEFT, 0, 0)
            nameCtrl:SetAnchor(LEFT, iconCtrl, RIGHT, pad, 0)
        else
            nameCtrl:SetAnchor(LEFT, window, LEFT, 0, 0)
            iconCtrl:SetAnchor(LEFT, nameCtrl, RIGHT, pad, 0)
        end
    elseif sv.showIcon then
        iconCtrl:SetAnchor(CENTER, window, CENTER, 0, 0)
    else
        nameCtrl:SetAnchor(CENTER, window, CENTER, 0, 0)
    end

    -- Window itself sized loosely; we don't try to perfectly fit since name
    -- length varies. A wide window with center-anchored child reads cleanly.
    local approxWidth = (sv.showIcon and sv.iconSize or 0)
                     + (sv.showName and 200 or 0)
                     + ((sv.showIcon and sv.showName) and pad or 0)
    window:SetDimensions(math.max(64, approxWidth), math.max(sv.iconSize, sv.fontSize + 6))
end

local function SaveWindowPosition()
    if not window or not TC.sv then return end
    local cx, _ = window:GetCenter()
    local _, top = window:GetScreenRect()
    TC.sv.x = cx - GuiRoot:GetWidth() / 2
    TC.sv.y = top
end

local function CreateUI()
    window = WM:CreateTopLevelWindow("ShoyruTargetClassWindow")
    window:SetClampedToScreen(true)
    window:SetDrawTier(DT_HIGH)
    window:SetDrawLayer(DL_OVERLAY)
    window:SetMovable(false)
    window:SetMouseEnabled(false)
    window:SetHidden(true)
    window:SetAnchor(TOP, GuiRoot, TOP, TC.sv.x, TC.sv.y)
    window:SetHandler("OnMoveStop", SaveWindowPosition)

    iconCtrl = WM:CreateControl(nil, window, CT_TEXTURE)
    iconCtrl:SetTexture("")

    nameCtrl = WM:CreateControl(nil, window, CT_LABEL)
    nameCtrl:SetColor(1, 1, 1, 1)
    nameCtrl:SetText("")
    nameCtrl:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
    nameCtrl:SetVerticalAlignment(TEXT_ALIGN_CENTER)
end

-- ---------------------------------------------------------------------------
-- Display update
-- ---------------------------------------------------------------------------

local function GetColorForClass(classId)
    local sv = TC.sv
    if not sv.useClassColor then
        local c = sv.textColor
        return c.r, c.g, c.b, c.a or 1
    end
    local c = DEFAULT_CLASS_COLORS[classId]
    if c then return c.r, c.g, c.b, 1 end
    return 1, 1, 1, 1
end

local function ShouldShowForTarget(unitTag)
    local sv = TC.sv
    if not sv.enabled then return false end
    if not DoesUnitExist(unitTag) then return false end
    if sv.playersOnly and not IsUnitPlayer(unitTag) then return false end
    if sv.hideDead and IsUnitDead(unitTag) then return false end
    if sv.onlyInCombat and not IsUnitInCombat("player") then return false end
    return true
end

local function ShowFor(classId, displayName)
    local info = CLASS_INFO[classId]
    if not info then return end
    iconCtrl:SetTexture(info.icon)
    nameCtrl:SetText(displayName or info.name or "")
    local r, g, b, a = GetColorForClass(classId)
    nameCtrl:SetColor(r, g, b, a)
    LayoutChildren()
    window:SetHidden(false)
end

local function Hide()
    if window then window:SetHidden(true) end
end

local function RefreshFromReticleTarget()
    if previewMode then return end -- preview drives display directly
    local unitTag = "reticleover"
    if not ShouldShowForTarget(unitTag) then
        Hide()
        return
    end
    local classId = GetUnitClassId(unitTag)
    if not classId or not CLASS_INFO[classId] then
        Hide()
        return
    end
    ShowFor(classId, GetUnitClass(unitTag))
end

-- ---------------------------------------------------------------------------
-- Preview (used when unlocked for positioning)
-- ---------------------------------------------------------------------------

local previewCycle = { 1, 2, 3, 4, 5, 6, 117 }
local previewIndex = 0

local function PreviewTick()
    if not previewMode then return end
    previewIndex = previewIndex + 1
    if previewIndex > #previewCycle then previewIndex = 1 end
    local classId = previewCycle[previewIndex]
    -- Only cycle through classes that actually exist in this client.
    while not CLASS_INFO[classId] do
        previewIndex = previewIndex + 1
        if previewIndex > #previewCycle then previewIndex = 1 end
        classId = previewCycle[previewIndex]
    end
    ShowFor(classId, CLASS_INFO[classId].name)
end

local function StartPreview()
    previewMode = true
    previewIndex = 0
    PreviewTick()
    EVENT_MANAGER:RegisterForUpdate(TC.name .. "_Preview", 1200, PreviewTick)
end

local function StopPreview()
    previewMode = false
    EVENT_MANAGER:UnregisterForUpdate(TC.name .. "_Preview")
    RefreshFromReticleTarget()
end

local function SetWindowInteractive(interactive)
    if not window then return end
    window:SetMovable(interactive)
    window:SetMouseEnabled(interactive)
end

-- ---------------------------------------------------------------------------
-- LAM panel
-- ---------------------------------------------------------------------------

local function colorGet(field)
    return function()
        local c = TC.sv[field]
        return c.r, c.g, c.b, c.a or 1
    end
end
local function colorSet(field)
    return function(r, g, b, a)
        local c = TC.sv[field]
        c.r, c.g, c.b, c.a = r, g, b, a
        RefreshFromReticleTarget()
    end
end

local function BuildSettings()
    local panelData = {
        type                = "panel",
        name                = "Shoyru's Target Class",
        displayName         = "Shoyru's Target Class",
        author              = "Shoyru",
        version             = TC.version,
        slashCommand        = "/targetclass",
        registerForRefresh  = true,
        registerForDefaults = true,
    }

    local options = {
        { type = "description",
          text = "Shows the class of the player you're looking at, anchored near the default target nameplate. Toggles below let you switch between icon-only, text-only, or both. Unlock under Layout to move/resize and preview each class." },
        { type = "checkbox", name = "Enabled",
          getFunc = function() return TC.sv.enabled end,
          setFunc = function(v) TC.sv.enabled = v; RefreshFromReticleTarget() end,
          width   = "full" },

        -- Content
        { type = "header", name = "Display" },
        { type = "checkbox", name = "Show class icon",
          getFunc = function() return TC.sv.showIcon end,
          setFunc = function(v) TC.sv.showIcon = v; LayoutChildren() end,
          width   = "half" },
        { type = "checkbox", name = "Show class name",
          getFunc = function() return TC.sv.showName end,
          setFunc = function(v) TC.sv.showName = v; LayoutChildren() end,
          width   = "half" },
        { type = "slider", name = "Icon size", min = 16, max = 96, step = 2,
          getFunc = function() return TC.sv.iconSize end,
          setFunc = function(v) TC.sv.iconSize = v; LayoutChildren() end,
          width   = "full" },
        { type = "slider", name = "Font size", min = 10, max = 48, step = 1,
          getFunc = function() return TC.sv.fontSize end,
          setFunc = function(v) TC.sv.fontSize = v; LayoutChildren() end,
          width   = "full" },
        { type = "slider", name = "Spacing between icon and text", min = 0, max = 24, step = 1,
          getFunc = function() return TC.sv.spacing end,
          setFunc = function(v) TC.sv.spacing = v; LayoutChildren() end,
          width   = "full" },
        { type = "checkbox", name = "Icon to the left of name",
          tooltip = "Off = icon to the right of the name.",
          getFunc = function() return TC.sv.iconOnLeft end,
          setFunc = function(v) TC.sv.iconOnLeft = v; LayoutChildren() end,
          width   = "full" },

        -- Color
        { type = "header", name = "Color" },
        { type = "checkbox", name = "Tint name by class (DK red, Sorc gold, etc.)",
          getFunc = function() return TC.sv.useClassColor end,
          setFunc = function(v) TC.sv.useClassColor = v; RefreshFromReticleTarget() end,
          width   = "full" },
        { type = "colorpicker", name = "Fixed text color (used when class tint is off)",
          getFunc = colorGet("textColor"), setFunc = colorSet("textColor"),
          disabled = function() return TC.sv.useClassColor end,
          width = "full" },

        -- Filtering
        { type = "header", name = "When to show" },
        { type = "checkbox", name = "Players only",
          tooltip = "Don't show class info on NPCs, even if they have one assigned.",
          getFunc = function() return TC.sv.playersOnly end,
          setFunc = function(v) TC.sv.playersOnly = v; RefreshFromReticleTarget() end,
          width   = "full" },
        { type = "checkbox", name = "Hide for dead targets",
          getFunc = function() return TC.sv.hideDead end,
          setFunc = function(v) TC.sv.hideDead = v; RefreshFromReticleTarget() end,
          width   = "half" },
        { type = "checkbox", name = "Only show in combat",
          getFunc = function() return TC.sv.onlyInCombat end,
          setFunc = function(v) TC.sv.onlyInCombat = v; RefreshFromReticleTarget() end,
          width   = "half" },

        -- Layout — at the bottom per the convention
        { type = "header", name = "Layout" },
        { type = "checkbox", name = "Unlock (move + preview cycling through classes)",
          getFunc = function() return not TC.sv.locked end,
          setFunc = function(v)
              TC.sv.locked = not v
              SetWindowInteractive(v)
              if v then StartPreview() else StopPreview() end
          end,
          width   = "full" },
        { type = "button", name = "Reset position",
          func    = function()
              TC.sv.x, TC.sv.y = 0, 120
              window:ClearAnchors()
              window:SetAnchor(TOP, GuiRoot, TOP, TC.sv.x, TC.sv.y)
          end,
          width   = "half" },

        -- Reset
        { type = "header", name = "Reset" },
        { type = "button", name = "Reset all settings to defaults",
          warning = "Wipes every setting in this addon's saved variables.",
          isDangerous = true,
          func    = function()
              for k, v in pairs(DEFAULTS) do
                  if type(v) == "table" then
                      TC.sv[k] = ZO_DeepTableCopy(v)
                  else
                      TC.sv[k] = v
                  end
              end
              window:ClearAnchors()
              window:SetAnchor(TOP, GuiRoot, TOP, TC.sv.x, TC.sv.y)
              LayoutChildren()
              RefreshFromReticleTarget()
          end,
          width   = "full" },
    }

    LAM:RegisterAddonPanel("ShoyruTargetClassPanel", panelData)
    LAM:RegisterOptionControls("ShoyruTargetClassPanel", options)
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------

local function OnReticleChanged()
    RefreshFromReticleTarget()
end

local function OnCombatStateChanged()
    if TC.sv.onlyInCombat then RefreshFromReticleTarget() end
end

local function OnAddonLoaded(_, addonName)
    if addonName ~= TC.name then return end
    EVENT_MANAGER:UnregisterForEvent(TC.name, EVENT_ADD_ON_LOADED)

    TC.sv = ZO_SavedVars:NewAccountWide("ShoyruTargetClassSavedVariables", 1, nil, DEFAULTS)

    BuildClassInfo()
    CreateUI()
    LayoutChildren()
    BuildSettings()

    EVENT_MANAGER:RegisterForEvent(TC.name, EVENT_RETICLE_TARGET_CHANGED, OnReticleChanged)
    EVENT_MANAGER:RegisterForEvent(TC.name, EVENT_PLAYER_COMBAT_STATE,     OnCombatStateChanged)
    EVENT_MANAGER:RegisterForEvent(TC.name, EVENT_UNIT_DEATH_STATE_CHANGED, function()
        if TC.sv.hideDead then RefreshFromReticleTarget() end
    end)

    RefreshFromReticleTarget()
end

EVENT_MANAGER:RegisterForEvent(TC.name, EVENT_ADD_ON_LOADED, OnAddonLoaded)
